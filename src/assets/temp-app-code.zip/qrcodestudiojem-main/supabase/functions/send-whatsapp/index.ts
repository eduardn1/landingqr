import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// WaSender API configuration
const WASENDER_API_URL = 'https://www.wasenderapi.com/api/send-message';

interface SendMessageRequest {
  phone: string;
  message?: string;
  templateKey?: string;
  variables?: Record<string, string>;
  recipientName?: string;
  reservationId?: string;
  broadcastId?: string;
}

function cleanPhoneNumber(phone: string): string {
  let cleanPhone = phone.replace(/[^0-9+]/g, '');
  
  if (!cleanPhone.startsWith('+')) {
    if (cleanPhone.startsWith('00')) {
      cleanPhone = '+' + cleanPhone.substring(2);
    } else {
      cleanPhone = '+39' + cleanPhone;
    }
  }
  
  return cleanPhone;
}

// Sleep function for delay
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function sendWhatsAppMessage(
  phone: string, 
  message: string, 
  apiKey: string,
  maxRetries: number = 4
): Promise<{ success: boolean; error?: string; msgId?: string }> {
  const cleanPhone = cleanPhoneNumber(phone);
  
  // Base wait time for rate limiting (WaSender allows 1 message per 5 seconds)
  const BASE_WAIT_MS = 6000;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`Sending WhatsApp message to ${cleanPhone} (attempt ${attempt}/${maxRetries})`);

      const response = await fetch(WASENDER_API_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: cleanPhone,
          text: message,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('WaSender API error:', data);
        
        // Check if it's a rate limit error
        const isRateLimited = data.retry_after !== undefined || 
          data.message?.includes('protection') || 
          data.message?.includes('5 seconds') ||
          data.message?.includes('rate');
        
        if (isRateLimited && attempt < maxRetries) {
          // Use exponential backoff with minimum of 6 seconds
          const retryAfter = data.retry_after || 6;
          const backoffMultiplier = Math.pow(1.5, attempt - 1);
          const waitTime = Math.max(retryAfter * 1000, BASE_WAIT_MS) * backoffMultiplier;
          
          console.log(`Rate limited. Waiting ${Math.round(waitTime)}ms before retry (attempt ${attempt + 1})...`);
          await sleep(waitTime);
          continue;
        }
        
        return { success: false, error: data.message || 'Failed to send message' };
      }

      console.log('WaSender API response:', data);
      return { success: true, msgId: data.data?.msgId };
    } catch (error) {
      console.error(`Error sending WhatsApp message (attempt ${attempt}):`, error);
      
      if (attempt < maxRetries) {
        // Exponential backoff for network errors too
        const waitTime = BASE_WAIT_MS * Math.pow(1.5, attempt - 1);
        console.log(`Network error. Waiting ${Math.round(waitTime)}ms before retry...`);
        await sleep(waitTime);
        continue;
      }
      
      return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
    }
  }
  
  return { success: false, error: 'Max retries exceeded' };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const wasenderApiKey = Deno.env.get('WASENDER_API_KEY');
    
    if (!wasenderApiKey) {
      console.error('WASENDER_API_KEY not configured');
      return new Response(
        JSON.stringify({ success: false, error: 'WASENDER_API_KEY not configured' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500
        }
      );
    }

    const body: SendMessageRequest = await req.json();
    const { phone, message, templateKey, variables, recipientName, reservationId, broadcastId } = body;

    if (!phone) {
      return new Response(
        JSON.stringify({ success: false, error: 'Phone number is required' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400
        }
      );
    }

    let finalMessage = message || '';

    // If templateKey is provided, fetch template from database
    if (templateKey && !message) {
      const { data: templateData } = await supabase
        .from('whatsapp_templates')
        .select('message_template')
        .eq('template_key', templateKey)
        .eq('is_active', true)
        .maybeSingle();

      if (!templateData) {
        // Log failed attempt
        await supabase.from('whatsapp_message_logs').insert({
          recipient_phone: cleanPhoneNumber(phone),
          recipient_name: recipientName,
          message_content: `Template not found: ${templateKey}`,
          template_key: templateKey,
          status: 'failed',
          error_message: `Template '${templateKey}' not found or inactive`,
          reservation_id: reservationId,
          broadcast_id: broadcastId,
        });

        return new Response(
          JSON.stringify({ success: false, error: `Template '${templateKey}' not found or inactive` }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 404
          }
        );
      }

      finalMessage = templateData.message_template;

      // Replace variables in template
      if (variables) {
        for (const [key, value] of Object.entries(variables)) {
          finalMessage = finalMessage.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value || '');
        }
      }
    }

    if (!finalMessage) {
      return new Response(
        JSON.stringify({ success: false, error: 'Message or templateKey is required' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400
        }
      );
    }

    // Create log entry before sending
    const cleanPhone = cleanPhoneNumber(phone);
    const { data: logEntry } = await supabase
      .from('whatsapp_message_logs')
      .insert({
        recipient_phone: cleanPhone,
        recipient_name: recipientName,
        message_content: finalMessage,
        template_key: templateKey,
        status: 'pending',
        reservation_id: reservationId,
        broadcast_id: broadcastId,
      })
      .select('id')
      .single();

    // Send the WhatsApp message with retry logic
    const result = await sendWhatsAppMessage(phone, finalMessage, wasenderApiKey, 3);

    // Update log entry with result
    if (logEntry?.id) {
      await supabase
        .from('whatsapp_message_logs')
        .update({
          status: result.success ? 'sent' : 'failed',
          error_message: result.error,
          msg_id: result.msgId,
          sent_at: result.success ? new Date().toISOString() : null,
        })
        .eq('id', logEntry.id);
    }

    if (result.success) {
      return new Response(
        JSON.stringify({
          success: true,
          message: 'WhatsApp message sent successfully',
          msgId: result.msgId,
          logId: logEntry?.id
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200
        }
      );
    } else {
      return new Response(
        JSON.stringify({
          success: false,
          error: result.error,
          logId: logEntry?.id
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500
        }
      );
    }

  } catch (error: unknown) {
    console.error('Error in send-whatsapp:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    );
  }
});
