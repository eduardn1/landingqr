import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// WaSender API configuration
const WASENDER_API_URL = 'https://www.wasenderapi.com/api/send-message';

async function sendWhatsAppMessage(phone: string, message: string, apiKey: string): Promise<{ success: boolean; error?: string; msgId?: string }> {
  try {
    // Clean phone number - remove spaces, dashes, and ensure proper format
    let cleanPhone = phone.replace(/[^0-9+]/g, '');
    
    // Ensure phone starts with + or add it
    if (!cleanPhone.startsWith('+')) {
      // If it starts with 00, replace with +
      if (cleanPhone.startsWith('00')) {
        cleanPhone = '+' + cleanPhone.substring(2);
      } else {
        // Assume Italian number if no country code
        cleanPhone = '+39' + cleanPhone;
      }
    }

    console.log(`Sending WhatsApp message to ${cleanPhone}`);

    const response = await fetch(WASENDER_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to: cleanPhone,
        text: message,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('WaSender API error:', data);
      return { success: false, error: data.message || 'Failed to send message' };
    }

    console.log('WaSender API response:', data);
    return { success: true, msgId: data.data?.msgId };
  } catch (error) {
    console.error('Error sending WhatsApp message:', error);
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const wasenderApiKey = Deno.env.get('WASENDER_API_KEY');
    
    if (!wasenderApiKey) {
      console.error('WASENDER_API_KEY not configured');
      return new Response(
        JSON.stringify({ success: false, error: 'WASENDER_API_KEY not configured' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 500
        }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get restaurant config for name
    const { data: config } = await supabase
      .from('restaurant_config')
      .select('name, whatsapp')
      .maybeSingle();

    const localeName = config?.name || 'Il Locale';

    // Get reminder template
    const { data: templateData } = await supabase
      .from('whatsapp_templates')
      .select('message_template')
      .eq('template_key', 'reservation_reminder')
      .eq('is_active', true)
      .maybeSingle();

    // Find reservations that are 24 hours from now (with 30 min window)
    const now = new Date();
    const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const targetDate = tomorrow.toISOString().split('T')[0];
    
    // Get confirmed reservations for tomorrow that haven't had reminders sent
    const { data: reservations, error: fetchError } = await supabase
      .from('reservations')
      .select('*')
      .eq('status', 'confirmed')
      .eq('reservation_date', targetDate)
      .eq('reminder_sent', false);

    if (fetchError) {
      console.error('Error fetching reservations:', fetchError);
      throw fetchError;
    }

    console.log(`Found ${reservations?.length || 0} reservations for ${targetDate} that need reminders`);

    const remindersToSend: Array<{
      id: string;
      phone: string;
      name: string;
      date: string;
      time: string;
      guests: number;
    }> = [];

    for (const reservation of reservations || []) {
      // Parse reservation time and check if it's within our window
      const [hours, minutes] = reservation.reservation_time.split(':').map(Number);
      const reservationDateTime = new Date(reservation.reservation_date);
      reservationDateTime.setHours(hours, minutes, 0, 0);

      const timeDiff = reservationDateTime.getTime() - now.getTime();
      const hoursUntilReservation = timeDiff / (1000 * 60 * 60);

      // Send reminder if reservation is between 23 and 25 hours away
      if (hoursUntilReservation >= 23 && hoursUntilReservation <= 25) {
        remindersToSend.push({
          id: reservation.id,
          phone: reservation.phone,
          name: reservation.name,
          date: reservation.reservation_date,
          time: reservation.reservation_time,
          guests: reservation.guests
        });
      }
    }

    console.log(`Sending ${remindersToSend.length} WhatsApp reminders via WaSender API`);

    // Send WhatsApp messages via WaSender API
    const results = [];
    for (let i = 0; i < remindersToSend.length; i++) {
      const reminder = remindersToSend[i];
      const formattedDate = new Date(reminder.date).toLocaleDateString('it-IT', {
        weekday: 'long',
        day: 'numeric',
        month: 'long'
      });

      // Use template if available, otherwise use default message
      let message: string;
      if (templateData?.message_template) {
        message = templateData.message_template
          .replace(/\{\{name\}\}/g, reminder.name)
          .replace(/\{\{date\}\}/g, formattedDate)
          .replace(/\{\{time\}\}/g, reminder.time)
          .replace(/\{\{guests\}\}/g, String(reminder.guests))
          .replace(/\{\{guests_label\}\}/g, reminder.guests === 1 ? 'persona' : 'persone')
          .replace(/\{\{locale_name\}\}/g, localeName);
      } else {
        message = `🔔 *Promemoria Prenotazione*\n\nCiao ${reminder.name}!\nTi ricordiamo la tua prenotazione per domani:\n\n📅 ${formattedDate}\n🕐 ${reminder.time}\n👥 ${reminder.guests} ${reminder.guests === 1 ? 'persona' : 'persone'}\n\nPresso: ${localeName}\n\nTi aspettiamo! 🍽️\n\n_Per modifiche o cancellazioni, contattaci._`;
      }

      // Send message via WaSender API
      const sendResult = await sendWhatsAppMessage(reminder.phone, message, wasenderApiKey);

      if (sendResult.success) {
        // Mark reminder as sent
        const { error: updateError } = await supabase
          .from('reservations')
          .update({ reminder_sent: true })
          .eq('id', reminder.id);

        if (updateError) {
          console.error(`Error updating reminder status for ${reminder.id}:`, updateError);
        }

        results.push({
          id: reminder.id,
          name: reminder.name,
          phone: reminder.phone,
          status: 'sent',
          msgId: sendResult.msgId
        });
      } else {
        results.push({
          id: reminder.id,
          name: reminder.name,
          phone: reminder.phone,
          status: 'failed',
          error: sendResult.error
        });
      }

      // 5-6 second delay between messages to respect WaSender API rate limits
      if (i < remindersToSend.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 5500));
      }
    }

    const successCount = results.filter(r => r.status === 'sent').length;
    const failedCount = results.filter(r => r.status === 'failed').length;

    return new Response(
      JSON.stringify({
        success: true,
        message: `Sent ${successCount} WhatsApp reminders, ${failedCount} failed`,
        reminders: results
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200
      }
    );

  } catch (error: unknown) {
    console.error('Error in send-reservation-reminders:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    );
  }
});
