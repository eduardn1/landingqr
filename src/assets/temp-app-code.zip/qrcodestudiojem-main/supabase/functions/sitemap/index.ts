import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Generating sitemap.xml...');

    // Fetch SEO settings for indexable pages only
    const { data: seoSettings, error } = await supabase
      .from('seo_settings')
      .select('page_slug, priority, change_frequency, robots, is_active, canonical_url')
      .eq('is_active', true);

    if (error) {
      console.error('Error fetching SEO settings:', error);
      throw error;
    }

    // Get base URL from query parameter (required for correct domain)
    const url = new URL(req.url);
    const baseUrl = url.searchParams.get('domain') || 'https://demo2.studiojem.it';
    
    console.log(`Base URL: ${baseUrl}`);
    console.log(`Found ${seoSettings?.length || 0} SEO entries`);

    // Filter only pages that should be indexed (robots contains 'index')
    const indexablePages = (seoSettings || []).filter(page => 
      page.robots?.includes('index') && page.is_active
    );

    console.log(`Indexable pages: ${indexablePages.length}`);

    // Map page slugs to actual URLs
    const getPageUrl = (slug: string): string => {
      switch (slug) {
        case 'home':
          return '';
        case 'menu':
          return '/menu';
        case 'takeaway':
          return '/takeaway';
        default:
          return `/${slug}`;
      }
    };

    // Generate XML
    const today = new Date().toISOString().split('T')[0];
    
    const urlEntries = indexablePages.map(page => {
      const pageUrl = getPageUrl(page.page_slug);
      const priority = page.priority || 0.5;
      const changefreq = page.change_frequency || 'weekly';
      const fullUrl = `${baseUrl}${pageUrl}`;
      
      return `  <url>
    <loc>${fullUrl}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${changefreq}</changefreq>
    <priority>${priority.toFixed(1)}</priority>
  </url>`;
    }).join('\n');

    const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urlEntries}
</urlset>`;

    console.log('Sitemap generated successfully');

    return new Response(sitemap, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/xml; charset=utf-8',
        'Cache-Control': 'public, max-age=3600',
      },
    });

  } catch (error) {
    console.error('Error generating sitemap:', error);
    return new Response(
      JSON.stringify({ error: 'Failed to generate sitemap' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});