import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Generate a 6-digit code
function generateToken(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const { action, phone, token, newPassword } = await req.json();

    if (action === 'request') {
      // Request password reset
      if (!phone) {
        return new Response(
          JSON.stringify({ success: false, error: 'Numero di telefono richiesto' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      // Clean phone number
      let cleanPhone = phone.replace(/[^0-9+]/g, '');
      if (!cleanPhone.startsWith('+')) {
        if (cleanPhone.startsWith('00')) {
          cleanPhone = '+' + cleanPhone.substring(2);
        } else {
          cleanPhone = '+39' + cleanPhone;
        }
      }

      // Find user by phone
      const phoneEmail = `${phone.replace(/[^0-9]/g, '')}@phone.local`;
      const { data: users, error: userError } = await supabase.auth.admin.listUsers();
      
      if (userError) {
        console.error('Error listing users:', userError);
        return new Response(
          JSON.stringify({ success: false, error: 'Errore nel sistema' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
        );
      }

      const user = users.users.find(u => u.email === phoneEmail);
      
      if (!user) {
        console.log('User not found for phone:', phone);
        return new Response(
          JSON.stringify({ success: false, error: 'Nessun account trovato con questo numero di telefono. Registrati prima.' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 404 }
        );
      }

      // Generate token
      const resetToken = generateToken();
      const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

      // Delete any existing tokens for this user
      await supabase
        .from('password_reset_tokens')
        .delete()
        .eq('user_id', user.id);

      // Insert new token
      const { error: insertError } = await supabase
        .from('password_reset_tokens')
        .insert({
          user_id: user.id,
          token: resetToken,
          phone: cleanPhone,
          expires_at: expiresAt.toISOString(),
        });

      if (insertError) {
        console.error('Error inserting token:', insertError);
        return new Response(
          JSON.stringify({ success: false, error: 'Errore nel creare il token' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
        );
      }

      // Get user name from profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('display_name')
        .eq('user_id', user.id)
        .maybeSingle();

      const userName = profile?.display_name || 'Utente';

      // Send WhatsApp message
      const wasenderApiKey = Deno.env.get('WASENDER_API_KEY');
      if (wasenderApiKey) {
        // Get template
        const { data: template } = await supabase
          .from('whatsapp_templates')
          .select('message_template')
          .eq('template_key', 'password_reset')
          .eq('is_active', true)
          .maybeSingle();

        if (template) {
          let message = template.message_template
            .replace(/\{\{name\}\}/g, userName)
            .replace(/\{\{token\}\}/g, resetToken);

          // Send message
          const response = await fetch('https://www.wasenderapi.com/api/send-message', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${wasenderApiKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              to: cleanPhone,
              text: message,
            }),
          });

          if (!response.ok) {
            console.error('Failed to send WhatsApp:', await response.text());
          }
        }
      }

      // Also send to restaurant owner
      const { data: config } = await supabase
        .from('restaurant_config')
        .select('phone')
        .maybeSingle();

      if (config?.phone && wasenderApiKey) {
        let ownerPhone = config.phone.replace(/[^0-9+]/g, '');
        if (!ownerPhone.startsWith('+')) {
          ownerPhone = '+39' + ownerPhone;
        }

        const ownerMessage = `🔐 *Richiesta Reset Password*

L'utente ${userName} (${cleanPhone}) ha richiesto il reset della password.

Codice inviato: ${resetToken}

Se non riconosci questa richiesta, contatta l'utente.`;

        await fetch('https://www.wasenderapi.com/api/send-message', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${wasenderApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            to: ownerPhone,
            text: ownerMessage,
          }),
        });
      }

      return new Response(
        JSON.stringify({ success: true, message: 'Codice inviato via WhatsApp' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );

    } else if (action === 'verify') {
      // Verify token and reset password
      if (!phone || !token || !newPassword) {
        return new Response(
          JSON.stringify({ success: false, error: 'Dati mancanti' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      if (newPassword.length < 6) {
        return new Response(
          JSON.stringify({ success: false, error: 'La password deve avere almeno 6 caratteri' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      // Clean phone
      let cleanPhone = phone.replace(/[^0-9+]/g, '');
      if (!cleanPhone.startsWith('+')) {
        if (cleanPhone.startsWith('00')) {
          cleanPhone = '+' + cleanPhone.substring(2);
        } else {
          cleanPhone = '+39' + cleanPhone;
        }
      }

      // Find valid token
      const { data: tokenData, error: tokenError } = await supabase
        .from('password_reset_tokens')
        .select('*')
        .eq('token', token)
        .eq('phone', cleanPhone)
        .is('used_at', null)
        .gt('expires_at', new Date().toISOString())
        .maybeSingle();

      if (tokenError || !tokenData) {
        return new Response(
          JSON.stringify({ success: false, error: 'Codice non valido o scaduto' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      // Update user password
      const { error: updateError } = await supabase.auth.admin.updateUserById(
        tokenData.user_id,
        { password: newPassword }
      );

      if (updateError) {
        console.error('Error updating password:', updateError);
        return new Response(
          JSON.stringify({ success: false, error: 'Errore nell\'aggiornare la password' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
        );
      }

      // Mark token as used
      await supabase
        .from('password_reset_tokens')
        .update({ used_at: new Date().toISOString() })
        .eq('id', tokenData.id);

      return new Response(
        JSON.stringify({ success: true, message: 'Password aggiornata con successo' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );

    } else {
      return new Response(
        JSON.stringify({ success: false, error: 'Azione non valida' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

  } catch (error: unknown) {
    console.error('Error in password-reset:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});