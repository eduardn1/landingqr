import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { user_id, title, body, type, action_url, metadata, driver_id } = await req.json();

    // Support both user notifications and driver notifications
    const targetUserId = user_id;
    const targetDriverId = driver_id;

    if (!title || !body) {
      console.error('Missing required fields: title or body');
      return new Response(JSON.stringify({ error: 'title and body are required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!targetUserId && !targetDriverId) {
      console.error('Missing target: user_id or driver_id');
      return new Response(JSON.stringify({ error: 'user_id or driver_id is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Processing notification: "${title}" to ${targetUserId ? 'user ' + targetUserId : 'driver ' + targetDriverId}`);

    // For user notifications
    if (targetUserId) {
      // Check if user has push notifications enabled
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('push_notifications')
        .eq('user_id', targetUserId)
        .maybeSingle();

      if (profileError) {
        console.error('Error fetching profile:', profileError);
      }

      if (!profile?.push_notifications) {
        console.log('User has push notifications disabled or profile not found');
        return new Response(JSON.stringify({ success: false, reason: 'notifications_disabled' }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Insert notification into database - this triggers realtime for in-app notifications
      const { error: insertError } = await supabase
        .from('notifications')
        .insert({
          user_id: targetUserId,
          title,
          body,
          type: type || 'info',
          action_url,
          metadata,
          is_read: false,
        });

      if (insertError) {
        console.error('Error inserting notification:', insertError);
        throw insertError;
      }

      console.log(`Notification stored in database for user ${targetUserId}`);

      // Get user's push subscriptions for browser notifications
      const { data: subscriptions, error: subError } = await supabase
        .from('push_subscriptions')
        .select('*')
        .eq('user_id', targetUserId);

      if (subError) {
        console.error('Error fetching subscriptions:', subError);
      }

      if (subscriptions && subscriptions.length > 0) {
        console.log(`Found ${subscriptions.length} push subscription(s) for user`);
        
        // For now, we rely on the browser's native Notification API
        // The client subscribes to realtime changes on the notifications table
        // and shows browser notifications when new ones arrive
      } else {
        console.log('No push subscriptions found for user');
      }
    }

    // For driver notifications - store in a way drivers can poll/receive
    if (targetDriverId) {
      console.log(`Driver notification for ${targetDriverId}: ${title} - ${body}`);
      
      // We could store driver notifications in a separate table
      // For now, drivers get updates via realtime subscription on takeaway_orders
    }

    console.log('Notification processing completed successfully');

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error sending push notification:', errMsg);
    return new Response(JSON.stringify({ error: errMsg }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});