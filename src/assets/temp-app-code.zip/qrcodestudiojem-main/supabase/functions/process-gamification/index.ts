import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { user_id, action_type, reservation_id, order_id } = await req.json();

    if (!user_id) {
      return new Response(JSON.stringify({ error: 'user_id required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Processing gamification for user ${user_id}, action: ${action_type}`);

    // Check profile completion for profile_completed badge
    const { data: profileData } = await supabase
      .from('profiles')
      .select('display_name, address, city, zip_code, phone')
      .eq('user_id', user_id)
      .maybeSingle();
    
    const isProfileComplete = profileData && 
      profileData.display_name && 
      profileData.address && 
      profileData.city && 
      profileData.zip_code && 
      profileData.phone;

    const results: any = { badges_awarded: [], streak_updated: false, xp_added: 0 };

    // Get user's reservation count
    const { count: reservationCount } = await supabase
      .from('reservations')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user_id)
      .in('status', ['confirmed', 'completed']);

    // Get user's takeaway order count
    const { count: orderCount } = await supabase
      .from('takeaway_orders')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user_id)
      .eq('status', 'completed');

    // Get total order amount for user
    const { data: orderTotals } = await supabase
      .from('takeaway_orders')
      .select('total')
      .eq('user_id', user_id)
      .eq('status', 'completed');
    
    const totalSpent = orderTotals?.reduce((sum, o) => sum + (o.total || 0), 0) || 0;

    console.log(`User has ${reservationCount} reservations, ${orderCount} takeaway orders, €${totalSpent} spent`);

    // Get all badges the user doesn't have yet
    const { data: allBadges } = await supabase
      .from('loyalty_badges')
      .select('*')
      .eq('is_active', true);

    const { data: userBadges } = await supabase
      .from('user_badges')
      .select('badge_id')
      .eq('user_id', user_id);

    const earnedBadgeIds = new Set(userBadges?.map(ub => ub.badge_id) || []);

    // Check which badges user should earn
    for (const badge of allBadges || []) {
      if (earnedBadgeIds.has(badge.id)) continue;

      let shouldAward = false;

      switch (badge.requirement_type) {
        case 'reservations_count':
          shouldAward = (reservationCount || 0) >= badge.requirement_value;
          break;
        case 'orders_count':
          shouldAward = (orderCount || 0) >= badge.requirement_value;
          break;
        case 'total_orders':
          // Combined reservations + orders
          shouldAward = ((reservationCount || 0) + (orderCount || 0)) >= badge.requirement_value;
          break;
        case 'total_spent':
          shouldAward = totalSpent >= badge.requirement_value;
          break;
        case 'consecutive_weeks':
          const { data: streak } = await supabase
            .from('loyalty_streaks')
            .select('current_streak')
            .eq('user_id', user_id)
            .single();
          shouldAward = (streak?.current_streak || 0) >= badge.requirement_value;
          break;
        case 'favorites_count':
          const { count: favCount } = await supabase
            .from('favorites')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user_id);
          shouldAward = (favCount || 0) >= badge.requirement_value;
          break;
        case 'profile_complete':
          shouldAward = isProfileComplete === true;
          break;
      }

      if (shouldAward) {
        const { error: badgeError } = await supabase
          .from('user_badges')
          .insert({
            user_id,
            badge_id: badge.id,
            is_new: true,
          });

        if (!badgeError) {
          results.badges_awarded.push(badge.badge_key);
          results.xp_added += badge.points_reward || 0;
          console.log(`Awarded badge: ${badge.badge_key}`);

          if (badge.points_reward > 0) {
            await supabase.from('loyalty_transactions').insert({
              user_id,
              points: badge.points_reward,
              transaction_type: 'badge_reward',
              description: `Badge earned: ${badge.name_it}`,
            });
          }

          await supabase.from('notifications').insert({
            user_id,
            title: `🏆 Nuovo badge sbloccato!`,
            body: `Hai ottenuto il badge "${badge.name_it}"! +${badge.points_reward || 0} punti`,
            type: 'loyalty',
            action_url: '/profile',
            metadata: { badge_id: badge.id, badge_key: badge.badge_key },
          });
        }
      }
    }

    // Update streak for reservation or order actions
    const streakActions = ['reservation_completed', 'reservation_confirmed', 'order_completed'];
    if (streakActions.includes(action_type)) {
      const today = new Date().toISOString().split('T')[0];
      const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

      let { data: streakData } = await supabase
        .from('loyalty_streaks')
        .select('*')
        .eq('user_id', user_id)
        .single();

      if (!streakData) {
        const { data: newStreak } = await supabase
          .from('loyalty_streaks')
          .insert({
            user_id,
            current_streak: 1,
            longest_streak: 1,
            last_activity_date: today,
            streak_type: 'weekly',
          })
          .select()
          .single();
        streakData = newStreak;
        results.streak_updated = true;
      } else {
        const lastActivity = streakData.last_activity_date;
        
        if (lastActivity !== today) {
          let newStreak = streakData.current_streak;
          
          if (lastActivity && lastActivity >= oneWeekAgo) {
            newStreak += 1;
          } else {
            newStreak = 1;
          }

          const longestStreak = Math.max(streakData.longest_streak, newStreak);

          await supabase
            .from('loyalty_streaks')
            .update({
              current_streak: newStreak,
              longest_streak: longestStreak,
              last_activity_date: today,
            })
            .eq('user_id', user_id);

          results.streak_updated = true;
          console.log(`Updated streak to ${newStreak}`);
        }
      }
    }

    // Award points for completed orders
    if (action_type === 'order_completed' && order_id) {
      const { data: orderData } = await supabase
        .from('takeaway_orders')
        .select('total, loyalty_points_earned')
        .eq('id', order_id)
        .single();

      if (orderData && !orderData.loyalty_points_earned) {
        // Award 1 point per €1 spent
        const pointsToAward = Math.floor(orderData.total);
        
        if (pointsToAward > 0) {
          await supabase.from('loyalty_transactions').insert({
            user_id,
            points: pointsToAward,
            transaction_type: 'order_points',
            description: `Punti per ordine asporto`,
            takeaway_order_id: order_id,
          });

          // Mark order as points awarded
          await supabase
            .from('takeaway_orders')
            .update({ loyalty_points_earned: pointsToAward })
            .eq('id', order_id);

          results.xp_added += pointsToAward;
          console.log(`Awarded ${pointsToAward} points for order`);
        }
      }
    }

    // Update user XP and level
    if (results.xp_added > 0) {
      let { data: pointsData } = await supabase
        .from('loyalty_points')
        .select('*')
        .eq('user_id', user_id)
        .single();

      if (!pointsData) {
        // Create loyalty_points record for user
        const { data: newPoints } = await supabase
          .from('loyalty_points')
          .insert({
            user_id,
            total_points: 0,
            lifetime_points: 0,
            xp_current: 0,
            xp_to_next_level: 100,
            level: 1,
            tier: 'bronze',
          })
          .select()
          .single();
        pointsData = newPoints;
      }

      if (pointsData) {
        let newXp = (pointsData.xp_current || 0) + results.xp_added;
        let newLevel = pointsData.level || 1;
        let xpToNext = pointsData.xp_to_next_level || 100;

        while (newXp >= xpToNext) {
          newXp -= xpToNext;
          newLevel += 1;
          xpToNext = Math.floor(xpToNext * 1.5);
        }

        await supabase
          .from('loyalty_points')
          .update({
            xp_current: newXp,
            xp_to_next_level: xpToNext,
            level: newLevel,
            total_points: (pointsData.total_points || 0) + results.xp_added,
            lifetime_points: (pointsData.lifetime_points || 0) + results.xp_added,
          })
          .eq('user_id', user_id);
      }
    }

    // Update challenge progress
    const { data: challenges } = await supabase
      .from('loyalty_challenges')
      .select('*')
      .eq('is_active', true);

    for (const challenge of challenges || []) {
      let { data: userChallenge } = await supabase
        .from('user_challenges')
        .select('*')
        .eq('user_id', user_id)
        .eq('challenge_id', challenge.id)
        .single();

      if (!userChallenge) {
        const { data: newUc } = await supabase
          .from('user_challenges')
          .insert({
            user_id,
            challenge_id: challenge.id,
            current_progress: 0,
          })
          .select()
          .single();
        userChallenge = newUc;
      }

      if (userChallenge && !userChallenge.is_completed) {
        let newProgress = userChallenge.current_progress;

        switch (challenge.requirement_type) {
          case 'reservations_count':
            newProgress = reservationCount || 0;
            break;
          case 'orders_count':
            newProgress = orderCount || 0;
            break;
          case 'total_orders':
            newProgress = (reservationCount || 0) + (orderCount || 0);
            break;
          case 'total_spent':
            newProgress = totalSpent;
            break;
        }

        const isCompleted = newProgress >= challenge.requirement_value;

        await supabase
          .from('user_challenges')
          .update({
            current_progress: newProgress,
            is_completed: isCompleted,
            completed_at: isCompleted ? new Date().toISOString() : null,
          })
          .eq('id', userChallenge.id);

        if (isCompleted && !userChallenge.is_completed) {
          await supabase.from('loyalty_transactions').insert({
            user_id,
            points: challenge.points_reward,
            transaction_type: 'challenge_reward',
            description: `Challenge completed: ${challenge.name_it}`,
          });

          await supabase.from('notifications').insert({
            user_id,
            title: `🎯 Sfida completata!`,
            body: `Hai completato la sfida "${challenge.name_it}"! +${challenge.points_reward} punti`,
            type: 'loyalty',
            action_url: '/profile',
            metadata: { challenge_id: challenge.id, challenge_key: challenge.challenge_key },
          });
        }
      }
    }

    console.log('Gamification processing complete:', results);

    return new Response(JSON.stringify({ success: true, ...results }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    const errMsg = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error processing gamification:', errMsg);
    return new Response(JSON.stringify({ error: errMsg }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
