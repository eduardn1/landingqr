-- Add placeholder configuration columns to restaurant_config
ALTER TABLE public.restaurant_config
ADD COLUMN IF NOT EXISTS placeholder_type text DEFAULT 'gradient',
ADD COLUMN IF NOT EXISTS placeholder_emoji text DEFAULT '🍽️',
ADD COLUMN IF NOT EXISTS placeholder_gradient text DEFAULT 'from-secondary/60 via-secondary/40 to-secondary/20',
ADD COLUMN IF NOT EXISTS placeholder_image text DEFAULT NULL;