-- Add RLS policies for admin to manage dishes and categories
CREATE POLICY "Admins can insert dishes" 
ON public.dishes 
FOR INSERT 
WITH CHECK (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can update dishes" 
ON public.dishes 
FOR UPDATE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can delete dishes" 
ON public.dishes 
FOR DELETE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can insert categories" 
ON public.categories 
FOR INSERT 
WITH CHECK (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can update categories" 
ON public.categories 
FOR UPDATE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can delete categories" 
ON public.categories 
FOR DELETE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));