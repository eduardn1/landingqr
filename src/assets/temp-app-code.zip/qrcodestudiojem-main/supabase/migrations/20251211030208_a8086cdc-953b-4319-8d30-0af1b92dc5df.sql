-- Create admin_users table to track who can access admin
CREATE TABLE IF NOT EXISTS public.admin_users (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL UNIQUE,
  role text NOT NULL DEFAULT 'admin',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- Policy: Admins can view admin_users list
CREATE POLICY "Admins can view admin users" 
ON public.admin_users 
FOR SELECT 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

-- Add RLS policies for admin operations on config tables
-- Allow admins to update restaurant_config
CREATE POLICY "Admins can update restaurant config" 
ON public.restaurant_config 
FOR UPDATE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

-- Allow admins to manage onboarding_steps
CREATE POLICY "Admins can insert onboarding steps" 
ON public.onboarding_steps 
FOR INSERT 
WITH CHECK (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can update onboarding steps" 
ON public.onboarding_steps 
FOR UPDATE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can delete onboarding steps" 
ON public.onboarding_steps 
FOR DELETE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

-- Allow admins to manage moods
CREATE POLICY "Admins can insert moods" 
ON public.moods 
FOR INSERT 
WITH CHECK (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can update moods" 
ON public.moods 
FOR UPDATE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can delete moods" 
ON public.moods 
FOR DELETE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

-- Allow admins to manage stories
CREATE POLICY "Admins can insert stories" 
ON public.stories 
FOR INSERT 
WITH CHECK (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can update stories" 
ON public.stories 
FOR UPDATE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can delete stories" 
ON public.stories 
FOR DELETE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

-- Allow admins to manage home_sections
CREATE POLICY "Admins can insert home sections" 
ON public.home_sections 
FOR INSERT 
WITH CHECK (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can update home sections" 
ON public.home_sections 
FOR UPDATE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

CREATE POLICY "Admins can delete home sections" 
ON public.home_sections 
FOR DELETE 
USING (auth.uid() IN (SELECT user_id FROM public.admin_users));

-- Timestamp trigger for admin_users
CREATE TRIGGER update_admin_users_updated_at
BEFORE UPDATE ON public.admin_users
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();