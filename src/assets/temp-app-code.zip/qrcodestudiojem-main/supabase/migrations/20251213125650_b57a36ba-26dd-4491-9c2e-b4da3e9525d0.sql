-- Add preferred_theme to profiles for theme sync
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS preferred_theme text DEFAULT 'dark';

-- Add onboarding_variant to restaurant_config to choose between interactive/quiz
ALTER TABLE public.restaurant_config 
ADD COLUMN IF NOT EXISTS onboarding_variant text DEFAULT 'interactive';

-- Create onboarding_actions table for "Cosa vorresti fare?" options
CREATE TABLE public.onboarding_actions (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  action_key text NOT NULL UNIQUE,
  icon text NOT NULL DEFAULT 'Utensils',
  label jsonb NOT NULL DEFAULT '{"it": "", "en": ""}',
  subtitle jsonb DEFAULT '{"it": "", "en": ""}',
  action_type text NOT NULL DEFAULT 'navigate',
  action_value text NOT NULL DEFAULT '/',
  display_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  gradient text DEFAULT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.onboarding_actions ENABLE ROW LEVEL SECURITY;

-- Public read access
CREATE POLICY "Anyone can read onboarding actions" 
ON public.onboarding_actions 
FOR SELECT 
USING (true);

-- Admin write access
CREATE POLICY "Admins can manage onboarding actions" 
ON public.onboarding_actions 
FOR ALL 
USING (
  EXISTS (
    SELECT 1 FROM admin_users 
    WHERE admin_users.user_id = auth.uid()
  )
);

-- Insert default onboarding actions
INSERT INTO public.onboarding_actions (action_key, icon, label, subtitle, action_type, action_value, display_order, gradient) VALUES
('view_menu', 'UtensilsCrossed', '{"it": "Sfoglia il menu", "en": "Browse menu"}', '{"it": "Scopri i nostri piatti", "en": "Discover our dishes"}', 'navigate', '/?view=menu', 1, 'from-orange-500 to-red-500'),
('order_takeaway', 'ShoppingBag', '{"it": "Ordina da asporto", "en": "Order takeaway"}', '{"it": "Ritira o ricevi a casa", "en": "Pickup or delivery"}', 'navigate', '/takeaway', 2, 'from-green-500 to-emerald-500'),
('book_table', 'Calendar', '{"it": "Prenota un tavolo", "en": "Book a table"}', '{"it": "Riserva il tuo posto", "en": "Reserve your spot"}', 'action', 'reservation', 3, 'from-blue-500 to-indigo-500'),
('view_events', 'PartyPopper', '{"it": "Eventi in programma", "en": "Upcoming events"}', '{"it": "Musica, DJ set e serate speciali", "en": "Music, DJ sets and special nights"}', 'navigate', '/?section=events', 4, 'from-purple-500 to-pink-500'),
('view_homepage', 'Home', '{"it": "Esplora tutto", "en": "Explore all"}', '{"it": "Vai alla homepage", "en": "Go to homepage"}', 'navigate', '/', 5, 'from-gray-500 to-gray-700');

-- Add comment
COMMENT ON TABLE public.onboarding_actions IS 'Configurable actions for interactive onboarding flow';
COMMENT ON COLUMN public.profiles.preferred_theme IS 'User preferred theme: light or dark';
COMMENT ON COLUMN public.restaurant_config.onboarding_variant IS 'Onboarding type: interactive or quiz';