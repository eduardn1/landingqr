-- Fix security definer view warning by recreating as SECURITY INVOKER

DROP VIEW IF EXISTS public.public_driver_profiles;

CREATE VIEW public.public_driver_profiles 
WITH (security_invoker = true) AS 
SELECT 
  id,
  name,
  emoji,
  vehicle_type,
  average_rating,
  photo_url,
  is_online,
  current_orders_count
FROM public.takeaway_drivers 
WHERE is_active = true;

-- Re-grant access
GRANT SELECT ON public.public_driver_profiles TO anon, authenticated;