-- Add takeaway_price column to dishes table
ALTER TABLE public.dishes 
ADD COLUMN IF NOT EXISTS takeaway_price numeric NULL;

-- Comment for clarity
COMMENT ON COLUMN public.dishes.takeaway_price IS 'Optional separate price for takeaway orders. If null, uses the regular price.';