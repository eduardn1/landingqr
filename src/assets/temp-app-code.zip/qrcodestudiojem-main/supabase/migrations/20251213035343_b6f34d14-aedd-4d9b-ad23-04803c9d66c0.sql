-- Add access token to drivers for secure panel access
ALTER TABLE public.takeaway_drivers 
ADD COLUMN IF NOT EXISTS access_token text UNIQUE,
ADD COLUMN IF NOT EXISTS pin_code text,
ADD COLUMN IF NOT EXISTS last_login_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS current_orders_count integer DEFAULT 0;

-- Create function to generate unique access token
CREATE OR REPLACE FUNCTION public.generate_driver_access_token()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.access_token IS NULL THEN
    NEW.access_token := encode(gen_random_bytes(16), 'hex');
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger to auto-generate access token
DROP TRIGGER IF EXISTS generate_driver_token_trigger ON public.takeaway_drivers;
CREATE TRIGGER generate_driver_token_trigger
BEFORE INSERT ON public.takeaway_drivers
FOR EACH ROW
EXECUTE FUNCTION public.generate_driver_access_token();

-- Update existing drivers with access tokens
UPDATE public.takeaway_drivers 
SET access_token = encode(gen_random_bytes(16), 'hex')
WHERE access_token IS NULL;