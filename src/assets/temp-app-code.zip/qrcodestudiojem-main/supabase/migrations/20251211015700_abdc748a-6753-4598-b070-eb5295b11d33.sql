-- Create allergens table
CREATE TABLE public.allergens (
  code TEXT PRIMARY KEY,
  name_it TEXT NOT NULL,
  name_en TEXT NOT NULL,
  icon TEXT NOT NULL,
  color TEXT NOT NULL DEFAULT '#666666'
);

-- Create categories table
CREATE TABLE public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_it TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description_it TEXT,
  description_en TEXT,
  icon TEXT NOT NULL DEFAULT '🍽️',
  image_url TEXT,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create dishes table
CREATE TABLE public.dishes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID REFERENCES public.categories(id) ON DELETE CASCADE NOT NULL,
  name_it TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description_it TEXT,
  description_en TEXT,
  ingredients_it TEXT,
  ingredients_en TEXT,
  image_url TEXT,
  price DECIMAL(10,2) NOT NULL,
  original_price DECIMAL(10,2),
  currency TEXT NOT NULL DEFAULT 'EUR',
  tags TEXT[] DEFAULT '{}',
  preparation_time INTEGER,
  spicy_level INTEGER DEFAULT 0,
  portion_size TEXT,
  is_available BOOLEAN NOT NULL DEFAULT true,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  is_seasonal BOOLEAN NOT NULL DEFAULT false,
  badge TEXT,
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create dish_allergens junction table
CREATE TABLE public.dish_allergens (
  dish_id UUID REFERENCES public.dishes(id) ON DELETE CASCADE NOT NULL,
  allergen_code TEXT REFERENCES public.allergens(code) ON DELETE CASCADE NOT NULL,
  PRIMARY KEY (dish_id, allergen_code)
);

-- Enable RLS on all tables
ALTER TABLE public.allergens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dishes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dish_allergens ENABLE ROW LEVEL SECURITY;

-- Public read access for menu tables (restaurant menu is public)
CREATE POLICY "Anyone can view allergens" ON public.allergens FOR SELECT USING (true);
CREATE POLICY "Anyone can view categories" ON public.categories FOR SELECT USING (true);
CREATE POLICY "Anyone can view dishes" ON public.dishes FOR SELECT USING (true);
CREATE POLICY "Anyone can view dish_allergens" ON public.dish_allergens FOR SELECT USING (true);

-- Create updated_at trigger for categories
CREATE TRIGGER update_categories_updated_at
  BEFORE UPDATE ON public.categories
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Create updated_at trigger for dishes
CREATE TRIGGER update_dishes_updated_at
  BEFORE UPDATE ON public.dishes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default allergens
INSERT INTO public.allergens (code, name_it, name_en, icon, color) VALUES
  ('gluten', 'Glutine', 'Gluten', '🌾', '#D4A574'),
  ('lactose', 'Lattosio', 'Lactose', '🥛', '#87CEEB'),
  ('eggs', 'Uova', 'Eggs', '🥚', '#FFD700'),
  ('fish', 'Pesce', 'Fish', '🐟', '#4169E1'),
  ('shellfish', 'Crostacei', 'Shellfish', '🦐', '#FF6B6B'),
  ('mollusks', 'Molluschi', 'Mollusks', '🦪', '#708090'),
  ('nuts', 'Frutta a guscio', 'Nuts', '🥜', '#8B4513'),
  ('peanuts', 'Arachidi', 'Peanuts', '🥜', '#CD853F'),
  ('soy', 'Soia', 'Soy', '🫘', '#90EE90'),
  ('celery', 'Sedano', 'Celery', '🥬', '#228B22'),
  ('mustard', 'Senape', 'Mustard', '🟡', '#FFD700'),
  ('sesame', 'Sesamo', 'Sesame', '⚪', '#F5DEB3'),
  ('sulphites', 'Solfiti', 'Sulphites', '🍷', '#722F37'),
  ('lupin', 'Lupini', 'Lupin', '🌿', '#9ACD32');