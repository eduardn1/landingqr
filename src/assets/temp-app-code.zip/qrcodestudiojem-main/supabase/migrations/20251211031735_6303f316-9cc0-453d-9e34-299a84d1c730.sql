-- Add RLS policies for admin to manage dish_allergens
CREATE POLICY "Admins can insert dish_allergens" 
ON public.dish_allergens 
FOR INSERT 
WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update dish_allergens" 
ON public.dish_allergens 
FOR UPDATE 
USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can delete dish_allergens" 
ON public.dish_allergens 
FOR DELETE 
USING (public.is_admin(auth.uid()));

-- Add RLS policy for admin to manage reservations
CREATE POLICY "Admins can view all reservations" 
ON public.reservations 
FOR SELECT 
USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update all reservations" 
ON public.reservations 
FOR UPDATE 
USING (public.is_admin(auth.uid()));