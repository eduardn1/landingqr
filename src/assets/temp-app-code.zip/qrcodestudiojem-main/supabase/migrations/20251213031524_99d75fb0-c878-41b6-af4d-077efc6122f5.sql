-- Add header and footer variant columns to active_template_config
ALTER TABLE active_template_config 
ADD COLUMN IF NOT EXISTS header_variant text DEFAULT 'default',
ADD COLUMN IF NOT EXISTS footer_variant text DEFAULT 'default';

-- Update current config with defaults
UPDATE active_template_config SET 
  header_variant = 'default',
  footer_variant = 'default'
WHERE header_variant IS NULL;