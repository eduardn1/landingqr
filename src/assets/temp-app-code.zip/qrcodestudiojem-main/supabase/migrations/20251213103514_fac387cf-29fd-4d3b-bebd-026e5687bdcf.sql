-- Create password reset tokens table
CREATE TABLE IF NOT EXISTS public.password_reset_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  token TEXT NOT NULL UNIQUE,
  phone TEXT NOT NULL,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  used_at TIMESTAMP WITH TIME ZONE NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.password_reset_tokens ENABLE ROW LEVEL SECURITY;

-- Only service role can manage tokens (for security)
CREATE POLICY "Service role can manage tokens"
ON public.password_reset_tokens
FOR ALL
USING (false)
WITH CHECK (false);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_token ON public.password_reset_tokens(token);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_expires ON public.password_reset_tokens(expires_at);

-- Add WhatsApp template for password reset
INSERT INTO public.whatsapp_templates (template_key, name, description, message_template, is_active)
VALUES (
  'password_reset',
  'Reset Password',
  'Inviato quando un utente richiede il reset della password',
  '🔐 *Recupero Password*

Ciao {{name}}!

Hai richiesto il reset della password.

Il tuo codice di verifica è: *{{token}}*

⚠️ Questo codice scade tra 15 minuti.

Se non hai richiesto tu il reset, ignora questo messaggio.

Grazie!',
  true
) ON CONFLICT (template_key) DO NOTHING;