-- Add size column to action_buttons for variable button sizes
ALTER TABLE public.action_buttons 
ADD COLUMN size text NOT NULL DEFAULT 'medium' CHECK (size IN ('small', 'medium', 'large'));

-- Add col_span for grid layout control on desktop
ALTER TABLE public.action_buttons 
ADD COLUMN col_span integer NOT NULL DEFAULT 1 CHECK (col_span >= 1 AND col_span <= 3);