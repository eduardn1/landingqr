-- Add max guests per slot and social integration fields to restaurant_config
ALTER TABLE public.restaurant_config 
ADD COLUMN IF NOT EXISTS max_guests_per_slot integer DEFAULT 20,
ADD COLUMN IF NOT EXISTS google_place_id text,
ADD COLUMN IF NOT EXISTS instagram_username text;

-- Create closed_dates table for holidays and special closures
CREATE TABLE IF NOT EXISTS public.closed_dates (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  date date NOT NULL,
  reason text,
  is_recurring boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on closed_dates
ALTER TABLE public.closed_dates ENABLE ROW LEVEL SECURITY;

-- RLS policies for closed_dates
CREATE POLICY "Anyone can view closed dates" ON public.closed_dates
  FOR SELECT USING (true);

CREATE POLICY "Admins can insert closed dates" ON public.closed_dates
  FOR INSERT WITH CHECK (is_admin(auth.uid()));

CREATE POLICY "Admins can update closed dates" ON public.closed_dates
  FOR UPDATE USING (is_admin(auth.uid()));

CREATE POLICY "Admins can delete closed dates" ON public.closed_dates
  FOR DELETE USING (is_admin(auth.uid()));

-- Add trigger for updated_at
CREATE TRIGGER update_closed_dates_updated_at
  BEFORE UPDATE ON public.closed_dates
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Comment for business_hours structure update (now supports multiple ranges)
-- New format: [{"day": "monday", "ranges": [{"open": "12:00", "close": "14:00"}, {"open": "17:00", "close": "23:00"}], "closed": false}]