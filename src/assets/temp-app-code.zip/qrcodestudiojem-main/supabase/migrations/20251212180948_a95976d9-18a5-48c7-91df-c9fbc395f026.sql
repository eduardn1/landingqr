-- Add event_id column to reservations table to link reservations to events
ALTER TABLE public.reservations
ADD COLUMN event_id UUID REFERENCES public.events(id) ON DELETE SET NULL;

-- Create index for event_id lookups
CREATE INDEX idx_reservations_event_id ON public.reservations(event_id);

-- Insert WhatsApp template for event reservation confirmation
INSERT INTO public.whatsapp_templates (template_key, name, description, message_template, variables, is_active)
VALUES (
  'event_reservation_received',
  'Conferma Prenotazione Evento',
  'Messaggio inviato al cliente quando prenota per un evento',
  'Ciao {{name}}! 🎉

La tua prenotazione per l''evento "{{event_name}}" è stata ricevuta!

📅 Data: {{date}}
🕐 Orario: {{time}}
👥 Ospiti: {{guests}}
🎭 Evento: {{event_name}}

Ti confermeremo a breve. A presto!',
  '["name", "date", "time", "guests", "event_name"]',
  true
),
(
  'event_reservation_confirmed',
  'Prenotazione Evento Confermata',
  'Messaggio inviato al cliente quando la prenotazione evento viene confermata',
  'Ciao {{name}}! ✅

La tua prenotazione per l''evento "{{event_name}}" è confermata!

📅 Data: {{date}}
🕐 Orario: {{time}}
👥 Ospiti: {{guests}}
🎭 Evento: {{event_name}}

Ti aspettiamo! 🎉',
  '["name", "date", "time", "guests", "event_name"]',
  true
),
(
  'new_event_reservation_owner',
  'Nuova Prenotazione Evento (Admin)',
  'Notifica al titolare di una nuova prenotazione per evento',
  '🎉 NUOVA PRENOTAZIONE EVENTO

👤 Cliente: {{name}}
📞 Tel: {{phone}}
📅 Data: {{date}}
🕐 Orario: {{time}}
👥 Ospiti: {{guests}}
🎭 Evento: {{event_name}}
📝 Note: {{notes}}

Gestisci dal pannello admin.',
  '["name", "phone", "date", "time", "guests", "event_name", "notes"]',
  true
)
ON CONFLICT (template_key) DO NOTHING;