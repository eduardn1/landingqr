-- Add driver location tracking columns
ALTER TABLE public.takeaway_drivers
ADD COLUMN IF NOT EXISTS current_lat numeric,
ADD COLUMN IF NOT EXISTS current_lng numeric,
ADD COLUMN IF NOT EXISTS location_updated_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS is_online boolean DEFAULT false;

-- Add ETA fields to takeaway_orders
ALTER TABLE public.takeaway_orders
ADD COLUMN IF NOT EXISTS estimated_delivery_at timestamp with time zone,
ADD COLUMN IF NOT EXISTS driver_lat numeric,
ADD COLUMN IF NOT EXISTS driver_lng numeric;

-- Enable realtime for takeaway_drivers to track location changes
ALTER PUBLICATION supabase_realtime ADD TABLE public.takeaway_drivers;