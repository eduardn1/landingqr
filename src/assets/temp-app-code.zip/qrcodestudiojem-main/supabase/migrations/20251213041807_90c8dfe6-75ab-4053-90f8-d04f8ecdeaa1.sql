-- Add address fields to profiles for delivery/booking sync
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS address TEXT,
ADD COLUMN IF NOT EXISTS city TEXT,
ADD COLUMN IF NOT EXISTS zip_code TEXT,
ADD COLUMN IF NOT EXISTS apartment_floor TEXT,
ADD COLUMN IF NOT EXISTS delivery_notes TEXT;