-- Add avatar_emoji column to profiles table for user personalization
ALTER TABLE public.profiles 
ADD COLUMN avatar_emoji TEXT DEFAULT '😊';