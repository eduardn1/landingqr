-- Create navigation_config table for customizable header, navbar, and language switcher
CREATE TABLE public.navigation_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Header settings
  header_logo_visible boolean NOT NULL DEFAULT true,
  header_favorites_visible boolean NOT NULL DEFAULT true,
  header_profile_visible boolean NOT NULL DEFAULT true,
  header_language_switcher_visible boolean NOT NULL DEFAULT true,
  
  -- Mobile navbar settings
  navbar_items jsonb NOT NULL DEFAULT '[
    {"key": "home", "icon": "Home", "label": {"it": "Home", "en": "Home"}, "visible": true, "order": 1},
    {"key": "menu", "icon": "UtensilsCrossed", "label": {"it": "Menu", "en": "Menu"}, "visible": true, "order": 2},
    {"key": "discover", "icon": "Sparkles", "label": {"it": "Scopri", "en": "Discover"}, "visible": true, "order": 3},
    {"key": "favorites", "icon": "Heart", "label": {"it": "Preferiti", "en": "Favorites"}, "visible": true, "order": 4},
    {"key": "profile", "icon": "User", "label": {"it": "Profilo", "en": "Profile"}, "visible": true, "order": 5}
  ]'::jsonb,
  
  -- Language switcher settings
  available_languages jsonb NOT NULL DEFAULT '[
    {"code": "it", "label": "Italiano", "flag": "🇮🇹", "visible": true},
    {"code": "en", "label": "English", "flag": "🇬🇧", "visible": true},
    {"code": "fr", "label": "Français", "flag": "🇫🇷", "visible": true},
    {"code": "de", "label": "Deutsch", "flag": "🇩🇪", "visible": true},
    {"code": "es", "label": "Español", "flag": "🇪🇸", "visible": true}
  ]'::jsonb,
  default_language text NOT NULL DEFAULT 'it',
  
  -- Desktop header menu items (optional additional links)
  header_menu_items jsonb DEFAULT '[]'::jsonb,
  
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.navigation_config ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Anyone can view navigation config"
  ON public.navigation_config
  FOR SELECT
  USING (true);

CREATE POLICY "Admins can update navigation config"
  ON public.navigation_config
  FOR UPDATE
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can insert navigation config"
  ON public.navigation_config
  FOR INSERT
  WITH CHECK (is_admin(auth.uid()));

-- Insert default config
INSERT INTO public.navigation_config (id) VALUES (gen_random_uuid());

-- Trigger for updated_at
CREATE TRIGGER update_navigation_config_updated_at
  BEFORE UPDATE ON public.navigation_config
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();