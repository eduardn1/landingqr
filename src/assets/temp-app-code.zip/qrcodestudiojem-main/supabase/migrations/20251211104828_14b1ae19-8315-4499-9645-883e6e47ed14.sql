-- Create events table
CREATE TABLE public.events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title_it TEXT NOT NULL,
  title_en TEXT,
  description_it TEXT,
  description_en TEXT,
  event_type TEXT NOT NULL DEFAULT 'live_music' CHECK (event_type IN ('dj_set', 'live_music', 'karaoke', 'aperitivo', 'degustazione', 'altro')),
  event_date DATE NOT NULL,
  start_time TEXT NOT NULL,
  end_time TEXT,
  image_url TEXT,
  entry_price NUMERIC,
  entry_price_note_it TEXT,
  entry_price_note_en TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_featured BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Anyone can view active events" ON public.events
FOR SELECT USING (is_active = true AND event_date >= CURRENT_DATE);

CREATE POLICY "Admins can manage events" ON public.events
FOR ALL USING (is_admin(auth.uid()));

-- Add alcohol_level to dishes for cocktails
ALTER TABLE public.dishes 
ADD COLUMN alcohol_level TEXT CHECK (alcohol_level IN ('analcolico', 'leggero', 'medio', 'forte'));

-- Add wine-specific fields
ALTER TABLE public.dishes 
ADD COLUMN wine_year INTEGER,
ADD COLUMN wine_region TEXT,
ADD COLUMN wine_pairing_it TEXT,
ADD COLUMN wine_pairing_en TEXT;

-- Trigger for updated_at
CREATE TRIGGER update_events_updated_at
BEFORE UPDATE ON public.events
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();