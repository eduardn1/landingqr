-- Add about us configuration fields to restaurant_config
ALTER TABLE public.restaurant_config
ADD COLUMN IF NOT EXISTS about_keywords jsonb DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS about_gallery jsonb DEFAULT '[]'::jsonb;

-- about_keywords: array of {it: string, en: string} for badges/tags
-- about_gallery: array of {url: string, caption_it: string, caption_en: string}