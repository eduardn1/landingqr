-- Add emoji field to takeaway_drivers
ALTER TABLE takeaway_drivers ADD COLUMN IF NOT EXISTS emoji TEXT DEFAULT '🚗';

-- Update Vanessa's total_deliveries based on actual completed orders
UPDATE takeaway_drivers d
SET total_deliveries = (
  SELECT COUNT(*) 
  FROM takeaway_orders o 
  WHERE o.driver_id = d.id AND o.status = 'completed'
)
WHERE total_deliveries = 0;