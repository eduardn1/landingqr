-- Add device-specific visibility columns to navigation_config
ALTER TABLE navigation_config
ADD COLUMN IF NOT EXISTS header_logo_visible_mobile boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_logo_visible_tablet boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_logo_visible_desktop boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_favorites_visible_mobile boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_favorites_visible_tablet boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_favorites_visible_desktop boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_profile_visible_mobile boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_profile_visible_tablet boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_profile_visible_desktop boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_language_visible_mobile boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS header_language_visible_tablet boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_language_visible_desktop boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_theme_visible_mobile boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_theme_visible_tablet boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_theme_visible_desktop boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_notifications_visible_mobile boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_notifications_visible_tablet boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS header_notifications_visible_desktop boolean DEFAULT true;

-- Update existing row with default values
UPDATE navigation_config SET
  header_logo_visible_mobile = COALESCE(header_logo_visible, true),
  header_logo_visible_tablet = COALESCE(header_logo_visible, true),
  header_logo_visible_desktop = COALESCE(header_logo_visible, true),
  header_favorites_visible_mobile = COALESCE(header_favorites_visible, true),
  header_favorites_visible_tablet = COALESCE(header_favorites_visible, true),
  header_favorites_visible_desktop = COALESCE(header_favorites_visible, true),
  header_profile_visible_mobile = COALESCE(header_profile_visible, true),
  header_profile_visible_tablet = COALESCE(header_profile_visible, true),
  header_profile_visible_desktop = COALESCE(header_profile_visible, true),
  header_language_visible_mobile = false,
  header_language_visible_tablet = COALESCE(header_language_switcher_visible, true),
  header_language_visible_desktop = COALESCE(header_language_switcher_visible, true),
  header_theme_visible_mobile = COALESCE(header_theme_toggle_visible, true),
  header_theme_visible_tablet = COALESCE(header_theme_toggle_visible, true),
  header_theme_visible_desktop = COALESCE(header_theme_toggle_visible, true),
  header_notifications_visible_mobile = true,
  header_notifications_visible_tablet = true,
  header_notifications_visible_desktop = true
WHERE id IS NOT NULL;