-- Add theme toggle visibility setting to navigation_config
ALTER TABLE public.navigation_config 
ADD COLUMN IF NOT EXISTS header_theme_toggle_visible boolean NOT NULL DEFAULT true;