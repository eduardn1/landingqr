-- Create promos table for promotional images/banners
CREATE TABLE public.promos (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title_it TEXT NOT NULL,
  title_en TEXT,
  description_it TEXT,
  description_en TEXT,
  image_url TEXT NOT NULL,
  link_url TEXT,
  link_type TEXT DEFAULT 'none', -- 'none', 'internal', 'external', 'whatsapp'
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  starts_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.promos ENABLE ROW LEVEL SECURITY;

-- Public can read active promos
CREATE POLICY "Anyone can view active promos"
ON public.promos FOR SELECT
USING (is_active = true AND (starts_at IS NULL OR starts_at <= now()) AND (expires_at IS NULL OR expires_at > now()));

-- Admins can manage promos
CREATE POLICY "Admins can manage promos"
ON public.promos FOR ALL
USING (public.is_admin(auth.uid()));

-- Add trigger for updated_at
CREATE TRIGGER update_promos_updated_at
  BEFORE UPDATE ON public.promos
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert a default promo section in home_sections
INSERT INTO public.home_sections (section_key, title, subtitle, display_order, is_active, config)
VALUES (
  'promos',
  '{"it": "Promozioni", "en": "Promotions"}',
  '{"it": "Offerte speciali per te", "en": "Special offers for you"}',
  2,
  true,
  '{"layout": "carousel"}'
)
ON CONFLICT (section_key) DO NOTHING;