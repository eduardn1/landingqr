-- =============================================
-- 1. WhatsApp Message Delivery Tracking
-- =============================================
CREATE TABLE public.whatsapp_message_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  recipient_phone TEXT NOT NULL,
  recipient_name TEXT,
  message_content TEXT NOT NULL,
  template_key TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, sent, failed, delivered
  error_message TEXT,
  msg_id TEXT, -- WaSender message ID
  sent_at TIMESTAMP WITH TIME ZONE,
  delivered_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  reservation_id UUID REFERENCES public.reservations(id) ON DELETE SET NULL,
  broadcast_id UUID REFERENCES public.broadcast_messages(id) ON DELETE SET NULL,
  created_by UUID
);

ALTER TABLE public.whatsapp_message_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all message logs" ON public.whatsapp_message_logs
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "Admins can insert message logs" ON public.whatsapp_message_logs
  FOR INSERT WITH CHECK (is_admin(auth.uid()));

CREATE POLICY "Service role can manage logs" ON public.whatsapp_message_logs
  FOR ALL USING (true);

CREATE INDEX idx_whatsapp_logs_phone ON public.whatsapp_message_logs(recipient_phone);
CREATE INDEX idx_whatsapp_logs_status ON public.whatsapp_message_logs(status);
CREATE INDEX idx_whatsapp_logs_created ON public.whatsapp_message_logs(created_at DESC);

-- =============================================
-- 2. Customer Loyalty Points System
-- =============================================
CREATE TABLE public.loyalty_config (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  points_per_reservation INTEGER NOT NULL DEFAULT 10,
  points_per_guest INTEGER NOT NULL DEFAULT 2,
  welcome_bonus INTEGER NOT NULL DEFAULT 50,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.loyalty_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view loyalty config" ON public.loyalty_config
  FOR SELECT USING (true);

CREATE POLICY "Admins can update loyalty config" ON public.loyalty_config
  FOR UPDATE USING (is_admin(auth.uid()));

-- Insert default config
INSERT INTO public.loyalty_config (points_per_reservation, points_per_guest, welcome_bonus) 
VALUES (10, 2, 50);

-- Loyalty rewards catalog
CREATE TABLE public.loyalty_rewards (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name_it TEXT NOT NULL,
  name_en TEXT,
  description_it TEXT,
  description_en TEXT,
  points_required INTEGER NOT NULL,
  reward_type TEXT NOT NULL DEFAULT 'discount', -- discount, free_item, experience
  reward_value TEXT, -- e.g., "10%", "free_dessert", etc.
  is_active BOOLEAN NOT NULL DEFAULT true,
  display_order INTEGER NOT NULL DEFAULT 0,
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.loyalty_rewards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active rewards" ON public.loyalty_rewards
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage rewards" ON public.loyalty_rewards
  FOR ALL USING (is_admin(auth.uid()));

-- Customer loyalty points balance
CREATE TABLE public.loyalty_points (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  total_points INTEGER NOT NULL DEFAULT 0,
  lifetime_points INTEGER NOT NULL DEFAULT 0,
  tier TEXT NOT NULL DEFAULT 'bronze', -- bronze, silver, gold, platinum
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE public.loyalty_points ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own points" ON public.loyalty_points
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all points" ON public.loyalty_points
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "System can manage points" ON public.loyalty_points
  FOR ALL USING (true);

-- Loyalty transactions history
CREATE TABLE public.loyalty_transactions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  points INTEGER NOT NULL, -- positive for earned, negative for redeemed
  transaction_type TEXT NOT NULL, -- reservation, redemption, bonus, welcome, manual
  description TEXT,
  reservation_id UUID REFERENCES public.reservations(id) ON DELETE SET NULL,
  reward_id UUID REFERENCES public.loyalty_rewards(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.loyalty_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own transactions" ON public.loyalty_transactions
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all transactions" ON public.loyalty_transactions
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "System can manage transactions" ON public.loyalty_transactions
  FOR ALL USING (true);

CREATE INDEX idx_loyalty_transactions_user ON public.loyalty_transactions(user_id);
CREATE INDEX idx_loyalty_transactions_created ON public.loyalty_transactions(created_at DESC);

-- =============================================
-- 3. Push Notifications System
-- =============================================
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info', -- info, reservation, promo, event, loyalty
  is_read BOOLEAN NOT NULL DEFAULT false,
  action_url TEXT,
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own notifications" ON public.notifications
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" ON public.notifications
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all notifications" ON public.notifications
  FOR ALL USING (is_admin(auth.uid()));

CREATE POLICY "System can create notifications" ON public.notifications
  FOR INSERT WITH CHECK (true);

CREATE INDEX idx_notifications_user ON public.notifications(user_id);
CREATE INDEX idx_notifications_unread ON public.notifications(user_id, is_read) WHERE is_read = false;
CREATE INDEX idx_notifications_created ON public.notifications(created_at DESC);

-- Push subscription tokens
CREATE TABLE public.push_subscriptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  endpoint TEXT NOT NULL,
  p256dh_key TEXT NOT NULL,
  auth_key TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, endpoint)
);

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage their own subscriptions" ON public.push_subscriptions
  FOR ALL USING (auth.uid() = user_id);

-- Enable realtime for notifications
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;

-- Trigger to update loyalty points
CREATE OR REPLACE FUNCTION public.update_loyalty_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_loyalty_points_updated_at
  BEFORE UPDATE ON public.loyalty_points
  FOR EACH ROW EXECUTE FUNCTION public.update_loyalty_updated_at();

CREATE TRIGGER update_loyalty_rewards_updated_at
  BEFORE UPDATE ON public.loyalty_rewards
  FOR EACH ROW EXECUTE FUNCTION public.update_loyalty_updated_at();

CREATE TRIGGER update_loyalty_config_updated_at
  BEFORE UPDATE ON public.loyalty_config
  FOR EACH ROW EXECUTE FUNCTION public.update_loyalty_updated_at();