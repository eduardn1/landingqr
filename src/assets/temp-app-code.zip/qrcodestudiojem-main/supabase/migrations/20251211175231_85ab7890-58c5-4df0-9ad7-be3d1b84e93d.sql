-- Add PWA configuration to restaurant_config table
ALTER TABLE public.restaurant_config
ADD COLUMN IF NOT EXISTS pwa_name TEXT DEFAULT 'Menu Digitale',
ADD COLUMN IF NOT EXISTS pwa_short_name TEXT DEFAULT 'Menu',
ADD COLUMN IF NOT EXISTS pwa_description TEXT DEFAULT 'Menu digitale con prenotazioni, preferiti e altro',
ADD COLUMN IF NOT EXISTS pwa_theme_color TEXT DEFAULT '#722F37',
ADD COLUMN IF NOT EXISTS pwa_background_color TEXT DEFAULT '#0a0a0a',
ADD COLUMN IF NOT EXISTS pwa_icon_192 TEXT,
ADD COLUMN IF NOT EXISTS pwa_icon_512 TEXT;