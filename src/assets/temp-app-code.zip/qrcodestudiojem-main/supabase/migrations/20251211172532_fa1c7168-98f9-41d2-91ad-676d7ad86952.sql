-- Add OG image field for social sharing
ALTER TABLE public.restaurant_config 
ADD COLUMN IF NOT EXISTS og_image_url text;