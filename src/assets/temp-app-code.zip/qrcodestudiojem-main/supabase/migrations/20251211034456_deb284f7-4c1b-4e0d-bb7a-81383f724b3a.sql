-- Update the handle_new_user function to properly save phone and enable notifications by default
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, phone, display_name, push_notifications, whatsapp_notifications)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'phone', NEW.phone, ''),
    COALESCE(NEW.raw_user_meta_data->>'display_name', ''),
    true,
    true
  );
  RETURN NEW;
END;
$$;

-- Update the columns to have proper defaults
ALTER TABLE public.profiles 
  ALTER COLUMN push_notifications SET DEFAULT true,
  ALTER COLUMN whatsapp_notifications SET DEFAULT true;