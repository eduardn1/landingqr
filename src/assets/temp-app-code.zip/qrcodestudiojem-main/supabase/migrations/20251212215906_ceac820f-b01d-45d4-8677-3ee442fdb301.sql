-- Add additional styling columns to action_buttons table for full editor control
ALTER TABLE public.action_buttons 
ADD COLUMN IF NOT EXISTS display_style text DEFAULT 'card',
ADD COLUMN IF NOT EXISTS bg_color text NULL,
ADD COLUMN IF NOT EXISTS bg_opacity numeric DEFAULT 1,
ADD COLUMN IF NOT EXISTS label_color text NULL,
ADD COLUMN IF NOT EXISTS icon_color text NULL,
ADD COLUMN IF NOT EXISTS border_color text NULL;

-- Comments for clarity
COMMENT ON COLUMN public.action_buttons.display_style IS 'Display type: card, button, pill, minimal';
COMMENT ON COLUMN public.action_buttons.bg_color IS 'Background color in HSL format';
COMMENT ON COLUMN public.action_buttons.bg_opacity IS 'Background opacity 0-1';
COMMENT ON COLUMN public.action_buttons.label_color IS 'Text/label color in HSL format';
COMMENT ON COLUMN public.action_buttons.icon_color IS 'Icon color in HSL format';
COMMENT ON COLUMN public.action_buttons.border_color IS 'Border color in HSL format';