-- Add RLS policies for admin to manage allergens
CREATE POLICY "Admins can insert allergens" 
ON public.allergens 
FOR INSERT 
WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update allergens" 
ON public.allergens 
FOR UPDATE 
USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can delete allergens" 
ON public.allergens 
FOR DELETE 
USING (public.is_admin(auth.uid()));