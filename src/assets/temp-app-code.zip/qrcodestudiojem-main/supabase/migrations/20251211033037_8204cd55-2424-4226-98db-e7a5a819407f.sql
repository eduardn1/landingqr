-- Create whatsapp_templates table for managing message templates
CREATE TABLE public.whatsapp_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  message_template TEXT NOT NULL,
  variables JSONB DEFAULT '[]'::jsonb,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.whatsapp_templates ENABLE ROW LEVEL SECURITY;

-- Allow public read for templates (needed by edge functions)
CREATE POLICY "Templates are viewable by everyone" 
ON public.whatsapp_templates 
FOR SELECT 
USING (true);

-- Admin can manage templates
CREATE POLICY "Admins can manage templates" 
ON public.whatsapp_templates 
FOR ALL 
USING (EXISTS (SELECT 1 FROM admin_users WHERE user_id = auth.uid()));

-- Insert default templates
INSERT INTO public.whatsapp_templates (template_key, name, description, message_template, variables) VALUES
('reservation_confirmed', 'Prenotazione Confermata', 'Messaggio inviato quando una prenotazione viene confermata', 
'✅ *Prenotazione Confermata*

Ciao {{name}}!
La tua prenotazione è stata confermata.

📅 *Data:* {{date}}
🕐 *Ora:* {{time}}
👥 *Coperti:* {{guests}}

Ti aspettiamo!
{{locale_name}}',
'["name", "date", "time", "guests", "locale_name"]'),

('reservation_rejected', 'Prenotazione Rifiutata', 'Messaggio inviato quando una prenotazione viene rifiutata',
'❌ *Prenotazione Non Disponibile*

Ciao {{name}},
Ci dispiace, non è possibile confermare la prenotazione per:

📅 {{date}} alle {{time}}

Ti invitiamo a provare un altro orario o contattarci per trovare una soluzione.

{{locale_name}}',
'["name", "date", "time", "locale_name"]'),

('reservation_reminder', 'Promemoria Prenotazione', 'Messaggio promemoria 24h prima della prenotazione',
'🔔 *Promemoria Prenotazione*

Ciao {{name}}!
Ti ricordiamo la tua prenotazione per domani:

📅 {{date}}
🕐 {{time}}
👥 {{guests}} {{guests_label}}

Presso: {{locale_name}}

Ti aspettiamo! 🍽️

_Per modifiche o cancellazioni, contattaci._',
'["name", "date", "time", "guests", "guests_label", "locale_name"]'),

('broadcast_promo', 'Promo / Offerta', 'Template per promozioni e offerte speciali',
'🎉 *{{title}}*

{{message}}

📅 Valido: {{validity}}

Ti aspettiamo!
{{locale_name}}',
'["title", "message", "validity", "locale_name"]'),

('broadcast_event', 'Evento Speciale', 'Template per eventi speciali',
'🎊 *{{title}}*

{{message}}

📅 Data: {{event_date}}
🕐 Ora: {{event_time}}

{{locale_name}}',
'["title", "message", "event_date", "event_time", "locale_name"]'),

('broadcast_news', 'Novità', 'Template per annunciare novità',
'✨ *Novità da {{locale_name}}*

{{message}}

Vieni a scoprirla!',
'["message", "locale_name"]');

-- Create broadcast_messages table for tracking sent broadcasts
CREATE TABLE public.broadcast_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_id UUID REFERENCES public.whatsapp_templates(id),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  recipients_count INTEGER DEFAULT 0,
  sent_at TIMESTAMP WITH TIME ZONE,
  status TEXT DEFAULT 'draft',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE public.broadcast_messages ENABLE ROW LEVEL SECURITY;

-- Admin can manage broadcasts
CREATE POLICY "Admins can manage broadcasts" 
ON public.broadcast_messages 
FOR ALL 
USING (EXISTS (SELECT 1 FROM admin_users WHERE user_id = auth.uid()));

-- Add trigger for updated_at on whatsapp_templates
CREATE TRIGGER update_whatsapp_templates_updated_at
BEFORE UPDATE ON public.whatsapp_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();