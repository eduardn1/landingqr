-- Add color field to action_buttons for custom button colors
ALTER TABLE public.action_buttons 
ADD COLUMN IF NOT EXISTS button_color text DEFAULT NULL;

-- Add comment for clarity
COMMENT ON COLUMN public.action_buttons.button_color IS 'Custom button background color in HSL format (e.g., "210 100% 50%") with opacity support';