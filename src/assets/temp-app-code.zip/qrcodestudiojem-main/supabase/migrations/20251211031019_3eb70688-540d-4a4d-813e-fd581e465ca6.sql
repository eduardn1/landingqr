-- Drop the recursive policy
DROP POLICY IF EXISTS "Admins can view admin users" ON public.admin_users;

-- Create a security definer function to check admin status
CREATE OR REPLACE FUNCTION public.is_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.admin_users
    WHERE user_id = _user_id
  )
$$;

-- Create new non-recursive policy - allow users to see their own admin record
CREATE POLICY "Users can view their own admin status"
ON public.admin_users
FOR SELECT
USING (auth.uid() = user_id);

-- Allow admins to view all admin users (using the security definer function)
CREATE POLICY "Admins can view all admin users"
ON public.admin_users
FOR SELECT
USING (public.is_admin(auth.uid()));