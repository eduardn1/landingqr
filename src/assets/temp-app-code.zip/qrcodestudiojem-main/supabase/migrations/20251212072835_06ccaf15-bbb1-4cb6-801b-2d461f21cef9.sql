-- Add DELETE policy for admins on reservations table
CREATE POLICY "Admins can delete reservations"
ON public.reservations
FOR DELETE
USING (is_admin(auth.uid()));

-- Add WhatsApp template for reservation modifications
INSERT INTO public.whatsapp_templates (template_key, name, description, message_template, variables, is_active)
VALUES (
  'reservation_modified',
  'Prenotazione Modificata',
  'Notifica al cliente quando l''admin modifica la sua prenotazione',
  'Ciao {{name}}! 📝

La tua prenotazione è stata modificata:

📅 Nuova data: {{date}}
🕐 Nuovo orario: {{time}}
👥 {{guests}} persone

Se hai domande, contattaci!',
  '["name", "date", "time", "guests"]',
  true
)
ON CONFLICT (template_key) DO NOTHING;