-- Fix critical security vulnerability: Driver access tokens publicly exposed

-- 1. Drop the overly permissive policy
DROP POLICY IF EXISTS "Anyone can view active drivers" ON public.takeaway_drivers;

-- 2. Create a secure public view with only safe fields
CREATE OR REPLACE VIEW public.public_driver_profiles AS 
SELECT 
  id,
  name,
  emoji,
  vehicle_type,
  average_rating,
  photo_url,
  is_online,
  current_orders_count
FROM public.takeaway_drivers 
WHERE is_active = true;

-- 3. Grant access to the view for all users
GRANT SELECT ON public.public_driver_profiles TO anon, authenticated;

-- 4. Create proper restricted policy - only admins can view full driver data
CREATE POLICY "Admins can view all driver data" 
ON public.takeaway_drivers 
FOR SELECT 
USING (is_admin(auth.uid()));

-- 5. Create policy for drivers to view their own data (for driver app)
CREATE POLICY "Drivers can view their own data" 
ON public.takeaway_drivers 
FOR SELECT 
USING (access_token IS NOT NULL AND id::text = current_setting('app.current_driver_id', true));