-- Allow first admin creation when no admins exist
CREATE POLICY "Allow first admin creation" 
ON public.admin_users 
FOR INSERT 
WITH CHECK (
  NOT EXISTS (SELECT 1 FROM public.admin_users)
);