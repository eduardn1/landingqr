-- Add column to exclude already discounted products from promo code usage
ALTER TABLE public.daily_promos 
ADD COLUMN IF NOT EXISTS exclude_discounted_items boolean DEFAULT true;

-- Add comment for clarity
COMMENT ON COLUMN public.daily_promos.exclude_discounted_items IS 'If true, promo codes cannot be applied to items with original_price (already discounted)';
