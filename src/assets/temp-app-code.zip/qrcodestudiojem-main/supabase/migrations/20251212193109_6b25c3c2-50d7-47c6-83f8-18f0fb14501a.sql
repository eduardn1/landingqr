
-- Add multilingual columns to categories
ALTER TABLE public.categories 
ADD COLUMN IF NOT EXISTS name_de text,
ADD COLUMN IF NOT EXISTS name_es text,
ADD COLUMN IF NOT EXISTS name_fr text,
ADD COLUMN IF NOT EXISTS description_de text,
ADD COLUMN IF NOT EXISTS description_es text,
ADD COLUMN IF NOT EXISTS description_fr text;

-- Add multilingual columns to dishes
ALTER TABLE public.dishes 
ADD COLUMN IF NOT EXISTS name_de text,
ADD COLUMN IF NOT EXISTS name_es text,
ADD COLUMN IF NOT EXISTS name_fr text,
ADD COLUMN IF NOT EXISTS description_de text,
ADD COLUMN IF NOT EXISTS description_es text,
ADD COLUMN IF NOT EXISTS description_fr text,
ADD COLUMN IF NOT EXISTS ingredients_de text,
ADD COLUMN IF NOT EXISTS ingredients_es text,
ADD COLUMN IF NOT EXISTS ingredients_fr text,
ADD COLUMN IF NOT EXISTS wine_pairing_de text,
ADD COLUMN IF NOT EXISTS wine_pairing_es text,
ADD COLUMN IF NOT EXISTS wine_pairing_fr text;

-- Add multilingual columns to events
ALTER TABLE public.events 
ADD COLUMN IF NOT EXISTS title_de text,
ADD COLUMN IF NOT EXISTS title_es text,
ADD COLUMN IF NOT EXISTS title_fr text,
ADD COLUMN IF NOT EXISTS description_de text,
ADD COLUMN IF NOT EXISTS description_es text,
ADD COLUMN IF NOT EXISTS description_fr text,
ADD COLUMN IF NOT EXISTS entry_price_note_de text,
ADD COLUMN IF NOT EXISTS entry_price_note_es text,
ADD COLUMN IF NOT EXISTS entry_price_note_fr text;

-- Add multilingual columns to promos
ALTER TABLE public.promos 
ADD COLUMN IF NOT EXISTS title_de text,
ADD COLUMN IF NOT EXISTS title_es text,
ADD COLUMN IF NOT EXISTS title_fr text,
ADD COLUMN IF NOT EXISTS description_de text,
ADD COLUMN IF NOT EXISTS description_es text,
ADD COLUMN IF NOT EXISTS description_fr text;

-- Add multilingual columns to allergens
ALTER TABLE public.allergens 
ADD COLUMN IF NOT EXISTS name_de text,
ADD COLUMN IF NOT EXISTS name_es text,
ADD COLUMN IF NOT EXISTS name_fr text;

-- Add multilingual columns to loyalty_rewards
ALTER TABLE public.loyalty_rewards 
ADD COLUMN IF NOT EXISTS name_de text,
ADD COLUMN IF NOT EXISTS name_es text,
ADD COLUMN IF NOT EXISTS name_fr text,
ADD COLUMN IF NOT EXISTS description_de text,
ADD COLUMN IF NOT EXISTS description_es text,
ADD COLUMN IF NOT EXISTS description_fr text;
