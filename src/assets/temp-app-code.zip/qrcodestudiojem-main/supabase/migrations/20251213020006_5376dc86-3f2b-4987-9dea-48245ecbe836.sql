-- ============================================
-- SEO SETTINGS - Per ogni pagina del sito
-- ============================================
CREATE TABLE public.seo_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Page identifier
  page_slug TEXT NOT NULL UNIQUE, -- 'home', 'menu', 'takeaway', 'profile', etc.
  page_name TEXT NOT NULL, -- Nome leggibile per admin
  
  -- Basic SEO (Multi-language)
  title JSONB NOT NULL DEFAULT '{"it": "", "en": "", "de": "", "es": "", "fr": ""}'::jsonb,
  description JSONB NOT NULL DEFAULT '{"it": "", "en": "", "de": "", "es": "", "fr": ""}'::jsonb,
  keywords JSONB DEFAULT '{"it": "", "en": "", "de": "", "es": "", "fr": ""}'::jsonb,
  
  -- Advanced Meta
  canonical_url TEXT,
  robots TEXT DEFAULT 'index, follow',
  
  -- Open Graph (Social sharing)
  og_title JSONB,
  og_description JSONB,
  og_image_url TEXT,
  og_type TEXT DEFAULT 'website',
  
  -- Twitter Cards
  twitter_card_type TEXT DEFAULT 'summary_large_image',
  twitter_title JSONB,
  twitter_description JSONB,
  twitter_image_url TEXT,
  
  -- Schema.org Structured Data (JSON-LD)
  schema_data JSONB,
  
  -- Hreflang (Multi-language URLs)
  hreflang_urls JSONB DEFAULT '{}'::jsonb,
  
  -- Sitemap settings
  is_active BOOLEAN DEFAULT true,
  priority DECIMAL(2,1) DEFAULT 0.5 CHECK (priority >= 0 AND priority <= 1),
  change_frequency TEXT DEFAULT 'weekly',
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_seo_settings_page ON seo_settings(page_slug);
CREATE INDEX idx_seo_settings_active ON seo_settings(is_active);

-- RLS
ALTER TABLE seo_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view SEO settings" 
  ON seo_settings FOR SELECT 
  USING (is_active = true);

CREATE POLICY "Admins can manage SEO settings" 
  ON seo_settings FOR ALL 
  USING (is_admin(auth.uid()));

-- Auto update updated_at trigger
CREATE TRIGGER update_seo_settings_updated_at
  BEFORE UPDATE ON seo_settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- Seed default SEO settings per ogni pagina
-- ============================================
INSERT INTO seo_settings (page_slug, page_name, title, description, keywords, og_type, schema_data) VALUES
(
  'home',
  'Homepage',
  '{"it": "Menu Digitale - Scopri i Nostri Piatti", "en": "Digital Menu - Discover Our Dishes"}'::jsonb,
  '{"it": "Scopri il nostro menu digitale. Prenota un tavolo, ordina per asporto e scopri i piatti del giorno.", "en": "Discover our digital menu. Book a table, order takeaway and discover today''s dishes."}'::jsonb,
  '{"it": "ristorante, menu digitale, prenotazioni, cucina italiana, asporto", "en": "restaurant, digital menu, reservations, italian cuisine, takeaway"}'::jsonb,
  'website',
  '{"@context": "https://schema.org", "@type": "Restaurant", "acceptsReservations": "True", "servesCuisine": "Italian"}'::jsonb
),
(
  'menu',
  'Menu',
  '{"it": "Il Nostro Menu - Tutti i Piatti", "en": "Our Menu - All Dishes"}'::jsonb,
  '{"it": "Esplora il nostro menu completo: antipasti, primi, secondi, dessert e bevande. Cucina italiana autentica.", "en": "Explore our complete menu: appetizers, first courses, main dishes, desserts and drinks. Authentic Italian cuisine."}'::jsonb,
  '{"it": "menu ristorante, piatti italiani, antipasti, primi piatti, secondi, dessert", "en": "restaurant menu, italian dishes, appetizers, first courses, main dishes, desserts"}'::jsonb,
  'restaurant.menu',
  '{"@context": "https://schema.org", "@type": "Menu"}'::jsonb
),
(
  'takeaway',
  'Ordina Asporto',
  '{"it": "Ordina Asporto - Consegna e Ritiro", "en": "Order Takeaway - Delivery and Pickup"}'::jsonb,
  '{"it": "Ordina i tuoi piatti preferiti per asporto o consegna a domicilio. Ritiro veloce e consegna in zona.", "en": "Order your favorite dishes for takeaway or home delivery. Quick pickup and local delivery."}'::jsonb,
  '{"it": "asporto, delivery, consegna a domicilio, ordine online, ritiro", "en": "takeaway, delivery, home delivery, online order, pickup"}'::jsonb,
  'website',
  NULL
),
(
  'profile',
  'Profilo Utente',
  '{"it": "Il Mio Profilo - Area Personale", "en": "My Profile - Personal Area"}'::jsonb,
  '{"it": "Gestisci il tuo profilo, visualizza le tue prenotazioni e ordini, e accumula punti fedeltà.", "en": "Manage your profile, view your reservations and orders, and earn loyalty points."}'::jsonb,
  NULL,
  'website',
  NULL
),
(
  'auth',
  'Accesso',
  '{"it": "Accedi o Registrati", "en": "Login or Register"}'::jsonb,
  '{"it": "Accedi con il tuo numero di telefono per prenotare tavoli e ordinare.", "en": "Login with your phone number to book tables and order."}'::jsonb,
  NULL,
  'website',
  NULL
);