-- Add size_variants column to dishes table for multiple sizes with different prices
-- Format: [{"name": "Piccola", "price": 8}, {"name": "Grande", "price": 12}]
ALTER TABLE public.dishes
ADD COLUMN IF NOT EXISTS size_variants jsonb DEFAULT '[]'::jsonb;