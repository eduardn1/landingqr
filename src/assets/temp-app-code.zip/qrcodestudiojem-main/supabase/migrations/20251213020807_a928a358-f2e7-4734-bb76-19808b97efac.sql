-- Remove deprecated SEO columns from restaurant_config (now managed in seo_settings)
ALTER TABLE public.restaurant_config 
DROP COLUMN IF EXISTS meta_title,
DROP COLUMN IF EXISTS meta_description,
DROP COLUMN IF EXISTS og_image_url;

-- Delete SEO entries for pages that should NOT be indexed (auth, profile are private/sensitive)
DELETE FROM public.seo_settings WHERE page_slug IN ('auth', 'profile');

-- Update existing pages to have proper SEO configuration
UPDATE public.seo_settings 
SET 
  robots = 'index, follow',
  change_frequency = 'weekly',
  priority = 1.0
WHERE page_slug = 'home';

UPDATE public.seo_settings 
SET 
  robots = 'index, follow',
  change_frequency = 'daily',
  priority = 0.9
WHERE page_slug = 'menu';

UPDATE public.seo_settings 
SET 
  robots = 'index, follow',
  change_frequency = 'weekly',
  priority = 0.8
WHERE page_slug = 'takeaway';