-- ============================================
-- PHASE 1: TAKEAWAY SYSTEM DATABASE SCHEMA
-- ============================================

-- ============================================
-- 1. DELIVERY ZONES (must be created first for FK reference)
-- ============================================
CREATE TABLE public.delivery_zones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Zone info
  name TEXT NOT NULL,
  description TEXT,
  
  -- Coverage
  zip_codes TEXT[] NOT NULL DEFAULT '{}',
  
  -- Pricing & Timing
  delivery_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
  estimated_minutes INTEGER NOT NULL DEFAULT 30,
  minimum_order DECIMAL(10,2) DEFAULT 0,
  
  -- Availability
  is_active BOOLEAN DEFAULT true,
  available_hours JSONB,
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_delivery_zones_active ON delivery_zones(is_active);

-- RLS
ALTER TABLE delivery_zones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active zones" 
  ON delivery_zones FOR SELECT 
  USING (is_active = true);

CREATE POLICY "Admins can manage zones" 
  ON delivery_zones FOR ALL 
  USING (is_admin(auth.uid()));

-- ============================================
-- 2. TAKEAWAY DRIVERS
-- ============================================
CREATE TABLE public.takeaway_drivers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Personal info
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  photo_url TEXT,
  
  -- Vehicle
  vehicle_type TEXT CHECK (vehicle_type IN ('bike', 'moto', 'car')),
  vehicle_plate TEXT,
  vehicle_color TEXT,
  
  -- Status
  status TEXT NOT NULL DEFAULT 'offline' CHECK (status IN (
    'available',
    'busy',
    'offline'
  )),
  
  -- Stats
  total_deliveries INTEGER DEFAULT 0,
  average_rating DECIMAL(3,2) DEFAULT 0,
  
  -- Additional
  notes TEXT,
  is_active BOOLEAN DEFAULT true,
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_drivers_status ON takeaway_drivers(status);
CREATE INDEX idx_drivers_active ON takeaway_drivers(is_active);

-- RLS
ALTER TABLE takeaway_drivers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active drivers" 
  ON takeaway_drivers FOR SELECT 
  USING (is_active = true);

CREATE POLICY "Admins can manage drivers" 
  ON takeaway_drivers FOR ALL 
  USING (is_admin(auth.uid()));

-- ============================================
-- 3. TAKEAWAY SETTINGS
-- ============================================
CREATE TABLE public.takeaway_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Enable/Disable
  is_enabled BOOLEAN DEFAULT true,
  accepts_pickup BOOLEAN DEFAULT true,
  accepts_delivery BOOLEAN DEFAULT true,
  
  -- Timing
  min_prep_time INTEGER DEFAULT 20,
  max_prep_time INTEGER DEFAULT 60,
  pickup_intervals INTEGER DEFAULT 15,
  
  -- Limits
  max_concurrent_orders INTEGER DEFAULT 20,
  max_daily_orders INTEGER,
  
  -- Business rules
  auto_accept_orders BOOLEAN DEFAULT false,
  
  -- Opening hours (if different from restaurant)
  custom_hours JSONB,
  
  -- Payments
  accepts_cash BOOLEAN DEFAULT true,
  accepts_card_on_delivery BOOLEAN DEFAULT true,
  
  -- Notifications
  notification_phone TEXT,
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS
ALTER TABLE takeaway_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view settings" 
  ON takeaway_settings FOR SELECT 
  USING (true);

CREATE POLICY "Admins can manage settings" 
  ON takeaway_settings FOR ALL 
  USING (is_admin(auth.uid()));

-- ============================================
-- 4. TAKEAWAY ORDERS (main table)
-- ============================================

-- Create sequence for order numbers
CREATE SEQUENCE IF NOT EXISTS takeaway_order_sequence START 1;

CREATE TABLE public.takeaway_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Order number (auto-generated)
  order_number TEXT UNIQUE,
  
  -- Customer
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  customer_email TEXT,
  
  -- Order details
  order_type TEXT NOT NULL CHECK (order_type IN ('pickup', 'delivery')),
  items JSONB NOT NULL,
  
  -- Pricing
  subtotal DECIMAL(10,2) NOT NULL,
  delivery_fee DECIMAL(10,2) DEFAULT 0,
  discount DECIMAL(10,2) DEFAULT 0,
  promo_code TEXT,
  loyalty_points_used INTEGER DEFAULT 0,
  total DECIMAL(10,2) NOT NULL,
  
  -- Status
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN (
    'pending',
    'accepted',
    'rejected',
    'preparing',
    'ready',
    'delivering',
    'completed',
    'cancelled'
  )),
  
  -- Pickup details
  pickup_time TIMESTAMPTZ,
  pickup_actual_time TIMESTAMPTZ,
  
  -- Delivery details
  delivery_address JSONB,
  delivery_zone_id UUID REFERENCES public.delivery_zones(id),
  delivery_time_estimate TIMESTAMPTZ,
  delivery_actual_time TIMESTAMPTZ,
  driver_id UUID REFERENCES public.takeaway_drivers(id),
  
  -- Additional
  special_notes TEXT,
  preparation_time INTEGER,
  estimated_ready_at TIMESTAMPTZ,
  
  -- Rating (added after completion)
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  rating_comment TEXT,
  rated_at TIMESTAMPTZ,
  
  -- Loyalty
  loyalty_points_earned INTEGER DEFAULT 0,
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  accepted_at TIMESTAMPTZ,
  ready_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ
);

-- Indexes
CREATE INDEX idx_takeaway_orders_user ON takeaway_orders(user_id);
CREATE INDEX idx_takeaway_orders_status ON takeaway_orders(status);
CREATE INDEX idx_takeaway_orders_created ON takeaway_orders(created_at DESC);
CREATE INDEX idx_takeaway_orders_driver ON takeaway_orders(driver_id);

-- Auto-generate order number function
CREATE OR REPLACE FUNCTION generate_takeaway_order_number()
RETURNS TRIGGER AS $$
BEGIN
  NEW.order_number := 'TA-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || 
    LPAD(NEXTVAL('takeaway_order_sequence')::TEXT, 3, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER set_takeaway_order_number
  BEFORE INSERT ON takeaway_orders
  FOR EACH ROW
  WHEN (NEW.order_number IS NULL)
  EXECUTE FUNCTION generate_takeaway_order_number();

-- Auto update updated_at
CREATE TRIGGER update_takeaway_orders_updated_at
  BEFORE UPDATE ON takeaway_orders
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- RLS Policies
ALTER TABLE takeaway_orders ENABLE ROW LEVEL SECURITY;

-- Users can view their own orders
CREATE POLICY "Users can view own orders" 
  ON takeaway_orders FOR SELECT 
  USING (auth.uid() = user_id);

-- Users can create orders (must be authenticated)
CREATE POLICY "Users can create orders" 
  ON takeaway_orders FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own pending orders (cancel)
CREATE POLICY "Users can update own pending orders" 
  ON takeaway_orders FOR UPDATE 
  USING (auth.uid() = user_id AND status = 'pending');

-- Admins can view all orders
CREATE POLICY "Admins can view all orders" 
  ON takeaway_orders FOR SELECT 
  USING (is_admin(auth.uid()));

-- Admins can update all orders
CREATE POLICY "Admins can update all orders" 
  ON takeaway_orders FOR UPDATE 
  USING (is_admin(auth.uid()));

-- Admins can delete orders
CREATE POLICY "Admins can delete orders" 
  ON takeaway_orders FOR DELETE 
  USING (is_admin(auth.uid()));

-- ============================================
-- 5. ORDER RATINGS
-- ============================================
CREATE TABLE public.order_ratings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID REFERENCES public.takeaway_orders(id) ON DELETE CASCADE UNIQUE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  
  -- Ratings (1-5)
  food_rating INTEGER CHECK (food_rating >= 1 AND food_rating <= 5),
  delivery_rating INTEGER CHECK (delivery_rating >= 1 AND delivery_rating <= 5),
  driver_rating INTEGER CHECK (driver_rating >= 1 AND driver_rating <= 5),
  overall_rating INTEGER CHECK (overall_rating >= 1 AND overall_rating <= 5),
  
  -- Comments
  comment TEXT,
  
  -- Response (from restaurant)
  response_text TEXT,
  responded_at TIMESTAMPTZ,
  responded_by UUID REFERENCES auth.users(id),
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_order_ratings_order ON order_ratings(order_id);
CREATE INDEX idx_order_ratings_user ON order_ratings(user_id);

-- RLS
ALTER TABLE order_ratings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can rate their completed orders" 
  ON order_ratings FOR INSERT 
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM takeaway_orders 
      WHERE id = order_id 
      AND user_id = auth.uid()
      AND status = 'completed'
    )
  );

CREATE POLICY "Anyone can view ratings" 
  ON order_ratings FOR SELECT 
  USING (true);

CREATE POLICY "Admins can update ratings" 
  ON order_ratings FOR UPDATE 
  USING (is_admin(auth.uid()));

-- ============================================
-- 6. DAILY PROMOS (specific for takeaway)
-- ============================================
CREATE TABLE public.daily_promos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Promo info
  title JSONB NOT NULL DEFAULT '{"it": "", "en": ""}',
  description JSONB,
  image_url TEXT,
  
  -- Discount
  discount_type TEXT NOT NULL CHECK (discount_type IN (
    'percentage',
    'fixed',
    'free_item',
    'free_delivery'
  )),
  discount_value DECIMAL(10,2),
  free_dish_id UUID REFERENCES public.dishes(id),
  
  -- Applicable to
  applies_to TEXT NOT NULL CHECK (applies_to IN (
    'all',
    'category',
    'dishes',
    'min_order'
  )),
  category_ids UUID[],
  dish_ids UUID[],
  minimum_order DECIMAL(10,2),
  
  -- Validity
  valid_from TIMESTAMPTZ NOT NULL,
  valid_until TIMESTAMPTZ NOT NULL,
  days_of_week INTEGER[],
  
  -- Usage limits
  max_uses INTEGER,
  max_uses_per_user INTEGER DEFAULT 1,
  current_uses INTEGER DEFAULT 0,
  
  -- Promo code (optional)
  promo_code TEXT UNIQUE,
  
  -- Status
  is_active BOOLEAN DEFAULT true,
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_daily_promos_active ON daily_promos(is_active);
CREATE INDEX idx_daily_promos_dates ON daily_promos(valid_from, valid_until);

-- RLS
ALTER TABLE daily_promos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active promos" 
  ON daily_promos FOR SELECT 
  USING (is_active = true AND NOW() BETWEEN valid_from AND valid_until);

CREATE POLICY "Admins can manage promos" 
  ON daily_promos FOR ALL 
  USING (is_admin(auth.uid()));

-- ============================================
-- 7. MODIFY EXISTING DISHES TABLE
-- ============================================
ALTER TABLE public.dishes
ADD COLUMN IF NOT EXISTS available_for_takeaway BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS available_for_delivery BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS takeaway_prep_time INTEGER DEFAULT 15,
ADD COLUMN IF NOT EXISTS has_extras BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS extras JSONB DEFAULT '[]';

-- ============================================
-- 8. MODIFY EXISTING LOYALTY_TRANSACTIONS
-- ============================================
ALTER TABLE public.loyalty_transactions
ADD COLUMN IF NOT EXISTS takeaway_order_id UUID REFERENCES public.takeaway_orders(id);

-- ============================================
-- 9. INSERT DEFAULT TAKEAWAY SETTINGS
-- ============================================
INSERT INTO public.takeaway_settings (
  is_enabled,
  accepts_pickup,
  accepts_delivery,
  min_prep_time,
  max_prep_time,
  pickup_intervals,
  max_concurrent_orders,
  auto_accept_orders,
  accepts_cash,
  accepts_card_on_delivery
) VALUES (
  true,
  true,
  true,
  20,
  60,
  15,
  20,
  false,
  true,
  true
);

-- ============================================
-- 10. ENABLE REALTIME FOR ORDERS
-- ============================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.takeaway_orders;