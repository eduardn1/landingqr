-- Add UPDATE and DELETE policies for storage
CREATE POLICY "Admins can update restaurant assets"
ON storage.objects FOR UPDATE
USING (bucket_id = 'restaurant-assets' AND auth.role() = 'authenticated');

CREATE POLICY "Admins can delete restaurant assets"
ON storage.objects FOR DELETE
USING (bucket_id = 'restaurant-assets' AND auth.role() = 'authenticated');