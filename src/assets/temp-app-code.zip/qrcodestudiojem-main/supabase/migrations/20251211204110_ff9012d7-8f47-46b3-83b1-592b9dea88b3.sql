-- Add menu view mode configuration to restaurant_config
ALTER TABLE public.restaurant_config 
ADD COLUMN IF NOT EXISTS menu_view_mode text DEFAULT 'cards';

-- Add comment for documentation
COMMENT ON COLUMN public.restaurant_config.menu_view_mode IS 'Menu display mode: cards (large images), list (compact list), grid (2x2 grid)';