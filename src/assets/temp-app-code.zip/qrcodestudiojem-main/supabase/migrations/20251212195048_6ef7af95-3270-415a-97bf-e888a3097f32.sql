-- Add gamification tables for loyalty system

-- Badges/Achievements table
CREATE TABLE public.loyalty_badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  badge_key TEXT NOT NULL UNIQUE,
  name_it TEXT NOT NULL,
  name_en TEXT,
  name_de TEXT,
  name_es TEXT,
  name_fr TEXT,
  description_it TEXT,
  description_en TEXT,
  description_de TEXT,
  description_es TEXT,
  description_fr TEXT,
  icon TEXT NOT NULL DEFAULT '🏆',
  color TEXT DEFAULT 'from-yellow-500 to-amber-500',
  category TEXT NOT NULL DEFAULT 'achievement', -- achievement, milestone, special
  requirement_type TEXT NOT NULL DEFAULT 'reservations_count', -- reservations_count, points_earned, streak_days, guests_total, favorites_count
  requirement_value INTEGER NOT NULL DEFAULT 1,
  points_reward INTEGER DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_secret BOOLEAN DEFAULT false, -- Hidden until unlocked
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User badges (earned achievements)
CREATE TABLE public.user_badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  badge_id UUID NOT NULL REFERENCES public.loyalty_badges(id) ON DELETE CASCADE,
  earned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_new BOOLEAN DEFAULT true,
  UNIQUE(user_id, badge_id)
);

-- Streaks tracking
CREATE TABLE public.loyalty_streaks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE,
  current_streak INTEGER NOT NULL DEFAULT 0,
  longest_streak INTEGER NOT NULL DEFAULT 0,
  last_activity_date DATE,
  streak_type TEXT DEFAULT 'weekly', -- daily, weekly
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Challenges/Missions
CREATE TABLE public.loyalty_challenges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge_key TEXT NOT NULL UNIQUE,
  name_it TEXT NOT NULL,
  name_en TEXT,
  name_de TEXT,
  name_es TEXT,
  name_fr TEXT,
  description_it TEXT,
  description_en TEXT,
  description_de TEXT,
  description_es TEXT,
  description_fr TEXT,
  icon TEXT NOT NULL DEFAULT '🎯',
  color TEXT DEFAULT 'from-purple-500 to-pink-500',
  challenge_type TEXT NOT NULL DEFAULT 'one_time', -- one_time, daily, weekly, monthly
  requirement_type TEXT NOT NULL DEFAULT 'reservations_count',
  requirement_value INTEGER NOT NULL DEFAULT 1,
  points_reward INTEGER NOT NULL DEFAULT 50,
  starts_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  is_active BOOLEAN NOT NULL DEFAULT true,
  display_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User challenge progress
CREATE TABLE public.user_challenges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  challenge_id UUID NOT NULL REFERENCES public.loyalty_challenges(id) ON DELETE CASCADE,
  current_progress INTEGER NOT NULL DEFAULT 0,
  is_completed BOOLEAN DEFAULT false,
  completed_at TIMESTAMP WITH TIME ZONE,
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, challenge_id)
);

-- Add level/XP fields to loyalty_points
ALTER TABLE public.loyalty_points 
ADD COLUMN IF NOT EXISTS level INTEGER NOT NULL DEFAULT 1,
ADD COLUMN IF NOT EXISTS xp_current INTEGER NOT NULL DEFAULT 0,
ADD COLUMN IF NOT EXISTS xp_to_next_level INTEGER NOT NULL DEFAULT 100;

-- Add streak bonus to loyalty_config
ALTER TABLE public.loyalty_config
ADD COLUMN IF NOT EXISTS streak_bonus_multiplier NUMERIC DEFAULT 1.5,
ADD COLUMN IF NOT EXISTS daily_login_bonus INTEGER DEFAULT 5;

-- Enable RLS
ALTER TABLE public.loyalty_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loyalty_streaks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loyalty_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_challenges ENABLE ROW LEVEL SECURITY;

-- RLS Policies for loyalty_badges (public read, admin write)
CREATE POLICY "Anyone can view active badges" ON public.loyalty_badges
  FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage badges" ON public.loyalty_badges
  FOR ALL USING (is_admin(auth.uid()));

-- RLS Policies for user_badges
CREATE POLICY "Users can view their own badges" ON public.user_badges
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "System can manage user badges" ON public.user_badges
  FOR ALL USING (true);

-- RLS Policies for loyalty_streaks
CREATE POLICY "Users can view their own streaks" ON public.loyalty_streaks
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "System can manage streaks" ON public.loyalty_streaks
  FOR ALL USING (true);

-- RLS Policies for loyalty_challenges
CREATE POLICY "Anyone can view active challenges" ON public.loyalty_challenges
  FOR SELECT USING (is_active = true AND (expires_at IS NULL OR expires_at > now()));

CREATE POLICY "Admins can manage challenges" ON public.loyalty_challenges
  FOR ALL USING (is_admin(auth.uid()));

-- RLS Policies for user_challenges
CREATE POLICY "Users can view their own challenge progress" ON public.user_challenges
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "System can manage user challenges" ON public.user_challenges
  FOR ALL USING (true);

-- Insert default badges
INSERT INTO public.loyalty_badges (badge_key, name_it, name_en, description_it, description_en, icon, color, category, requirement_type, requirement_value, points_reward, display_order) VALUES
('first_reservation', 'Prima Prenotazione', 'First Reservation', 'Hai fatto la tua prima prenotazione!', 'You made your first reservation!', '🎉', 'from-green-500 to-emerald-500', 'milestone', 'reservations_count', 1, 10, 1),
('regular_customer', 'Cliente Abituale', 'Regular Customer', 'Hai fatto 5 prenotazioni', 'You made 5 reservations', '⭐', 'from-yellow-500 to-amber-500', 'milestone', 'reservations_count', 5, 50, 2),
('loyal_customer', 'Cliente Fedele', 'Loyal Customer', 'Hai fatto 10 prenotazioni', 'You made 10 reservations', '🏆', 'from-amber-500 to-orange-500', 'milestone', 'reservations_count', 10, 100, 3),
('vip', 'VIP', 'VIP', 'Hai fatto 25 prenotazioni', 'You made 25 reservations', '👑', 'from-purple-500 to-pink-500', 'milestone', 'reservations_count', 25, 250, 4),
('points_collector', 'Collezionista', 'Points Collector', 'Hai guadagnato 500 punti', 'You earned 500 points', '💎', 'from-blue-500 to-cyan-500', 'achievement', 'points_earned', 500, 25, 5),
('streak_master', 'Maestro delle Serie', 'Streak Master', 'Hai mantenuto una serie di 4 settimane', 'You maintained a 4-week streak', '🔥', 'from-red-500 to-orange-500', 'achievement', 'streak_days', 4, 100, 6),
('social_butterfly', 'Farfalla Sociale', 'Social Butterfly', 'Hai portato 20 ospiti in totale', 'You brought 20 guests total', '🦋', 'from-pink-500 to-rose-500', 'achievement', 'guests_total', 20, 75, 7),
('foodie', 'Foodie', 'Foodie', 'Hai salvato 10 piatti preferiti', 'You saved 10 favorite dishes', '😋', 'from-orange-500 to-red-500', 'achievement', 'favorites_count', 10, 30, 8);

-- Insert default challenges
INSERT INTO public.loyalty_challenges (challenge_key, name_it, name_en, description_it, description_en, icon, color, challenge_type, requirement_type, requirement_value, points_reward, display_order) VALUES
('weekly_reservation', 'Sfida Settimanale', 'Weekly Challenge', 'Fai una prenotazione questa settimana', 'Make a reservation this week', '📅', 'from-blue-500 to-indigo-500', 'weekly', 'reservations_count', 1, 20, 1),
('bring_friends', 'Porta Amici', 'Bring Friends', 'Prenota per 4 o più persone', 'Book for 4 or more guests', '👥', 'from-green-500 to-teal-500', 'one_time', 'guests_total', 4, 30, 2);

-- Create trigger to update timestamps
CREATE TRIGGER update_loyalty_badges_updated_at
  BEFORE UPDATE ON public.loyalty_badges
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_loyalty_streaks_updated_at
  BEFORE UPDATE ON public.loyalty_streaks
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_loyalty_challenges_updated_at
  BEFORE UPDATE ON public.loyalty_challenges
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();