-- ========================================
-- FASE 1: CORE BACKEND TABLES
-- ========================================

-- 1. RESTAURANT CONFIG (branding, colori, font, features)
CREATE TABLE public.restaurant_config (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  
  -- Basic Info
  name TEXT NOT NULL DEFAULT 'Ristorante',
  tagline JSONB DEFAULT '{"it": "", "en": ""}',
  description JSONB DEFAULT '{"it": "", "en": ""}',
  
  -- Branding
  logo_url TEXT,
  favicon_url TEXT,
  cover_image_url TEXT,
  
  -- Colors (HSL format)
  color_primary TEXT DEFAULT '12 76% 61%',
  color_secondary TEXT DEFAULT '240 3.7% 15.9%',
  color_accent TEXT DEFAULT '12 76% 61%',
  color_background TEXT DEFAULT '0 0% 100%',
  color_foreground TEXT DEFAULT '240 10% 3.9%',
  
  -- Typography
  font_heading TEXT DEFAULT 'Brandon Grotesque',
  font_body TEXT DEFAULT 'system-ui',
  
  -- Theme
  theme TEXT DEFAULT 'modern',
  border_radius TEXT DEFAULT 'rounded',
  
  -- Contact Info
  phone TEXT,
  email TEXT,
  address TEXT,
  city TEXT,
  country TEXT DEFAULT 'Italia',
  
  -- Social Links
  instagram_url TEXT,
  facebook_url TEXT,
  tripadvisor_url TEXT,
  google_maps_url TEXT,
  
  -- Business Hours (JSONB for flexibility)
  business_hours JSONB DEFAULT '[
    {"day": "monday", "open": "12:00", "close": "23:00", "closed": false},
    {"day": "tuesday", "open": "12:00", "close": "23:00", "closed": false},
    {"day": "wednesday", "open": "12:00", "close": "23:00", "closed": false},
    {"day": "thursday", "open": "12:00", "close": "23:00", "closed": false},
    {"day": "friday", "open": "12:00", "close": "23:00", "closed": false},
    {"day": "saturday", "open": "12:00", "close": "23:00", "closed": false},
    {"day": "sunday", "open": "12:00", "close": "23:00", "closed": true}
  ]',
  
  -- Features Toggles
  features JSONB DEFAULT '{
    "onboarding_enabled": true,
    "stories_enabled": true,
    "mood_selector_enabled": true,
    "swiper_enabled": true,
    "favorites_enabled": true,
    "reservations_enabled": true,
    "search_enabled": true,
    "allergen_filter_enabled": true,
    "instagram_feed_enabled": false,
    "google_reviews_enabled": false,
    "takeaway_enabled": false
  }',
  
  -- SEO
  meta_title TEXT,
  meta_description TEXT,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.restaurant_config ENABLE ROW LEVEL SECURITY;

-- Anyone can view config (public menu)
CREATE POLICY "Anyone can view restaurant config" 
ON public.restaurant_config FOR SELECT USING (true);

-- 2. ONBOARDING STEPS (dynamic steps)
CREATE TABLE public.onboarding_steps (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  step_key TEXT NOT NULL UNIQUE,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_optional BOOLEAN NOT NULL DEFAULT false,
  
  -- Content (multi-language)
  question JSONB NOT NULL DEFAULT '{"it": "", "en": ""}',
  subtext JSONB DEFAULT '{"it": "", "en": ""}',
  tip JSONB,
  
  -- Options (array of options with filters)
  options JSONB NOT NULL DEFAULT '[]',
  -- Example: [{"id": "light", "emoji": "🥗", "label": {"it": "Leggero", "en": "Light"}, "gradient": "from-green-400 to-emerald-500", "filters": {"tags": ["light", "salad"]}}]
  
  -- UI Settings
  skip_button_text JSONB DEFAULT '{"it": "Salta", "en": "Skip"}',
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.onboarding_steps ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view onboarding steps" 
ON public.onboarding_steps FOR SELECT USING (true);

-- 3. MOODS (mood selector items)
CREATE TABLE public.moods (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mood_key TEXT NOT NULL UNIQUE,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  
  -- Content
  emoji TEXT NOT NULL DEFAULT '🍽️',
  label JSONB NOT NULL DEFAULT '{"it": "", "en": ""}',
  gradient TEXT DEFAULT 'from-gray-400 to-gray-500',
  
  -- Filter rules
  filters JSONB DEFAULT '{}',
  -- Example: {"tags": ["comfort"], "is_featured": true, "max_price": 25}
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.moods ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view moods" 
ON public.moods FOR SELECT USING (true);

-- 4. STORIES (Instagram-style stories)
CREATE TABLE public.stories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  story_key TEXT NOT NULL UNIQUE,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  
  -- Story ring/preview
  icon TEXT, -- emoji or icon name
  label JSONB NOT NULL DEFAULT '{"it": "", "en": ""}',
  gradient TEXT DEFAULT 'from-accent to-accent/50',
  thumbnail_url TEXT,
  has_new BOOLEAN DEFAULT false,
  
  -- Story slides (array)
  slides JSONB NOT NULL DEFAULT '[]',
  -- Example: [{"id": "1", "type": "image", "url": "...", "duration": 5, "caption": {"it": "", "en": ""}, "link_dish_id": null}]
  
  -- Scheduling
  publish_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.stories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active stories" 
ON public.stories FOR SELECT 
USING (is_active = true AND (publish_at IS NULL OR publish_at <= now()) AND (expires_at IS NULL OR expires_at > now()));

-- 5. HOME SECTIONS (configurable order and visibility)
CREATE TABLE public.home_sections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  section_key TEXT NOT NULL UNIQUE,
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  
  -- Content
  title JSONB DEFAULT '{"it": "", "en": ""}',
  subtitle JSONB,
  
  -- Section-specific config
  config JSONB DEFAULT '{}',
  -- Examples:
  -- stories: {"auto_advance": true, "advance_interval": 5}
  -- mood: {"grid_columns": 4}
  -- featured: {"max_dishes": 6, "show_price": true}
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.home_sections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view home sections" 
ON public.home_sections FOR SELECT USING (true);

-- ========================================
-- TRIGGERS FOR updated_at
-- ========================================

CREATE TRIGGER update_restaurant_config_updated_at
BEFORE UPDATE ON public.restaurant_config
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_onboarding_steps_updated_at
BEFORE UPDATE ON public.onboarding_steps
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_moods_updated_at
BEFORE UPDATE ON public.moods
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_stories_updated_at
BEFORE UPDATE ON public.stories
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_home_sections_updated_at
BEFORE UPDATE ON public.home_sections
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ========================================
-- STORAGE BUCKET FOR UPLOADS
-- ========================================

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'restaurant-assets',
  'restaurant-assets',
  true,
  5242880, -- 5MB limit
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4']
);

-- Storage policies
CREATE POLICY "Public can view restaurant assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'restaurant-assets');

CREATE POLICY "Authenticated users can upload assets"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'restaurant-assets' AND auth.role() = 'authenticated');