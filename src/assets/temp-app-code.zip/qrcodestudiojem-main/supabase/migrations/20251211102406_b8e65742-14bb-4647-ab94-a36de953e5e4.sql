-- Create action_buttons table for dynamic homepage buttons
CREATE TABLE public.action_buttons (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  button_key TEXT NOT NULL UNIQUE,
  label JSONB NOT NULL DEFAULT '{"it": "", "en": ""}',
  subtitle JSONB DEFAULT '{"it": "", "en": ""}',
  icon TEXT NOT NULL DEFAULT 'Utensils',
  action_type TEXT NOT NULL DEFAULT 'internal', -- 'internal', 'modal', 'external'
  action_value TEXT, -- route path, modal name, or external URL
  gradient TEXT DEFAULT 'from-accent/20 to-accent/5',
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_visible_mobile BOOLEAN NOT NULL DEFAULT true,
  is_visible_desktop BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.action_buttons ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Anyone can view action buttons"
  ON public.action_buttons
  FOR SELECT
  USING (true);

CREATE POLICY "Admins can insert action buttons"
  ON public.action_buttons
  FOR INSERT
  WITH CHECK (is_admin(auth.uid()));

CREATE POLICY "Admins can update action buttons"
  ON public.action_buttons
  FOR UPDATE
  USING (is_admin(auth.uid()));

CREATE POLICY "Admins can delete action buttons"
  ON public.action_buttons
  FOR DELETE
  USING (is_admin(auth.uid()));

-- Add trigger for updated_at
CREATE TRIGGER update_action_buttons_updated_at
  BEFORE UPDATE ON public.action_buttons
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default buttons
INSERT INTO public.action_buttons (button_key, label, subtitle, icon, action_type, action_value, gradient, display_order) VALUES
  ('menu', '{"it": "Menu", "en": "Menu"}', '{"it": "Sfoglia i piatti", "en": "Browse dishes"}', 'UtensilsCrossed', 'internal', 'menu', 'from-accent/20 to-accent/5', 0),
  ('reservation', '{"it": "Prenota", "en": "Book"}', '{"it": "Un tavolo", "en": "A table"}', 'CalendarDays', 'modal', 'reservation', 'from-accent/20 to-accent/5', 1),
  ('discover', '{"it": "Scopri", "en": "Discover"}', '{"it": "Swipe i piatti", "en": "Swipe dishes"}', 'Sparkles', 'modal', 'discover', 'from-accent/30 via-accent/20 to-accent/30', 2),
  ('takeaway', '{"it": "Asporto", "en": "Takeaway"}', '{"it": "Ordina", "en": "Order"}', 'ShoppingBag', 'modal', 'takeaway', 'from-accent/20 to-accent/5', 3),
  ('about', '{"it": "Chi siamo", "en": "About us"}', '{"it": "La nostra storia", "en": "Our story"}', 'Info', 'modal', 'about', 'from-accent/20 to-accent/5', 4);