-- Add tiktok_url to restaurant_config
ALTER TABLE public.restaurant_config 
ADD COLUMN IF NOT EXISTS tiktok_url text DEFAULT NULL;

-- Add whatsapp number to restaurant_config
ALTER TABLE public.restaurant_config 
ADD COLUMN IF NOT EXISTS whatsapp text DEFAULT NULL;