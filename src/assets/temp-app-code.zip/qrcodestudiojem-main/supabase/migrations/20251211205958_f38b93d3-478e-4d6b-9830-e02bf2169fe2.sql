-- Remove preparation_time column from dishes table
ALTER TABLE public.dishes DROP COLUMN IF EXISTS preparation_time;