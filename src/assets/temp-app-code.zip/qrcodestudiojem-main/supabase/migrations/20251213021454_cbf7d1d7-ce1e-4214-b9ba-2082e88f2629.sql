-- ============================================
-- DESIGN TEMPLATES SYSTEM
-- ============================================
CREATE TABLE public.design_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Template info
  template_type TEXT NOT NULL CHECK (template_type IN ('homepage', 'takeaway', 'onboarding')),
  template_key TEXT NOT NULL UNIQUE,
  template_name JSONB NOT NULL DEFAULT '{"it": "", "en": ""}'::jsonb,
  template_description JSONB,
  
  -- Preview
  preview_image_url TEXT,
  
  -- Design configuration
  design_config JSONB NOT NULL DEFAULT '{}'::jsonb,
  
  -- Features flags
  features JSONB DEFAULT '{}'::jsonb,
  
  -- Status
  is_active BOOLEAN DEFAULT true,
  is_premium BOOLEAN DEFAULT false,
  
  -- Metadata
  difficulty_level TEXT DEFAULT 'easy' CHECK (difficulty_level IN ('easy', 'medium', 'advanced')),
  best_for TEXT[] DEFAULT '{}',
  tags TEXT[] DEFAULT '{}',
  display_order INTEGER DEFAULT 0,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_design_templates_type ON design_templates(template_type);
CREATE INDEX idx_design_templates_active ON design_templates(is_active);
CREATE INDEX idx_design_templates_key ON design_templates(template_key);

-- Active template selection (one row, tracks which template is active for each type)
CREATE TABLE public.active_template_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  homepage_template_key TEXT DEFAULT 'homepage_classic',
  takeaway_template_key TEXT DEFAULT 'takeaway_card_grid',
  onboarding_template_key TEXT DEFAULT 'onboarding_conversational',
  
  -- Custom overrides
  homepage_custom_config JSONB DEFAULT '{}'::jsonb,
  takeaway_custom_config JSONB DEFAULT '{}'::jsonb,
  onboarding_custom_config JSONB DEFAULT '{}'::jsonb,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS
ALTER TABLE design_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE active_template_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active templates" 
  ON design_templates FOR SELECT 
  USING (is_active = true);

CREATE POLICY "Admins can manage templates" 
  ON design_templates FOR ALL 
  USING (is_admin(auth.uid()));

CREATE POLICY "Anyone can view active config" 
  ON active_template_config FOR SELECT 
  USING (true);

CREATE POLICY "Admins can manage active config" 
  ON active_template_config FOR ALL 
  USING (is_admin(auth.uid()));

-- Insert default templates
-- HOMEPAGE TEMPLATES (8)
INSERT INTO design_templates (template_type, template_key, template_name, template_description, design_config, features, tags, display_order) VALUES
('homepage', 'homepage_classic', 
  '{"it": "Classico", "en": "Classic"}'::jsonb,
  '{"it": "Layout tradizionale con hero e sezioni verticali", "en": "Traditional layout with hero and vertical sections"}'::jsonb,
  '{"layout": "classic", "hero_style": "image", "sections_order": ["hero", "stories", "action_buttons", "featured", "menu", "events", "about"], "card_style": "elevated", "animations": {"scroll_reveal": true, "hover_lift": true}}'::jsonb,
  '{"floating_elements": false, "gradient_animation": false}'::jsonb,
  ARRAY['classic', 'simple', 'elegant'], 1),

('homepage', 'homepage_modern_glass',
  '{"it": "Hero Glassmorphism", "en": "Glass Hero"}'::jsonb,
  '{"it": "Hero moderno con effetti vetro e sfocatura", "en": "Modern hero with glass and blur effects"}'::jsonb,
  '{"layout": "hero_center", "hero_style": "glassmorphism", "hero_config": {"height": "90vh", "background": "mesh_gradient", "blur_intensity": "20px"}, "sections_order": ["hero", "stories", "featured", "menu", "events"], "card_style": "glassmorphism", "animations": {"scroll_reveal": true, "fade_in_up": true, "parallax_scroll": true, "hover_lift": true}}'::jsonb,
  '{"floating_elements": true, "gradient_animation": true, "glassmorphism": true}'::jsonb,
  ARRAY['modern', 'glass', 'trendy'], 2),

('homepage', 'homepage_bento_minimal',
  '{"it": "Bento Grid Minimal", "en": "Minimal Bento Grid"}'::jsonb,
  '{"it": "Layout a griglia asimmetrica stile Apple", "en": "Asymmetric grid layout Apple-style"}'::jsonb,
  '{"layout": "bento_grid", "hero_style": "minimal_text", "grid_config": {"columns": 12, "gap": "1rem"}, "card_style": "flat_hover_elevated", "typography": {"heading_size": "8xl", "heading_weight": "300"}}'::jsonb,
  '{"bento_layout": true}'::jsonb,
  ARRAY['minimal', 'bento', 'modern'], 3),

('homepage', 'homepage_parallax',
  '{"it": "Parallax Full Image", "en": "Full Image Parallax"}'::jsonb,
  '{"it": "Hero full-width con effetto parallax su scroll", "en": "Full-width hero with scroll parallax effect"}'::jsonb,
  '{"layout": "hero_full", "hero_style": "image_parallax", "hero_config": {"height": "100vh", "parallax_speed": 0.5}, "card_style": "elevated", "animations": {"parallax_scroll": true, "scroll_reveal": true}}'::jsonb,
  '{"parallax": true, "sticky_nav": true}'::jsonb,
  ARRAY['parallax', 'immersive', 'photo'], 4),

('homepage', 'homepage_split',
  '{"it": "Split Hero + Carousel", "en": "Split Hero + Carousel"}'::jsonb,
  '{"it": "Hero diviso con immagine e testo affiancati", "en": "Split hero with image and text side by side"}'::jsonb,
  '{"layout": "hero_split", "hero_style": "split", "hero_config": {"image_position": "left"}, "sections_order": ["hero", "carousel", "menu", "events"], "card_style": "elevated", "animations": {"slide_in": true}}'::jsonb,
  '{"carousel": true}'::jsonb,
  ARRAY['split', 'balanced', 'elegant'], 5),

('homepage', 'homepage_video',
  '{"it": "Video Background", "en": "Video Background"}'::jsonb,
  '{"it": "Hero con video di sfondo e menu floating", "en": "Hero with background video and floating menu"}'::jsonb,
  '{"layout": "hero_video", "hero_style": "video", "hero_config": {"autoplay": true, "muted": true, "loop": true}, "card_style": "glassmorphism", "animations": {"fade_in": true}}'::jsonb,
  '{"video_background": true, "floating_menu": true}'::jsonb,
  ARRAY['video', 'dynamic', 'premium'], 6),

('homepage', 'homepage_masonry',
  '{"it": "Grid Masonry", "en": "Masonry Grid"}'::jsonb,
  '{"it": "Griglia masonry con forme liquide animate", "en": "Masonry grid with animated liquid shapes"}'::jsonb,
  '{"layout": "masonry", "hero_style": "minimal", "card_style": "elevated", "animations": {"stagger_reveal": true, "hover_zoom": true}}'::jsonb,
  '{"masonry_layout": true, "liquid_shapes": true}'::jsonb,
  ARRAY['masonry', 'creative', 'artistic'], 7),

('homepage', 'homepage_aurora',
  '{"it": "Aurora Gradient + Neon", "en": "Aurora Gradient + Neon"}'::jsonb,
  '{"it": "Gradient aurora animato con accenti neon", "en": "Animated aurora gradient with neon accents"}'::jsonb,
  '{"layout": "hero_center", "hero_style": "aurora", "hero_config": {"gradient_colors": ["#FF6B6B", "#4ECDC4", "#45B7D1", "#A855F7"]}, "card_style": "neon_glow", "animations": {"aurora_animation": true, "glow_pulse": true}}'::jsonb,
  '{"aurora_gradient": true, "neon_accents": true, "dark_mode_optimized": true}'::jsonb,
  ARRAY['aurora', 'neon', 'dark', 'premium'], 8);

-- TAKEAWAY TEMPLATES (3)
INSERT INTO design_templates (template_type, template_key, template_name, template_description, design_config, features, tags, display_order) VALUES
('takeaway', 'takeaway_card_grid',
  '{"it": "Griglia Cards", "en": "Card Grid"}'::jsonb,
  '{"it": "Griglia responsive con cart floating", "en": "Responsive grid with floating cart"}'::jsonb,
  '{"layout": "grid", "grid_columns": {"mobile": 1, "tablet": 2, "desktop": 3}, "dish_card_style": "elevated", "cart_position": "floating_bottom_right", "filters": {"style": "pills_scroll", "position": "sticky_top"}, "animations": {"add_to_cart": "scale_bounce", "cart_update": "shake"}}'::jsonb,
  '{"floating_cart": true, "category_filters": true}'::jsonb,
  ARRAY['grid', 'modern', 'responsive'], 1),

('takeaway', 'takeaway_list_quick',
  '{"it": "Lista Compatta", "en": "Compact List"}'::jsonb,
  '{"it": "Lista compatta con azioni rapide inline", "en": "Compact list with inline quick actions"}'::jsonb,
  '{"layout": "list", "dish_card_style": "list_compact", "quick_actions": true, "image_size": "small_thumbnail", "cart_position": "sticky_bottom_bar", "animations": {"quantity_change": "number_flip", "item_remove": "swipe_left"}}'::jsonb,
  '{"inline_actions": true, "swipe_actions": true}'::jsonb,
  ARRAY['list', 'compact', 'fast'], 2),

('takeaway', 'takeaway_tabs_image',
  '{"it": "Tabs + Immagini Large", "en": "Tabs + Large Images"}'::jsonb,
  '{"it": "Tabs per categorie con focus su immagini", "en": "Category tabs with focus on images"}'::jsonb,
  '{"layout": "tabs", "tabs_style": "underline_animated", "dish_card_style": "image_overlay", "image_size": "large_hero", "cart_position": "sidebar_slide", "animations": {"tab_change": "fade_slide", "image_hover": "zoom_parallax"}}'::jsonb,
  '{"tabs_navigation": true, "sidebar_cart": true}'::jsonb,
  ARRAY['tabs', 'visual', 'premium'], 3);

-- ONBOARDING TEMPLATES (3)
INSERT INTO design_templates (template_type, template_key, template_name, template_description, design_config, features, tags, display_order) VALUES
('onboarding', 'onboarding_conversational',
  '{"it": "Conversazionale", "en": "Conversational"}'::jsonb,
  '{"it": "Quiz stile chat con animazioni fluide", "en": "Chat-style quiz with smooth animations"}'::jsonb,
  '{"layout": "conversational", "style": "chat_bubbles", "progress": "dots", "animations": {"message_appear": "slide_up", "option_select": "scale_bounce"}}'::jsonb,
  '{"chat_style": true, "typing_indicator": true}'::jsonb,
  ARRAY['conversational', 'friendly', 'modern'], 1),

('onboarding', 'onboarding_cards_stack',
  '{"it": "Stack di Cards", "en": "Card Stack"}'::jsonb,
  '{"it": "Cards impilate con swipe gesture", "en": "Stacked cards with swipe gesture"}'::jsonb,
  '{"layout": "card_stack", "style": "stacked", "progress": "bar", "animations": {"card_swipe": "3d_rotate", "card_stack": "depth_parallax"}}'::jsonb,
  '{"swipe_gesture": true, "3d_cards": true}'::jsonb,
  ARRAY['cards', 'interactive', 'premium'], 2),

('onboarding', 'onboarding_fullscreen_steps',
  '{"it": "Steps Fullscreen", "en": "Fullscreen Steps"}'::jsonb,
  '{"it": "Ogni step occupa tutto lo schermo", "en": "Each step takes full screen"}'::jsonb,
  '{"layout": "fullscreen", "style": "immersive", "progress": "vertical_line", "animations": {"step_transition": "fade_slide", "background_morph": true}}'::jsonb,
  '{"fullscreen_steps": true, "background_animation": true}'::jsonb,
  ARRAY['fullscreen', 'immersive', 'bold'], 3);

-- Insert default active config
INSERT INTO active_template_config (homepage_template_key, takeaway_template_key, onboarding_template_key) 
VALUES ('homepage_classic', 'takeaway_card_grid', 'onboarding_conversational');