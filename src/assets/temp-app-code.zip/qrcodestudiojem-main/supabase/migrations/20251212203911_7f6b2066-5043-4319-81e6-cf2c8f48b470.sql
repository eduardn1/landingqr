-- Fix storage policies to only allow admin users to upload/modify assets

-- Drop existing policies
DROP POLICY IF EXISTS "Restaurant assets are viewable by everyone" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload restaurant assets" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can update restaurant assets" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete restaurant assets" ON storage.objects;
DROP POLICY IF EXISTS "Only admins can upload assets" ON storage.objects;
DROP POLICY IF EXISTS "Only admins can update assets" ON storage.objects;
DROP POLICY IF EXISTS "Only admins can delete assets" ON storage.objects;

-- Recreate with proper admin-only restrictions
CREATE POLICY "Restaurant assets are viewable by everyone" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'restaurant-assets');

CREATE POLICY "Only admins can upload assets" 
ON storage.objects FOR INSERT 
WITH CHECK (
  bucket_id = 'restaurant-assets' 
  AND public.is_admin(auth.uid())
);

CREATE POLICY "Only admins can update assets" 
ON storage.objects FOR UPDATE 
USING (
  bucket_id = 'restaurant-assets' 
  AND public.is_admin(auth.uid())
);

CREATE POLICY "Only admins can delete assets" 
ON storage.objects FOR DELETE 
USING (
  bucket_id = 'restaurant-assets' 
  AND public.is_admin(auth.uid())
);