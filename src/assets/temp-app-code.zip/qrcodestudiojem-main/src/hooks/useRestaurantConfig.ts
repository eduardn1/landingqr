import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export type MenuViewMode = 'cards' | 'list' | 'grid' | 'compact';
export type PlaceholderType = 'gradient' | 'emoji' | 'image' | 'pattern';

export interface RestaurantConfig {
  id: string;
  name: string;
  tagline: { it: string; en: string };
  description: { it: string; en: string };
  logo_url: string | null;
  favicon_url: string | null;
  cover_image_url: string | null;
  color_primary: string;
  color_secondary: string;
  color_accent: string;
  color_background: string;
  color_foreground: string;
  font_heading: string;
  font_body: string;
  theme: string;
  border_radius: string;
  phone: string | null;
  whatsapp: string | null;
  email: string | null;
  address: string | null;
  city: string | null;
  country: string;
  instagram_url: string | null;
  instagram_username: string | null;
  facebook_url: string | null;
  tiktok_url: string | null;
  tripadvisor_url: string | null;
  google_maps_url: string | null;
  google_place_id: string | null;
  max_guests_per_slot: number | null;
  business_hours: BusinessHour[];
  features: FeatureToggles;
  meta_title: string | null;
  meta_description: string | null;
  og_image_url: string | null;
  // PWA Settings
  pwa_name: string | null;
  pwa_short_name: string | null;
  pwa_description: string | null;
  pwa_theme_color: string | null;
  pwa_background_color: string | null;
  pwa_icon_192: string | null;
  pwa_icon_512: string | null;
  // Menu Display
  menu_view_mode: MenuViewMode;
  // Placeholder Settings
  placeholder_type: PlaceholderType;
  placeholder_emoji: string;
  placeholder_gradient: string;
  placeholder_image: string | null;
  // Onboarding
  onboarding_variant: 'interactive' | 'quiz';
}

export interface TimeRange {
  open: string;
  close: string;
}

export interface BusinessHour {
  day: string;
  closed: boolean;
  ranges: TimeRange[];
  // Legacy fields for backwards compatibility
  open?: string;
  close?: string;
}

export interface FeatureToggles {
  onboarding_enabled: boolean;
  stories_enabled: boolean;
  mood_selector_enabled: boolean;
  swiper_enabled: boolean;
  favorites_enabled: boolean;
  reservations_enabled: boolean;
  search_enabled: boolean;
  allergen_filter_enabled: boolean;
  instagram_feed_enabled: boolean;
  google_reviews_enabled: boolean;
  takeaway_enabled: boolean;
}

export function useRestaurantConfig() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['restaurant-config'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('restaurant_config')
        .select('*')
        .limit(1)
        .single();
      
      if (error) throw error;
      return data as unknown as RestaurantConfig;
    },
    staleTime: 1000 * 60 * 2, // 2 minutes
    gcTime: 1000 * 60 * 10, // Keep in cache for 10 minutes
  });

  return {
    config: data,
    isLoading,
    error,
    refetch,
    features: data?.features || {
      onboarding_enabled: true,
      stories_enabled: true,
      mood_selector_enabled: true,
      swiper_enabled: true,
      favorites_enabled: true,
      reservations_enabled: true,
      search_enabled: true,
      allergen_filter_enabled: true,
      instagram_feed_enabled: false,
      google_reviews_enabled: false,
      takeaway_enabled: false,
    },
  };
}
