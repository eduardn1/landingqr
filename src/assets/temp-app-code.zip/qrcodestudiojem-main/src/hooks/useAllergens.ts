import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface DbAllergen {
  code: string;
  name_it: string;
  name_en: string;
  icon: string;
  color: string;
}

export function useAllergens() {
  const { data: allergens = [], isLoading } = useQuery({
    queryKey: ['allergens'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('allergens')
        .select('code, name_it, name_en, icon, color')
        .order('code');
      if (error) throw error;
      return data as DbAllergen[];
    },
    staleTime: 1000 * 60 * 30, // 30 minutes cache
  });

  return { allergens, isLoading };
}
