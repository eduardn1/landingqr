import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { useAdminAuth } from './useAdminAuth';

interface AdminNotification {
  id: string;
  user_id: string;
  title: string;
  body: string;
  type: string;
  is_read: boolean;
  action_url: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export function useAdminNotifications() {
  const { user, isAuthenticated } = useAuth();
  const { isAdmin } = useAdminAuth();
  const [notifications, setNotifications] = useState<AdminNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  const fetchNotifications = useCallback(async () => {
    if (!user || !isAuthenticated || !isAdmin) {
      setNotifications([]);
      setUnreadCount(0);
      setIsLoading(false);
      return;
    }

    try {
      // Fetch notifications for this admin user OR admin-level notifications (reservation, takeaway_order types)
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .or(`user_id.eq.${user.id},type.in.(reservation,takeaway_order,new_customer)`)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      const notifs = (data || []) as AdminNotification[];
      setNotifications(notifs);
      setUnreadCount(notifs.filter(n => !n.is_read).length);
    } catch (error) {
      console.error('Error fetching admin notifications:', error);
    } finally {
      setIsLoading(false);
    }
  }, [user, isAuthenticated, isAdmin]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  // Subscribe to realtime updates for admin notifications
  useEffect(() => {
    if (!user || !isAuthenticated || !isAdmin) return;

    const channel = supabase
      .channel('admin-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const newNotification = payload.new as AdminNotification;
          setNotifications(prev => [newNotification, ...prev]);
          setUnreadCount(prev => prev + 1);
          
          // Send browser notification if supported
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(newNotification.title, {
              body: newNotification.body,
              icon: '/favicon.ico',
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, isAuthenticated, isAdmin]);

  // Subscribe to new reservations (for admin alerts)
  useEffect(() => {
    if (!user || !isAuthenticated || !isAdmin) return;

    const channel = supabase
      .channel('new-reservations')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'reservations',
        },
        async (payload) => {
          const newReservation = payload.new as any;
          
          // Create a notification for the admin
          await supabase.from('notifications').insert({
            user_id: user.id,
            title: 'Nuova prenotazione!',
            body: `${newReservation.name} ha prenotato per ${newReservation.guests} persone il ${newReservation.reservation_date} alle ${newReservation.reservation_time}`,
            type: 'reservation',
            action_url: '/admin',
            metadata: { reservation_id: newReservation.id },
          });

          // Also show browser notification
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('Nuova prenotazione!', {
              body: `${newReservation.name} - ${newReservation.guests} persone`,
              icon: '/favicon.ico',
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, isAuthenticated, isAdmin]);

  // Subscribe to new takeaway orders (for admin alerts)
  useEffect(() => {
    if (!user || !isAuthenticated || !isAdmin) return;

    const channel = supabase
      .channel('new-takeaway-orders')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'takeaway_orders',
        },
        async (payload) => {
          const newOrder = payload.new as any;
          const orderType = newOrder.order_type === 'pickup' ? 'Ritiro' : 'Consegna';
          
          // Create a notification for the admin
          await supabase.from('notifications').insert({
            user_id: user.id,
            title: '🔔 Nuovo ordine asporto!',
            body: `${newOrder.customer_name} - ${orderType} - €${newOrder.total?.toFixed(2) || '0.00'}`,
            type: 'takeaway_order',
            action_url: '/admin',
            metadata: { order_id: newOrder.id, order_number: newOrder.order_number },
          });

          // Also show browser notification
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('🔔 Nuovo ordine asporto!', {
              body: `${newOrder.customer_name} - ${orderType} - €${newOrder.total?.toFixed(2) || '0.00'}`,
              icon: '/favicon.ico',
              tag: 'takeaway-order',
            });
          }
          
          // Play notification sound if available
          try {
            const audio = new Audio('/notification.mp3');
            audio.volume = 0.5;
            audio.play().catch(() => {});
          } catch (e) {
            // Audio not available
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, isAuthenticated, isAdmin]);

  // Subscribe to reservation status changes (for admin alerts)
  useEffect(() => {
    if (!user || !isAuthenticated || !isAdmin) return;

    const channel = supabase
      .channel('reservation-status-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'reservations',
        },
        async (payload) => {
          const updated = payload.new as any;
          const old = payload.old as any;
          
          // Only notify on actual status changes
          if (old.status === updated.status) return;
          
          const statusLabels: Record<string, string> = {
            confirmed: '✅ Confermata',
            cancelled: '❌ Annullata',
            rejected: '⛔ Rifiutata',
            completed: '✓ Completata',
            pending: '⏳ In attesa',
          };
          
          const statusLabel = statusLabels[updated.status] || updated.status;
          
          // Show toast notification in-app
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(`Prenotazione ${statusLabel}`, {
              body: `${updated.name} - ${updated.reservation_date} alle ${updated.reservation_time}`,
              icon: '/favicon.ico',
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, isAuthenticated, isAdmin]);

  // Subscribe to takeaway order status changes (for admin alerts)
  useEffect(() => {
    if (!user || !isAuthenticated || !isAdmin) return;

    const channel = supabase
      .channel('takeaway-status-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'takeaway_orders',
        },
        async (payload) => {
          const updated = payload.new as any;
          const old = payload.old as any;
          
          // Only notify on actual status changes
          if (old.status === updated.status) return;
          
          const statusLabels: Record<string, string> = {
            pending: '⏳ In attesa',
            accepted: '✅ Accettato',
            preparing: '👨‍🍳 In preparazione',
            ready: '🔔 Pronto',
            delivering: '🚗 In consegna',
            completed: '✓ Completato',
            rejected: '⛔ Rifiutato',
            cancelled: '❌ Annullato',
          };
          
          const statusLabel = statusLabels[updated.status] || updated.status;
          
          // Show browser notification
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(`Ordine ${updated.order_number} - ${statusLabel}`, {
              body: `${updated.customer_name} - €${updated.total?.toFixed(2)}`,
              icon: '/favicon.ico',
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, isAuthenticated, isAdmin]);

  const markAsRead = async (notificationId: string) => {
    try {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notificationId);

      setNotifications(prev =>
        prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    if (!user) return;

    try {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('user_id', user.id)
        .eq('is_read', false);

      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  const deleteNotification = async (notificationId: string) => {
    try {
      await supabase
        .from('notifications')
        .delete()
        .eq('id', notificationId);

      setNotifications(prev => {
        const notification = prev.find(n => n.id === notificationId);
        if (notification && !notification.is_read) {
          setUnreadCount(c => Math.max(0, c - 1));
        }
        return prev.filter(n => n.id !== notificationId);
      });
    } catch (error) {
      console.error('Error deleting notification:', error);
    }
  };

  const deleteAllNotifications = async () => {
    if (!user) return;

    try {
      await supabase
        .from('notifications')
        .delete()
        .or(`user_id.eq.${user.id},type.in.(reservation,takeaway_order,new_customer)`);

      setNotifications([]);
      setUnreadCount(0);
    } catch (error) {
      console.error('Error deleting all notifications:', error);
    }
  };

  return {
    notifications,
    unreadCount,
    isLoading,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    deleteAllNotifications,
    refetch: fetchNotifications,
  };
}
