import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface OnboardingStepOption {
  id: string;
  emoji: string;
  label: { it: string; en: string };
  gradient: string;
  filters?: {
    tags?: string[];
    is_featured?: boolean;
    is_seasonal?: boolean;
    random?: boolean;
    suggest_sharing?: boolean;
    max_prep_time?: number;
  };
}

export interface OnboardingStep {
  id: string;
  step_key: string;
  display_order: number;
  is_active: boolean;
  is_optional: boolean;
  question: { it: string; en: string };
  subtext: { it: string; en: string } | null;
  tip: { it: string; en: string } | null;
  options: OnboardingStepOption[];
  skip_button_text: { it: string; en: string };
}

export function useOnboardingSteps() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['onboarding-steps'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('onboarding_steps')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });
      
      if (error) throw error;
      return data as unknown as OnboardingStep[];
    },
    staleTime: 1000 * 60 * 5,
  });

  return {
    steps: data || [],
    isLoading,
    error,
  };
}
