import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export function useCacheManager() {
  const queryClient = useQueryClient();

  const clearAllCache = async () => {
    try {
      // Clear service worker caches first
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(
          cacheNames.map(cacheName => caches.delete(cacheName))
        );
      }

      // Clear localStorage cache keys (keep important ones including auth)
      const keysToKeep = ['app-theme', 'app-language', 'onboarding_preferences', 'sb-pnwdsfvjzwtcuiwpvkfj-auth-token'];
      const allKeys = Object.keys(localStorage);
      allKeys.forEach(key => {
        if (!keysToKeep.includes(key) && !key.startsWith('sb-')) {
          localStorage.removeItem(key);
        }
      });

      // Clear sessionStorage (except reservation draft)
      const reservationDraft = sessionStorage.getItem('reservation_draft');
      const reservationPending = sessionStorage.getItem('reservation_pending');
      sessionStorage.clear();
      if (reservationDraft) sessionStorage.setItem('reservation_draft', reservationDraft);
      if (reservationPending) sessionStorage.setItem('reservation_pending', reservationPending);

      // Reload service worker
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map(reg => reg.update()));
      }

      // Invalidate React Query cache but refetch critical data
      queryClient.clear();
      // Refetch user-related data to restore profile
      await queryClient.invalidateQueries({ queryKey: ['user-profile'] });

      return true;
    } catch (error) {
      console.error('Error clearing cache:', error);
      return false;
    }
  };

  const clearMenuCache = async () => {
    try {
      // Clear only menu-related queries
      queryClient.invalidateQueries({ queryKey: ['dishes'] });
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      queryClient.invalidateQueries({ queryKey: ['featured-dishes'] });
      queryClient.invalidateQueries({ queryKey: ['moods'] });

      // Clear supabase cache from service worker
      if ('caches' in window) {
        await caches.delete('supabase-cache');
      }

      return true;
    } catch (error) {
      console.error('Error clearing menu cache:', error);
      return false;
    }
  };

  const clearImageCache = async () => {
    try {
      if ('caches' in window) {
        await caches.delete('storage-cache');
        await caches.delete('image-cache');
      }
      return true;
    } catch (error) {
      console.error('Error clearing image cache:', error);
      return false;
    }
  };

  const getCacheSize = async (): Promise<string> => {
    try {
      if ('storage' in navigator && 'estimate' in navigator.storage) {
        const estimate = await navigator.storage.estimate();
        const usedMB = ((estimate.usage || 0) / (1024 * 1024)).toFixed(2);
        return `${usedMB} MB`;
      }
      return 'N/A';
    } catch {
      return 'N/A';
    }
  };

  return {
    clearAllCache,
    clearMenuCache,
    clearImageCache,
    getCacheSize,
  };
}
