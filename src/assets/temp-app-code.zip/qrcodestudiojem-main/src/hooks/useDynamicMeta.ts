import { useEffect } from 'react';
import { useRestaurantConfig } from './useRestaurantConfig';

export function useDynamicMeta() {
  const { config } = useRestaurantConfig();

  useEffect(() => {
    if (!config) return;

    // Update document title
    const title = config.meta_title || config.name || 'Menu Digitale';
    document.title = title;

    // Update meta description
    const description = config.meta_description || config.description?.it || 'Scopri il nostro menu digitale';
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', description);
    }

    // Update author
    const metaAuthor = document.querySelector('meta[name="author"]');
    if (metaAuthor) {
      metaAuthor.setAttribute('content', config.name || 'Il Locale');
    }

    // Update OG tags
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute('content', title);
    }

    const ogDescription = document.querySelector('meta[property="og:description"]');
    if (ogDescription) {
      ogDescription.setAttribute('content', description);
    }

    const ogImage = document.querySelector('meta[property="og:image"]');
    if (ogImage && config.og_image_url) {
      ogImage.setAttribute('content', config.og_image_url);
    }

    // Update Twitter tags
    const twitterTitle = document.querySelector('meta[name="twitter:title"]');
    if (twitterTitle) {
      twitterTitle.setAttribute('content', title);
    }

    const twitterDescription = document.querySelector('meta[name="twitter:description"]');
    if (twitterDescription) {
      twitterDescription.setAttribute('content', description);
    }

    const twitterImage = document.querySelector('meta[name="twitter:image"]');
    if (twitterImage && config.og_image_url) {
      twitterImage.setAttribute('content', config.og_image_url);
    }

  }, [config]);
}
