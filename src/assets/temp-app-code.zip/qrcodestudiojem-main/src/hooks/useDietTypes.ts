import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface DietType {
  code: string;
  name: { it: string; en: string };
  icon: string;
}

// Diet types are derived from distinct tags in dishes
export function useDietTypes() {
  const { data: dietTypes = [], isLoading } = useQuery({
    queryKey: ['diet-types'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('dishes')
        .select('tags')
        .not('tags', 'is', null);
      
      if (error) throw error;
      
      // Extract unique diet-related tags
      const allTags = new Set<string>();
      data.forEach(dish => {
        if (dish.tags) {
          dish.tags.forEach((tag: string) => allTags.add(tag));
        }
      });
      
      // Map known diet types
      const dietTypeMap: Record<string, DietType> = {
        'vegetarian': { code: 'vegetarian', name: { it: 'Vegetariano', en: 'Vegetarian' }, icon: '🥬' },
        'vegan': { code: 'vegan', name: { it: 'Vegano', en: 'Vegan' }, icon: '🌱' },
        'gluten-free': { code: 'gluten-free', name: { it: 'Senza Glutine', en: 'Gluten Free' }, icon: '🌾' },
        'lactose-free': { code: 'lactose-free', name: { it: 'Senza Lattosio', en: 'Lactose Free' }, icon: '🥛' },
      };
      
      const result: DietType[] = [];
      allTags.forEach(tag => {
        if (dietTypeMap[tag]) {
          result.push(dietTypeMap[tag]);
        }
      });
      
      return result;
    },
    staleTime: 1000 * 60 * 30, // 30 minutes cache
  });

  return { dietTypes, isLoading };
}
