import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface DeliveryZone {
  id: string;
  name: string;
  description: string | null;
  zip_codes: string[];
  delivery_fee: number;
  estimated_minutes: number;
  minimum_order: number;
  is_active: boolean;
  available_hours: any;
}

export function useDeliveryZones() {
  return useQuery({
    queryKey: ['delivery-zones'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('delivery_zones')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      return data as DeliveryZone[];
    },
  });
}

export function findZoneByZip(zones: DeliveryZone[], zipCode: string): DeliveryZone | null {
  return zones.find(zone => zone.zip_codes.includes(zipCode)) || null;
}
