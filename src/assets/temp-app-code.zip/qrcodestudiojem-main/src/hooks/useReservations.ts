import { useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuthSession } from './useAuthSession';
import { toast } from 'sonner';

interface Reservation {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  email: string | null;
  reservation_date: string;
  reservation_time: string;
  guests: number;
  notes: string | null;
  status: string;
  created_at: string;
  event_id: string | null;
}

// Schedule push notification reminder
function schedulePushReminder(reservation: {
  name: string;
  reservation_date: string;
  reservation_time: string;
  guests: number;
}) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;

  const reservationDateTime = new Date(reservation.reservation_date);
  const [hours, minutes] = reservation.reservation_time.split(':').map(Number);
  reservationDateTime.setHours(hours, minutes, 0, 0);

  // Schedule reminder 24 hours before
  const reminder24h = new Date(reservationDateTime.getTime() - 24 * 60 * 60 * 1000);
  const now = new Date();
  const msUntil24h = reminder24h.getTime() - now.getTime();

  if (msUntil24h > 0 && msUntil24h < 7 * 24 * 60 * 60 * 1000) {
    setTimeout(() => {
      new Notification('Promemoria: Prenotazione domani!', {
        body: `${reservation.name}, ti ricordiamo la tua prenotazione per domani alle ${reservation.reservation_time} (${reservation.guests} persone)`,
        icon: '/favicon.ico',
        tag: 'reservation-reminder-24h'
      });
    }, msUntil24h);
  }

  // Schedule reminder 2 hours before
  const reminder2h = new Date(reservationDateTime.getTime() - 2 * 60 * 60 * 1000);
  const msUntil2h = reminder2h.getTime() - now.getTime();

  if (msUntil2h > 0 && msUntil2h < 7 * 24 * 60 * 60 * 1000) {
    setTimeout(() => {
      new Notification('Promemoria: Prenotazione tra 2 ore!', {
        body: `${reservation.name}, la tua prenotazione è tra 2 ore alle ${reservation.reservation_time}`,
        icon: '/favicon.ico',
        tag: 'reservation-reminder-2h'
      });
    }, msUntil2h);
  }
}

export function useReservations() {
  const { user, isAuthenticated } = useAuthSession();
  const queryClient = useQueryClient();

  const { data: reservations = [], isLoading, refetch } = useQuery({
    queryKey: ['user-reservations', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('reservations')
        .select('*')
        .eq('user_id', user.id)
        .order('reservation_date', { ascending: false });
      
      if (error) throw error;
      
      // Schedule push reminders for upcoming confirmed reservations
      const upcomingConfirmed = (data || []).filter(
        r => r.status === 'confirmed' && new Date(r.reservation_date) >= new Date()
      );
      upcomingConfirmed.forEach(r => schedulePushReminder(r));
      
      return data as Reservation[];
    },
    enabled: !!user && isAuthenticated,
    staleTime: 1000 * 60, // 1 minute
  });

  const createReservation = useCallback(async (reservation: {
    name: string;
    phone: string;
    email?: string;
    reservation_date: string;
    reservation_time: string;
    guests: number;
    notes?: string;
    event_id?: string;
    event_name?: string;
  }) => {
    if (!user) {
      toast.error('Devi essere loggato per prenotare');
      return { error: 'Not authenticated', data: null };
    }

    const { event_name, ...reservationData } = reservation;

    const { data, error } = await supabase
      .from('reservations')
      .insert({
        user_id: user.id,
        ...reservationData,
        status: 'pending'
      })
      .select()
      .single();
    
    if (error) {
      toast.error('Errore durante la prenotazione');
      return { error, data: null };
    }

    // Invalidate cache to refetch
    queryClient.invalidateQueries({ queryKey: ['user-reservations', user.id] });
    toast.success('Prenotazione inviata! Riceverai conferma a breve.');
    
    // Immediate notification
    if ('Notification' in window && Notification.permission === 'granted') {
      const notificationBody = reservation.event_id && event_name
        ? `${reservation.name}, ti aspettiamo per "${event_name}" il ${new Date(reservation.reservation_date).toLocaleDateString('it-IT')} alle ${reservation.reservation_time}`
        : `${reservation.name}, ti aspettiamo il ${new Date(reservation.reservation_date).toLocaleDateString('it-IT')} alle ${reservation.reservation_time}`;
      
      new Notification('Prenotazione inviata!', {
        body: notificationBody,
        icon: '/favicon.ico'
      });
    }
    
    // Schedule push reminders
    schedulePushReminder(reservation);

    // Send WhatsApp notifications in the background (don't block UI)
    const sendWhatsAppNotifications = async () => {
      try {
        const formattedDate = new Date(reservation.reservation_date).toLocaleDateString('it-IT', {
          weekday: 'long',
          day: 'numeric',
          month: 'long'
        });
        
        // Get restaurant config for owner's WhatsApp number
        const { data: config } = await supabase
          .from('restaurant_config')
          .select('whatsapp, name')
          .single();
        
        // Determine template based on whether this is an event reservation
        const isEventReservation = !!reservation.event_id && !!event_name;
        const customerTemplate = isEventReservation ? 'event_reservation_received' : 'reservation_received';
        const ownerTemplate = isEventReservation ? 'new_event_reservation_owner' : 'new_reservation_owner';
        
        // Build variables based on reservation type
        const customerVariables: Record<string, string> = {
          name: reservation.name,
          date: formattedDate,
          time: reservation.reservation_time,
          guests: reservation.guests.toString()
        };
        
        if (isEventReservation && event_name) {
          customerVariables.event_name = event_name;
        }
        
        // Send confirmation to customer
        await supabase.functions.invoke('send-whatsapp', {
          body: {
            phone: reservation.phone,
            templateKey: customerTemplate,
            variables: customerVariables
          }
        });
        
        // Send notification to restaurant owner (with 5.5s delay for WaSender rate limit)
        if (config?.whatsapp) {
          await new Promise(resolve => setTimeout(resolve, 5500));
          
          const ownerVariables: Record<string, string> = {
            name: reservation.name,
            phone: reservation.phone,
            date: formattedDate,
            time: reservation.reservation_time,
            guests: reservation.guests.toString(),
            notes: reservation.notes || 'Nessuna nota'
          };
          
          if (isEventReservation && event_name) {
            ownerVariables.event_name = event_name;
          }
          
          await supabase.functions.invoke('send-whatsapp', {
            body: {
              phone: config.whatsapp,
              templateKey: ownerTemplate,
              variables: ownerVariables
            }
          });
        }
      } catch (whatsappError) {
        console.error('Failed to send WhatsApp notifications:', whatsappError);
      }
    };
    
    // Fire and forget - don't await
    sendWhatsAppNotifications();

    return { error: null, data };
  }, [user, queryClient]);

  const cancelReservation = useCallback(async (reservationId: string) => {
    if (!user) return { error: 'Not authenticated' };

    const { error } = await supabase
      .from('reservations')
      .update({ status: 'cancelled' })
      .eq('id', reservationId)
      .eq('user_id', user.id);
    
    if (error) {
      toast.error('Errore durante la cancellazione');
      return { error };
    }

    queryClient.invalidateQueries({ queryKey: ['user-reservations', user.id] });
    toast.success('Prenotazione cancellata');
    return { error: null };
  }, [user, queryClient]);

  const upcomingReservations = reservations.filter(
    r => r.status !== 'cancelled' && new Date(r.reservation_date) >= new Date()
  );

  return {
    reservations,
    upcomingReservations,
    createReservation,
    cancelReservation,
    refetch,
    isLoading,
    isAuthenticated: !!user && isAuthenticated
  };
}
