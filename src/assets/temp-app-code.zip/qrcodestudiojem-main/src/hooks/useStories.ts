import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface StorySlide {
  id: string;
  type: 'image' | 'video';
  url: string;
  duration: number;
  caption?: { it: string; en: string };
  subtitle?: { it: string; en: string };
  link_dish_id?: string | null;
}

export interface Story {
  id: string;
  story_key: string;
  display_order: number;
  is_active: boolean;
  icon: string | null;
  label: { it: string; en: string };
  gradient: string;
  thumbnail_url: string | null;
  has_new: boolean;
  slides: StorySlide[];
  publish_at: string | null;
  expires_at: string | null;
}

export function useStories() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['stories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('stories')
        .select('*')
        .order('display_order', { ascending: true });
      
      if (error) throw error;
      return data as unknown as Story[];
    },
    staleTime: 1000 * 60 * 5,
  });

  return {
    stories: data || [],
    isLoading,
    error,
  };
}
