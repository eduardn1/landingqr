import { useEffect } from 'react';
import { useRestaurantConfig } from './useRestaurantConfig';

/**
 * Hook that dynamically generates and updates the PWA manifest based on database settings
 */
export function useDynamicManifest() {
  const { config, isLoading } = useRestaurantConfig();

  useEffect(() => {
    if (isLoading || !config) return;

    // Generate manifest from config
    const manifest = {
      name: config.pwa_name || config.name || 'Menu Digitale',
      short_name: config.pwa_short_name || 'Menu',
      description: config.pwa_description || 'Menu digitale con prenotazioni, preferiti e altro',
      theme_color: config.pwa_theme_color || '#722F37',
      background_color: config.pwa_background_color || '#0a0a0a',
      display: 'standalone' as const,
      orientation: 'portrait' as const,
      scope: '/',
      start_url: '/',
      icons: [
        {
          src: config.pwa_icon_192 || '/pwa-192x192.png',
          sizes: '192x192',
          type: 'image/png'
        },
        {
          src: config.pwa_icon_512 || '/pwa-512x512.png',
          sizes: '512x512',
          type: 'image/png'
        },
        {
          src: config.pwa_icon_512 || '/pwa-512x512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'maskable'
        }
      ]
    };

    // Create blob and update manifest link
    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
    const manifestUrl = URL.createObjectURL(blob);

    // Find existing manifest link or create one
    let manifestLink = document.querySelector('link[rel="manifest"]') as HTMLLinkElement;
    if (manifestLink) {
      manifestLink.href = manifestUrl;
    } else {
      manifestLink = document.createElement('link');
      manifestLink.rel = 'manifest';
      manifestLink.href = manifestUrl;
      document.head.appendChild(manifestLink);
    }

    // Update theme-color meta tag
    let themeColorMeta = document.querySelector('meta[name="theme-color"]') as HTMLMetaElement;
    if (themeColorMeta) {
      themeColorMeta.content = config.pwa_theme_color || '#722F37';
    } else {
      themeColorMeta = document.createElement('meta');
      themeColorMeta.name = 'theme-color';
      themeColorMeta.content = config.pwa_theme_color || '#722F37';
      document.head.appendChild(themeColorMeta);
    }

    // Update apple-touch-icon
    let appleTouchIcon = document.querySelector('link[rel="apple-touch-icon"]') as HTMLLinkElement;
    if (appleTouchIcon) {
      appleTouchIcon.href = config.pwa_icon_192 || '/pwa-192x192.png';
    }

    // Update apple-mobile-web-app-title
    let appleTitle = document.querySelector('meta[name="apple-mobile-web-app-title"]') as HTMLMetaElement;
    if (appleTitle) {
      appleTitle.content = config.pwa_short_name || 'Menu';
    }

    // Cleanup blob URL on unmount or re-render
    return () => {
      URL.revokeObjectURL(manifestUrl);
    };
  }, [config, isLoading]);
}
