import { useState, useEffect, useCallback } from 'react';
import { useAuth } from './useAuth';
import type { OnboardingOption, OnboardingFilters } from '@/components/client/ConversationalOnboarding';

const SESSION_STORAGE_KEY = 'onboarding_answers';

export function useOnboardingPreferences() {
  const { user, isAuthenticated } = useAuth();
  const [preferences, setPreferences] = useState<Record<string, OnboardingOption> | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load preferences from sessionStorage on mount
  useEffect(() => {
    loadPreferences();
  }, []);

  const loadPreferences = () => {
    setIsLoading(true);
    try {
      const stored = sessionStorage.getItem(SESSION_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        setPreferences(parsed);
      }
    } catch (e) {
      console.error('Failed to load onboarding preferences:', e);
    }
    setIsLoading(false);
  };

  const savePreferences = useCallback((answers: Record<string, OnboardingOption>) => {
    // Save to sessionStorage for current session persistence
    try {
      sessionStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(answers));
    } catch (e) {
      console.error('Failed to save onboarding preferences:', e);
    }
    // Update state immediately
    setPreferences(answers);
  }, []);

  const clearPreferences = useCallback(() => {
    sessionStorage.removeItem(SESSION_STORAGE_KEY);
    setPreferences(null);
  }, []);

  // Check if a dish matches the user's preferences
  const isDishRecommended = useCallback((dish: {
    tags: string[];
    isFeatured: boolean;
    isSeasonal: boolean;
  }): boolean => {
    if (!preferences || Object.keys(preferences).length === 0) return false;

    const allFilters: OnboardingFilters[] = Object.values(preferences)
      .filter(answer => answer && answer.filters)
      .map(answer => answer.filters!);

    // If user completed quiz but no filters, recommend featured dishes
    if (allFilters.length === 0) {
      return dish.isFeatured;
    }

    // Collect all tags from preferences
    const allTags = allFilters
      .filter(f => f.tags)
      .flatMap(f => f.tags || []);

    // Check for featured/seasonal preferences
    const prefersFeatured = allFilters.some(f => f.is_featured);
    const prefersSeasonal = allFilters.some(f => f.is_seasonal);

    // Normalize tags for comparison (lowercase)
    const normalizedDishTags = dish.tags.map(t => t.toLowerCase());
    const normalizedPrefTags = allTags.map(t => t.toLowerCase());

    // Dish is recommended if:
    // 1. It matches any preferred tag (case-insensitive, partial match)
    // 2. OR it's featured and user prefers featured
    // 3. OR it's seasonal and user prefers seasonal
    // 4. OR it's featured (fallback - always show featured for completed quiz)
    const matchesTags = normalizedPrefTags.length > 0 && normalizedPrefTags.some(prefTag => 
      normalizedDishTags.some(dishTag => 
        dishTag.includes(prefTag) || prefTag.includes(dishTag)
      )
    );
    const matchesFeatured = prefersFeatured && dish.isFeatured;
    const matchesSeasonal = prefersSeasonal && dish.isSeasonal;

    // If any specific match, return true, otherwise fallback to featured
    if (matchesTags || matchesFeatured || matchesSeasonal) {
      return true;
    }

    // Fallback: if quiz completed, show featured dishes
    return dish.isFeatured;
  }, [preferences]);

  // Get sharing suggestion based on social context
  const shouldSuggestSharing = useCallback((): boolean => {
    if (!preferences) return false;
    const socialAnswer = preferences['social'];
    return socialAnswer?.filters?.suggest_sharing === true;
  }, [preferences]);

  return {
    preferences,
    isLoading,
    savePreferences,
    clearPreferences,
    isDishRecommended,
    shouldSuggestSharing,
    hasPreferences: preferences !== null && Object.keys(preferences).length > 0
  };
}
