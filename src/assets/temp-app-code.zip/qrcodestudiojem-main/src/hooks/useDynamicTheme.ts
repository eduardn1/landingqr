import { useEffect, useMemo } from 'react';
import { useRestaurantConfig } from './useRestaurantConfig';
import { 
  isGradient, 
  extractPrimaryFromGradient, 
  extractColorsFromGradient,
  tailwindGradientToCss 
} from '@/lib/gradientUtils';

export function useDynamicTheme() {
  const { config, isLoading } = useRestaurantConfig();

  // Extract gradient colors for templates that use them
  const gradientColors = useMemo(() => {
    if (!config?.color_accent) return null;
    
    if (isGradient(config.color_accent)) {
      const hexColors = extractColorsFromGradient(config.color_accent);
      if (hexColors.length > 0) {
        return hexColors;
      }
    }
    return null;
  }, [config?.color_accent]);

  // Get CSS gradient string
  const cssGradient = useMemo(() => {
    if (!config?.color_accent || !isGradient(config.color_accent)) return null;
    return tailwindGradientToCss(config.color_accent);
  }, [config?.color_accent]);

  useEffect(() => {
    if (!config || isLoading) return;

    const root = document.documentElement;

    // Apply accent color from config - handle both HSL and gradient formats
    if (config.color_accent) {
      const accentValue = config.color_accent.trim();
      
      if (isGradient(accentValue)) {
        // Store gradient class for components that support it (Tailwind format)
        root.style.setProperty('--accent-gradient-class', accentValue);
        
        // Store CSS gradient for inline styles
        const cssGrad = tailwindGradientToCss(accentValue);
        if (cssGrad) {
          root.style.setProperty('--accent-gradient', cssGrad);
        }
        
        // Extract fallback HSL for standard accent usage (first color of gradient)
        const fallbackHsl = extractPrimaryFromGradient(accentValue);
        
        if (fallbackHsl) {
          // Apply to accent CSS variable
          root.style.setProperty('--accent', fallbackHsl);
        }
      } else {
        // Standard HSL value - apply directly
        root.style.setProperty('--accent', accentValue);
        root.style.setProperty('--accent-gradient', '');
        root.style.setProperty('--accent-gradient-class', '');
      }
    }

    // Apply fonts
    if (config.font_heading) {
      root.style.setProperty('--font-heading', config.font_heading);
    }
    if (config.font_body) {
      root.style.setProperty('--font-body', config.font_body);
    }

    // Update document title if meta_title is set
    if (config.meta_title) {
      document.title = config.meta_title;
    } else if (config.name) {
      document.title = config.name;
    }

    // Update meta description
    if (config.meta_description) {
      let metaDesc = document.querySelector('meta[name="description"]');
      if (!metaDesc) {
        metaDesc = document.createElement('meta');
        metaDesc.setAttribute('name', 'description');
        document.head.appendChild(metaDesc);
      }
      metaDesc.setAttribute('content', config.meta_description);
    }

    // Update OG tags for social sharing
    const updateOgTag = (property: string, content: string | null) => {
      if (!content) return;
      let tag = document.querySelector(`meta[property="${property}"]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('property', property);
        document.head.appendChild(tag);
      }
      tag.setAttribute('content', content);
    };

    updateOgTag('og:title', config.meta_title || config.name);
    updateOgTag('og:description', config.meta_description);
    updateOgTag('og:image', config.og_image_url);
    updateOgTag('og:type', 'website');
    updateOgTag('og:site_name', config.name);

  }, [config, isLoading]);

  return { 
    config, 
    isLoading, 
    gradientColors,
    cssGradient,
    hasGradient: isGradient(config?.color_accent)
  };
}
