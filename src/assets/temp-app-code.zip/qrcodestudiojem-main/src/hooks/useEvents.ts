import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface DbEvent {
  id: string;
  title_it: string;
  title_en: string | null;
  description_it: string | null;
  description_en: string | null;
  event_type: 'dj_set' | 'live_music' | 'karaoke' | 'aperitivo' | 'degustazione' | 'altro';
  event_date: string;
  start_time: string;
  end_time: string | null;
  image_url: string | null;
  entry_price: number | null;
  entry_price_note_it: string | null;
  entry_price_note_en: string | null;
  is_active: boolean;
  is_featured: boolean;
  created_at: string;
  updated_at: string;
}

export function useEvents() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['events'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .eq('is_active', true)
        .gte('event_date', new Date().toISOString().split('T')[0])
        .order('event_date', { ascending: true })
        .order('start_time', { ascending: true });

      if (error) throw error;
      return data as DbEvent[];
    },
    staleTime: 1000 * 60 * 5,
  });

  return {
    events: data || [],
    isLoading,
    error,
    refetch,
  };
}

export function useAllEvents() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['events-all'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .order('event_date', { ascending: false });

      if (error) throw error;
      return data as DbEvent[];
    },
  });

  return {
    events: data || [],
    isLoading,
    error,
    refetch,
  };
}

export function useEventMutations() {
  const queryClient = useQueryClient();

  const createEvent = useMutation({
    mutationFn: async (event: Omit<DbEvent, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('events')
        .insert([event])
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      queryClient.invalidateQueries({ queryKey: ['events-all'] });
    },
  });

  const updateEvent = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<DbEvent> & { id: string }) => {
      const { data, error } = await supabase
        .from('events')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      queryClient.invalidateQueries({ queryKey: ['events-all'] });
    },
  });

  const deleteEvent = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('events')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
      queryClient.invalidateQueries({ queryKey: ['events-all'] });
    },
  });

  return { createEvent, updateEvent, deleteEvent };
}
