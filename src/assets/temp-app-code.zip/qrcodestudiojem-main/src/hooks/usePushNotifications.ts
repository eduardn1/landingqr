import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';

export function usePushNotifications() {
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    if ('Notification' in window) {
      setIsSupported(true);
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = useCallback(async () => {
    if (!isSupported) {
      toast.error('Le notifiche push non sono supportate su questo browser');
      return false;
    }

    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      
      if (result === 'granted') {
        toast.success('Notifiche push attivate!');
        // Send a test notification
        new Notification('Notifiche attivate!', {
          body: 'Riceverai aggiornamenti sulle tue prenotazioni',
          icon: '/favicon.ico'
        });
        return true;
      } else if (result === 'denied') {
        toast.error('Notifiche push bloccate. Puoi attivarle dalle impostazioni del browser.');
        return false;
      }
      return false;
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      toast.error('Errore durante l\'attivazione delle notifiche');
      return false;
    }
  }, [isSupported]);

  const sendNotification = useCallback((title: string, options?: NotificationOptions) => {
    if (!isSupported || permission !== 'granted') {
      return false;
    }

    try {
      new Notification(title, {
        icon: '/favicon.ico',
        ...options
      });
      return true;
    } catch (error) {
      console.error('Error sending notification:', error);
      return false;
    }
  }, [isSupported, permission]);

  const scheduleReminder = useCallback((reservationDate: Date, reservationTime: string, name: string) => {
    if (!isSupported || permission !== 'granted') return;

    // Calculate time until reservation (reminder 2 hours before)
    const reminderTime = new Date(reservationDate);
    const [hours, minutes] = reservationTime.split(':').map(Number);
    reminderTime.setHours(hours - 2, minutes, 0, 0);

    const now = new Date();
    const msUntilReminder = reminderTime.getTime() - now.getTime();

    if (msUntilReminder > 0) {
      setTimeout(() => {
        sendNotification('Promemoria prenotazione', {
          body: `${name}, la tua prenotazione è tra 2 ore alle ${reservationTime}`,
          tag: 'reservation-reminder'
        });
      }, msUntilReminder);
    }
  }, [isSupported, permission, sendNotification]);

  return {
    isSupported,
    permission,
    isEnabled: permission === 'granted',
    requestPermission,
    sendNotification,
    scheduleReminder
  };
}
