import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuthSession } from './useAuthSession';

export interface TakeAwayOrder {
  id: string;
  order_number: string;
  user_id: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string | null;
  order_type: 'pickup' | 'delivery';
  items: any[];
  subtotal: number;
  delivery_fee: number;
  discount: number;
  promo_code: string | null;
  loyalty_points_used: number;
  total: number;
  status: string;
  pickup_time: string | null;
  pickup_actual_time: string | null;
  delivery_address: any;
  delivery_zone_id: string | null;
  delivery_time_estimate: string | null;
  delivery_actual_time: string | null;
  driver_id: string | null;
  special_notes: string | null;
  preparation_time: number | null;
  estimated_ready_at: string | null;
  rating: number | null;
  rating_comment: string | null;
  rated_at: string | null;
  loyalty_points_earned: number;
  created_at: string;
  updated_at: string;
  accepted_at: string | null;
  ready_at: string | null;
  completed_at: string | null;
  // Joined data
  takeaway_drivers?: any;
  order_ratings?: any[];
}

export function useMyTakeAwayOrders() {
  const { user } = useAuthSession();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ['my-takeaway-orders', user?.id],
    queryFn: async () => {
      if (!user) return [];

      const { data, error } = await supabase
        .from('takeaway_orders')
        .select('*, order_ratings(*)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as unknown as TakeAwayOrder[];
    },
    enabled: !!user,
    staleTime: 1000 * 60, // 1 minute
  });

  // Subscribe to realtime updates for order status changes
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('my-orders-realtime')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'takeaway_orders',
          filter: `user_id=eq.${user.id}`,
        },
        () => {
          // Refetch orders when any of user's orders change
          queryClient.invalidateQueries({ queryKey: ['my-takeaway-orders', user.id] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, queryClient]);

  return query;
}

export function useTakeAwayOrder(orderId: string) {
  return useQuery({
    queryKey: ['takeaway-order', orderId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('takeaway_orders')
        .select('*, takeaway_drivers(*), order_ratings(*)')
        .eq('id', orderId)
        .single();

      if (error) throw error;
      return data as unknown as TakeAwayOrder;
    },
    enabled: !!orderId,
  });
}

export function useCreateTakeAwayOrder() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (orderData: {
      user_id: string;
      customer_name: string;
      customer_phone: string;
      order_type: 'pickup' | 'delivery';
      items: any[];
      subtotal: number;
      delivery_fee?: number;
      total: number;
      pickup_time?: string | null;
      delivery_address?: any;
      delivery_zone_id?: string | null;
      special_notes?: string | null;
      preparation_time?: number | null;
      estimated_ready_at?: string | null;
    }) => {
      const { data, error } = await supabase
        .from('takeaway_orders')
        .insert(orderData)
        .select()
        .single();

      if (error) throw error;
      return data as unknown as TakeAwayOrder;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-takeaway-orders'] });
    },
  });
}

// Admin hooks
export function useAdminTakeAwayOrders(date?: string) {
  const selectedDate = date || new Date().toISOString().split('T')[0];

  return useQuery({
    queryKey: ['admin-takeaway-orders', selectedDate],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('takeaway_orders')
        .select('*, takeaway_drivers(*)')
        .gte('created_at', `${selectedDate}T00:00:00`)
        .lte('created_at', `${selectedDate}T23:59:59`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as TakeAwayOrder[];
    },
    refetchInterval: 5000, // Refresh every 5 seconds
  });
}

export function useUpdateTakeAwayOrderStatus() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      orderId,
      status,
      additionalData = {},
      sendWhatsApp = true,
    }: {
      orderId: string;
      status: string;
      additionalData?: Record<string, any>;
      sendWhatsApp?: boolean;
    }) => {
      const updateData: Record<string, any> = {
        status,
        updated_at: new Date().toISOString(),
        ...additionalData,
      };

      // Set timestamps based on status
      if (status === 'accepted') {
        updateData.accepted_at = new Date().toISOString();
      } else if (status === 'ready') {
        updateData.ready_at = new Date().toISOString();
      } else if (status === 'completed') {
        updateData.completed_at = new Date().toISOString();
      }

      const { data, error } = await supabase
        .from('takeaway_orders')
        .update(updateData)
        .eq('id', orderId)
        .select('*, takeaway_drivers(*)')
        .single();

      if (error) throw error;

      // Send WhatsApp notification (don't block status update on notification failure)
      if (sendWhatsApp && data) {
        const templateMap: Record<string, string> = {
          accepted: 'takeaway_order_confirmed',
          ready: 'takeaway_order_ready',
          delivering: 'takeaway_order_delivering',
        };

        const templateKey = templateMap[status];
        if (templateKey) {
          const variables: Record<string, string> = {
            customer_name: data.customer_name,
            order_number: data.order_number || data.id.slice(0, 8),
            total: data.total?.toFixed(2) || '0.00',
          };

          if (status === 'accepted') {
            const readyAt = data.estimated_ready_at 
              ? new Date(data.estimated_ready_at).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })
              : '~20 min';
            variables.ready_time = readyAt;
          }

          if (status === 'delivering' && data.takeaway_drivers) {
            variables.driver_name = data.takeaway_drivers.name || 'Il nostro driver';
            variables.driver_phone = data.takeaway_drivers.phone || '';
          }

          // Fire and forget - don't block status update on WhatsApp failure
          supabase.functions.invoke('send-whatsapp', {
            body: {
              phone: data.customer_phone,
              templateKey,
              variables,
              recipientName: data.customer_name,
            },
          }).catch((err) => {
            console.error('WhatsApp notification failed:', err);
          });
        }
      }

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-takeaway-orders'] });
      queryClient.invalidateQueries({ queryKey: ['my-takeaway-orders'] });
      queryClient.invalidateQueries({ queryKey: ['takeaway-order'] });
    },
  });
}
