import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export function usePrefetch() {
  const queryClient = useQueryClient();

  const prefetchMenu = () => {
    // Prefetch categories
    queryClient.prefetchQuery({
      queryKey: ['categories'],
      queryFn: async () => {
        const { data } = await supabase
          .from('categories')
          .select('*')
          .eq('is_active', true)
          .order('display_order');
        return data || [];
      },
      staleTime: 5 * 60 * 1000,
    });

    // Prefetch dishes
    queryClient.prefetchQuery({
      queryKey: ['dishes'],
      queryFn: async () => {
        const { data } = await supabase
          .from('dishes')
          .select('*, dish_allergens(allergen_code)')
          .eq('is_available', true)
          .order('display_order');
        return data || [];
      },
      staleTime: 5 * 60 * 1000,
    });
  };

  const prefetchHome = () => {
    prefetchMenu();
    
    // Prefetch moods - rarely changes
    queryClient.prefetchQuery({
      queryKey: ['moods'],
      queryFn: async () => {
        const { data } = await supabase
          .from('moods')
          .select('*')
          .eq('is_active', true)
          .order('display_order');
        return data || [];
      },
      staleTime: Infinity, // Static data, never stale
    });

    // Prefetch stories
    queryClient.prefetchQuery({
      queryKey: ['stories'],
      queryFn: async () => {
        const { data } = await supabase
          .from('stories')
          .select('*')
          .eq('is_active', true)
          .order('display_order');
        return data || [];
      },
      staleTime: 30 * 60 * 1000, // 30 minutes
    });
    
    // Prefetch home sections config - rarely changes
    queryClient.prefetchQuery({
      queryKey: ['home-sections'],
      queryFn: async () => {
        const { data } = await supabase
          .from('home_sections')
          .select('*')
          .eq('is_active', true)
          .order('display_order');
        return data || [];
      },
      staleTime: Infinity,
    });
    
    // Prefetch restaurant config - rarely changes
    queryClient.prefetchQuery({
      queryKey: ['restaurant-config'],
      queryFn: async () => {
        const { data } = await supabase
          .from('restaurant_config')
          .select('*')
          .single();
        return data;
      },
      staleTime: Infinity,
    });
  };

  const prefetchProfile = () => {
    // Profile data is fetched via useAuth which uses session
    // Prefetch allergens for profile settings
    queryClient.prefetchQuery({
      queryKey: ['allergens'],
      queryFn: async () => {
        const { data } = await supabase.from('allergens').select('*');
        return data || [];
      },
      staleTime: 10 * 60 * 1000,
    });
  };

  const prefetchReservations = () => {
    // Prefetch business hours for reservation form
    queryClient.prefetchQuery({
      queryKey: ['restaurant-config'],
      queryFn: async () => {
        const { data } = await supabase
          .from('restaurant_config')
          .select('*')
          .single();
        return data;
      },
      staleTime: 5 * 60 * 1000,
    });

    // Prefetch closed dates
    queryClient.prefetchQuery({
      queryKey: ['closed-dates'],
      queryFn: async () => {
        const { data } = await supabase.from('closed_dates').select('*');
        return data || [];
      },
      staleTime: 5 * 60 * 1000,
    });
  };

  const prefetchFavorites = () => {
    prefetchMenu(); // Favorites need dish data
  };

  return {
    prefetchMenu,
    prefetchHome,
    prefetchProfile,
    prefetchReservations,
    prefetchFavorites,
  };
}
