import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface Location {
  lat: number;
  lng: number;
  timestamp: Date;
}

export function useDriverLocation(driverId: string | null) {
  const [location, setLocation] = useState<Location | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const watchIdRef = useRef<number | null>(null);

  const startTracking = useCallback(async () => {
    if (!driverId || !navigator.geolocation) {
      setError('Geolocalizzazione non supportata');
      return;
    }

    setIsTracking(true);
    setError(null);

    // Set driver as online
    await supabase
      .from('takeaway_drivers')
      .update({ is_online: true })
      .eq('id', driverId);

    watchIdRef.current = navigator.geolocation.watchPosition(
      async (position) => {
        const newLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          timestamp: new Date(),
        };
        setLocation(newLocation);

        // Update driver location in database
        await supabase
          .from('takeaway_drivers')
          .update({
            current_lat: newLocation.lat,
            current_lng: newLocation.lng,
            location_updated_at: newLocation.timestamp.toISOString(),
          })
          .eq('id', driverId);
      },
      (err) => {
        console.error('Geolocation error:', err);
        setError(err.message);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 5000,
      }
    );
  }, [driverId]);

  const stopTracking = useCallback(async () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }

    if (driverId) {
      await supabase
        .from('takeaway_drivers')
        .update({ is_online: false })
        .eq('id', driverId);
    }

    setIsTracking(false);
    setLocation(null);
  }, [driverId]);

  const updateOrderLocation = useCallback(async (orderId: string) => {
    if (!location) return;

    await supabase
      .from('takeaway_orders')
      .update({
        driver_lat: location.lat,
        driver_lng: location.lng,
      })
      .eq('id', orderId);
  }, [location]);

  // Calculate ETA based on distance (simplified)
  const calculateETA = useCallback((destLat: number, destLng: number): number => {
    if (!location) return 30; // Default 30 min

    // Haversine formula for distance
    const R = 6371; // Earth's radius in km
    const dLat = (destLat - location.lat) * Math.PI / 180;
    const dLng = (destLng - location.lng) * Math.PI / 180;
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(location.lat * Math.PI / 180) * Math.cos(destLat * Math.PI / 180) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;

    // Assume average speed of 25 km/h in city
    const etaMinutes = Math.round((distance / 25) * 60);
    return Math.max(5, etaMinutes); // Minimum 5 minutes
  }, [location]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  return {
    location,
    isTracking,
    error,
    startTracking,
    stopTracking,
    updateOrderLocation,
    calculateETA,
  };
}
