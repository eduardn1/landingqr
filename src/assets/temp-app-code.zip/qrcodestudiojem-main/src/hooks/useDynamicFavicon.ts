import { useEffect } from 'react';
import { useRestaurantConfig } from './useRestaurantConfig';

export function useDynamicFavicon() {
  const { config } = useRestaurantConfig();

  useEffect(() => {
    if (config?.favicon_url) {
      // Update favicon
      let link: HTMLLinkElement | null = document.querySelector("link[rel~='icon']");
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.head.appendChild(link);
      }
      link.href = config.favicon_url;
    }

    // Update meta title if available
    if (config?.meta_title) {
      document.title = config.meta_title;
    } else if (config?.name) {
      document.title = config.name;
    }

    // Update meta description
    if (config?.meta_description) {
      let meta: HTMLMetaElement | null = document.querySelector("meta[name='description']");
      if (!meta) {
        meta = document.createElement('meta');
        meta.name = 'description';
        document.head.appendChild(meta);
      }
      meta.content = config.meta_description;
    }
  }, [config?.favicon_url, config?.meta_title, config?.meta_description, config?.name]);
}
