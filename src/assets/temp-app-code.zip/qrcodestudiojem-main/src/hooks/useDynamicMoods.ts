import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface DynamicMood {
  id: string;
  mood_key: string;
  display_order: number;
  is_active: boolean;
  emoji: string;
  label: { it: string; en: string };
  gradient: string;
  filters: {
    tags?: string[];
    is_featured?: boolean;
    is_seasonal?: boolean;
    max_prep_time?: number;
  };
}

export function useDynamicMoods() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['moods'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('moods')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });
      
      if (error) throw error;
      return data as unknown as DynamicMood[];
    },
    staleTime: 1000 * 60 * 5,
  });

  return {
    moods: data || [],
    isLoading,
    error,
  };
}
