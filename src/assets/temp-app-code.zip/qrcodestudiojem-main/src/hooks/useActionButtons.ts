import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface ActionButton {
  id: string;
  button_key: string;
  label: { it: string; en: string };
  subtitle: { it: string; en: string } | null;
  icon: string;
  action_type: 'internal' | 'modal' | 'external';
  action_value: string | null;
  gradient: string | null;
  button_color: string | null;
  display_order: number;
  is_active: boolean;
  is_visible_mobile: boolean;
  is_visible_desktop: boolean;
  size: 'small' | 'medium' | 'large';
  col_span: number;
  // New styling fields
  display_style: 'card' | 'button' | 'pill' | 'minimal' | null;
  bg_color: string | null;
  bg_opacity: number | null;
  label_color: string | null;
  icon_color: string | null;
  border_color: string | null;
}

export function useActionButtons() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['action-buttons'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('action_buttons')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (error) throw error;
      return data as unknown as ActionButton[];
    },
    staleTime: 1000 * 60 * 5,
  });

  return {
    buttons: data || [],
    isLoading,
    error,
    refetch,
  };
}

export function useAllActionButtons() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['action-buttons-all'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('action_buttons')
        .select('*')
        .order('display_order', { ascending: true });

      if (error) throw error;
      return data as unknown as ActionButton[];
    },
  });

  return {
    buttons: data || [],
    isLoading,
    error,
    refetch,
  };
}
