import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface Promo {
  id: string;
  title_it: string;
  title_en: string | null;
  description_it: string | null;
  description_en: string | null;
  image_url: string;
  link_url: string | null;
  link_type: string;
  display_order: number;
  is_active: boolean;
  starts_at: string | null;
  expires_at: string | null;
  created_at: string;
  updated_at: string;
}

export function usePromos() {
  const queryClient = useQueryClient();

  const { data: promos = [], isLoading } = useQuery({
    queryKey: ['promos'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('promos')
        .select('*')
        .order('display_order', { ascending: true });
      if (error) throw error;
      return data as Promo[];
    }
  });

  const { data: activePromos = [] } = useQuery({
    queryKey: ['active-promos'],
    queryFn: async () => {
      const now = new Date().toISOString();
      const { data, error } = await supabase
        .from('promos')
        .select('*')
        .eq('is_active', true)
        .or(`starts_at.is.null,starts_at.lte.${now}`)
        .or(`expires_at.is.null,expires_at.gt.${now}`)
        .order('display_order', { ascending: true });
      if (error) throw error;
      return data as Promo[];
    }
  });

  const createPromo = useMutation({
    mutationFn: async (promo: Omit<Promo, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('promos')
        .insert(promo)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['promos'] });
      queryClient.invalidateQueries({ queryKey: ['active-promos'] });
    }
  });

  const updatePromo = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Promo> & { id: string }) => {
      const { data, error } = await supabase
        .from('promos')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['promos'] });
      queryClient.invalidateQueries({ queryKey: ['active-promos'] });
    }
  });

  const deletePromo = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('promos')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['promos'] });
      queryClient.invalidateQueries({ queryKey: ['active-promos'] });
    }
  });

  return {
    promos,
    activePromos,
    isLoading,
    createPromo,
    updatePromo,
    deletePromo
  };
}
