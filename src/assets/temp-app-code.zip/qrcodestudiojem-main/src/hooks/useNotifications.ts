import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

interface Notification {
  id: string;
  user_id: string;
  title: string;
  body: string;
  type: string;
  is_read: boolean;
  action_url: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

export function useNotifications() {
  const { user, isAuthenticated } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  const fetchNotifications = useCallback(async () => {
    if (!user || !isAuthenticated) {
      setNotifications([]);
      setUnreadCount(0);
      setIsLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      const notifs = (data || []) as Notification[];
      setNotifications(notifs);
      setUnreadCount(notifs.filter(n => !n.is_read).length);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setIsLoading(false);
    }
  }, [user, isAuthenticated]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  // Subscribe to realtime notification inserts
  useEffect(() => {
    if (!user || !isAuthenticated) return;

    const channel = supabase
      .channel('user-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const newNotification = payload.new as Notification;
          setNotifications(prev => [newNotification, ...prev]);
          setUnreadCount(prev => prev + 1);
          
          // Send browser notification if supported
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(newNotification.title, {
              body: newNotification.body,
              icon: '/favicon.ico',
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, isAuthenticated]);

  // Subscribe to reservation status changes for the user
  useEffect(() => {
    if (!user || !isAuthenticated) return;

    const channel = supabase
      .channel('user-reservation-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'reservations',
          filter: `user_id=eq.${user.id}`,
        },
        async (payload) => {
          const oldRes = payload.old as any;
          const newRes = payload.new as any;
          
          // Only notify if status changed
          if (oldRes.status !== newRes.status) {
            const statusMessages: Record<string, { title: string; body: string }> = {
              confirmed: {
                title: '✅ Prenotazione confermata!',
                body: `La tua prenotazione per il ${newRes.reservation_date} alle ${newRes.reservation_time} è stata confermata!`,
              },
              rejected: {
                title: '❌ Prenotazione non accettata',
                body: `Ci dispiace, la tua prenotazione per il ${newRes.reservation_date} non è stata accettata.`,
              },
              cancelled: {
                title: '🚫 Prenotazione annullata',
                body: `La tua prenotazione per il ${newRes.reservation_date} è stata annullata.`,
              },
            };

            const message = statusMessages[newRes.status];
            if (message) {
              // Show browser notification
              if ('Notification' in window && Notification.permission === 'granted') {
                new Notification(message.title, {
                  body: message.body,
                  icon: '/favicon.ico',
                });
              }
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, isAuthenticated]);

  // Subscribe to takeaway order status changes for the user
  useEffect(() => {
    if (!user || !isAuthenticated) return;

    const channel = supabase
      .channel('user-takeaway-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'takeaway_orders',
          filter: `user_id=eq.${user.id}`,
        },
        async (payload) => {
          const oldOrder = payload.old as any;
          const newOrder = payload.new as any;
          
          // Only notify if status changed
          if (oldOrder.status !== newOrder.status) {
            const statusMessages: Record<string, { title: string; body: string }> = {
              accepted: {
                title: '✅ Ordine accettato!',
                body: `Il tuo ordine #${newOrder.order_number || newOrder.id.slice(0, 8)} è stato accettato!`,
              },
              preparing: {
                title: '👨‍🍳 In preparazione',
                body: `Il tuo ordine #${newOrder.order_number || newOrder.id.slice(0, 8)} è in preparazione!`,
              },
              ready: {
                title: '🎉 Ordine pronto!',
                body: newOrder.order_type === 'pickup' 
                  ? `Il tuo ordine è pronto per il ritiro!`
                  : `Il tuo ordine è pronto per la consegna!`,
              },
              delivering: {
                title: '🚗 In consegna',
                body: `Il tuo ordine è in arrivo!`,
              },
              completed: {
                title: '✅ Ordine completato',
                body: `Grazie per il tuo ordine! Buon appetito!`,
              },
              rejected: {
                title: '❌ Ordine non accettato',
                body: `Ci dispiace, il tuo ordine non può essere accettato.`,
              },
            };

            const message = statusMessages[newOrder.status];
            if (message) {
              // Show browser notification
              if ('Notification' in window && Notification.permission === 'granted') {
                new Notification(message.title, {
                  body: message.body,
                  icon: '/favicon.ico',
                });
              }
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, isAuthenticated]);

  const markAsRead = async (notificationId: string) => {
    try {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notificationId);

      setNotifications(prev =>
        prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    if (!user) return;

    try {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('user_id', user.id)
        .eq('is_read', false);

      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
      setUnreadCount(0);
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  const requestPushPermission = async () => {
    if (!('Notification' in window)) {
      return false;
    }

    const permission = await Notification.requestPermission();
    return permission === 'granted';
  };

  return {
    notifications,
    unreadCount,
    isLoading,
    markAsRead,
    markAllAsRead,
    requestPushPermission,
    refetch: fetchNotifications,
  };
}
