import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuthSession } from './useAuthSession';

interface LoyaltyPoints {
  id: string;
  user_id: string;
  total_points: number;
  lifetime_points: number;
  tier: string;
}

interface LoyaltyTransaction {
  id: string;
  points: number;
  transaction_type: string;
  description: string | null;
  created_at: string;
}

interface LoyaltyReward {
  id: string;
  name_it: string;
  name_en: string | null;
  description_it: string | null;
  description_en: string | null;
  points_required: number;
  reward_type: string;
  reward_value: string | null;
  image_url: string | null;
}

interface LoyaltyConfig {
  points_per_reservation: number;
  points_per_guest: number;
  welcome_bonus: number;
  is_active: boolean;
}

export function useLoyalty() {
  const { user, isAuthenticated } = useAuthSession();

  // Fetch config (public)
  const { data: config } = useQuery({
    queryKey: ['loyalty-config'],
    queryFn: async () => {
      const { data } = await supabase
        .from('loyalty_config')
        .select('*')
        .single();
      return data as LoyaltyConfig | null;
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Fetch rewards (public)
  const { data: rewards = [] } = useQuery({
    queryKey: ['loyalty-rewards'],
    queryFn: async () => {
      const { data } = await supabase
        .from('loyalty_rewards')
        .select('*')
        .eq('is_active', true)
        .order('points_required', { ascending: true });
      return data as LoyaltyReward[] || [];
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Fetch user points
  const { data: points, isLoading: pointsLoading } = useQuery({
    queryKey: ['loyalty-points', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data } = await supabase
        .from('loyalty_points')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();
      return data as LoyaltyPoints | null;
    },
    enabled: !!user && isAuthenticated,
    staleTime: 1000 * 60, // 1 minute
  });

  // Fetch transactions
  const { data: transactions = [] } = useQuery({
    queryKey: ['loyalty-transactions', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data } = await supabase
        .from('loyalty_transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(20);
      return data as LoyaltyTransaction[] || [];
    },
    enabled: !!user && isAuthenticated,
    staleTime: 1000 * 60, // 1 minute
  });

  const getTierProgress = () => {
    if (!points) return { current: 'bronze', next: 'silver', progress: 0, pointsNeeded: 100 };
    
    const tiers = [
      { name: 'bronze', min: 0 },
      { name: 'silver', min: 100 },
      { name: 'gold', min: 500 },
      { name: 'platinum', min: 1000 },
    ];

    const currentTierIndex = tiers.findIndex(t => t.name === points.tier);
    const nextTier = tiers[currentTierIndex + 1];

    if (!nextTier) {
      return { current: points.tier, next: null, progress: 100, pointsNeeded: 0 };
    }

    const currentMin = tiers[currentTierIndex].min;
    const nextMin = nextTier.min;
    const progress = ((points.lifetime_points - currentMin) / (nextMin - currentMin)) * 100;
    const pointsNeeded = nextMin - points.lifetime_points;

    return { 
      current: points.tier, 
      next: nextTier.name, 
      progress: Math.min(100, Math.max(0, progress)),
      pointsNeeded: Math.max(0, pointsNeeded)
    };
  };

  return {
    points,
    transactions,
    rewards,
    config,
    isLoading: pointsLoading,
    isActive: config?.is_active ?? false,
    getTierProgress,
  };
}
