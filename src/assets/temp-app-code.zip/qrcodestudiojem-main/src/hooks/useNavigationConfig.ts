import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface NavbarItem {
  key: string;
  icon: string;
  label: { it: string; en: string };
  visible: boolean;
  order: number;
}

export interface LanguageOption {
  code: string;
  label: string;
  flag: string;
  visible: boolean;
}

export interface NavigationConfig {
  id: string;
  header_logo_visible: boolean;
  header_favorites_visible: boolean;
  header_profile_visible: boolean;
  header_language_switcher_visible: boolean;
  header_theme_toggle_visible: boolean;
  navbar_items: NavbarItem[];
  available_languages: LanguageOption[];
  default_language: string;
  header_menu_items: any[];
  created_at: string;
  updated_at: string;
}

export function useNavigationConfig() {
  const { data: config, isLoading, error } = useQuery({
    queryKey: ['navigation-config'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('navigation_config')
        .select('*')
        .maybeSingle();

      if (error) {
        console.error('Error fetching navigation config:', error);
        return null;
      }

      if (!data) return null;

      // Cast JSONB fields properly
      return {
        ...data,
        navbar_items: data.navbar_items as unknown as NavbarItem[],
        available_languages: data.available_languages as unknown as LanguageOption[],
        header_menu_items: data.header_menu_items as unknown as any[],
      } as NavigationConfig;
    },
    staleTime: 1000 * 60 * 10, // 10 minutes
  });

  // Default config if not loaded
  const defaultConfig: NavigationConfig = {
    id: '',
    header_logo_visible: true,
    header_favorites_visible: true,
    header_profile_visible: true,
    header_language_switcher_visible: true,
    header_theme_toggle_visible: true,
    navbar_items: [
      { key: 'home', icon: 'Home', label: { it: 'Home', en: 'Home' }, visible: true, order: 1 },
      { key: 'menu', icon: 'UtensilsCrossed', label: { it: 'Menu', en: 'Menu' }, visible: true, order: 2 },
      { key: 'reservations', icon: 'CalendarDays', label: { it: 'Prenota', en: 'Book' }, visible: true, order: 3 },
      { key: 'discover', icon: 'Sparkles', label: { it: 'Scopri', en: 'Discover' }, visible: true, order: 4 },
      { key: 'favorites', icon: 'Heart', label: { it: 'Preferiti', en: 'Favorites' }, visible: true, order: 5 },
      { key: 'profile', icon: 'User', label: { it: 'Profilo', en: 'Profile' }, visible: true, order: 6 },
    ],
    available_languages: [
      { code: 'it', label: 'Italiano', flag: '🇮🇹', visible: true },
      { code: 'en', label: 'English', flag: '🇬🇧', visible: true },
      { code: 'fr', label: 'Français', flag: '🇫🇷', visible: true },
      { code: 'de', label: 'Deutsch', flag: '🇩🇪', visible: true },
      { code: 'es', label: 'Español', flag: '🇪🇸', visible: true },
    ],
    default_language: 'it',
    header_menu_items: [],
    created_at: '',
    updated_at: '',
  };

  return {
    config: config || defaultConfig,
    isLoading,
    error,
  };
}
