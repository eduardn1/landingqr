import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface OnboardingAction {
  id: string;
  action_key: string;
  icon: string;
  label: { it: string; en: string };
  subtitle: { it: string; en: string };
  action_type: string;
  action_value: string;
  display_order: number;
  is_active: boolean;
  gradient: string | null;
  created_at: string;
  updated_at: string;
}

export function useOnboardingActions() {
  return useQuery({
    queryKey: ['onboarding-actions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('onboarding_actions')
        .select('*')
        .order('display_order');
      
      if (error) throw error;
      return data as OnboardingAction[];
    },
  });
}

export function useUpdateOnboardingAction() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<OnboardingAction> & { id: string }) => {
      const { data, error } = await supabase
        .from('onboarding_actions')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboarding-actions'] });
    },
  });
}

export function useCreateOnboardingAction() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (action: Omit<OnboardingAction, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('onboarding_actions')
        .insert(action)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboarding-actions'] });
    },
  });
}

export function useDeleteOnboardingAction() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('onboarding_actions')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboarding-actions'] });
    },
  });
}
