import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuthSession } from './useAuthSession';

const FAVORITES_KEY = 'menu-favorites';

export function useFavorites() {
  const [favorites, setFavorites] = useState<string[]>(() => {
    // Initialize from localStorage synchronously
    try {
      const stored = localStorage.getItem(FAVORITES_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const { user, isLoading: authLoading } = useAuthSession();
  const [isLoading, setIsLoading] = useState(true);
  const [hasSynced, setHasSynced] = useState(false);

  // Sync with database when user is available
  useEffect(() => {
    if (authLoading) return;
    
    if (!user) {
      setIsLoading(false);
      return;
    }
    
    if (hasSynced) {
      setIsLoading(false);
      return;
    }
    
    syncFavoritesFromDB(user.id);
  }, [user, authLoading, hasSynced]);

  // Mark as not loading if no auth needed
  useEffect(() => {
    if (!authLoading && !user) {
      setIsLoading(false);
    }
  }, [authLoading, user]);

  // Sync favorites from database when user logs in
  const syncFavoritesFromDB = async (userId: string) => {
    try {
      const { data } = await supabase
        .from('favorites')
        .select('dish_id')
        .eq('user_id', userId);
      
      if (data && data.length > 0) {
        const dbFavorites = data.map(f => f.dish_id);
        // Merge local and DB favorites
        const currentFavorites = JSON.parse(localStorage.getItem(FAVORITES_KEY) || '[]');
        const merged = [...new Set([...currentFavorites, ...dbFavorites])];
        setFavorites(merged);
        localStorage.setItem(FAVORITES_KEY, JSON.stringify(merged));
        
        // Sync any local-only favorites to DB (fire and forget)
        const localOnlyFavorites = currentFavorites.filter((f: string) => !dbFavorites.includes(f));
        if (localOnlyFavorites.length > 0) {
          const inserts = localOnlyFavorites.map((dishId: string) => ({
            user_id: userId,
            dish_id: dishId,
            source: 'manual'
          }));
          supabase.from('favorites').upsert(inserts).then(() => {});
        }
      }
    } finally {
      setHasSynced(true);
      setIsLoading(false);
    }
  };

  // Save to localStorage and optionally to DB
  const saveFavorites = useCallback(async (newFavorites: string[]) => {
    try {
      localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavorites));
      setFavorites(newFavorites);
    } catch (e) {
      console.error('Error saving favorites:', e);
    }
  }, []);

  const toggleFavorite = useCallback(async (dishId: string) => {
    const isCurrentlyFavorite = favorites.includes(dishId);
    const newFavorites = isCurrentlyFavorite
      ? favorites.filter(id => id !== dishId)
      : [...favorites, dishId];
    
    // Update local state immediately
    setFavorites(newFavorites);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(newFavorites));
    
    // If user is logged in, sync to DB
    if (user) {
      if (isCurrentlyFavorite) {
        await supabase
          .from('favorites')
          .delete()
          .eq('user_id', user.id)
          .eq('dish_id', dishId);
      } else {
        await supabase.from('favorites').upsert({
          user_id: user.id,
          dish_id: dishId,
          source: 'manual'
        });
      }
    }
  }, [favorites, user]);

  const isFavorite = useCallback((dishId: string) => {
    return favorites.includes(dishId);
  }, [favorites]);

  const clearFavorites = useCallback(async () => {
    setFavorites([]);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify([]));
    
    if (user) {
      await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id);
    }
  }, [user]);

  return {
    favorites,
    toggleFavorite,
    isFavorite,
    clearFavorites,
    favoritesCount: favorites.length,
    isLoading
  };
}

// Hook for swipe interactions
export function useSwipeInteractions() {
  const { user, isAuthenticated } = useAuthSession();

  const recordSwipe = useCallback(async (dishId: string, action: 'like' | 'skip') => {
    if (!user) return;
    
    // Fire and forget - don't await
    supabase.from('swipe_interactions').upsert({
      user_id: user.id,
      dish_id: dishId,
      action
    }).then(() => {});

    // If liked, also add to favorites
    if (action === 'like') {
      supabase.from('favorites').upsert({
        user_id: user.id,
        dish_id: dishId,
        source: 'swipe'
      }).then(() => {});
    }
  }, [user]);

  return { recordSwipe, isAuthenticated };
}
