import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRestaurantConfig } from './useRestaurantConfig';

interface SEOSettings {
  id: string;
  page_slug: string;
  page_name: string;
  title: Record<string, string>;
  description: Record<string, string>;
  keywords?: Record<string, string>;
  canonical_url?: string;
  robots?: string;
  og_title?: Record<string, string>;
  og_description?: Record<string, string>;
  og_image_url?: string;
  og_type?: string;
  twitter_card_type?: string;
  twitter_title?: Record<string, string>;
  twitter_description?: Record<string, string>;
  twitter_image_url?: string;
  schema_data?: Record<string, any>;
  hreflang_urls?: Record<string, string>;
  is_active: boolean;
  priority: number;
  change_frequency: string;
}

export function useDynamicSEO(pageSlug: string = 'home') {
  const { currentLanguage } = useLanguage();
  const { config } = useRestaurantConfig();
  
  const { data: seoSettings } = useQuery({
    queryKey: ['seo-settings', pageSlug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('seo_settings')
        .select('*')
        .eq('page_slug', pageSlug)
        .eq('is_active', true)
        .single();
      
      if (error) {
        console.log('SEO settings not found for page:', pageSlug);
        return null;
      }
      return data as SEOSettings;
    },
    staleTime: 1000 * 60 * 10, // 10 minutes
  });

  useEffect(() => {
    const lang = currentLanguage || 'it';
    const restaurantName = config?.name || 'Menu Digitale';
    
    // Get values with fallbacks
    const title = seoSettings?.title?.[lang] || seoSettings?.title?.it || restaurantName;
    const description = seoSettings?.description?.[lang] || seoSettings?.description?.it || '';
    const keywords = seoSettings?.keywords?.[lang] || seoSettings?.keywords?.it || '';
    
    // Update document title
    document.title = title;
    
    // Update meta description
    updateMetaTag('name', 'description', description);
    
    // Update keywords
    if (keywords) {
      updateMetaTag('name', 'keywords', keywords);
    }
    
    // Update author
    updateMetaTag('name', 'author', restaurantName);
    
    // Robots
    if (seoSettings?.robots) {
      updateMetaTag('name', 'robots', seoSettings.robots);
    }
    
    // Canonical URL
    if (seoSettings?.canonical_url) {
      updateLinkTag('canonical', seoSettings.canonical_url);
    } else {
      updateLinkTag('canonical', window.location.href.split('?')[0]);
    }
    
    // Open Graph tags
    const ogTitle = seoSettings?.og_title?.[lang] || seoSettings?.og_title?.it || title;
    const ogDescription = seoSettings?.og_description?.[lang] || seoSettings?.og_description?.it || description;
    const ogImage = seoSettings?.og_image_url || config?.cover_image_url || '';
    
    updateMetaTag('property', 'og:title', ogTitle);
    updateMetaTag('property', 'og:description', ogDescription);
    updateMetaTag('property', 'og:type', seoSettings?.og_type || 'website');
    updateMetaTag('property', 'og:locale', getOGLocale(lang));
    updateMetaTag('property', 'og:url', window.location.href);
    updateMetaTag('property', 'og:site_name', restaurantName);
    
    if (ogImage) {
      updateMetaTag('property', 'og:image', ogImage);
      updateMetaTag('property', 'og:image:width', '1200');
      updateMetaTag('property', 'og:image:height', '630');
    }
    
    // Twitter Cards
    const twitterTitle = seoSettings?.twitter_title?.[lang] || seoSettings?.twitter_title?.it || ogTitle;
    const twitterDescription = seoSettings?.twitter_description?.[lang] || seoSettings?.twitter_description?.it || ogDescription;
    const twitterImage = seoSettings?.twitter_image_url || ogImage;
    
    updateMetaTag('name', 'twitter:card', seoSettings?.twitter_card_type || 'summary_large_image');
    updateMetaTag('name', 'twitter:title', twitterTitle);
    updateMetaTag('name', 'twitter:description', twitterDescription);
    
    if (twitterImage) {
      updateMetaTag('name', 'twitter:image', twitterImage);
    }
    
    // Hreflang tags for multi-language
    if (seoSettings?.hreflang_urls && Object.keys(seoSettings.hreflang_urls).length > 0) {
      // Remove existing hreflang tags
      document.querySelectorAll('link[hreflang]').forEach(el => el.remove());
      
      // Add new hreflang tags
      Object.entries(seoSettings.hreflang_urls).forEach(([hrefLang, url]) => {
        const link = document.createElement('link');
        link.rel = 'alternate';
        link.hreflang = hrefLang;
        link.href = url;
        document.head.appendChild(link);
      });
      
      // Add x-default
      const defaultLink = document.createElement('link');
      defaultLink.rel = 'alternate';
      defaultLink.hreflang = 'x-default';
      defaultLink.href = seoSettings.hreflang_urls.it || seoSettings.hreflang_urls.en || window.location.href;
      document.head.appendChild(defaultLink);
    }
    
    // Structured Data (Schema.org JSON-LD)
    if (seoSettings?.schema_data) {
      updateStructuredData({
        ...seoSettings.schema_data,
        name: restaurantName,
        address: config?.address ? {
          '@type': 'PostalAddress',
          streetAddress: config.address,
          addressLocality: config.city || '',
          addressCountry: config.country || 'IT'
        } : undefined,
        telephone: config?.phone,
        email: config?.email,
        url: window.location.origin
      });
    }
    
  }, [seoSettings, currentLanguage, config]);

  return { seoSettings };
}

// Helper functions
function updateMetaTag(attribute: 'name' | 'property', key: string, content: string) {
  if (!content) return;
  
  let element = document.querySelector(`meta[${attribute}="${key}"]`);
  
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attribute, key);
    document.head.appendChild(element);
  }
  
  element.setAttribute('content', content);
}

function updateLinkTag(rel: string, href: string) {
  let element = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement;
  
  if (!element) {
    element = document.createElement('link');
    element.setAttribute('rel', rel);
    document.head.appendChild(element);
  }
  
  element.setAttribute('href', href);
}

function updateStructuredData(data: Record<string, any>) {
  const scriptId = 'structured-data-seo';
  let script = document.getElementById(scriptId) as HTMLScriptElement | null;
  
  if (!script) {
    script = document.createElement('script');
    script.id = scriptId;
    script.type = 'application/ld+json';
    document.head.appendChild(script);
  }
  
  // Clean undefined values
  const cleanData = JSON.parse(JSON.stringify(data));
  script.textContent = JSON.stringify(cleanData);
}

function getOGLocale(lang: string): string {
  const localeMap: Record<string, string> = {
    it: 'it_IT',
    en: 'en_GB',
    de: 'de_DE',
    es: 'es_ES',
    fr: 'fr_FR'
  };
  return localeMap[lang] || 'it_IT';
}
