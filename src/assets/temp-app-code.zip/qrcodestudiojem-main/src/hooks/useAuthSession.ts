import { useState, useEffect, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

// Singleton pattern for auth state to prevent multiple subscriptions
let globalSession: Session | null = null;
let globalUser: User | null = null;
let isInitialized = false;
let initPromise: Promise<void> | null = null;
const listeners = new Set<(session: Session | null, user: User | null) => void>();

const initAuth = async () => {
  if (initPromise) return initPromise;
  
  initPromise = (async () => {
    const { data: { session } } = await supabase.auth.getSession();
    globalSession = session;
    globalUser = session?.user ?? null;
    isInitialized = true;
    
    // Notify all listeners
    listeners.forEach(listener => listener(globalSession, globalUser));
  })();
  
  // Set up single subscription
  supabase.auth.onAuthStateChange((event, session) => {
    globalSession = session;
    globalUser = session?.user ?? null;
    listeners.forEach(listener => listener(globalSession, globalUser));
  });
  
  return initPromise;
};

// Initialize on module load
initAuth();

export function useAuthSession() {
  const [session, setSession] = useState<Session | null>(globalSession);
  const [user, setUser] = useState<User | null>(globalUser);
  const [isLoading, setIsLoading] = useState(!isInitialized);

  useEffect(() => {
    // If already initialized, use cached values
    if (isInitialized) {
      setSession(globalSession);
      setUser(globalUser);
      setIsLoading(false);
      
      // Subscribe to updates
      const listener = (s: Session | null, u: User | null) => {
        setSession(s);
        setUser(u);
      };
      listeners.add(listener);
      return () => { listeners.delete(listener); };
    }
    
    // Wait for initialization
    initAuth().then(() => {
      setSession(globalSession);
      setUser(globalUser);
      setIsLoading(false);
    });
    
    // Subscribe to updates
    const listener = (s: Session | null, u: User | null) => {
      setSession(s);
      setUser(u);
    };
    listeners.add(listener);
    return () => { listeners.delete(listener); };
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  return {
    session,
    user,
    isLoading,
    isAuthenticated: !!user,
    signOut
  };
}
