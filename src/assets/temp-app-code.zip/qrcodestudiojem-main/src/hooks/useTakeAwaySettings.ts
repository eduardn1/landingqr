import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface TakeAwaySettings {
  id: string;
  is_enabled: boolean;
  accepts_pickup: boolean;
  accepts_delivery: boolean;
  min_prep_time: number;
  max_prep_time: number;
  pickup_intervals: number;
  max_concurrent_orders: number;
  max_daily_orders: number | null;
  auto_accept_orders: boolean;
  custom_hours: any;
  accepts_cash: boolean;
  accepts_card_on_delivery: boolean;
  notification_phone: string | null;
}

export function useTakeAwaySettings() {
  return useQuery({
    queryKey: ['takeaway-settings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('takeaway_settings')
        .select('*')
        .single();

      if (error) throw error;
      return data as TakeAwaySettings;
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}
