import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export interface Badge {
  id: string;
  badge_key: string;
  name_it: string;
  name_en: string | null;
  description_it: string | null;
  description_en: string | null;
  icon: string;
  color: string;
  category: string;
  requirement_type: string;
  requirement_value: number;
  points_reward: number;
  is_secret: boolean;
}

export interface UserBadge {
  id: string;
  badge_id: string;
  earned_at: string;
  is_new: boolean;
  badge?: Badge;
}

export interface Challenge {
  id: string;
  challenge_key: string;
  name_it: string;
  name_en: string | null;
  description_it: string | null;
  description_en: string | null;
  icon: string;
  color: string;
  challenge_type: string;
  requirement_type: string;
  requirement_value: number;
  points_reward: number;
  expires_at: string | null;
}

export interface UserChallenge {
  id: string;
  challenge_id: string;
  current_progress: number;
  is_completed: boolean;
  completed_at: string | null;
  challenge?: Challenge;
}

export interface Streak {
  current_streak: number;
  longest_streak: number;
  last_activity_date: string | null;
}

export interface LevelInfo {
  level: number;
  xp_current: number;
  xp_to_next_level: number;
  progress: number;
  title: string;
}

const LEVEL_TITLES: Record<number, { it: string; en: string }> = {
  1: { it: 'Novizio', en: 'Novice' },
  2: { it: 'Apprendista', en: 'Apprentice' },
  3: { it: 'Esploratore', en: 'Explorer' },
  4: { it: 'Intenditore', en: 'Connoisseur' },
  5: { it: 'Esperto', en: 'Expert' },
  6: { it: 'Maestro', en: 'Master' },
  7: { it: 'Gran Maestro', en: 'Grand Master' },
  8: { it: 'Leggenda', en: 'Legend' },
  9: { it: 'Mito', en: 'Myth' },
  10: { it: 'Divinità', en: 'Deity' },
};

export function useGamification() {
  const { user, isAuthenticated } = useAuth();
  const [badges, setBadges] = useState<Badge[]>([]);
  const [userBadges, setUserBadges] = useState<UserBadge[]>([]);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [userChallenges, setUserChallenges] = useState<UserChallenge[]>([]);
  const [streak, setStreak] = useState<Streak | null>(null);
  const [levelInfo, setLevelInfo] = useState<LevelInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchGamificationData();
  }, [user, isAuthenticated]);

  const fetchGamificationData = async () => {
    setIsLoading(true);
    try {
      // Fetch all badges (public)
      const { data: badgesData } = await supabase
        .from('loyalty_badges')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });
      
      if (badgesData) setBadges(badgesData as Badge[]);

      // Fetch all challenges (public)
      const { data: challengesData } = await supabase
        .from('loyalty_challenges')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });
      
      if (challengesData) setChallenges(challengesData as Challenge[]);

      // User-specific data
      if (user && isAuthenticated) {
        // Fetch user badges
        const { data: userBadgesData } = await supabase
          .from('user_badges')
          .select('*')
          .eq('user_id', user.id);
        
        if (userBadgesData) setUserBadges(userBadgesData as UserBadge[]);

        // Fetch user challenges
        const { data: userChallengesData } = await supabase
          .from('user_challenges')
          .select('*')
          .eq('user_id', user.id);
        
        if (userChallengesData) setUserChallenges(userChallengesData as UserChallenge[]);

        // Fetch streak - use maybeSingle to handle no rows gracefully
        const { data: streakData } = await supabase
          .from('loyalty_streaks')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();
        
        if (streakData) {
          setStreak({
            current_streak: streakData.current_streak,
            longest_streak: streakData.longest_streak,
            last_activity_date: streakData.last_activity_date,
          });
        }

        // Fetch level info from loyalty_points - use maybeSingle
        const { data: pointsData } = await supabase
          .from('loyalty_points')
          .select('level, xp_current, xp_to_next_level')
          .eq('user_id', user.id)
          .maybeSingle();
        
        if (pointsData) {
          const level = pointsData.level || 1;
          const xp_current = pointsData.xp_current || 0;
          const xp_to_next_level = pointsData.xp_to_next_level || 100;
          setLevelInfo({
            level,
            xp_current,
            xp_to_next_level,
            progress: (xp_current / xp_to_next_level) * 100,
            title: LEVEL_TITLES[Math.min(level, 10)]?.it || 'Leggenda',
          });
        }
      }
    } catch (error) {
      console.error('Error fetching gamification data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getEarnedBadges = (): (Badge & { earned_at: string })[] => {
    return userBadges.map(ub => {
      const badge = badges.find(b => b.id === ub.badge_id);
      if (!badge) return null;
      return { ...badge, earned_at: ub.earned_at };
    }).filter(Boolean) as (Badge & { earned_at: string })[];
  };

  const getLockedBadges = (): Badge[] => {
    const earnedIds = new Set(userBadges.map(ub => ub.badge_id));
    return badges.filter(b => !earnedIds.has(b.id) && !b.is_secret);
  };

  const getActiveChallenges = (): (Challenge & { progress: number; isCompleted: boolean })[] => {
    return challenges.map(c => {
      const userChallenge = userChallenges.find(uc => uc.challenge_id === c.id);
      return {
        ...c,
        progress: userChallenge?.current_progress || 0,
        isCompleted: userChallenge?.is_completed || false,
      };
    });
  };

  const markBadgeAsSeen = async (badgeId: string) => {
    if (!user) return;
    await supabase
      .from('user_badges')
      .update({ is_new: false })
      .eq('user_id', user.id)
      .eq('badge_id', badgeId);
    
    setUserBadges(prev => 
      prev.map(ub => ub.badge_id === badgeId ? { ...ub, is_new: false } : ub)
    );
  };

  const getNewBadgesCount = () => {
    return userBadges.filter(ub => ub.is_new).length;
  };

  return {
    badges,
    userBadges,
    challenges,
    userChallenges,
    streak,
    levelInfo,
    isLoading,
    getEarnedBadges,
    getLockedBadges,
    getActiveChallenges,
    markBadgeAsSeen,
    getNewBadgesCount,
    refetch: fetchGamificationData,
  };
}
