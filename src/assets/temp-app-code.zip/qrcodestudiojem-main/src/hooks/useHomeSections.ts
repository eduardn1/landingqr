import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface HomeSection {
  id: string;
  section_key: string;
  display_order: number;
  is_active: boolean;
  title: { it: string; en: string };
  subtitle: { it: string; en: string } | null;
  config: Record<string, unknown>;
}

// Get active sections for client display
export function useHomeSections() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['home-sections'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('home_sections')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });
      
      if (error) throw error;
      return data as unknown as HomeSection[];
    },
    staleTime: 1000 * 60 * 2, // 2 minutes
    gcTime: 1000 * 60 * 10, // Keep in cache for 10 minutes
  });

  // Helper to check if a section is enabled
  const isSectionEnabled = (sectionKey: string) => {
    return data?.some(s => s.section_key === sectionKey) ?? false;
  };

  // Helper to get section config
  const getSectionConfig = (sectionKey: string) => {
    return data?.find(s => s.section_key === sectionKey);
  };

  return {
    sections: data || [],
    isLoading,
    error,
    isSectionEnabled,
    getSectionConfig,
    refetch,
  };
}

// Get ALL sections for admin management (including inactive)
export function useAllHomeSections() {
  const queryClient = useQueryClient();
  
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['home-sections-all'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('home_sections')
        .select('*')
        .order('display_order', { ascending: true });
      
      if (error) throw error;
      return data as unknown as HomeSection[];
    },
    staleTime: 1000 * 60 * 2,
  });

  const invalidateAll = () => {
    queryClient.invalidateQueries({ queryKey: ['home-sections'] });
    queryClient.invalidateQueries({ queryKey: ['home-sections-all'] });
  };

  return {
    sections: data || [],
    isLoading,
    error,
    refetch,
    invalidateAll,
  };
}
