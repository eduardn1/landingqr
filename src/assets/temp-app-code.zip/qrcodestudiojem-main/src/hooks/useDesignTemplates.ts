import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface DesignTemplate {
  id: string;
  template_type: 'homepage' | 'takeaway' | 'onboarding';
  template_key: string;
  template_name: Record<string, string>;
  template_description?: Record<string, string>;
  preview_image_url?: string;
  design_config: Record<string, any>;
  features: Record<string, boolean>;
  is_active: boolean;
  is_premium: boolean;
  difficulty_level: 'easy' | 'medium' | 'advanced';
  best_for: string[];
  tags: string[];
  display_order: number;
}

export interface ActiveTemplateConfig {
  id: string;
  homepage_template_key: string;
  takeaway_template_key: string;
  onboarding_template_key: string;
  homepage_custom_config: Record<string, any>;
  takeaway_custom_config: Record<string, any>;
  onboarding_custom_config: Record<string, any>;
  header_variant: 'default' | 'minimal' | 'centered' | 'floating';
  footer_variant: 'default' | 'minimal' | 'expanded' | 'split';
}

export function useDesignTemplates(type?: 'homepage' | 'takeaway' | 'onboarding') {
  const queryClient = useQueryClient();

  // Fetch all active templates (we need all types for getActiveTemplate to work)
  const { data: allTemplates = [], isLoading: templatesLoading } = useQuery({
    queryKey: ['design-templates-all'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('design_templates')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (error) throw error;
      return data as DesignTemplate[];
    },
    staleTime: 1000 * 60 * 10, // 10 minutes
  });

  // Filter templates by type if specified (for display purposes)
  const templates = type 
    ? allTemplates.filter(t => t.template_type === type)
    : allTemplates;

  // Fetch active template configuration
  const { data: activeConfig, isLoading: configLoading } = useQuery({
    queryKey: ['active-template-config'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('active_template_config')
        .select('*')
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      return data as ActiveTemplateConfig | null;
    },
    staleTime: 1000 * 60 * 5,
  });

  // Get current active template for a specific type
  const getActiveTemplate = (templateType: 'homepage' | 'takeaway' | 'onboarding'): DesignTemplate | undefined => {
    if (!activeConfig || !allTemplates.length) return undefined;

    const keyField = `${templateType}_template_key` as keyof ActiveTemplateConfig;
    const activeKey = activeConfig[keyField] as string;
    
    if (!activeKey) return undefined;

    return allTemplates.find(t => t.template_key === activeKey && t.template_type === templateType);
  };

  // Get merged config (template default + custom overrides)
  const getMergedConfig = (templateType: 'homepage' | 'takeaway' | 'onboarding'): Record<string, any> => {
    const template = getActiveTemplate(templateType);
    if (!template) return {};
    if (!activeConfig) return template.design_config || {};

    const customConfigField = `${templateType}_custom_config` as keyof ActiveTemplateConfig;
    const customConfig = (activeConfig[customConfigField] as Record<string, any>) || {};

    return {
      ...(template.design_config || {}),
      ...customConfig,
    };
  };

  // Update active template mutation
  const updateActiveTemplateMutation = useMutation({
    mutationFn: async ({ 
      templateType, 
      templateKey 
    }: { 
      templateType: 'homepage' | 'takeaway' | 'onboarding'; 
      templateKey: string 
    }) => {
      const keyField = `${templateType}_template_key`;

      if (!activeConfig) {
        // Create new config
        const { error } = await supabase
          .from('active_template_config')
          .insert({ [keyField]: templateKey });
        if (error) throw error;
      } else {
        // Update existing config
        const { error } = await supabase
          .from('active_template_config')
          .update({ [keyField]: templateKey })
          .eq('id', activeConfig.id);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-template-config'] });
      queryClient.invalidateQueries({ queryKey: ['design-templates-all'] });
    },
  });

  // Update custom config mutation
  const updateCustomConfigMutation = useMutation({
    mutationFn: async ({
      templateType,
      customConfig,
    }: {
      templateType: 'homepage' | 'takeaway' | 'onboarding';
      customConfig: Record<string, any>;
    }) => {
      const configField = `${templateType}_custom_config`;

      if (!activeConfig) return;

      const { error } = await supabase
        .from('active_template_config')
        .update({ [configField]: customConfig })
        .eq('id', activeConfig.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-template-config'] });
      queryClient.invalidateQueries({ queryKey: ['design-templates-all'] });
    },
  });

  // Update header/footer variant mutation
  const updateLayoutVariantMutation = useMutation({
    mutationFn: async ({
      headerVariant,
      footerVariant,
    }: {
      headerVariant?: 'default' | 'minimal' | 'centered' | 'floating';
      footerVariant?: 'default' | 'minimal' | 'expanded' | 'split';
    }) => {
      if (!activeConfig) return;

      const updates: Record<string, string> = {};
      if (headerVariant) updates.header_variant = headerVariant;
      if (footerVariant) updates.footer_variant = footerVariant;

      const { error } = await supabase
        .from('active_template_config')
        .update(updates)
        .eq('id', activeConfig.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-template-config'] });
    },
  });

  return {
    templates,
    activeConfig,
    isLoading: templatesLoading || configLoading,
    getActiveTemplate,
    getMergedConfig,
    updateActiveTemplate: updateActiveTemplateMutation.mutate,
    updateCustomConfig: updateCustomConfigMutation.mutate,
    updateLayoutVariant: updateLayoutVariantMutation.mutate,
    isUpdating: updateActiveTemplateMutation.isPending || updateCustomConfigMutation.isPending || updateLayoutVariantMutation.isPending,
    // Header and footer variants
    headerVariant: (activeConfig?.header_variant || 'default') as 'default' | 'minimal' | 'centered' | 'floating',
    footerVariant: (activeConfig?.footer_variant || 'default') as 'default' | 'minimal' | 'expanded' | 'split',
  };
}