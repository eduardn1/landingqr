import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface DbCategory {
  id: string;
  name_it: string;
  name_en: string;
  description_it: string | null;
  description_en: string | null;
  icon: string;
  image_url: string | null;
  display_order: number;
  is_active: boolean;
  is_featured: boolean;
}

export interface DbDish {
  id: string;
  category_id: string;
  name_it: string;
  name_en: string;
  description_it: string | null;
  description_en: string | null;
  ingredients_it: string | null;
  ingredients_en: string | null;
  image_url: string | null;
  price: number;
  original_price: number | null;
  currency: string;
  tags: string[];
  spicy_level: number | null;
  portion_size: string | null;
  is_available: boolean;
  is_featured: boolean;
  is_seasonal: boolean;
  badge: string | null;
  display_order: number;
  allergens?: string[];
}

export interface DbAllergen {
  code: string;
  name_it: string;
  name_en: string;
  icon: string;
  color: string;
}

export function useCategories() {
  const [categories, setCategories] = useState<DbCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const { data, error } = await supabase
          .from('categories')
          .select('*')
          .eq('is_active', true)
          .order('display_order');

        if (error) throw error;
        setCategories(data || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error fetching categories');
      } finally {
        setIsLoading(false);
      }
    };

    fetchCategories();
  }, []);

  return { categories, isLoading, error };
}

export function useDishes(categoryId?: string, excludeAllergens?: string[]) {
  const [dishes, setDishes] = useState<DbDish[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDishes = async () => {
      setIsLoading(true);
      try {
        let query = supabase
          .from('dishes')
          .select(`
            *,
            dish_allergens(allergen_code)
          `)
          .eq('is_available', true)
          .order('display_order');

        if (categoryId) {
          query = query.eq('category_id', categoryId);
        }

        const { data, error } = await query;

        if (error) throw error;

        // Transform data to include allergens array
        let transformedData = (data || []).map(dish => ({
          ...dish,
          allergens: dish.dish_allergens?.map((da: { allergen_code: string }) => da.allergen_code) || []
        }));

        // Filter out dishes with excluded allergens
        if (excludeAllergens && excludeAllergens.length > 0) {
          transformedData = transformedData.filter(dish => 
            !dish.allergens.some((allergen: string) => excludeAllergens.includes(allergen))
          );
        }

        setDishes(transformedData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error fetching dishes');
      } finally {
        setIsLoading(false);
      }
    };

    fetchDishes();
  }, [categoryId, excludeAllergens?.join(',')]);

  return { dishes, isLoading, error };
}

export function useAllergens() {
  const [allergens, setAllergens] = useState<DbAllergen[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAllergens = async () => {
      try {
        const { data, error } = await supabase
          .from('allergens')
          .select('*')
          .order('name_it');

        if (error) throw error;
        setAllergens(data || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error fetching allergens');
      } finally {
        setIsLoading(false);
      }
    };

    fetchAllergens();
  }, []);

  return { allergens, isLoading, error };
}

export function useFeaturedDishes(excludeAllergens?: string[]) {
  const [dishes, setDishes] = useState<DbDish[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchFeaturedDishes = async () => {
      try {
        const { data, error } = await supabase
          .from('dishes')
          .select(`
            *,
            dish_allergens(allergen_code)
          `)
          .eq('is_available', true)
          .eq('is_featured', true)
          .order('display_order')
          .limit(10);

        if (error) throw error;

        let transformedData = (data || []).map(dish => ({
          ...dish,
          allergens: dish.dish_allergens?.map((da: { allergen_code: string }) => da.allergen_code) || []
        }));

        if (excludeAllergens && excludeAllergens.length > 0) {
          transformedData = transformedData.filter(dish => 
            !dish.allergens.some((allergen: string) => excludeAllergens.includes(allergen))
          );
        }

        setDishes(transformedData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Error fetching featured dishes');
      } finally {
        setIsLoading(false);
      }
    };

    fetchFeaturedDishes();
  }, [excludeAllergens?.join(',')]);

  return { dishes, isLoading, error };
}
