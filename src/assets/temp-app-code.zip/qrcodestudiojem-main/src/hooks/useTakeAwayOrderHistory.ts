import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { TakeAwayOrder } from './useTakeAwayOrders';

export function useTakeAwayOrderHistory(filters?: {
  startDate?: string;
  endDate?: string;
  status?: string;
  orderType?: string;
}) {
  return useQuery({
    queryKey: ['takeaway-order-history', filters],
    queryFn: async () => {
      let query = supabase
        .from('takeaway_orders')
        .select('*, takeaway_drivers(*)')
        .order('created_at', { ascending: false });

      // Apply date filters
      if (filters?.startDate) {
        query = query.gte('created_at', `${filters.startDate}T00:00:00`);
      }
      if (filters?.endDate) {
        query = query.lte('created_at', `${filters.endDate}T23:59:59`);
      }

      // Apply status filter
      if (filters?.status && filters.status !== 'all') {
        query = query.eq('status', filters.status);
      }

      // Apply order type filter
      if (filters?.orderType && filters.orderType !== 'all') {
        query = query.eq('order_type', filters.orderType);
      }

      const { data, error } = await query.limit(100);

      if (error) throw error;
      return data as TakeAwayOrder[];
    },
  });
}

export function useTakeAwayStats(period: 'today' | 'week' | 'month' = 'today') {
  return useQuery({
    queryKey: ['takeaway-stats', period],
    queryFn: async () => {
      const now = new Date();
      let startDate: string;

      switch (period) {
        case 'week':
          const weekAgo = new Date(now);
          weekAgo.setDate(weekAgo.getDate() - 7);
          startDate = weekAgo.toISOString().split('T')[0];
          break;
        case 'month':
          const monthAgo = new Date(now);
          monthAgo.setMonth(monthAgo.getMonth() - 1);
          startDate = monthAgo.toISOString().split('T')[0];
          break;
        default:
          startDate = now.toISOString().split('T')[0];
      }

      const { data: orders, error } = await supabase
        .from('takeaway_orders')
        .select('*')
        .gte('created_at', `${startDate}T00:00:00`)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const stats = {
        totalOrders: orders?.length || 0,
        totalRevenue: orders?.reduce((sum, o) => sum + (o.status !== 'cancelled' && o.status !== 'rejected' ? o.total : 0), 0) || 0,
        completedOrders: orders?.filter(o => o.status === 'completed').length || 0,
        cancelledOrders: orders?.filter(o => o.status === 'cancelled' || o.status === 'rejected').length || 0,
        pickupOrders: orders?.filter(o => o.order_type === 'pickup').length || 0,
        deliveryOrders: orders?.filter(o => o.order_type === 'delivery').length || 0,
        averageOrderValue: 0,
        averageDeliveryTime: 0,
      };

      const validOrders = orders?.filter(o => o.status !== 'cancelled' && o.status !== 'rejected') || [];
      stats.averageOrderValue = validOrders.length > 0 
        ? stats.totalRevenue / validOrders.length 
        : 0;

      // Calculate average delivery time
      const deliveredOrders = orders?.filter(o => 
        o.status === 'completed' && 
        o.order_type === 'delivery' && 
        o.created_at && 
        o.completed_at
      ) || [];

      if (deliveredOrders.length > 0) {
        const totalTime = deliveredOrders.reduce((sum, o) => {
          const created = new Date(o.created_at).getTime();
          const completed = new Date(o.completed_at!).getTime();
          return sum + (completed - created);
        }, 0);
        stats.averageDeliveryTime = Math.round(totalTime / deliveredOrders.length / 60000); // in minutes
      }

      return stats;
    },
    staleTime: 1000 * 60, // 1 minute
  });
}