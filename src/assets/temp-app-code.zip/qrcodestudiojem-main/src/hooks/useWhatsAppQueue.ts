import { useState, useCallback, useRef } from 'react';
import { toast } from 'sonner';

// WaSender rate limit: 1 message per 5 seconds minimum
const MIN_MESSAGE_INTERVAL_MS = 6000;

interface QueuedMessage {
  id: string;
  callback: () => Promise<void>;
  timestamp: number;
}

export function useWhatsAppQueue() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [cooldownRemaining, setCooldownRemaining] = useState(0);
  const lastMessageTimeRef = useRef<number>(0);
  const cooldownIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const startCooldownTimer = useCallback((remainingMs: number) => {
    if (cooldownIntervalRef.current) {
      clearInterval(cooldownIntervalRef.current);
    }
    
    setCooldownRemaining(Math.ceil(remainingMs / 1000));
    
    cooldownIntervalRef.current = setInterval(() => {
      setCooldownRemaining(prev => {
        if (prev <= 1) {
          if (cooldownIntervalRef.current) {
            clearInterval(cooldownIntervalRef.current);
            cooldownIntervalRef.current = null;
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, []);

  const canSendMessage = useCallback((): boolean => {
    const now = Date.now();
    const timeSinceLastMessage = now - lastMessageTimeRef.current;
    return timeSinceLastMessage >= MIN_MESSAGE_INTERVAL_MS;
  }, []);

  const getWaitTime = useCallback((): number => {
    const now = Date.now();
    const timeSinceLastMessage = now - lastMessageTimeRef.current;
    return Math.max(0, MIN_MESSAGE_INTERVAL_MS - timeSinceLastMessage);
  }, []);

  const sendWithRateLimit = useCallback(async (
    sendFn: () => Promise<void>,
    options?: { 
      skipNotification?: boolean;
      showCooldownToast?: boolean;
    }
  ): Promise<boolean> => {
    const waitTime = getWaitTime();
    
    if (waitTime > 0) {
      if (options?.showCooldownToast !== false) {
        toast.warning(`Attendi ${Math.ceil(waitTime / 1000)}s prima del prossimo invio WhatsApp`, {
          duration: 2000,
          id: 'whatsapp-cooldown'
        });
      }
      startCooldownTimer(waitTime);
      return false;
    }

    setIsProcessing(true);
    try {
      await sendFn();
      lastMessageTimeRef.current = Date.now();
      startCooldownTimer(MIN_MESSAGE_INTERVAL_MS);
      return true;
    } catch (error) {
      console.error('WhatsApp send error:', error);
      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, [getWaitTime, startCooldownTimer]);

  const queueMessage = useCallback(async (
    sendFn: () => Promise<void>,
    options?: { 
      waitIfNeeded?: boolean;
      showProgress?: boolean;
    }
  ): Promise<boolean> => {
    const waitTime = getWaitTime();
    
    if (waitTime > 0 && options?.waitIfNeeded) {
      if (options?.showProgress) {
        toast.loading(`Invio in ${Math.ceil(waitTime / 1000)}s...`, {
          id: 'whatsapp-queue',
          duration: waitTime
        });
      }
      
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
    
    return sendWithRateLimit(sendFn, { showCooldownToast: !options?.waitIfNeeded });
  }, [getWaitTime, sendWithRateLimit]);

  return {
    isProcessing,
    cooldownRemaining,
    canSendMessage,
    getWaitTime,
    sendWithRateLimit,
    queueMessage,
    isCoolingDown: cooldownRemaining > 0
  };
}

// Global singleton for shared state across components
let globalLastMessageTime = 0;

export function getGlobalCooldown(): number {
  const now = Date.now();
  const timeSinceLastMessage = now - globalLastMessageTime;
  return Math.max(0, MIN_MESSAGE_INTERVAL_MS - timeSinceLastMessage);
}

export function setGlobalLastMessageTime(): void {
  globalLastMessageTime = Date.now();
}
