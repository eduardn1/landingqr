import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useState, useEffect } from 'react';

interface HeaderVisibility {
  logo: boolean;
  favorites: boolean;
  profile: boolean;
  language: boolean;
  theme: boolean;
  notifications: boolean;
}

type DeviceType = 'mobile' | 'tablet' | 'desktop';

const getDeviceType = (): DeviceType => {
  if (typeof window === 'undefined') return 'desktop';
  const width = window.innerWidth;
  if (width < 640) return 'mobile';
  if (width < 1024) return 'tablet';
  return 'desktop';
};

export function useHeaderVisibility(): HeaderVisibility {
  const [device, setDevice] = useState<DeviceType>(getDeviceType);
  
  // Update device type on window resize
  useEffect(() => {
    const handleResize = () => {
      const newDevice = getDeviceType();
      setDevice(prev => prev !== newDevice ? newDevice : prev);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const { data: config } = useQuery({
    queryKey: ['header-visibility'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('navigation_config')
        .select('header_logo_visible_mobile, header_logo_visible_tablet, header_logo_visible_desktop, header_favorites_visible_mobile, header_favorites_visible_tablet, header_favorites_visible_desktop, header_profile_visible_mobile, header_profile_visible_tablet, header_profile_visible_desktop, header_language_visible_mobile, header_language_visible_tablet, header_language_visible_desktop, header_theme_visible_mobile, header_theme_visible_tablet, header_theme_visible_desktop, header_notifications_visible_mobile, header_notifications_visible_tablet, header_notifications_visible_desktop')
        .maybeSingle();
      if (error) return null;
      return data;
    },
    staleTime: 1000 * 60 * 10,
  });

  if (!config) {
    return {
      logo: true,
      favorites: true,
      profile: true,
      language: device !== 'mobile',
      theme: true,
      notifications: true,
    };
  }

  return {
    logo: config[`header_logo_visible_${device}`] ?? true,
    favorites: config[`header_favorites_visible_${device}`] ?? true,
    profile: config[`header_profile_visible_${device}`] ?? true,
    language: config[`header_language_visible_${device}`] ?? (device !== 'mobile'),
    theme: config[`header_theme_visible_${device}`] ?? true,
    notifications: config[`header_notifications_visible_${device}`] ?? true,
  };
}