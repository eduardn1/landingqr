import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { detectBrowserLanguage, getTranslation, languages, type Language } from '@/lib/i18n';

interface LanguageContextType {
  currentLanguage: string;
  setLanguage: (code: string) => void;
  t: (key: string) => string;
  languages: Language[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<string>('it');

  useEffect(() => {
    // Check localStorage first, then browser language
    const savedLang = localStorage.getItem('menu-language');
    if (savedLang && languages.find(l => l.code === savedLang)) {
      setCurrentLanguage(savedLang);
    } else {
      const browserLang = detectBrowserLanguage();
      setCurrentLanguage(browserLang);
    }
  }, []);

  const setLanguage = (code: string) => {
    setCurrentLanguage(code);
    localStorage.setItem('menu-language', code);
  };

  const t = (key: string) => getTranslation(currentLanguage, key);

  return (
    <LanguageContext.Provider value={{ currentLanguage, setLanguage, t, languages }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
