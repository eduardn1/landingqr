import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface CartItemExtra {
  name: string;
  price: number;
}

interface CartItem {
  dish_id: string;
  name: string;
  price: number;
  quantity: number;
  notes?: string;
  extras?: CartItemExtra[];
  image_url?: string;
  size_variant?: string; // e.g. "Piccola", "Media", "Grande"
  removed_ingredients?: string[];
}

export type { CartItem, CartItemExtra };

interface TakeAwayCartContextType {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (dishId: string) => void;
  updateQuantity: (dishId: string, quantity: number) => void;
  updateNotes: (dishId: string, notes: string) => void;
  clearCart: () => void;
  subtotal: number;
  itemCount: number;
}

const TakeAwayCartContext = createContext<TakeAwayCartContextType | null>(null);

const CART_STORAGE_KEY = 'takeaway_cart';

export function TakeAwayCartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Persist cart to localStorage
  useEffect(() => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
  }, [items]);

  const addItem = (item: CartItem) => {
    setItems(prev => {
      const existing = prev.find(i => i.dish_id === item.dish_id);
      if (existing) {
        return prev.map(i =>
          i.dish_id === item.dish_id
            ? { ...i, quantity: i.quantity + item.quantity }
            : i
        );
      }
      return [...prev, item];
    });
  };

  const removeItem = (dishId: string) => {
    setItems(prev => prev.filter(i => i.dish_id !== dishId));
  };

  const updateQuantity = (dishId: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(dishId);
      return;
    }
    setItems(prev =>
      prev.map(i => (i.dish_id === dishId ? { ...i, quantity } : i))
    );
  };

  const updateNotes = (dishId: string, notes: string) => {
    setItems(prev =>
      prev.map(i => (i.dish_id === dishId ? { ...i, notes } : i))
    );
  };

  const clearCart = () => {
    setItems([]);
    localStorage.removeItem(CART_STORAGE_KEY);
  };

  const subtotal = items.reduce((sum, item) => {
    const extrasTotal = item.extras?.reduce((s, e) => s + e.price, 0) || 0;
    return sum + (item.price + extrasTotal) * item.quantity;
  }, 0);

  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <TakeAwayCartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        updateNotes,
        clearCart,
        subtotal,
        itemCount,
      }}
    >
      {children}
    </TakeAwayCartContext.Provider>
  );
}

export const useTakeAwayCart = () => {
  const context = useContext(TakeAwayCartContext);
  if (!context) {
    throw new Error('useTakeAwayCart must be used within TakeAwayCartProvider');
  }
  return context;
};
