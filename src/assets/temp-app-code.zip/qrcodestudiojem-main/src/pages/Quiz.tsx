import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ConversationalOnboarding } from '@/components/client/ConversationalOnboarding';
import { useOnboardingPreferences } from '@/hooks/useOnboardingPreferences';

export default function Quiz() {
  const navigate = useNavigate();
  const { savePreferences, clearPreferences } = useOnboardingPreferences();

  // Clear any existing preferences when starting quiz
  useEffect(() => {
    clearPreferences();
    sessionStorage.removeItem('onboarding_completed');
  }, []);

  const handleComplete = (answers: Record<string, any>) => {
    savePreferences(answers);
    sessionStorage.setItem('onboarding_completed', 'true');
    navigate('/menu');
  };

  const handleSkipToMenu = () => {
    sessionStorage.setItem('onboarding_completed', 'true');
    navigate('/menu');
  };

  return (
    <div className="min-h-screen bg-background">
      <ConversationalOnboarding 
        onComplete={handleComplete}
        onSkipToMenu={handleSkipToMenu}
      />
    </div>
  );
}
