import { useState, useRef, useMemo, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { type Dish } from '@/lib/mockData';
import { useCategories, useDishes, useFeaturedDishes, type DbDish } from '@/hooks/useMenu';
import { useRestaurantConfig, type MenuViewMode } from '@/hooks/useRestaurantConfig';
import { useDynamicTheme } from '@/hooks/useDynamicTheme';
import { useDynamicSEO } from '@/hooks/useDynamicSEO';
import { useDesignTemplates } from '@/hooks/useDesignTemplates';
import { HomepageClassic, HomepageModernGlass, HomepageBentoMinimal, HomepageParallax, HomepageAurora, HomepageSplitHero, HomepageVideoBackground, HomepageMasonry, type HomepageSectionProps } from '@/components/templates/homepage';
import { SplashScreen } from '@/components/client/SplashScreen';
import { ConversationalOnboarding, type OnboardingOption, type OnboardingFilters } from '@/components/client/ConversationalOnboarding';
import { useDynamicMoods } from '@/hooks/useDynamicMoods';
import { SwipeableCards } from '@/components/client/SwipeableCards';
import { DishDetailModal } from '@/components/client/DishDetailModal';
import { TableReservation } from '@/components/client/TableReservation';
import { FavoritesSection } from '@/components/client/FavoritesSection';
import { BottomNavigation } from '@/components/client/BottomNavigation';
import { AboutUsModal } from '@/components/client/AboutUsModal';
import { DishCard } from '@/components/DishCard';
import { AppHeader } from '@/components/AppHeader';
import { Footer } from '@/components/Footer';
import { HeaderMinimal, HeaderCentered, HeaderFloating } from '@/components/layout/HeaderVariants';
import { FooterMinimal, FooterExpanded, FooterSplit } from '@/components/layout/FooterVariants';
import { useFavorites, useSwipeInteractions } from '@/hooks/useFavorites';
import { useAuth } from '@/hooks/useAuth';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useOnboardingPreferences } from '@/hooks/useOnboardingPreferences';
import { DynamicHomeSections } from '@/components/client/DynamicHomeSections';
import { type FilterState } from '@/components/client/MenuFilterBar';
import { X, ShoppingBag } from 'lucide-react';

// Helper to convert database dish to Dish format for components
const dbDishToDish = (dbDish: DbDish, language: string): Dish => ({
  id: dbDish.id,
  categoryId: dbDish.category_id,
  name: { it: dbDish.name_it, en: dbDish.name_en },
  description: { it: dbDish.description_it || '', en: dbDish.description_en || '' },
  ingredients: { it: dbDish.ingredients_it || '', en: dbDish.ingredients_en || '' },
  images: dbDish.image_url && dbDish.image_url.trim() !== '' ? [dbDish.image_url] : [],
  price: Number(dbDish.price),
  originalPrice: dbDish.original_price ? Number(dbDish.original_price) : undefined,
  currency: dbDish.currency,
  tags: dbDish.tags || [],
  allergens: dbDish.allergens || [],
  spicyLevel: dbDish.spicy_level || undefined,
  portionSize: dbDish.portion_size || undefined,
  isAvailable: dbDish.is_available,
  isFeatured: dbDish.is_featured,
  isSeasonal: dbDish.is_seasonal,
  badge: dbDish.badge || undefined,
  displayOrder: dbDish.display_order,
});

type AppState = 'splash' | 'onboarding' | 'home';
type BottomTab = 'home' | 'menu' | 'discover' | 'favorites' | 'reservations' | 'profile';

const Index = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const skipOnboarding = searchParams.get('skipOnboarding') === 'true';
  const { currentLanguage, t } = useLanguage();
  
  // Dynamic SEO for home page
  useDynamicSEO('home');
  const menuRef = useRef<HTMLDivElement>(null);
  const accountRef = useRef<HTMLDivElement>(null);
  const { favorites, toggleFavorite, isFavorite, favoritesCount } = useFavorites();
  const { recordSwipe } = useSwipeInteractions();
  const { user, profile, isAuthenticated, isLoading: authLoading, signOut, updateProfile } = useAuth();
  const { requestPermission, isEnabled: pushEnabled } = usePushNotifications();
  const { 
    preferences: onboardingAnswers, 
    savePreferences: saveOnboardingAnswers,
    isDishRecommended,
    shouldSuggestSharing,
    clearPreferences,
  } = useOnboardingPreferences();

  // Check if user has completed onboarding in this session
  const hasCompletedOnboarding = sessionStorage.getItem('onboarding_completed') === 'true';
  const [appState, setAppState] = useState<AppState>(() => {
    if (skipOnboarding || hasCompletedOnboarding) return 'home';
    return 'splash';
  });
  const [activeTab, setActiveTab] = useState<BottomTab>('home');
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showSwipeCards, setShowSwipeCards] = useState(false);
  const [showReservation, setShowReservation] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [showTakeaway, setShowTakeaway] = useState(false);
  const [selectedDish, setSelectedDish] = useState<Dish | null>(null);
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    allergens: [],
    dietTypes: [],
    priceRange: [0, 50],
  });

  // Reopen reservation modal if user came back from login with pending reservation
  useEffect(() => {
    const hasPendingReservation = sessionStorage.getItem('reservation_pending') === 'true';
    const hasDraft = sessionStorage.getItem('reservation_draft');
    
    if (hasPendingReservation && hasDraft && isAuthenticated && !authLoading) {
      sessionStorage.removeItem('reservation_pending');
      // Small delay to ensure everything is loaded
      setTimeout(() => {
        setShowReservation(true);
      }, 500);
    }
  }, [isAuthenticated, authLoading]);

  // Fetch data from database
  const { config: restaurantConfig } = useRestaurantConfig();
  useDynamicTheme(); // Apply dynamic colors
  const { categories: dbCategories, isLoading: categoriesLoading } = useCategories();
  const { dishes: dbDishes, isLoading: dishesLoading } = useDishes(undefined, filters.allergens);
  const { moods: dynamicMoods } = useDynamicMoods();
  const { dishes: dbFeaturedDishes, isLoading: featuredLoading } = useFeaturedDishes(filters.allergens);
  
  // Design templates
  const { getActiveTemplate, getMergedConfig, headerVariant, footerVariant } = useDesignTemplates('homepage');
  const activeHomepageTemplate = getActiveTemplate('homepage');
  const baseHomepageConfig = getMergedConfig('homepage');
  const homepageTemplateKey = activeHomepageTemplate?.template_key || 'homepage_classic';
  
  // Get gradient colors from theme and merge into config
  const { gradientColors } = useDynamicTheme();
  const homepageConfig = useMemo(() => ({
    ...baseHomepageConfig,
    hero_config: {
      ...baseHomepageConfig.hero_config,
      gradient_colors: gradientColors || baseHomepageConfig.hero_config?.gradient_colors,
    }
  }), [baseHomepageConfig, gradientColors]);

  // Menu view mode - use backend config as default, allow client toggle
  const [menuViewMode, setMenuViewMode] = useState<MenuViewMode>('cards');
  
  // Sync with backend config when it loads
  useEffect(() => {
    if (restaurantConfig?.menu_view_mode) {
      setMenuViewMode(restaurantConfig.menu_view_mode);
    }
  }, [restaurantConfig?.menu_view_mode]);

  // Always show onboarding on each visit - no skip based on preferences

  const goToMenu = () => {
    navigate('/menu');
  };
  const goToHome = () => {
    setAppState('home');
    setActiveTab('home');
  };

  // Handle bottom tab navigation
  const handleTabChange = (tab: BottomTab) => {
    setActiveTab(tab);
    
    switch (tab) {
      case 'home':
        setAppState('home');
        break;
      case 'menu':
        navigate('/menu');
        break;
      case 'discover':
        setShowSwipeCards(true);
        break;
      case 'favorites':
        setShowFavorites(true);
        break;
      case 'reservations':
        setShowReservation(true);
        break;
      case 'profile':
        navigate('/profile');
        break;
    }
  };

  // Handle dynamic action button clicks
  const handleButtonAction = (actionType: string, actionValue: string | null) => {
    switch (actionType) {
      case 'internal':
        if (actionValue === 'menu') navigate('/menu');
        else if (actionValue === 'home') goToHome();
        else if (actionValue === 'takeaway' || actionValue === 'asporto') navigate('/takeaway');
        else if (actionValue === 'profile') navigate('/profile');
        else if (actionValue) navigate(`/${actionValue}`);
        break;
      case 'modal':
        if (actionValue === 'reservation') setShowReservation(true);
        else if (actionValue === 'discover') setShowSwipeCards(true);
        else if (actionValue === 'takeaway' || actionValue === 'asporto') navigate('/takeaway');
        else if (actionValue === 'about') setShowAbout(true);
        else if (actionValue === 'favorites') setShowFavorites(true);
        break;
      case 'quiz':
        navigate('/quiz');
        break;
      case 'external':
        if (actionValue) window.open(actionValue, '_blank');
        break;
    }
  };

  // Convert db dishes to Dish format
  const allDishes = useMemo(() => {
    return dbDishes.map(d => dbDishToDish(d, currentLanguage));
  }, [dbDishes, currentLanguage]);

  // Featured dishes for home
  const featuredDishes = useMemo(() => {
    return dbFeaturedDishes.map(d => dbDishToDish(d, currentLanguage)).slice(0, 4);
  }, [dbFeaturedDishes, currentLanguage]);

  // Recommended based on onboarding answers or mood
  const recommendedDishes = useMemo(() => {
    // If we have onboarding answers, use them for filtering
    if (onboardingAnswers) {
      // Collect all filters from answers
      const allFilters: OnboardingFilters[] = Object.values(onboardingAnswers)
        .filter(answer => answer.filters)
        .map(answer => answer.filters!);
      
      // Check for random selection
      const needsRandom = allFilters.some(f => f.random);
      if (needsRandom) {
        // Shuffle and return random dishes
        const shuffled = [...allDishes].sort(() => Math.random() - 0.5);
        return shuffled.slice(0, 6);
      }
      
      // Collect all tags
      const allTags = allFilters
        .filter(f => f.tags)
        .flatMap(f => f.tags || []);
      
      // Check for featured/seasonal filters
      const needsFeatured = allFilters.some(f => f.is_featured);
      const needsSeasonal = allFilters.some(f => f.is_seasonal);
      
      let filtered = allDishes.filter((dish) => {
        // Featured filter
        if (needsFeatured && !dish.isFeatured) return false;
        
        // Seasonal filter
        if (needsSeasonal && !dish.isSeasonal) return false;
        
        // Tags filter - dish should match at least one tag
        if (allTags.length > 0) {
          const hasMatchingTag = allTags.some(tag => dish.tags.includes(tag));
          // If dish doesn't match tags but is featured, still include it
          if (!hasMatchingTag && !dish.isFeatured) return false;
        }
        
        return dish.isAvailable;
      });
      
      // Sort by featured first, then by display order
      filtered.sort((a, b) => {
        if (a.isFeatured && !b.isFeatured) return -1;
        if (!a.isFeatured && b.isFeatured) return 1;
        return a.displayOrder - b.displayOrder;
      });
      
      return filtered.slice(0, 6);
    }
    
    // Fallback to mood-based filtering using dynamic moods from DB
    if (!selectedMood) return featuredDishes;
    const mood = dynamicMoods.find((m) => m.mood_key === selectedMood);
    if (!mood) return featuredDishes;
    
    return allDishes
      .filter((dish) => {
        // Featured filter
        if (mood.filters?.is_featured && !dish.isFeatured) return false;
        // Seasonal filter
        if (mood.filters?.is_seasonal && !dish.isSeasonal) return false;
        // Tags filter
        if (mood.filters?.tags?.length) {
          const hasTags = mood.filters.tags.some((tag) => dish.tags.includes(tag));
          if (!hasTags && !dish.isFeatured) return false;
        }
        // Removed max_prep_time filter (preparation_time removed from dishes)
        return dish.isAvailable;
      })
      .slice(0, 6);
  }, [onboardingAnswers, selectedMood, featuredDishes, allDishes, dynamicMoods]);

  // Shareable dishes for groups (friends/family)
  const shareableDishes = useMemo(() => {
    if (!shouldSuggestSharing()) return [];
    
    // Filter dishes that are good for sharing - larger portions, family style, etc.
    return allDishes
      .filter((dish) => {
        const shareableTags = ['sharing', 'famiglia', 'grande', 'tagliere', 'antipasti'];
        const hasShareableTag = shareableTags.some(tag => 
          dish.tags.some(t => t.toLowerCase().includes(tag))
        );
        // Include featured dishes or dishes with large portions as shareable
        return hasShareableTag || dish.portionSize === 'large' || dish.isFeatured;
      })
      .slice(0, 4);
  }, [allDishes, shouldSuggestSharing]);

  // Handle reset preferences
  const handleResetPreferences = () => {
    clearPreferences();
    setSelectedMood(null);
    setAppState('onboarding');
  };

  // Check if a dish matches the selected mood
  const isDishMoodMatch = (dish: Dish): boolean => {
    if (!selectedMood) return false;
    const mood = dynamicMoods.find((m) => m.mood_key === selectedMood);
    if (!mood) return false;
    
    // Check all mood filters
    if (mood.filters?.is_featured && !dish.isFeatured) return false;
    if (mood.filters?.is_seasonal && !dish.isSeasonal) return false;
    if (mood.filters?.tags?.length) {
      const hasTags = mood.filters.tags.some((tag) => dish.tags.includes(tag));
      if (!hasTags) return false;
    }
    // Removed max_prep_time filter (preparation_time removed from dishes)
    return true;
  };

  // Swipeable dishes
  const swipeableDishes = useMemo(() => {
    return allDishes.filter(d => d.isFeatured && d.isAvailable);
  }, [allDishes]);

  // Filtered dishes for menu (also considers mood selection)
  const filteredDishes = useMemo(() => {
    return allDishes
      .filter((dish) => {
        if (selectedCategory && dish.categoryId !== selectedCategory) return false;
        if (filters.search) {
          const searchLower = filters.search.toLowerCase();
          const name = getLocalizedContent(dish.name, currentLanguage).toLowerCase();
          const desc = getLocalizedContent(dish.description, currentLanguage).toLowerCase();
          if (!name.includes(searchLower) && !desc.includes(searchLower)) return false;
        }
        if (filters.dietTypes.length > 0 && !filters.dietTypes.some((d) => dish.tags.includes(d))) return false;
        if (dish.price < filters.priceRange[0] || dish.price > filters.priceRange[1]) return false;
        
        // Mood filter for menu page
        if (selectedMood) {
          const mood = dynamicMoods.find((m) => m.mood_key === selectedMood);
          if (mood) {
            if (mood.filters?.is_featured && !dish.isFeatured) return false;
            if (mood.filters?.is_seasonal && !dish.isSeasonal) return false;
            if (mood.filters?.tags?.length) {
              const hasTags = mood.filters.tags.some((tag) => dish.tags.includes(tag));
              if (!hasTags && !dish.isFeatured) return false;
            }
            // Removed max_prep_time filter (preparation_time removed from dishes)
          }
        }
        
        return dish.isAvailable;
      })
      .sort((a, b) => {
        if (a.isFeatured && !b.isFeatured) return -1;
        if (!a.isFeatured && b.isFeatured) return 1;
        return a.displayOrder - b.displayOrder;
      });
  }, [allDishes, selectedCategory, filters, currentLanguage, selectedMood, dynamicMoods]);

  // Convert db categories for use
  const categories = useMemo(() => {
    return dbCategories.map(c => ({
      id: c.id,
      name: { it: c.name_it, en: c.name_en },
      description: { it: c.description_it || '', en: c.description_en || '' },
      icon: c.icon,
      imageUrl: c.image_url || '',
      displayOrder: c.display_order,
      isActive: c.is_active,
      isFeatured: c.is_featured,
    }));
  }, [dbCategories]);

  // Grouped dishes
  const groupedDishes = useMemo(() => {
    if (selectedCategory) {
      const cat = categories.find((c) => c.id === selectedCategory);
      return cat ? [{ category: cat, dishes: filteredDishes }] : [];
    }
    return categories
      .filter((c) => c.isActive)
      .map((category) => ({ category, dishes: filteredDishes.filter((d) => d.categoryId === category.id) }))
      .filter((g) => g.dishes.length > 0);
  }, [filteredDishes, selectedCategory, categories]);
  

  const handleLikeDish = (dish: Dish) => {
    toggleFavorite(dish.id);
    recordSwipe(dish.id, 'like');
  };

  const handleSkipDish = (dish: Dish) => {
    recordSwipe(dish.id, 'skip');
  };

  const handleDishClick = (dish: Dish) => {
    setSelectedDish(dish);
  };

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      {/* Splash */}
      <AnimatePresence>
        {appState === 'splash' && (
          <SplashScreen 
            onComplete={(destination) => {
              if (destination) {
                // Handle destination from interactive onboarding
                if (destination.startsWith('/?action=')) {
                  const action = destination.replace('/?action=', '');
                  setAppState('home');
                  if (action === 'reservation') {
                    setTimeout(() => setShowReservation(true), 300);
                  }
                } else if (destination === '/?view=menu') {
                  navigate('/menu');
                  return;
                } else if (destination === '/?section=events') {
                  setAppState('home');
                  // Scroll to events section after render
                  setTimeout(() => {
                    const eventsSection = document.querySelector('[data-section="events"]');
                    eventsSection?.scrollIntoView({ behavior: 'smooth' });
                  }, 500);
                } else if (destination === '/takeaway') {
                  navigate('/takeaway');
                  return;
                } else {
                  setAppState('home');
                }
              } else {
                setAppState('onboarding');
              }
            }} 
          />
        )}
      </AnimatePresence>

      {/* Onboarding */}
      <AnimatePresence>
        {appState === 'onboarding' && (
          <ConversationalOnboarding 
            onComplete={(answers) => {
              saveOnboardingAnswers(answers);
              sessionStorage.setItem('onboarding_completed', 'true');
              setAppState('home');
            }} 
            onSkipToMenu={() => {
              sessionStorage.setItem('onboarding_completed', 'true');
              goToHome();
            }}
          />
        )}
      </AnimatePresence>

      {/* Main Content */}
      {appState === 'home' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          {/* Dynamic Header based on template config */}
          {headerVariant === 'minimal' ? (
            <HeaderMinimal 
              showBack={false} 
              onBack={goToHome}
              onOpenFavorites={() => setShowFavorites(true)}
            />
          ) : headerVariant === 'centered' ? (
            <HeaderCentered 
              showBack={false} 
              onBack={goToHome}
              onOpenFavorites={() => setShowFavorites(true)}
            />
          ) : headerVariant === 'floating' ? (
            <>
              <HeaderFloating 
                showBack={false} 
                onBack={goToHome}
                onOpenFavorites={() => setShowFavorites(true)}
              />
              {/* Spacer for floating header */}
              <div className="h-20" />
            </>
          ) : (
            <AppHeader 
              showBack={false} 
              onBack={goToHome}
              onOpenFavorites={() => setShowFavorites(true)}
            />
          )}

          {/* Home */}
          {appState === 'home' && (() => {
            // Build section props for templates
            const sectionProps: HomepageSectionProps = {
              onOpenAbout: () => setShowAbout(true),
              onButtonAction: handleButtonAction,
              goToMenu,
              onDishClick: handleDishClick,
              onOpenFavorites: () => setShowFavorites(true),
              handleResetPreferences,
              selectedMood,
              onSelectMood: setSelectedMood,
              recommendedDishes,
              shareableDishes,
              featuredLoading,
              categoriesLoading,
              onboardingAnswers,
              favoritesCount,
              isAuthenticated,
              isAuthLoading: authLoading,
              isDishRecommended,
              t,
              restaurantConfig: restaurantConfig ? {
                name: restaurantConfig.name,
                tagline: restaurantConfig.tagline as { it?: string; en?: string },
                cover_image_url: restaurantConfig.cover_image_url || undefined,
                logo_url: restaurantConfig.logo_url || undefined,
              } : undefined,
              currentLanguage,
            };

            switch (homepageTemplateKey) {
              case 'homepage_split':
                return <HomepageSplitHero config={homepageConfig} sectionProps={sectionProps} />;
              case 'homepage_video':
                return <HomepageVideoBackground config={homepageConfig} sectionProps={sectionProps} />;
              case 'homepage_masonry':
                return <HomepageMasonry config={homepageConfig} sectionProps={sectionProps} />;
              case 'homepage_modern_glass':
                return <HomepageModernGlass config={homepageConfig} sectionProps={sectionProps} />;
              case 'homepage_parallax':
                return <HomepageParallax config={homepageConfig} sectionProps={sectionProps} />;
              case 'homepage_aurora':
                return <HomepageAurora config={homepageConfig} sectionProps={sectionProps} />;
              case 'homepage_bento_minimal':
                return <HomepageBentoMinimal config={homepageConfig} sectionProps={sectionProps} />;
              default:
                return <HomepageClassic config={homepageConfig} sectionProps={sectionProps} />;
            }
          })()}

        </motion.div>
      )}

      {/* Swipeable Cards Modal */}
      <AnimatePresence>
        {showSwipeCards && (
          <SwipeableCards
            dishes={swipeableDishes}
            isOpen={showSwipeCards}
            onClose={() => setShowSwipeCards(false)}
            onLike={handleLikeDish}
            onSkip={handleSkipDish}
          />
        )}
      </AnimatePresence>

      {/* Favorites Section */}
      <AnimatePresence>
        {showFavorites && (
          <FavoritesSection
            isOpen={showFavorites}
            onClose={() => setShowFavorites(false)}
            localFavorites={favorites}
            onRemoveFavorite={toggleFavorite}
            onDishClick={handleDishClick}
          />
        )}
      </AnimatePresence>

      {/* Dish Detail Modal */}
      <DishDetailModal
        dish={selectedDish}
        isOpen={!!selectedDish}
        onClose={() => setSelectedDish(null)}
        isFavorite={selectedDish ? isFavorite(selectedDish.id) : false}
        onToggleFavorite={toggleFavorite}
      />

      {/* Table Reservation Modal */}
      <TableReservation
        isOpen={showReservation}
        onClose={() => setShowReservation(false)}
      />

      {/* About Us Modal */}
      <AboutUsModal
        isOpen={showAbout}
        onClose={() => setShowAbout(false)}
      />

      {/* Takeaway Modal */}
      <AnimatePresence>
        {showTakeaway && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/60 backdrop-blur-sm"
            onClick={() => setShowTakeaway(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-sm bg-card/90 backdrop-blur-xl border border-border/20 rounded-3xl p-8 shadow-2xl"
            >
              <button
                onClick={() => setShowTakeaway(false)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full bg-secondary flex items-center justify-center hover:bg-secondary/80 transition-colors"
              >
                <X className="w-4 h-4 text-foreground" />
              </button>
              
              <div className="text-center space-y-4">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-accent/30 to-accent/10 flex items-center justify-center">
                  <ShoppingBag className="w-8 h-8 text-accent" />
                </div>
                <h2 className="text-xl font-semibold text-foreground">Ordina da Asporto</h2>
                <div className="py-4">
                  <p className="text-foreground/80 text-sm leading-relaxed">
                    🚀 <span className="font-medium">A breve disponibile!</span>
                  </p>
                  <p className="text-muted-foreground text-xs mt-2">
                    Stiamo lavorando per offrirti la possibilità di ordinare comodamente da casa e ritirare in negozio.
                  </p>
                </div>
                <button
                  onClick={() => setShowTakeaway(false)}
                  className="w-full py-3 rounded-xl bg-secondary text-foreground font-medium hover:bg-secondary/80 transition-colors"
                >
                  Ho capito
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Info & Contatti Section - Rendered via DynamicHomeSections based on home_sections order */}

      {/* Footer - Dynamic based on template config */}
      {appState === 'home' && (
        <div className={headerVariant === 'floating' ? 'pb-24' : 'pb-20'}>
          {footerVariant === 'minimal' ? (
            <FooterMinimal />
          ) : footerVariant === 'expanded' ? (
            <FooterExpanded />
          ) : footerVariant === 'split' ? (
            <FooterSplit />
          ) : (
            <Footer />
          )}
        </div>
      )}

      {/* Bottom Navigation - Mobile Only */}
      {appState === 'home' && (
        <BottomNavigation
          activeTab={activeTab}
          onTabChange={handleTabChange}
          favoritesCount={favoritesCount}
        />
      )}
    </div>
  );
};

export default Index;