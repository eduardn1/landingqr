import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { format, isToday } from 'date-fns';
import { it } from 'date-fns/locale';
import { 
  Package, Truck, Clock, CheckCircle2, Phone, MapPin, 
  Navigation, User, Star, TrendingUp, LogIn, 
  ChefHat, AlertCircle, MapPinned, Power
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { useDriverLocation } from '@/hooks/useDriverLocation';
import { DriverPerformanceDashboard } from '@/components/driver/DriverPerformanceDashboard';

interface DriverOrder {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  order_type: 'pickup' | 'delivery';
  delivery_address: any;
  total: number;
  status: string;
  items: any[];
  special_notes: string | null;
  created_at: string;
  ready_at: string | null;
  completed_at: string | null;
  delivery_actual_time: string | null;
}

interface DriverInfo {
  id: string;
  name: string;
  phone: string;
  vehicle_type: string | null;
  vehicle_plate: string | null;
  status: string;
  average_rating: number | null;
  total_deliveries: number | null;
  is_online?: boolean;
  emoji?: string | null;
}

const statusConfig = {
  ready: { label: 'Pronto per consegna', color: 'bg-green-500', icon: Package },
  delivering: { label: 'In consegna', color: 'bg-indigo-500', icon: Truck },
  completed: { label: 'Consegnato', color: 'bg-emerald-600', icon: CheckCircle2 },
};

export default function Driver() {
  const [searchParams] = useSearchParams();
  const tokenFromUrl = searchParams.get('token');
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [driver, setDriver] = useState<DriverInfo | null>(null);
  const [orders, setOrders] = useState<DriverOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loginMethod, setLoginMethod] = useState<'token' | 'phone' | 'pin'>('phone');
  const [phoneInput, setPhoneInput] = useState('');
  const [pinInput, setPinInput] = useState('');
  const [activeTab, setActiveTab] = useState<'active' | 'today' | 'stats'>('active');

  // Location tracking
  const { 
    location, 
    isTracking, 
    startTracking, 
    stopTracking, 
    updateOrderLocation 
  } = useDriverLocation(driver?.id || null);

  // Auto-login with token from URL
  useEffect(() => {
    if (tokenFromUrl) {
      loginWithToken(tokenFromUrl);
    } else {
      setIsLoading(false);
    }
  }, [tokenFromUrl]);

  // Real-time subscription for orders
  useEffect(() => {
    if (!driver) return;

    console.log('Setting up realtime subscription for driver:', driver.id);

    const channel = supabase
      .channel('driver-orders-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'takeaway_orders',
          filter: `driver_id=eq.${driver.id}`,
        },
        (payload) => {
          console.log('Realtime update received:', payload.eventType);
          
          if (payload.eventType === 'INSERT') {
            const newOrder = payload.new as unknown as DriverOrder;
            setOrders(prev => [newOrder, ...prev]);
            
            // Show browser notification for new order
            if ('Notification' in window && Notification.permission === 'granted') {
              new Notification('🚗 Nuova consegna assegnata!', {
                body: `Ordine #${newOrder.order_number} - ${newOrder.customer_name}`,
                icon: '/favicon.ico',
              });
            }
            toast.success('Nuova consegna assegnata!');
          } else if (payload.eventType === 'UPDATE') {
            const updatedOrder = payload.new as unknown as DriverOrder;
            setOrders(prev => prev.map(o => o.id === updatedOrder.id ? updatedOrder : o));
          }
        }
      )
      .subscribe((status) => {
        console.log('Realtime subscription status:', status);
      });

    return () => {
      console.log('Removing realtime channel');
      supabase.removeChannel(channel);
    };
  }, [driver?.id]);

  const loginWithToken = async (token: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('takeaway_drivers')
        .select('*')
        .eq('access_token', token)
        .eq('is_active', true)
        .single();

      if (error || !data) {
        toast.error('Link non valido o scaduto');
        setIsLoading(false);
        return;
      }

      // Update last login
      await supabase
        .from('takeaway_drivers')
        .update({ last_login_at: new Date().toISOString() })
        .eq('id', data.id);

      setDriver(data);
      setIsAuthenticated(true);
      localStorage.setItem('driver_token', token);
      await fetchOrders(data.id);
    } catch (err) {
      toast.error('Errore di autenticazione');
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithPhone = async () => {
    if (!phoneInput.trim()) {
      toast.error('Inserisci il numero di telefono');
      return;
    }

    setIsLoading(true);
    try {
      // Normalize phone number
      const normalizedPhone = phoneInput.replace(/\s/g, '');
      
      const { data, error } = await supabase
        .from('takeaway_drivers')
        .select('*')
        .eq('is_active', true)
        .or(`phone.eq.${normalizedPhone},phone.ilike.%${normalizedPhone.slice(-9)}%`)
        .single();

      if (error || !data) {
        toast.error('Numero non trovato');
        setIsLoading(false);
        return;
      }

      // Update last login
      await supabase
        .from('takeaway_drivers')
        .update({ last_login_at: new Date().toISOString() })
        .eq('id', data.id);

      setDriver(data);
      setIsAuthenticated(true);
      if (data.access_token) {
        localStorage.setItem('driver_token', data.access_token);
      }
      await fetchOrders(data.id);
    } catch (err) {
      toast.error('Errore di autenticazione');
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithPin = async () => {
    if (!pinInput.trim()) {
      toast.error('Inserisci il PIN');
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('takeaway_drivers')
        .select('*')
        .eq('pin_code', pinInput)
        .eq('is_active', true)
        .single();

      if (error || !data) {
        toast.error('PIN non valido');
        setIsLoading(false);
        return;
      }

      // Update last login
      await supabase
        .from('takeaway_drivers')
        .update({ last_login_at: new Date().toISOString() })
        .eq('id', data.id);

      setDriver(data);
      setIsAuthenticated(true);
      if (data.access_token) {
        localStorage.setItem('driver_token', data.access_token);
      }
      await fetchOrders(data.id);
    } catch (err) {
      toast.error('Errore di autenticazione');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchOrders = async (driverId?: string) => {
    const id = driverId || driver?.id;
    if (!id) return;

    try {
      // Get today's orders assigned to this driver
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('takeaway_orders')
        .select('*')
        .eq('driver_id', id)
        .gte('created_at', `${today}T00:00:00`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setOrders((data || []) as unknown as DriverOrder[]);
    } catch (err) {
      console.error('Error fetching orders:', err);
    }
  };

  const handleMarkDelivered = async (orderId: string) => {
    try {
      const { error } = await supabase
        .from('takeaway_orders')
        .update({
          status: 'completed',
          completed_at: new Date().toISOString(),
          delivery_actual_time: new Date().toISOString(),
        })
        .eq('id', orderId);

      if (error) throw error;

      toast.success('Ordine consegnato!');
      
      // Update local state immediately
      setOrders(prev => prev.map(o => 
        o.id === orderId ? { ...o, status: 'completed', completed_at: new Date().toISOString() } : o
      ));

      // Update driver stats
      if (driver) {
        await supabase
          .from('takeaway_drivers')
          .update({ 
            total_deliveries: (driver.total_deliveries || 0) + 1,
            status: 'available'
          })
          .eq('id', driver.id);
        
        setDriver(prev => prev ? { 
          ...prev, 
          total_deliveries: (prev.total_deliveries || 0) + 1,
          status: 'available'
        } : null);
      }
    } catch (err: any) {
      toast.error('Errore: ' + (err.message || 'Impossibile aggiornare'));
    }
  };

  const handleSetBusy = async () => {
    if (!driver) return;
    const newStatus = driver.status === 'busy' ? 'available' : 'busy';
    
    try {
      await supabase
        .from('takeaway_drivers')
        .update({ status: newStatus })
        .eq('id', driver.id);
      
      setDriver(prev => prev ? { ...prev, status: newStatus } : null);
      toast.success(newStatus === 'busy' ? 'Stato: Occupato' : 'Stato: Disponibile');
    } catch (err) {
      toast.error('Errore aggiornamento stato');
    }
  };

  const handleToggleOnline = async () => {
    if (!driver) return;
    
    if (isTracking) {
      await stopTracking();
      toast.success('Sei offline');
    } else {
      await startTracking();
      toast.success('Sei online - GPS attivo');
    }
    
    setDriver(prev => prev ? { ...prev, is_online: !isTracking } : null);
  };

  // Update order location when delivering
  useEffect(() => {
    if (location && driver) {
      const deliveringOrders = orders.filter(o => o.status === 'delivering');
      deliveringOrders.forEach(order => {
        updateOrderLocation(order.id);
      });
    }
  }, [location, orders, driver, updateOrderLocation]);

  // Try auto-login from localStorage
  useEffect(() => {
    const savedToken = localStorage.getItem('driver_token');
    if (savedToken && !tokenFromUrl) {
      loginWithToken(savedToken);
    }
  }, []);

  // Active orders (ready or delivering)
  const activeOrders = orders.filter(o => ['ready', 'delivering'].includes(o.status));
  const completedToday = orders.filter(o => o.status === 'completed');

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-sm"
        >
          <Card>
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="w-8 h-8 text-accent" />
              </div>
              <CardTitle className="text-xl">Pannello Driver</CardTitle>
              <p className="text-sm text-muted-foreground">Accedi per vedere le tue consegne</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs value={loginMethod} onValueChange={(v) => setLoginMethod(v as any)}>
                <TabsList className="grid grid-cols-2 w-full">
                  <TabsTrigger value="phone">Telefono</TabsTrigger>
                  <TabsTrigger value="pin">PIN</TabsTrigger>
                </TabsList>
                
                <TabsContent value="phone" className="space-y-4 mt-4">
                  <Input
                    type="tel"
                    placeholder="Il tuo numero di telefono"
                    value={phoneInput}
                    onChange={(e) => setPhoneInput(e.target.value)}
                  />
                  <Button className="w-full" onClick={loginWithPhone}>
                    <LogIn className="w-4 h-4 mr-2" />
                    Accedi
                  </Button>
                </TabsContent>
                
                <TabsContent value="pin" className="space-y-4 mt-4">
                  <Input
                    type="password"
                    placeholder="Il tuo PIN"
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    maxLength={6}
                  />
                  <Button className="w-full" onClick={loginWithPin}>
                    <LogIn className="w-4 h-4 mr-2" />
                    Accedi
                  </Button>
                </TabsContent>
              </Tabs>
              
              <p className="text-xs text-center text-muted-foreground">
                Oppure usa il link personale inviato dal ristorante
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="bg-card border-b border-border sticky top-0 z-10">
        <div className="p-4 max-w-lg mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center text-xl">
                {driver?.emoji || '🚗'}
              </div>
              <div>
                <h1 className="font-bold">{driver?.name}</h1>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  {driver?.vehicle_type && <span>{driver.vehicle_type}</span>}
                  {driver?.vehicle_plate && <span>• {driver.vehicle_plate}</span>}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 bg-secondary/50 rounded-lg px-3 py-1.5">
                <Power className={cn("w-4 h-4", isTracking ? "text-green-500" : "text-muted-foreground")} />
                <Switch 
                  checked={isTracking}
                  onCheckedChange={handleToggleOnline}
                />
                <span className="text-xs">{isTracking ? 'Online' : 'Offline'}</span>
              </div>
              <Button
                variant={driver?.status === 'busy' ? 'destructive' : 'default'}
                size="sm"
                onClick={handleSetBusy}
              >
                {driver?.status === 'busy' ? 'Occupato' : 'Disponibile'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Location Status Banner */}
      {isTracking && location && (
        <div className="bg-green-500/10 border-b border-green-500/20 px-4 py-2">
          <div className="max-w-lg mx-auto flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
            <MapPinned className="w-4 h-4" />
            <span>GPS attivo - Posizione condivisa con i clienti</span>
          </div>
        </div>
      )}

      {/* Stats Bar */}
      <div className="bg-secondary/30 border-b border-border">
        <div className="p-3 max-w-lg mx-auto flex items-center justify-around text-center">
          <div>
            <p className="text-2xl font-bold text-accent">{activeOrders.length}</p>
            <p className="text-xs text-muted-foreground">Attive</p>
          </div>
          <div className="w-px h-8 bg-border" />
          <div>
            <p className="text-2xl font-bold">{completedToday.length}</p>
            <p className="text-xs text-muted-foreground">Oggi</p>
          </div>
          <div className="w-px h-8 bg-border" />
          <div>
            <p className="text-2xl font-bold">{driver?.total_deliveries || 0}</p>
            <p className="text-xs text-muted-foreground">Totali</p>
          </div>
          <div className="w-px h-8 bg-border" />
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
            <p className="text-lg font-bold">{driver?.average_rating?.toFixed(1) || '-'}</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-lg mx-auto p-4">
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
          <TabsList className="grid grid-cols-3 w-full mb-4">
            <TabsTrigger value="active" className="gap-1">
              <Truck className="w-4 h-4" />
              <span className="hidden sm:inline">Attive</span>
              {activeOrders.length > 0 && (
                <Badge variant="destructive" className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
                  {activeOrders.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="today" className="gap-1">
              <CheckCircle2 className="w-4 h-4" />
              <span className="hidden sm:inline">Oggi</span>
            </TabsTrigger>
            <TabsTrigger value="stats" className="gap-1">
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Stats</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-3">
            <AnimatePresence mode="popLayout">
              {activeOrders.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-12"
                >
                  <Package className="w-12 h-12 mx-auto text-muted-foreground/30 mb-4" />
                  <p className="text-muted-foreground">Nessuna consegna attiva</p>
                  <p className="text-sm text-muted-foreground/70">Le nuove consegne appariranno qui</p>
                </motion.div>
              ) : (
                activeOrders.map((order) => (
                  <DriverOrderCard 
                    key={order.id} 
                    order={order} 
                    onMarkDelivered={handleMarkDelivered}
                  />
                ))
              )}
            </AnimatePresence>
          </TabsContent>

          <TabsContent value="today" className="space-y-3">
            {completedToday.length === 0 ? (
              <div className="text-center py-12">
                <CheckCircle2 className="w-12 h-12 mx-auto text-muted-foreground/30 mb-4" />
                <p className="text-muted-foreground">Nessuna consegna completata oggi</p>
              </div>
            ) : (
              completedToday.map((order) => (
                <DriverOrderCard key={order.id} order={order} completed />
              ))
            )}
          </TabsContent>

          <TabsContent value="stats">
            {driver && (
              <DriverPerformanceDashboard 
                driver={driver} 
                orders={orders} 
              />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function DriverOrderCard({ 
  order, 
  onMarkDelivered,
  completed = false 
}: { 
  order: DriverOrder; 
  onMarkDelivered?: (id: string) => void;
  completed?: boolean;
}) {
  const status = order.status as keyof typeof statusConfig;
  const StatusIcon = statusConfig[status]?.icon || Package;

  const openNavigation = () => {
    if (order.delivery_address) {
      const address = `${order.delivery_address.street}, ${order.delivery_address.city}`;
      const encodedAddress = encodeURIComponent(address);
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`, '_blank');
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -100 }}
    >
      <Card className={cn(
        "overflow-hidden",
        !completed && order.status === 'ready' && "border-green-500/50 bg-green-500/5"
      )}>
        <CardHeader className="p-4 pb-2">
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-base font-bold flex items-center gap-2">
                #{order.order_number}
                <Badge 
                  variant="outline" 
                  className={cn("text-xs", statusConfig[status]?.color, "text-white border-0")}
                >
                  {statusConfig[status]?.label}
                </Badge>
              </CardTitle>
              <p className="text-xs text-muted-foreground mt-1">
                {format(new Date(order.created_at), 'HH:mm', { locale: it })}
                {order.ready_at && ` • Pronto: ${format(new Date(order.ready_at), 'HH:mm')}`}
                {order.completed_at && ` • Consegnato: ${format(new Date(order.completed_at), 'HH:mm')}`}
              </p>
            </div>
            <span className="font-bold text-accent text-lg">€{order.total.toFixed(2)}</span>
          </div>
        </CardHeader>
        
        <CardContent className="p-4 pt-2 space-y-3">
          {/* Customer */}
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-muted-foreground" />
            <span className="font-medium">{order.customer_name}</span>
          </div>

          {/* Phone */}
          <a 
            href={`tel:${order.customer_phone}`}
            className="flex items-center gap-2 text-accent hover:underline"
          >
            <Phone className="w-4 h-4" />
            {order.customer_phone}
          </a>

          {/* Address */}
          {order.delivery_address && (
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
              <div>
                <p className="font-medium">{order.delivery_address.street}</p>
                <p className="text-sm text-muted-foreground">
                  {order.delivery_address.city} {order.delivery_address.zip}
                </p>
                {order.delivery_address.floor && (
                  <p className="text-xs text-muted-foreground">
                    Piano: {order.delivery_address.floor} 
                    {order.delivery_address.doorbell && ` • Citofono: ${order.delivery_address.doorbell}`}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Items */}
          <div className="bg-secondary/30 rounded-lg p-3">
            <p className="text-xs text-muted-foreground mb-2">{order.items.length} articoli</p>
            <ul className="space-y-2 text-sm">
              {order.items.map((item: any, idx: number) => (
                <li key={idx} className="border-b border-border/30 last:border-0 pb-2 last:pb-0">
                  <div className="flex justify-between font-medium">
                    <span>{item.quantity}x {item.name}</span>
                  </div>
                  {/* Extras */}
                  {item.extras && item.extras.length > 0 && (
                    <div className="mt-1 pl-3">
                      {item.extras.map((extra: any, i: number) => (
                        <p key={i} className="text-xs text-accent">+ {extra.name}</p>
                      ))}
                    </div>
                  )}
                  {/* Notes */}
                  {item.notes && (
                    <p className="text-xs text-muted-foreground mt-1 pl-3 italic">"{item.notes}"</p>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Special Notes */}
          {order.special_notes && (
            <div className="flex items-start gap-2 bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
              <AlertCircle className="w-4 h-4 text-yellow-500 mt-0.5" />
              <p className="text-sm">{order.special_notes}</p>
            </div>
          )}

          {/* Actions */}
          {!completed && (
            <div className="flex gap-2 pt-2">
              {order.delivery_address && (
                <Button variant="outline" className="flex-1" onClick={openNavigation}>
                  <Navigation className="w-4 h-4 mr-2" />
                  Naviga
                </Button>
              )}
              {order.status === 'delivering' && onMarkDelivered && (
                <Button className="flex-1" onClick={() => onMarkDelivered(order.id)}>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Consegnato
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}