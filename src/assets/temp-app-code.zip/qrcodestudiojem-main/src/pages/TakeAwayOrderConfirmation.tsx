import { useParams, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useTakeAwayOrder, TakeAwayOrder } from '@/hooks/useTakeAwayOrders';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { BackButton } from '@/components/ui/BackButton';
import { OrderRatingModal } from '@/components/client/OrderRatingModal';
import { DeliveryTracker } from '@/components/client/DeliveryTracker';
import { useAuthSession } from '@/hooks/useAuthSession';
import { 
  CheckCircle2, 
  Clock, 
  Package, 
  Truck, 
  MapPin, 
  Phone,
  AlertCircle,
  XCircle,
  RefreshCw,
  Star
} from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const statusConfig: Record<string, { icon: any; label: string; color: string }> = {
  pending: { icon: Clock, label: 'In attesa di conferma', color: 'text-yellow-500' },
  accepted: { icon: CheckCircle2, label: 'Accettato', color: 'text-blue-500' },
  preparing: { icon: Package, label: 'In preparazione', color: 'text-purple-500' },
  ready: { icon: CheckCircle2, label: 'Pronto per il ritiro', color: 'text-green-500' },
  delivering: { icon: Truck, label: 'In consegna', color: 'text-indigo-500' },
  completed: { icon: CheckCircle2, label: 'Completato', color: 'text-green-500' },
  rejected: { icon: XCircle, label: 'Rifiutato', color: 'text-red-500' },
  cancelled: { icon: XCircle, label: 'Annullato', color: 'text-red-500' },
};

// Status progress component
function OrderStatusProgress({ 
  currentStatus, 
  orderType 
}: { 
  currentStatus: string; 
  orderType: 'pickup' | 'delivery';
}) {
  const pickupSteps = ['pending', 'accepted', 'preparing', 'ready'];
  const deliverySteps = ['pending', 'accepted', 'preparing', 'ready', 'delivering'];
  const steps = orderType === 'delivery' ? deliverySteps : pickupSteps;
  
  const currentIndex = steps.indexOf(currentStatus);
  
  const stepLabels: Record<string, string> = {
    pending: 'Attesa',
    accepted: 'Accettato',
    preparing: 'Preparazione',
    ready: 'Pronto',
    delivering: 'Consegna',
  };

  return (
    <div className="bg-card rounded-xl border border-border p-4">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => {
          const isCompleted = index < currentIndex;
          const isCurrent = index === currentIndex;
          const StepIcon = statusConfig[step]?.icon || Clock;
          
          return (
            <div key={step} className="flex-1 flex flex-col items-center relative">
              {/* Connector line */}
              {index > 0 && (
                <div 
                  className={cn(
                    "absolute top-4 right-1/2 w-full h-0.5 -translate-y-1/2",
                    isCompleted ? "bg-accent" : "bg-border"
                  )}
                />
              )}
              
              {/* Step icon */}
              <div 
                className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center relative z-10",
                  isCompleted && "bg-accent text-accent-foreground",
                  isCurrent && "bg-accent/20 border-2 border-accent text-accent",
                  !isCompleted && !isCurrent && "bg-secondary text-muted-foreground"
                )}
              >
                {isCompleted ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : (
                  <StepIcon className="w-4 h-4" />
                )}
              </div>
              
              {/* Step label */}
              <span 
                className={cn(
                  "text-xs mt-2 text-center",
                  isCurrent ? "font-semibold text-foreground" : "text-muted-foreground"
                )}
              >
                {stepLabels[step]}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function TakeAwayOrderConfirmation() {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuthSession();
  const { data: initialOrder, isLoading, error, refetch } = useTakeAwayOrder(orderId || '');
  const [order, setOrder] = useState<TakeAwayOrder | null>(null);
  const [showRatingModal, setShowRatingModal] = useState(false);

  // Sync initial data
  useEffect(() => {
    if (initialOrder) {
      setOrder(initialOrder);
    }
  }, [initialOrder]);

  // Real-time order status tracking
  useEffect(() => {
    if (!orderId) return;

    const channel = supabase
      .channel(`order-${orderId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'takeaway_orders',
          filter: `id=eq.${orderId}`,
        },
        async (payload) => {
          const updatedOrder = payload.new as any;
          
          // Refetch to get complete order with joins
          const { data } = await supabase
            .from('takeaway_orders')
            .select('*, takeaway_drivers(*), order_ratings(*)')
            .eq('id', orderId)
            .single();
          
          if (data) {
            setOrder(data as unknown as TakeAwayOrder);
            
            // Show toast notification for status changes
            const newStatus = statusConfig[updatedOrder.status];
            if (newStatus) {
              toast.success(`Aggiornamento ordine: ${newStatus.label}`, {
                icon: <RefreshCw className="w-4 h-4" />,
              });
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [orderId]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <Skeleton className="h-8 w-48 mb-6" />
        <Skeleton className="h-32 rounded-xl mb-4" />
        <Skeleton className="h-48 rounded-xl mb-4" />
        <Skeleton className="h-32 rounded-xl" />
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 mx-auto text-destructive mb-4" />
          <h1 className="text-2xl font-bold mb-2">Ordine non trovato</h1>
          <p className="text-muted-foreground mb-4">
            L'ordine richiesto non esiste o non hai i permessi per visualizzarlo.
          </p>
          <Button onClick={() => navigate('/takeaway')}>Torna al menu</Button>
        </div>
      </div>
    );
  }

  const status = statusConfig[order.status] || statusConfig.pending;
  const StatusIcon = status.icon;

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container px-4 py-4">
          <div className="flex items-center gap-3">
            <BackButton onClick={() => navigate('/takeaway')} />
            <div>
              <h1 className="text-lg font-bold">Ordine {order.order_number}</h1>
              <p className="text-sm text-muted-foreground">
                {format(new Date(order.created_at), 'PPP p', { locale: it })}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container max-w-2xl px-4 py-6 space-y-6">
        {/* Status Progress */}
        {!['rejected', 'cancelled', 'completed'].includes(order.status) && (
          <OrderStatusProgress 
            currentStatus={order.status} 
            orderType={order.order_type} 
          />
        )}

        {/* Status Card */}
        <div className={cn(
          "bg-card rounded-xl border p-6 text-center",
          order.status === 'completed' && "border-green-500/50 bg-green-500/5",
          order.status === 'rejected' && "border-red-500/50 bg-red-500/5",
          order.status === 'cancelled' && "border-red-500/50 bg-red-500/5"
        )}>
          <StatusIcon className={cn("w-16 h-16 mx-auto mb-4", status.color)} />
          <h2 className={cn("text-2xl font-bold mb-2", status.color)}>{status.label}</h2>
          
          {order.status === 'pending' && (
            <p className="text-muted-foreground">
              Il ristorante sta verificando il tuo ordine
            </p>
          )}
          
          {order.status === 'accepted' && (
            <p className="text-muted-foreground">
              L'ordine è stato accettato e sarà presto in preparazione
            </p>
          )}
          
          {order.status === 'preparing' && order.estimated_ready_at && (
            <p className="text-muted-foreground">
              Pronto per le ~{format(new Date(order.estimated_ready_at), 'HH:mm')}
            </p>
          )}
          
          {order.status === 'ready' && order.order_type === 'pickup' && (
            <p className="text-muted-foreground">
              Il tuo ordine è pronto per il ritiro!
            </p>
          )}
          
          {order.status === 'delivering' && order.takeaway_drivers && (
            <p className="text-muted-foreground">
              Il tuo ordine è in arrivo!
            </p>
          )}
        </div>

        {/* Live Delivery Tracking */}
        {order.status === 'delivering' && order.driver_id && order.delivery_address && (
          <DeliveryTracker
            orderId={order.id}
            driverId={order.driver_id}
            deliveryAddress={order.delivery_address}
          />
        )}

        {/* Order Details */}
        <div className="bg-card rounded-xl border border-border p-4 space-y-4">
          <h3 className="font-semibold">Dettagli ordine</h3>
          
          <div className="space-y-3">
            {order.items.map((item: any, index: number) => (
              <div key={index} className="border-b border-border/30 last:border-0 pb-2 last:pb-0">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">
                    {item.quantity}x {item.name}
                  </span>
                  <span>€{(item.price * item.quantity).toFixed(2)}</span>
                </div>
                
                {/* Extras */}
                {item.extras && item.extras.length > 0 && (
                  <div className="mt-1 pl-4">
                    {item.extras.map((extra: any, idx: number) => (
                      <p key={idx} className="text-xs text-accent">
                        + {extra.name} {extra.price > 0 && `(€${extra.price.toFixed(2)})`}
                      </p>
                    ))}
                  </div>
                )}
                
                {/* Notes */}
                {item.notes && (
                  <p className="text-xs text-muted-foreground mt-1 pl-4 italic">
                    "{item.notes}"
                  </p>
                )}
              </div>
            ))}
          </div>
          
          <div className="border-t border-border pt-3 space-y-1">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotale</span>
              <span>€{order.subtotal.toFixed(2)}</span>
            </div>
            {order.delivery_fee > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Consegna</span>
                <span>€{order.delivery_fee.toFixed(2)}</span>
              </div>
            )}
            {order.discount > 0 && (
              <div className="flex justify-between text-sm text-green-500">
                <span>Sconto</span>
                <span>-€{order.discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-lg pt-2">
              <span>Totale</span>
              <span className="text-accent">€{order.total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Order Info */}
        <div className="bg-card rounded-xl border border-border p-4 space-y-4">
          <h3 className="font-semibold">Informazioni</h3>
          
          <div className="space-y-3 text-sm">
            <div className="flex items-start gap-3">
              {order.order_type === 'pickup' ? (
                <Package className="w-5 h-5 text-muted-foreground flex-shrink-0" />
              ) : (
                <Truck className="w-5 h-5 text-muted-foreground flex-shrink-0" />
              )}
              <div>
                <p className="font-medium">
                  {order.order_type === 'pickup' ? 'Ritiro' : 'Consegna'}
                </p>
                {order.order_type === 'pickup' && order.pickup_time && (
                  <p className="text-muted-foreground">
                    Orario: {format(new Date(order.pickup_time), 'HH:mm')}
                  </p>
                )}
              </div>
            </div>
            
            {order.delivery_address && (
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                <div>
                  <p className="font-medium">{order.delivery_address.street}</p>
                  <p className="text-muted-foreground">
                    {order.delivery_address.city}, {order.delivery_address.zip}
                  </p>
                </div>
              </div>
            )}
            
            {order.special_notes && (
              <div className="p-3 bg-secondary/30 rounded-lg">
                <p className="text-muted-foreground">Note: {order.special_notes}</p>
              </div>
            )}
          </div>
        </div>

        {/* Rating CTA for completed orders */}
        {order.status === 'completed' && !order.order_ratings?.length && (
          <div className="bg-accent/10 border border-accent/30 rounded-xl p-4 text-center">
            <Star className="w-8 h-8 mx-auto mb-2 text-accent" />
            <p className="font-semibold mb-2">Come è andato il tuo ordine?</p>
            <Button onClick={() => setShowRatingModal(true)}>
              Lascia una valutazione
            </Button>
          </div>
        )}

        {/* Already rated */}
        {order.order_ratings?.length > 0 && (
          <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 text-center">
            <div className="flex items-center justify-center gap-1 mb-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={cn(
                    'w-5 h-5',
                    star <= (order.order_ratings[0]?.overall_rating || 0)
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'text-muted-foreground'
                  )}
                />
              ))}
            </div>
            <p className="text-sm text-muted-foreground">Grazie per la tua valutazione!</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => navigate('/profile')}
          >
            I miei ordini
          </Button>
          <Button
            className="flex-1"
            onClick={() => navigate('/takeaway')}
          >
            Nuovo ordine
          </Button>
        </div>
      </div>

      {/* Rating Modal */}
      {user && order && (
        <OrderRatingModal
          isOpen={showRatingModal}
          onClose={() => setShowRatingModal(false)}
          orderId={order.id}
          orderNumber={order.order_number || order.id.slice(0, 8)}
          orderType={order.order_type}
          userId={user.id}
          onRated={() => refetch()}
        />
      )}
    </div>
  );
}
