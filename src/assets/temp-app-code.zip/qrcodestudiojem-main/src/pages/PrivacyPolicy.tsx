import { motion } from 'framer-motion';
import { ArrowLeft, Shield, Mail, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';

export default function PrivacyPolicy() {
  const { config } = useRestaurantConfig();
  const businessName = config?.name || 'Il Locale';
  const businessEmail = config?.email || 'info@example.com';
  const businessPhone = config?.phone || '';
  const businessAddress = config?.address || '';
  const businessCity = config?.city || '';

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border/20">
        <div className="container px-4 py-4 flex items-center gap-4">
          <Link 
            to="/" 
            className="p-2 rounded-full hover:bg-secondary/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </Link>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-accent" />
            <h1 className="text-lg font-semibold text-foreground">Privacy Policy</h1>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container px-4 py-8 max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="prose prose-sm dark:prose-invert max-w-none"
        >
          <p className="text-muted-foreground text-sm mb-8">
            Ultimo aggiornamento: {new Date().toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric' })}
          </p>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">1. Titolare del Trattamento</h2>
            <div className="p-4 rounded-xl bg-secondary/30 border border-border/20">
              <p className="text-foreground font-medium">{businessName}</p>
              {businessAddress && <p className="text-muted-foreground text-sm">{businessAddress}</p>}
              {businessCity && <p className="text-muted-foreground text-sm">{businessCity}</p>}
              {businessEmail && (
                <p className="text-muted-foreground text-sm flex items-center gap-2 mt-2">
                  <Mail className="w-4 h-4" /> {businessEmail}
                </p>
              )}
              {businessPhone && (
                <p className="text-muted-foreground text-sm flex items-center gap-2">
                  <Phone className="w-4 h-4" /> {businessPhone}
                </p>
              )}
            </div>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">2. Tipologie di Dati Raccolti</h2>
            <p className="text-muted-foreground leading-relaxed">
              Fra i Dati Personali raccolti da questa Applicazione, in modo autonomo o tramite terze parti, ci sono:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li><strong className="text-foreground">Dati di contatto:</strong> numero di telefono, nome, cognome</li>
              <li><strong className="text-foreground">Dati di utilizzo:</strong> preferenze alimentari, allergie, piatti preferiti</li>
              <li><strong className="text-foreground">Dati di prenotazione:</strong> data, ora, numero di ospiti, note speciali</li>
              <li><strong className="text-foreground">Dati tecnici:</strong> Cookie, dati di utilizzo, identificatori univoci di dispositivo</li>
            </ul>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">3. Finalità del Trattamento</h2>
            <p className="text-muted-foreground leading-relaxed">
              I Dati dell'Utente sono raccolti per consentire al Titolare di fornire i propri Servizi, così come per le seguenti finalità:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li><strong className="text-foreground">Gestione delle prenotazioni:</strong> per confermare, modificare o cancellare prenotazioni al ristorante</li>
              <li><strong className="text-foreground">Comunicazioni WhatsApp:</strong> per inviare conferme, promemoria e aggiornamenti relativi alle prenotazioni</li>
              <li><strong className="text-foreground">Personalizzazione dell'esperienza:</strong> per suggerire piatti in base alle preferenze e allergie dichiarate</li>
              <li><strong className="text-foreground">Miglioramento del servizio:</strong> per analizzare l'utilizzo dell'app e migliorare l'esperienza utente</li>
              <li><strong className="text-foreground">Marketing diretto:</strong> previo consenso, per inviare promozioni e novità via WhatsApp</li>
            </ul>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">4. Base Giuridica del Trattamento</h2>
            <p className="text-muted-foreground leading-relaxed">
              Il Titolare tratta Dati Personali relativi all'Utente in caso sussista una delle seguenti condizioni:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>L'Utente ha prestato il consenso per una o più specifiche finalità</li>
              <li>Il trattamento è necessario all'esecuzione di un contratto con l'Utente (es. prenotazione tavolo)</li>
              <li>Il trattamento è necessario per adempiere un obbligo legale</li>
              <li>Il trattamento è necessario per il perseguimento del legittimo interesse del Titolare</li>
            </ul>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">5. Modalità di Trattamento</h2>
            <p className="text-muted-foreground leading-relaxed">
              Il Titolare adotta le opportune misure di sicurezza volte ad impedire l'accesso, la divulgazione, 
              la modifica o la distruzione non autorizzate dei Dati Personali.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Il trattamento viene effettuato mediante strumenti informatici e/o telematici, con modalità organizzative 
              e con logiche strettamente correlate alle finalità indicate. I dati sono conservati su server sicuri 
              situati nell'Unione Europea.
            </p>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">6. Periodo di Conservazione</h2>
            <p className="text-muted-foreground leading-relaxed">
              I Dati sono trattati e conservati per il tempo richiesto dalle finalità per le quali sono stati raccolti:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li><strong className="text-foreground">Dati di prenotazione:</strong> conservati per 24 mesi dalla data della prenotazione</li>
              <li><strong className="text-foreground">Dati di contatto:</strong> conservati fino a revoca del consenso o richiesta di cancellazione</li>
              <li><strong className="text-foreground">Preferenze utente:</strong> conservati per la durata dell'utilizzo dell'applicazione</li>
              <li><strong className="text-foreground">Dati per marketing:</strong> conservati fino a revoca del consenso</li>
            </ul>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">7. Diritti dell'Utente</h2>
            <p className="text-muted-foreground leading-relaxed">
              Gli Utenti possono esercitare determinati diritti con riferimento ai Dati trattati dal Titolare. 
              In particolare, l'Utente ha il diritto di:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li><strong className="text-foreground">Accesso:</strong> ottenere conferma che sia o meno in corso un trattamento di dati personali</li>
              <li><strong className="text-foreground">Rettifica:</strong> ottenere la rettifica dei dati personali inesatti</li>
              <li><strong className="text-foreground">Cancellazione:</strong> ottenere la cancellazione dei propri dati personali</li>
              <li><strong className="text-foreground">Limitazione:</strong> ottenere la limitazione del trattamento</li>
              <li><strong className="text-foreground">Portabilità:</strong> ricevere i propri dati in formato strutturato</li>
              <li><strong className="text-foreground">Opposizione:</strong> opporsi al trattamento dei propri dati personali</li>
              <li><strong className="text-foreground">Revoca del consenso:</strong> revocare il consenso in qualsiasi momento</li>
            </ul>
            <p className="text-muted-foreground leading-relaxed mt-4">
              Per esercitare i propri diritti, l'Utente può inviare una richiesta a: <strong className="text-accent">{businessEmail}</strong>
            </p>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">8. Cookie e Tecnologie Simili</h2>
            <p className="text-muted-foreground leading-relaxed">
              Questa Applicazione fa utilizzo di Cookie e altre tecnologie di tracciamento. 
              Per maggiori informazioni, consulta la nostra{' '}
              <Link to="/cookie-policy" className="text-accent hover:underline">Cookie Policy</Link>.
            </p>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">9. Modifiche alla Privacy Policy</h2>
            <p className="text-muted-foreground leading-relaxed">
              Il Titolare si riserva il diritto di apportare modifiche alla presente privacy policy in qualunque momento, 
              dandone informazione agli Utenti su questa pagina. Si prega dunque di consultare spesso questa pagina.
            </p>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">10. Contatti</h2>
            <p className="text-muted-foreground leading-relaxed">
              Per qualsiasi domanda relativa alla presente Privacy Policy o al trattamento dei dati personali, 
              è possibile contattare il Titolare del trattamento:
            </p>
            <div className="p-4 rounded-xl bg-accent/10 border border-accent/20">
              <p className="text-foreground font-medium">{businessName}</p>
              <p className="text-muted-foreground text-sm">Email: {businessEmail}</p>
              {businessPhone && <p className="text-muted-foreground text-sm">Tel: {businessPhone}</p>}
            </div>
          </section>

          <section className="space-y-4 pt-8 border-t border-border/20">
            <p className="text-xs text-muted-foreground text-center">
              Questa informativa è resa ai sensi dell'art. 13 del Regolamento UE 2016/679 (GDPR) 
              e del D.Lgs. 196/2003 come modificato dal D.Lgs. 101/2018.
            </p>
          </section>
        </motion.div>
      </main>
    </div>
  );
}
