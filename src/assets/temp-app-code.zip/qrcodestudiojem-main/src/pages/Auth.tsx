import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Phone, User, ArrowRight, MessageCircle, Bell, Check, Loader2, Home, Mail, Lock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { z } from 'zod';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { useAuthSession } from '@/hooks/useAuthSession';
import logoFallback from '@/assets/logo-restaurant.png';
import { FooterSimple } from '@/components/Footer';

const phoneSchema = z.string()
  .min(10, 'Numero troppo corto')
  .max(15, 'Numero troppo lungo')
  .regex(/^\+?[0-9]+$/, 'Formato numero non valido');

const nameSchema = z.string()
  .min(2, 'Nome troppo corto')
  .max(50, 'Nome troppo lungo');

const emailSchema = z.string().email('Email non valida');
const passwordSchema = z.string().min(6, 'Password deve avere almeno 6 caratteri');

type CustomerMode = 'login' | 'register' | 'forgot';

const customerPasswordSchema = z.string().min(6, 'Password deve avere almeno 6 caratteri');

export default function Auth() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const isAdminMode = searchParams.get('mode') === 'admin';
  const returnTo = searchParams.get('returnTo');
  const { config } = useRestaurantConfig();
  const { user, isLoading: isCheckingAuth } = useAuthSession();
  
  const logoImage = config?.logo_url || logoFallback;
  
  const [customerMode, setCustomerMode] = useState<CustomerMode>('login');
  const [step, setStep] = useState<'phone' | 'name' | 'password' | 'success' | 'forgot-phone' | 'forgot-code' | 'forgot-password'>('phone');
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    phone: '',
    name: '',
    customerPassword: '',
    confirmPassword: '',
    email: '',
    password: '',
    resetCode: '',
    newPassword: '',
    confirmNewPassword: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Set noindex for auth page (private) and redirect if logged in
  useEffect(() => {
    document.title = 'Accesso | Menu Digitale';
    let meta = document.querySelector('meta[name="robots"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'robots');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', 'noindex, nofollow');
    
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const [isCheckingPhone, setIsCheckingPhone] = useState(false);
  const [phoneExists, setPhoneExists] = useState<boolean | null>(null);

  const validateField = (field: string, value: string) => {
    try {
      if (field === 'phone') phoneSchema.parse(value);
      if (field === 'name') nameSchema.parse(value);
      if (field === 'customerPassword') customerPasswordSchema.parse(value);
      if (field === 'email') emailSchema.parse(value);
      if (field === 'password') passwordSchema.parse(value);
      setErrors(prev => ({ ...prev, [field]: '' }));
      return true;
    } catch (e) {
      if (e instanceof z.ZodError) {
        setErrors(prev => ({ ...prev, [field]: e.errors[0].message }));
      }
      return false;
    }
  };

  // Live validation on field change
  const handleFieldChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear phone exists check when phone changes
    if (field === 'phone') {
      setPhoneExists(null);
    }
    
    // Live validation (only show errors after user starts typing)
    if (value.length > 0) {
      validateField(field, value);
    } else {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
    
    // Live password match validation
    if (field === 'confirmPassword' || field === 'customerPassword') {
      const currentPassword = field === 'customerPassword' ? value : formData.customerPassword;
      const currentConfirm = field === 'confirmPassword' ? value : formData.confirmPassword;
      
      if (currentConfirm.length > 0 && currentPassword !== currentConfirm) {
        setErrors(prev => ({ ...prev, confirmPassword: 'Le password non coincidono' }));
      } else if (currentConfirm.length > 0 && currentPassword === currentConfirm) {
        setErrors(prev => ({ ...prev, confirmPassword: '' }));
      }
    }
  };

  // Check if phone number already exists
  const checkPhoneExists = async (phone: string): Promise<boolean> => {
    const phoneEmail = `${phone.replace(/[^0-9]/g, '')}@phone.local`;
    
    // Try to sign in with a dummy password - if we get "Invalid login credentials" 
    // the user exists, if we get other errors they don't
    const { error } = await supabase.auth.signInWithPassword({
      email: phoneEmail,
      password: 'dummy_check_password_12345'
    });
    
    // If error says invalid credentials, user exists (wrong password but user found)
    if (error?.message.includes('Invalid login credentials')) {
      return true;
    }
    
    // If no error or other errors, user doesn't exist
    return false;
  };

  const handlePhoneSubmit = async () => {
    if (!validateField('phone', formData.phone)) return;
    
    // Check if phone already registered (only in register mode)
    if (customerMode === 'register') {
      setIsCheckingPhone(true);
      try {
        const exists = await checkPhoneExists(formData.phone);
        setPhoneExists(exists);
        
        if (exists) {
          setErrors(prev => ({ ...prev, phone: 'Questo numero è già registrato' }));
          toast.error('Questo numero è già registrato. Prova ad accedere.', { id: 'phone-exists' });
          setIsCheckingPhone(false);
          return;
        }
      } catch (e) {
        // Continue if check fails
      }
      setIsCheckingPhone(false);
    }
    
    setStep('name');
  };

  const handleLoginPhoneSubmit = () => {
    if (!validateField('phone', formData.phone)) return;
    if (!validateField('customerPassword', formData.customerPassword)) return;
    handleCustomerLogin();
  };

  // Customer login with phone
  const handleCustomerLogin = async () => {
    setIsLoading(true);
    try {
      const phoneEmail = `${formData.phone.replace(/[^0-9]/g, '')}@phone.local`;

      const { error } = await supabase.auth.signInWithPassword({
        email: phoneEmail,
        password: formData.customerPassword
      });

      if (error) {
        if (error.message.includes('Invalid login credentials')) {
          toast.error('Credenziali non valide. Verifica numero e password.');
          return;
        }
        toast.error(error.message);
        return;
      }

      // Use a unique toast id to prevent duplicates
      const hasPendingReservation = sessionStorage.getItem('reservation_pending');
      if (!hasPendingReservation) {
        toast.success('Bentornato!', { id: 'auth-success' });
      }
      navigate(returnTo || '/?skipOnboarding=true');
    } catch (error: any) {
      toast.error('Errore durante l\'accesso');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNameSubmit = () => {
    if (!validateField('name', formData.name)) return;
    setStep('password');
  };

  // Customer signup with phone and password
  const handleCustomerSignUp = async () => {
    if (!validateField('customerPassword', formData.customerPassword)) return;
    
    // Check password confirmation
    if (formData.customerPassword !== formData.confirmPassword) {
      setErrors(prev => ({ ...prev, confirmPassword: 'Le password non coincidono' }));
      return;
    }

    setIsLoading(true);
    try {
      // Use phone number as email identifier for Supabase Auth
      const phoneEmail = `${formData.phone.replace(/[^0-9]/g, '')}@phone.local`;

      const { error } = await supabase.auth.signUp({
        email: phoneEmail,
        password: formData.customerPassword,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
          data: {
            phone: formData.phone,
            display_name: formData.name
          }
        }
      });

      if (error) {
        if (error.message.includes('already registered')) {
          toast.error('Questo numero è già registrato. Prova ad accedere.');
          setCustomerMode('login');
          setStep('phone');
          return;
        }
        // Translate common Supabase errors to Italian
        if (error.message.includes('weak') || error.message.includes('easy to guess')) {
          toast.error('Password troppo debole. Scegli una password più sicura con lettere, numeri e simboli.');
          return;
        }
        if (error.message.includes('at least')) {
          toast.error('La password deve avere almeno 6 caratteri.');
          return;
        }
        toast.error('Errore durante la registrazione. Riprova.');
        return;
      }

      setStep('success');
      toast.success('Account creato con successo!');
      
    } catch (error: any) {
      toast.error('Errore durante la registrazione');
    } finally {
      setIsLoading(false);
    }
  };

  // Forgot password - request reset code
  const handleForgotPasswordRequest = async () => {
    if (!validateField('phone', formData.phone)) return;

    setIsLoading(true);
    try {
      const response = await supabase.functions.invoke('password-reset', {
        body: { action: 'request', phone: formData.phone }
      });

      if (response.error) {
        toast.error('Errore nell\'invio del codice');
        return;
      }

      toast.success('Codice inviato via WhatsApp!');
      setStep('forgot-code');
    } catch (error) {
      toast.error('Errore nell\'invio del codice');
    } finally {
      setIsLoading(false);
    }
  };

  // Forgot password - verify code and set new password
  const handleForgotPasswordVerify = async () => {
    if (!formData.resetCode || formData.resetCode.length !== 6) {
      setErrors(prev => ({ ...prev, resetCode: 'Inserisci il codice a 6 cifre' }));
      return;
    }
    if (!validateField('newPassword', formData.newPassword)) return;
    if (formData.newPassword !== formData.confirmNewPassword) {
      setErrors(prev => ({ ...prev, confirmNewPassword: 'Le password non coincidono' }));
      return;
    }

    setIsLoading(true);
    try {
      const response = await supabase.functions.invoke('password-reset', {
        body: { 
          action: 'verify', 
          phone: formData.phone, 
          token: formData.resetCode,
          newPassword: formData.newPassword
        }
      });

      if (response.error || !response.data?.success) {
        toast.error(response.data?.error || 'Codice non valido o scaduto');
        return;
      }

      toast.success('Password aggiornata! Ora puoi accedere.');
      setCustomerMode('login');
      setStep('phone');
      setFormData(prev => ({ 
        ...prev, 
        customerPassword: '', 
        resetCode: '', 
        newPassword: '', 
        confirmNewPassword: '' 
      }));
    } catch (error) {
      toast.error('Errore nell\'aggiornamento della password');
    } finally {
      setIsLoading(false);
    }
  };

  // Validate new password field
  const validateNewPassword = (value: string) => {
    try {
      customerPasswordSchema.parse(value);
      setErrors(prev => ({ ...prev, newPassword: '' }));
      return true;
    } catch (e) {
      if (e instanceof z.ZodError) {
        setErrors(prev => ({ ...prev, newPassword: e.errors[0].message }));
      }
      return false;
    }
  };

  // Admin login with email/password
  const handleAdminLogin = async () => {
    if (!validateField('email', formData.email)) return;
    if (!validateField('password', formData.password)) return;

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password
      });

      if (error) {
        toast.error('Email o password non corretti');
        return;
      }

      toast.success('Benvenuto!');
      navigate('/admin');
    } catch (error) {
      toast.error('Errore durante l\'accesso');
    } finally {
      setIsLoading(false);
    }
  };

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center gap-4"
        >
          <img src={logoImage} alt={config?.name || 'Logo'} className="w-[52px] h-[52px] object-contain animate-pulse" />
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </motion.div>
      </div>
    );
  }

  // Admin login mode
  if (isAdminMode) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="p-4 flex items-center justify-between">
          <motion.button
            onClick={() => navigate('/?skipOnboarding=true')}
            className="flex items-center gap-2 px-3 py-2 rounded-full bg-secondary/60 border border-border/20 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary hover:border-border/40 transition-all"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Home className="w-4 h-4" />
            <span>Torna alla home</span>
          </motion.button>
          <img src={logoImage} alt={config?.name || 'Logo'} className="w-[52px] h-[52px] object-contain" />
        </div>

        <div className="flex-1 flex items-center justify-center p-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md space-y-8"
          >
            <div className="text-center space-y-2">
              <div className="flex justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                  <Lock className="w-6 h-6 text-accent" />
                </div>
              </div>
              <h1 className="text-2xl font-semibold">Accesso Admin</h1>
              <p className="text-muted-foreground text-sm">
                Accedi con le tue credenziali amministratore
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="admin@esempio.com"
                  className="w-full px-4 py-3 rounded-xl bg-secondary/30 border border-border/30 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all"
                />
                {errors.email && <p className="text-xs text-destructive">{errors.email}</p>}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Password
                </label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 rounded-xl bg-secondary/30 border border-border/30 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all"
                />
                {errors.password && <p className="text-xs text-destructive">{errors.password}</p>}
              </div>

              <button
                onClick={handleAdminLogin}
                disabled={isLoading}
                className="w-full py-4 rounded-2xl bg-accent text-accent-foreground font-medium flex items-center justify-center gap-2 hover:bg-accent/90 transition-colors disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  'Accedi'
                )}
              </button>
            </div>
          </motion.div>
        </div>

        <FooterSimple />
      </div>
    );
  }

  // Customer flow (phone only)
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="p-4 flex items-center justify-between">
        <motion.button
          onClick={() => navigate('/?skipOnboarding=true')}
          className="flex items-center gap-2 px-3 py-2 rounded-full bg-secondary/60 border border-border/20 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary hover:border-border/40 transition-all"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Home className="w-4 h-4" />
          <span>Torna alla home</span>
        </motion.button>
        <img src={logoImage} alt={config?.name || 'Logo'} className="w-[52px] h-[52px] object-contain" />
      </div>

      <div className="flex-1 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md space-y-8"
        >
          {/* Mode Tabs */}
          {step === 'phone' && (
            <div className="flex rounded-2xl bg-secondary/30 p-1">
              <button
                onClick={() => setCustomerMode('login')}
                className={`flex-1 py-2.5 px-4 rounded-xl text-sm font-medium transition-all ${
                  customerMode === 'login'
                    ? 'bg-background shadow-sm text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Accedi
              </button>
              <button
                onClick={() => setCustomerMode('register')}
                className={`flex-1 py-2.5 px-4 rounded-xl text-sm font-medium transition-all ${
                  customerMode === 'register'
                    ? 'bg-background shadow-sm text-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                Registrati
              </button>
            </div>
          )}

          <div className="text-center space-y-2">
            <h1 className="text-2xl font-semibold">
              {step === 'success' ? 'Benvenuto!' : 
               step === 'password' ? 'Crea la tua password' :
               customerMode === 'login' ? 'Accedi' : 'Registrati'}
            </h1>
            <p className="text-muted-foreground text-sm">
              {step === 'phone' && customerMode === 'login' && 'Inserisci le tue credenziali'}
              {step === 'phone' && customerMode === 'register' && 'Inserisci il tuo numero di telefono'}
              {step === 'name' && 'Come possiamo chiamarti?'}
              {step === 'password' && 'Scegli una password sicura'}
            </p>
          </div>

          <AnimatePresence mode="wait">
            {/* Step 1: Phone (Register) or Phone+Password (Login) */}
            {step === 'phone' && (
              <motion.div
                key="phone"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {/* Phone tip - only show in register mode */}
                {customerMode === 'register' && (
                  <div className="p-4 rounded-2xl bg-accent/10 border border-accent/20 space-y-2">
                    <div className="flex items-center gap-2 text-accent">
                      <MessageCircle className="w-5 h-5" />
                      <span className="text-sm font-medium">Perché il numero?</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Il tuo numero sarà usato per l'accesso rapido e per ricevere 
                      <strong className="text-foreground"> notifiche WhatsApp</strong> su prenotazioni, 
                      offerte speciali e aggiornamenti del menu.
                    </p>
                  </div>
                )}

                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Numero di telefono
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleFieldChange('phone', e.target.value)}
                    placeholder="+39 333 123 4567"
                    className={`w-full px-4 py-4 rounded-2xl bg-secondary/30 border transition-all text-lg focus:outline-none focus:ring-2 ${
                      errors.phone 
                        ? 'border-destructive focus:border-destructive focus:ring-destructive/20' 
                        : formData.phone.length >= 10 && !errors.phone
                          ? 'border-green-500 focus:border-green-500 focus:ring-green-500/20'
                          : 'border-border/30 focus:border-accent focus:ring-accent/20'
                    }`}
                  />
                  {errors.phone ? (
                    <p className="text-xs text-destructive flex items-center gap-1">
                      <span>✕</span> {errors.phone}
                    </p>
                  ) : formData.phone.length >= 10 && (
                    <p className="text-xs text-green-500 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Numero valido
                    </p>
                  )}
                </div>

                {/* Password field for login mode */}
                {customerMode === 'login' && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                      <Lock className="w-4 h-4" />
                      Password
                    </label>
                    <input
                      type="password"
                      value={formData.customerPassword}
                      onChange={(e) => handleFieldChange('customerPassword', e.target.value)}
                      placeholder="••••••••"
                      className={`w-full px-4 py-4 rounded-2xl bg-secondary/30 border transition-all text-lg focus:outline-none focus:ring-2 ${
                        errors.customerPassword 
                          ? 'border-destructive focus:border-destructive focus:ring-destructive/20' 
                          : formData.customerPassword.length >= 6
                            ? 'border-green-500 focus:border-green-500 focus:ring-green-500/20'
                            : 'border-border/30 focus:border-accent focus:ring-accent/20'
                      }`}
                    />
                    {errors.customerPassword ? (
                      <p className="text-xs text-destructive flex items-center gap-1">
                        <span>✕</span> {errors.customerPassword}
                      </p>
                    ) : formData.customerPassword.length >= 6 && (
                      <p className="text-xs text-green-500 flex items-center gap-1">
                        <Check className="w-3 h-3" /> Password valida
                      </p>
                    )}
                  </div>
                )}

                {/* Benefits - only show in register mode */}
                {customerMode === 'register' && (
                  <div className="space-y-3">
                    <p className="text-xs text-muted-foreground uppercase tracking-wider">Vantaggi</p>
                    <div className="space-y-2">
                      {[
                        { icon: Bell, text: 'Conferme prenotazione istantanee' },
                        { icon: MessageCircle, text: 'Promemoria via WhatsApp' },
                        { icon: Check, text: 'Accesso rapido ai tuoi preferiti' }
                      ].map(({ icon: Icon, text }) => (
                        <div key={text} className="flex items-center gap-3 text-sm text-muted-foreground">
                          <div className="w-8 h-8 rounded-lg bg-secondary/50 flex items-center justify-center">
                            <Icon className="w-4 h-4" />
                          </div>
                          {text}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <button
                  onClick={customerMode === 'login' ? handleLoginPhoneSubmit : handlePhoneSubmit}
                  disabled={!formData.phone || isLoading || isCheckingPhone || (customerMode === 'login' && !formData.customerPassword) || !!errors?.phone}
                  className="w-full py-4 rounded-2xl bg-accent text-accent-foreground font-medium flex items-center justify-center gap-2 hover:bg-accent/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading || isCheckingPhone ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      {isCheckingPhone && <span>Verifica...</span>}
                    </>
                  ) : (
                    <>
                      {customerMode === 'login' ? 'Accedi' : 'Continua'}
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                {/* Forgot password link - only in login mode */}
                {customerMode === 'login' && (
                  <button
                    onClick={() => {
                      setCustomerMode('forgot');
                      setStep('forgot-phone');
                    }}
                    className="w-full text-center text-sm text-muted-foreground hover:text-accent transition-colors"
                  >
                    Password dimenticata?
                  </button>
                )}
              </motion.div>
            )}

            {/* Forgot Password - Step 1: Phone */}
            {step === 'forgot-phone' && (
              <motion.div
                key="forgot-phone"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="p-4 rounded-2xl bg-accent/10 border border-accent/20 space-y-2">
                  <div className="flex items-center gap-2 text-accent">
                    <MessageCircle className="w-5 h-5" />
                    <span className="text-sm font-medium">Recupero via WhatsApp</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Ti invieremo un codice di verifica via WhatsApp per reimpostare la password.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Numero di telefono
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleFieldChange('phone', e.target.value)}
                    placeholder="+39 333 123 4567"
                    className={`w-full px-4 py-4 rounded-2xl bg-secondary/30 border transition-all text-lg focus:outline-none focus:ring-2 ${
                      errors?.phone 
                        ? 'border-destructive focus:border-destructive focus:ring-destructive/20' 
                        : formData.phone.length >= 10 && !errors?.phone
                          ? 'border-green-500 focus:border-green-500 focus:ring-green-500/20'
                          : 'border-border/30 focus:border-accent focus:ring-accent/20'
                    }`}
                  />
                  {errors?.phone && (
                    <p className="text-xs text-destructive flex items-center gap-1">
                      <span>✕</span> {errors.phone}
                    </p>
                  )}
                </div>

                <button
                  onClick={handleForgotPasswordRequest}
                  disabled={!formData.phone || isLoading || !!errors?.phone}
                  className="w-full py-4 rounded-2xl bg-accent text-accent-foreground font-medium flex items-center justify-center gap-2 hover:bg-accent/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      Invia codice
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                <button
                  onClick={() => {
                    setCustomerMode('login');
                    setStep('phone');
                  }}
                  className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  ← Torna al login
                </button>
              </motion.div>
            )}

            {/* Forgot Password - Step 2: Enter Code and New Password */}
            {step === 'forgot-code' && (
              <motion.div
                key="forgot-code"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="p-4 rounded-2xl bg-green-500/10 border border-green-500/20 space-y-2">
                  <div className="flex items-center gap-2 text-green-500">
                    <Check className="w-5 h-5" />
                    <span className="text-sm font-medium">Codice inviato!</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Controlla WhatsApp e inserisci il codice a 6 cifre che hai ricevuto.
                  </p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground">
                    Codice di verifica
                  </label>
                  <input
                    type="text"
                    value={formData.resetCode}
                    onChange={(e) => {
                      const value = e.target.value.replace(/[^0-9]/g, '').slice(0, 6);
                      setFormData(prev => ({ ...prev, resetCode: value }));
                      if (value.length === 6) {
                        setErrors(prev => ({ ...prev, resetCode: '' }));
                      }
                    }}
                    placeholder="123456"
                    maxLength={6}
                    className={`w-full px-4 py-4 rounded-2xl bg-secondary/30 border transition-all text-lg text-center tracking-[0.5em] font-mono focus:outline-none focus:ring-2 ${
                      errors?.resetCode 
                        ? 'border-destructive focus:border-destructive focus:ring-destructive/20' 
                        : formData.resetCode.length === 6
                          ? 'border-green-500 focus:border-green-500 focus:ring-green-500/20'
                          : 'border-border/30 focus:border-accent focus:ring-accent/20'
                    }`}
                  />
                  {errors?.resetCode && (
                    <p className="text-xs text-destructive">{errors.resetCode}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    Nuova password
                  </label>
                  <input
                    type="password"
                    value={formData.newPassword}
                    onChange={(e) => {
                      setFormData(prev => ({ ...prev, newPassword: e.target.value }));
                      if (e.target.value.length > 0) validateNewPassword(e.target.value);
                    }}
                    placeholder="••••••••"
                    className={`w-full px-4 py-4 rounded-2xl bg-secondary/30 border transition-all text-lg focus:outline-none focus:ring-2 ${
                      errors?.newPassword 
                        ? 'border-destructive focus:border-destructive focus:ring-destructive/20' 
                        : formData.newPassword.length >= 6
                          ? 'border-green-500 focus:border-green-500 focus:ring-green-500/20'
                          : 'border-border/30 focus:border-accent focus:ring-accent/20'
                    }`}
                  />
                  {errors?.newPassword && (
                    <p className="text-xs text-destructive">{errors.newPassword}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    Conferma password
                  </label>
                  <input
                    type="password"
                    value={formData.confirmNewPassword}
                    onChange={(e) => {
                      setFormData(prev => ({ ...prev, confirmNewPassword: e.target.value }));
                      if (e.target.value !== formData.newPassword && e.target.value.length > 0) {
                        setErrors(prev => ({ ...prev, confirmNewPassword: 'Le password non coincidono' }));
                      } else {
                        setErrors(prev => ({ ...prev, confirmNewPassword: '' }));
                      }
                    }}
                    placeholder="••••••••"
                    className={`w-full px-4 py-4 rounded-2xl bg-secondary/30 border transition-all text-lg focus:outline-none focus:ring-2 ${
                      errors?.confirmNewPassword 
                        ? 'border-destructive focus:border-destructive focus:ring-destructive/20' 
                        : formData.confirmNewPassword.length >= 6 && formData.confirmNewPassword === formData.newPassword
                          ? 'border-green-500 focus:border-green-500 focus:ring-green-500/20'
                          : 'border-border/30 focus:border-accent focus:ring-accent/20'
                    }`}
                  />
                  {errors?.confirmNewPassword ? (
                    <p className="text-xs text-destructive">{errors.confirmNewPassword}</p>
                  ) : formData.confirmNewPassword.length >= 6 && formData.confirmNewPassword === formData.newPassword && (
                    <p className="text-xs text-green-500 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Password confermata
                    </p>
                  )}
                </div>

                <button
                  onClick={handleForgotPasswordVerify}
                  disabled={
                    isLoading || 
                    formData.resetCode.length !== 6 || 
                    formData.newPassword.length < 6 || 
                    formData.newPassword !== formData.confirmNewPassword
                  }
                  className="w-full py-4 rounded-2xl bg-accent text-accent-foreground font-medium flex items-center justify-center gap-2 hover:bg-accent/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    'Reimposta password'
                  )}
                </button>

                <button
                  onClick={() => setStep('forgot-phone')}
                  className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  ← Torna indietro
                </button>
              </motion.div>
            )}

            {/* Step 2: Name (Register only) */}
            {step === 'name' && (
              <motion.div
                key="name"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Il tuo nome
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleFieldChange('name', e.target.value)}
                    placeholder="Come ti chiami?"
                    autoFocus
                    className={`w-full px-4 py-4 rounded-2xl bg-secondary/30 border transition-all text-lg focus:outline-none focus:ring-2 ${
                      errors.name 
                        ? 'border-destructive focus:border-destructive focus:ring-destructive/20' 
                        : formData.name.length >= 2
                          ? 'border-green-500 focus:border-green-500 focus:ring-green-500/20'
                          : 'border-border/30 focus:border-accent focus:ring-accent/20'
                    }`}
                  />
                  {errors.name ? (
                    <p className="text-xs text-destructive flex items-center gap-1">
                      <span>✕</span> {errors.name}
                    </p>
                  ) : formData.name.length >= 2 && (
                    <p className="text-xs text-green-500 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Nome valido
                    </p>
                  )}
                </div>

                <button
                  onClick={handleNameSubmit}
                  disabled={isLoading || !formData.name}
                  className="w-full py-4 rounded-2xl bg-accent text-accent-foreground font-medium flex items-center justify-center gap-2 hover:bg-accent/90 transition-colors disabled:opacity-50"
                >
                  Continua
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setStep('phone')}
                  className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  ← Torna indietro
                </button>
              </motion.div>
            )}

            {/* Step 3: Password (Register only) */}
            {step === 'password' && (
              <motion.div
                key="password"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    Password
                  </label>
                  <input
                    type="password"
                    value={formData.customerPassword}
                    onChange={(e) => handleFieldChange('customerPassword', e.target.value)}
                    placeholder="Almeno 6 caratteri"
                    autoFocus
                    className={`w-full px-4 py-4 rounded-2xl bg-secondary/30 border transition-all text-lg focus:outline-none focus:ring-2 ${
                      errors.customerPassword 
                        ? 'border-destructive focus:border-destructive focus:ring-destructive/20' 
                        : formData.customerPassword.length >= 6
                          ? 'border-green-500 focus:border-green-500 focus:ring-green-500/20'
                          : 'border-border/30 focus:border-accent focus:ring-accent/20'
                    }`}
                  />
                  {errors.customerPassword ? (
                    <p className="text-xs text-destructive flex items-center gap-1">
                      <span>✕</span> {errors.customerPassword}
                    </p>
                  ) : formData.customerPassword.length >= 6 && (
                    <p className="text-xs text-green-500 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Password valida
                    </p>
                  )}
                </div>

                {/* Confirm Password */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                    <Lock className="w-4 h-4" />
                    Conferma password
                  </label>
                  <input
                    type="password"
                    value={formData.confirmPassword}
                    onChange={(e) => handleFieldChange('confirmPassword', e.target.value)}
                    placeholder="Ripeti la password"
                    className={`w-full px-4 py-4 rounded-2xl bg-secondary/30 border transition-all text-lg focus:outline-none focus:ring-2 ${
                      errors.confirmPassword
                        ? 'border-destructive focus:border-destructive focus:ring-destructive/20'
                        : formData.confirmPassword && formData.customerPassword === formData.confirmPassword
                          ? 'border-green-500 focus:border-green-500 focus:ring-green-500/20'
                          : 'border-border/30 focus:border-accent focus:ring-accent/20'
                    }`}
                  />
                  {errors.confirmPassword && (
                    <p className="text-xs text-destructive">{errors.confirmPassword}</p>
                  )}
                  {formData.confirmPassword && formData.customerPassword === formData.confirmPassword && (
                    <p className="text-xs text-green-500 flex items-center gap-1">
                      <Check className="w-3 h-3" /> Password confermata
                    </p>
                  )}
                </div>

                <p className="text-xs text-muted-foreground">
                  La password ti servirà per accedere al tuo account
                </p>

                <button
                  onClick={handleCustomerSignUp}
                  disabled={isLoading || !formData.customerPassword || !formData.confirmPassword || formData.customerPassword !== formData.confirmPassword}
                  className="w-full py-4 rounded-2xl bg-accent text-accent-foreground font-medium flex items-center justify-center gap-2 hover:bg-accent/90 transition-colors disabled:opacity-50"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      Crea account
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                <button
                  onClick={() => setStep('name')}
                  className="w-full text-center text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  ← Torna indietro
                </button>
              </motion.div>
            )}

            {/* Success */}
            {step === 'success' && (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center space-y-6"
              >
                <div className="w-20 h-20 mx-auto rounded-full bg-accent/20 flex items-center justify-center">
                  <Check className="w-10 h-10 text-accent" />
                </div>
                <div className="space-y-2">
                  <h2 className="text-xl font-semibold">Account creato!</h2>
                  <p className="text-muted-foreground text-sm">
                    Benvenuto {formData.name}! Ora puoi salvare i tuoi piatti preferiti.
                  </p>
                </div>
                <button
                  onClick={() => navigate('/?skipOnboarding=true')}
                  className="w-full py-4 rounded-2xl bg-accent text-accent-foreground font-medium"
                >
                  Esplora il menu
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      <FooterSimple />
    </div>
  );
}
