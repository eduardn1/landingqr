import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTakeAwayCart } from '@/contexts/TakeAwayCartContext';
import { useTakeAwaySettings } from '@/hooks/useTakeAwaySettings';
import { useDeliveryZones, findZoneByZip } from '@/hooks/useDeliveryZones';
import { useCreateTakeAwayOrder } from '@/hooks/useTakeAwayOrders';
import { useAuthSession } from '@/hooks/useAuthSession';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { BackButton } from '@/components/ui/BackButton';
import { PromoCodeInput, AppliedPromo } from '@/components/client/PromoCodeInput';
import { toast } from 'sonner';
import { Package, Truck, Clock, Minus, Plus, Trash2, ShoppingBag, MapPin, Home } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

export default function TakeAwayCheckout() {
  const navigate = useNavigate();
  const { user } = useAuthSession();
  const { items, subtotal, itemCount, clearCart, updateQuantity, removeItem } = useTakeAwayCart();
  const { data: settings } = useTakeAwaySettings();
  const { data: zones = [] } = useDeliveryZones();
  const { config } = useRestaurantConfig();
  const createOrder = useCreateTakeAwayOrder();

  const [orderType, setOrderType] = useState<'pickup' | 'delivery'>('pickup');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState({
    street: '',
    city: '',
    zip: '',
    floor: '',
    intercom: '',
    notes: '',
  });
  const [pickupTime, setPickupTime] = useState('');
  const [notes, setNotes] = useState('');
  const [selectedZone, setSelectedZone] = useState<any>(null);
  const [appliedPromo, setAppliedPromo] = useState<AppliedPromo | null>(null);
  const [showAddressChoice, setShowAddressChoice] = useState(false);
  const [savedAddresses, setSavedAddresses] = useState<Array<{
    id: string;
    label: string;
    street: string;
    city: string;
    zip: string;
    floor: string;
    notes: string;
    is_default: boolean;
  }>>([]);

  // Pre-fill user data from profile and fetch saved addresses
  useEffect(() => {
    const fetchProfileAndAddresses = async () => {
      if (!user?.id) return;
      
      // Fetch profile for name and phone
      const { data: profile } = await supabase
        .from('profiles')
        .select('display_name, phone')
        .eq('user_id', user.id)
        .single();
      
      if (profile) {
        setCustomerName(profile.display_name || user.user_metadata?.display_name || '');
        setCustomerPhone(profile.phone || user.phone || '');
      } else {
        setCustomerName(user.user_metadata?.display_name || '');
        setCustomerPhone(user.user_metadata?.phone || user.phone || '');
      }

      // Fetch saved delivery addresses
      const { data: addresses } = await supabase
        .from('delivery_addresses')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });
      
      if (addresses && addresses.length > 0) {
        setSavedAddresses(addresses.map(a => ({
          id: a.id,
          label: a.label,
          street: a.address,
          city: a.city,
          zip: a.zip_code,
          floor: a.apartment_floor || '',
          notes: a.delivery_notes || '',
          is_default: a.is_default,
        })));
      }
    };
    
    fetchProfileAndAddresses();
  }, [user]);

  // Find delivery zone when zip changes
  useEffect(() => {
    if (deliveryAddress.zip.length >= 5) {
      const zone = findZoneByZip(zones, deliveryAddress.zip);
      setSelectedZone(zone);
    } else {
      setSelectedZone(null);
    }
  }, [deliveryAddress.zip, zones]);

  // Show address choice dialog when delivery is selected and user has saved addresses
  useEffect(() => {
    if (orderType === 'delivery' && savedAddresses.length > 0 && !deliveryAddress.street) {
      setShowAddressChoice(true);
    }
  }, [orderType, savedAddresses]);

  const useSavedAddress = (addr: typeof savedAddresses[0]) => {
    setDeliveryAddress({
      street: addr.street,
      city: addr.city,
      zip: addr.zip,
      floor: addr.floor,
      intercom: '',
      notes: addr.notes,
    });
    setShowAddressChoice(false);
  };

  const useNewAddress = () => {
    setDeliveryAddress({
      street: '',
      city: '',
      zip: '',
      floor: '',
      intercom: '',
      notes: '',
    });
    setShowAddressChoice(false);
  };

  const deliveryFee = orderType === 'delivery' && selectedZone 
    ? (appliedPromo?.discountType === 'free_delivery' ? 0 : selectedZone.delivery_fee) 
    : 0;
  const discount = appliedPromo?.discountAmount || 0;
  const total = Math.max(0, subtotal + deliveryFee - discount);

  // Minimum order check for delivery
  const minimumOrder = selectedZone?.minimum_order || 0;
  const meetsMinimum = orderType === 'pickup' || subtotal >= minimumOrder;

  // Check if restaurant is open based on business hours
  const isRestaurantOpen = () => {
    if (!config?.business_hours) return true;
    
    const now = new Date();
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const today = dayNames[now.getDay()];
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    const todayHours = (config.business_hours as any[])?.find((h: any) => h.day === today);
    if (!todayHours || todayHours.closed) return false;
    
    // Check if current time is within opening hours
    // Handle multiple time ranges per day
    if (Array.isArray(todayHours.ranges)) {
      return todayHours.ranges.some((range: any) => 
        currentTime >= range.open && currentTime <= range.close
      );
    }
    
    return currentTime >= todayHours.open && currentTime <= todayHours.close;
  };

  const getOpeningInfo = () => {
    if (!config?.business_hours) return null;
    
    const now = new Date();
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const today = dayNames[now.getDay()];
    
    const todayHours = (config.business_hours as any[])?.find((h: any) => h.day === today);
    if (!todayHours || todayHours.closed) {
      return { isOpen: false, message: 'Chiuso oggi', openTime: null, closeTime: null };
    }
    
    // Handle multiple time ranges
    if (Array.isArray(todayHours.ranges) && todayHours.ranges.length > 0) {
      const firstRange = todayHours.ranges[0];
      const lastRange = todayHours.ranges[todayHours.ranges.length - 1];
      return { 
        isOpen: true, 
        openTime: firstRange.open, 
        closeTime: lastRange.close 
      };
    }
    
    return { 
      isOpen: true, 
      openTime: todayHours.open || null, 
      closeTime: todayHours.close || null 
    };
  };

  const restaurantOpen = isRestaurantOpen();
  const openingInfo = getOpeningInfo();

  // Generate pickup time slots based on business hours
  const generateTimeSlots = () => {
    const slots: string[] = [];
    const now = new Date();
    const interval = settings?.pickup_intervals || 15;
    const minPrep = settings?.min_prep_time || 20;

    // Get today's business hours
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const today = dayNames[now.getDay()];
    const todayHours = config?.business_hours 
      ? (config.business_hours as any[])?.find((h: any) => h.day === today)
      : null;

    if (!todayHours || todayHours.closed) return slots;

    // Get time ranges - support both new ranges format and legacy open/close
    let timeRanges: { open: string; close: string }[] = [];
    
    if (Array.isArray(todayHours.ranges) && todayHours.ranges.length > 0) {
      timeRanges = todayHours.ranges;
    } else if (todayHours.open && todayHours.close) {
      timeRanges = [{ open: todayHours.open, close: todayHours.close }];
    } else {
      return slots;
    }

    // Start from current time + min prep time, rounded to next interval
    let startTime = new Date(now.getTime() + minPrep * 60000);
    const minutes = startTime.getMinutes();
    const remainder = minutes % interval;
    if (remainder !== 0) {
      startTime = new Date(startTime.getTime() + (interval - remainder) * 60000);
    }

    // Generate slots within each time range
    for (let i = 0; i < 48; i++) {
      const time = new Date(startTime.getTime() + i * interval * 60000);
      const timeStr = `${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}`;
      
      // Check if this time falls within any open range
      const isWithinRange = timeRanges.some(range => {
        return timeStr >= range.open && timeStr < range.close;
      });
      
      if (isWithinRange) {
        slots.push(timeStr);
      }
    }

    return slots;
  };

  const timeSlots = generateTimeSlots();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      toast.error('Devi accedere per effettuare un ordine');
      navigate('/auth?returnTo=/takeaway/checkout');
      return;
    }

    if (!meetsMinimum) {
      toast.error(`Ordine minimo per la consegna: €${minimumOrder.toFixed(2)}`);
      return;
    }

    try {
      const orderData = {
        user_id: user.id,
        customer_name: customerName,
        customer_phone: customerPhone,
        customer_email: customerEmail || null,
        order_type: orderType,
        items: items.map(item => ({
          dish_id: item.dish_id,
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          notes: item.notes,
          extras: item.extras,
        })),
        subtotal,
        delivery_fee: deliveryFee,
        discount,
        promo_code: appliedPromo?.code || null,
        total,
        pickup_time:
          orderType === 'pickup' && pickupTime
            ? new Date(`${new Date().toISOString().split('T')[0]}T${pickupTime}`).toISOString()
            : null,
        delivery_address: orderType === 'delivery' ? {
          ...deliveryAddress,
          full_address: `${deliveryAddress.street}, ${deliveryAddress.zip} ${deliveryAddress.city}`
        } : null,
        delivery_zone_id: orderType === 'delivery' ? selectedZone?.id : null,
        special_notes: notes || null,
        preparation_time: settings?.min_prep_time,
        estimated_ready_at: new Date(
          Date.now() + (settings?.min_prep_time || 20) * 60000
        ).toISOString(),
      };

      // Increment promo usage if applied
      if (appliedPromo) {
        const { data: currentPromo } = await supabase
          .from('daily_promos')
          .select('current_uses')
          .eq('id', appliedPromo.id)
          .single();
        
        if (currentPromo) {
          await supabase
            .from('daily_promos')
            .update({ current_uses: (currentPromo.current_uses || 0) + 1 })
            .eq('id', appliedPromo.id);
        }
      }

      const order = await createOrder.mutateAsync(orderData);

      // Build full items list for WhatsApp
      const itemsList = items.map(i => {
        let line = `• ${i.quantity}x ${i.name} - €${(i.price * i.quantity).toFixed(2)}`;
        if (i.extras && i.extras.length > 0) {
          line += `\n  + ${i.extras.map((e: any) => e.name).join(', ')}`;
        }
        if (i.notes) {
          line += `\n  (${i.notes})`;
        }
        return line;
      }).join('\n');

      // Build delivery info
      let deliveryInfo = '';
      if (orderType === 'delivery' && deliveryAddress.street) {
        deliveryInfo = `📍 Indirizzo:\n${deliveryAddress.street}\n${deliveryAddress.zip} ${deliveryAddress.city}`;
        if (deliveryAddress.floor) deliveryInfo += `\nPiano: ${deliveryAddress.floor}`;
        if (deliveryAddress.intercom) deliveryInfo += `\nCitofono: ${deliveryAddress.intercom}`;
      } else if (orderType === 'pickup' && pickupTime) {
        deliveryInfo = `⏰ Ritiro alle: ${pickupTime}`;
      }

      // Build notes line
      const notesLine = notes ? `📝 Note: ${notes}` : '';

      // Build delivery fee line
      const deliveryFeeLine = deliveryFee > 0 ? `🚗 Consegna: €${deliveryFee.toFixed(2)}` : '';

      // Notify customer with full details
      await supabase.functions.invoke('send-whatsapp', {
        body: {
          phone: customerPhone,
          templateKey: 'takeaway_order_received',
          variables: {
            customer_name: customerName,
            order_number: order.order_number || order.id.slice(0, 8),
            order_type: orderType === 'pickup' ? 'Ritiro' : 'Consegna',
            delivery_info: deliveryInfo,
            items_list: itemsList,
            subtotal: subtotal.toFixed(2),
            delivery_fee_line: deliveryFeeLine,
            total: total.toFixed(2),
            notes_line: notesLine,
          },
          recipientName: customerName,
        },
      });

      // Notify restaurant owner (with delay)
      if (config?.whatsapp) {
        setTimeout(async () => {
          await supabase.functions.invoke('send-whatsapp', {
            body: {
              phone: config.whatsapp,
              templateKey: 'new_takeaway_order_owner',
              variables: {
                order_number: order.order_number || order.id.slice(0, 8),
                customer_name: customerName,
                customer_phone: customerPhone,
                order_type: orderType === 'pickup' ? 'Ritiro' : 'Consegna',
                total: total.toFixed(2),
                items_summary: itemsList,
              },
            },
          });
        }, 6000);
      }

      clearCart();
      toast.success('Ordine inviato con successo!');
      navigate(`/takeaway/order/${order.id}`);
    } catch (error: any) {
      toast.error(error.message || 'Errore durante l\'invio dell\'ordine');
    }
  };

  if (itemCount === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center">
          <ShoppingBag className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h1 className="text-2xl font-bold mb-2">Il carrello è vuoto</h1>
          <p className="text-muted-foreground mb-4">
            Aggiungi qualcosa dal nostro menu
          </p>
          <Button onClick={() => navigate('/takeaway')}>Vai al menu</Button>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Address Choice Dialog */}
      <Dialog open={showAddressChoice} onOpenChange={setShowAddressChoice}>
        <DialogContent className="max-w-sm max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-accent" />
              Dove consegnare?
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2 pt-2">
            {savedAddresses.map((addr) => (
              <button
                key={addr.id}
                type="button"
                onClick={() => useSavedAddress(addr)}
                className={`w-full p-3 rounded-xl border text-left transition-colors ${
                  addr.is_default 
                    ? 'border-accent bg-accent/10 hover:bg-accent/20' 
                    : 'border-border hover:border-accent/50'
                }`}
              >
                <div className="flex items-start gap-3">
                  <Home className="w-5 h-5 text-accent mt-0.5 shrink-0" />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-sm">{addr.label}</p>
                      {addr.is_default && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-accent/20 text-accent">
                          Default
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground truncate">
                      {addr.street}, {addr.zip} {addr.city}
                    </p>
                  </div>
                </div>
              </button>
            ))}
            <button
              type="button"
              onClick={useNewAddress}
              className="w-full p-3 rounded-xl border border-border text-left hover:border-accent/50 transition-colors"
            >
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Altro indirizzo</p>
                  <p className="text-xs text-muted-foreground">
                    Inserisci un nuovo indirizzo
                  </p>
                </div>
              </div>
            </button>
          </div>
        </DialogContent>
      </Dialog>

    <div className="min-h-screen bg-background pb-8">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container px-4 py-4">
          <div className="flex items-center gap-3">
            <BackButton onClick={() => navigate('/takeaway')} />
            <h1 className="text-xl font-bold">Completa l'ordine</h1>
          </div>
        </div>
      </div>

      <div className="container max-w-2xl px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Cart Items */}
          <div className="bg-card rounded-xl border border-border p-4">
            <h2 className="font-semibold text-base mb-4">Il tuo ordine ({itemCount})</h2>
            <div className="space-y-3">
              {items.map(item => (
                <div key={item.dish_id} className="border-b border-border/30 pb-3 last:border-0 last:pb-0">
                  {/* Row 1: Name + Controls + Price */}
                  <div className="flex items-center gap-2">
                    <div className="flex-1 min-w-0">
                      <span className="font-medium text-sm">
                        {item.name}
                        {item.size_variant && (
                          <span className="text-accent ml-1">({item.size_variant})</span>
                        )}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-1 shrink-0">
                      <Button
                        type="button"
                        size="icon"
                        variant="outline"
                        className="h-6 w-6"
                        onClick={() => updateQuantity(item.dish_id, item.quantity - 1)}
                      >
                        <Minus className="w-3 h-3" />
                      </Button>
                      <span className="w-5 text-center text-xs font-medium">{item.quantity}</span>
                      <Button
                        type="button"
                        size="icon"
                        variant="outline"
                        className="h-6 w-6"
                        onClick={() => updateQuantity(item.dish_id, item.quantity + 1)}
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                      <Button
                        type="button"
                        size="icon"
                        variant="ghost"
                        className="h-6 w-6 text-destructive"
                        onClick={() => removeItem(item.dish_id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                    
                    <span className="font-medium text-sm w-16 text-right shrink-0">
                      €{(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                  
                  {/* Row 2: Unit price */}
                  <p className="text-xs text-muted-foreground mt-0.5">
                    €{item.price.toFixed(2)} cad.
                  </p>
                  
                  {/* Extras/Additions */}
                  {item.extras && item.extras.length > 0 && (
                    <div className="mt-1.5 space-y-0.5">
                      {item.extras.map((extra: any, idx: number) => (
                        <p key={idx} className="text-xs text-accent">
                          + {extra.name} {extra.price > 0 && `(+€${extra.price.toFixed(2)})`}
                        </p>
                      ))}
                    </div>
                  )}
                  
                  {/* Removed Ingredients */}
                  {item.removed_ingredients && item.removed_ingredients.length > 0 && (
                    <div className="mt-1.5 space-y-0.5">
                      {item.removed_ingredients.map((ingredient: string, idx: number) => (
                        <p key={idx} className="text-xs text-muted-foreground">
                          − Senza {ingredient}
                        </p>
                      ))}
                    </div>
                  )}
                  
                  {/* Notes */}
                  {item.notes && (
                    <p className="text-xs text-muted-foreground/80 mt-1.5 italic">
                      "{item.notes}"
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Customer Info */}
          <div className="bg-card rounded-xl border border-border p-4 space-y-4">
            <h2 className="font-semibold">I tuoi dati</h2>
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Nome completo *</Label>
                  <Input
                    id="name"
                    required
                    placeholder="Mario Rossi"
                    value={customerName}
                    onChange={e => setCustomerName(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Telefono *</Label>
                  <Input
                    id="phone"
                    required
                    type="tel"
                    placeholder="+39 333 1234567"
                    value={customerPhone}
                    onChange={e => setCustomerPhone(e.target.value)}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="email">Email (opzionale)</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="mario@email.com"
                  value={customerEmail}
                  onChange={e => setCustomerEmail(e.target.value)}
                />
                <p className="text-xs text-muted-foreground mt-1">Per ricevere conferma ordine via email</p>
              </div>
            </div>
          </div>

          {/* Order Type */}
          <div className="bg-card rounded-xl border border-border p-4 space-y-4">
            <h2 className="font-semibold">Tipo di ordine</h2>
            <RadioGroup
              value={orderType}
              onValueChange={v => setOrderType(v as 'pickup' | 'delivery')}
              className="grid grid-cols-2 gap-3"
            >
              {settings?.accepts_pickup && (
                <Label
                  htmlFor="pickup"
                  className={cn(
                    "flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-colors",
                    orderType === 'pickup'
                      ? "border-accent bg-accent/10"
                      : "border-border hover:border-accent/50"
                  )}
                >
                  <RadioGroupItem value="pickup" id="pickup" className="sr-only" />
                  <Package className="w-5 h-5" />
                  <div>
                    <p className="font-medium">Ritiro</p>
                    <p className="text-xs text-muted-foreground">Passa a ritirare</p>
                  </div>
                </Label>
              )}
              {settings?.accepts_delivery && (
                <Label
                  htmlFor="delivery"
                  className={cn(
                    "flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-colors",
                    orderType === 'delivery'
                      ? "border-accent bg-accent/10"
                      : "border-border hover:border-accent/50"
                  )}
                >
                  <RadioGroupItem value="delivery" id="delivery" className="sr-only" />
                  <Truck className="w-5 h-5" />
                  <div>
                    <p className="font-medium">Consegna</p>
                    <p className="text-xs text-muted-foreground">A domicilio</p>
                  </div>
                </Label>
              )}
            </RadioGroup>
          </div>

          {/* Pickup Time or Delivery Address */}
          {orderType === 'pickup' ? (
            <div className="bg-card rounded-xl border border-border p-4 space-y-4">
              <h2 className="font-semibold flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Orario di ritiro
              </h2>
              
              {!restaurantOpen && (
                <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                  <p className="text-sm font-medium text-yellow-600 dark:text-yellow-400">
                    {openingInfo?.message === 'Chiuso oggi' 
                      ? 'Siamo chiusi oggi' 
                      : openingInfo?.openTime 
                        ? `Siamo chiusi. Apriamo alle ${openingInfo.openTime}`
                        : 'Siamo chiusi'}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Puoi comunque prenotare per dopo
                  </p>
                </div>
              )}

              {timeSlots.length === 0 ? (
                <div className="p-4 text-center text-muted-foreground">
                  <Clock className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Nessun orario disponibile oggi</p>
                  <p className="text-xs">Riprova domani durante gli orari di apertura</p>
                </div>
              ) : (
                <div className="grid grid-cols-4 gap-2">
                  {timeSlots.map(slot => (
                    <Button
                      key={slot}
                      type="button"
                      variant={pickupTime === slot ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setPickupTime(slot)}
                    >
                      {slot}
                    </Button>
                  ))}
                </div>
              )}

              {openingInfo?.openTime && openingInfo?.closeTime && (
                <p className="text-xs text-muted-foreground text-center">
                  Oggi aperto: {openingInfo.openTime} - {openingInfo.closeTime}
                </p>
              )}
            </div>
          ) : (
            <div className="bg-card rounded-xl border border-border p-4 space-y-4">
              <h2 className="font-semibold flex items-center gap-2">
                <Truck className="w-4 h-4" />
                Indirizzo di consegna
              </h2>
              <div className="grid gap-4">
                <div>
                  <Label htmlFor="street">Via e numero civico *</Label>
                  <Input
                    id="street"
                    required={orderType === 'delivery'}
                    placeholder="Via Roma 123"
                    value={deliveryAddress.street}
                    onChange={e =>
                      setDeliveryAddress({ ...deliveryAddress, street: e.target.value })
                    }
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="city">Città *</Label>
                    <Input
                      id="city"
                      required={orderType === 'delivery'}
                      placeholder="Milano"
                      value={deliveryAddress.city}
                      onChange={e =>
                        setDeliveryAddress({ ...deliveryAddress, city: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="zip">CAP *</Label>
                    <Input
                      id="zip"
                      required={orderType === 'delivery'}
                      placeholder="20121"
                      value={deliveryAddress.zip}
                      onChange={e =>
                        setDeliveryAddress({ ...deliveryAddress, zip: e.target.value })
                      }
                    />
                  </div>
                </div>
                {selectedZone && (
                  <div className="p-3 rounded-lg bg-accent/10 border border-accent/30">
                    <p className="text-sm font-medium">Zona: {selectedZone.name}</p>
                    <p className="text-xs text-muted-foreground">
                      Consegna in ~{selectedZone.estimated_minutes} min • 
                      {selectedZone.delivery_fee > 0 
                        ? ` €${selectedZone.delivery_fee.toFixed(2)}`
                        : ' Gratuita'}
                      {selectedZone.minimum_order > 0 && 
                        ` • Ordine min. €${selectedZone.minimum_order.toFixed(2)}`}
                    </p>
                  </div>
                )}
                {deliveryAddress.zip.length >= 5 && !selectedZone && (
                  <p className="text-sm text-destructive">
                    CAP non coperto dal servizio di consegna
                  </p>
                )}
                
                {/* Additional delivery details */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="floor">Piano / Scala</Label>
                    <Input
                      id="floor"
                      placeholder="3° piano, scala B"
                      value={deliveryAddress.floor}
                      onChange={e =>
                        setDeliveryAddress({ ...deliveryAddress, floor: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="intercom">Citofono</Label>
                    <Input
                      id="intercom"
                      placeholder="Rossi / 12"
                      value={deliveryAddress.intercom}
                      onChange={e =>
                        setDeliveryAddress({ ...deliveryAddress, intercom: e.target.value })
                      }
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="addressNotes">Istruzioni per il rider</Label>
                  <Input
                    id="addressNotes"
                    placeholder="Es: porta sul retro, campanello rotto..."
                    value={deliveryAddress.notes}
                    onChange={e =>
                      setDeliveryAddress({ ...deliveryAddress, notes: e.target.value })
                    }
                  />
                </div>
              </div>
            </div>
          )}

          {/* Notes */}
          <div className="bg-card rounded-xl border border-border p-4 space-y-4">
            <h2 className="font-semibold">Note (opzionale)</h2>
            <Textarea
              placeholder="Allergie, richieste speciali..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              rows={3}
            />
          </div>

          {/* Promo Code */}
          <div className="bg-card rounded-xl border border-border p-4 space-y-4">
            <h2 className="font-semibold">Codice promozionale</h2>
            <PromoCodeInput
              subtotal={subtotal}
              onPromoApplied={setAppliedPromo}
              appliedPromo={appliedPromo}
            />
          </div>

          {/* Summary */}
          <div className="bg-card rounded-xl border border-border p-4 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotale</span>
              <span>€{subtotal.toFixed(2)}</span>
            </div>
            {orderType === 'delivery' && (
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Consegna</span>
                <span>{deliveryFee > 0 ? `€${deliveryFee.toFixed(2)}` : 'Gratuita'}</span>
              </div>
            )}
            {discount > 0 && (
              <div className="flex justify-between text-sm text-green-500">
                <span>Sconto ({appliedPromo?.code})</span>
                <span>-€{discount.toFixed(2)}</span>
              </div>
            )}
            <div className="border-t border-border pt-3 flex justify-between font-bold text-lg">
              <span>Totale</span>
              <span className="text-accent">€{total.toFixed(2)}</span>
            </div>
          </div>

          {/* Submit */}
          {!user ? (
            <Button
              type="button"
              size="lg"
              className="w-full"
              onClick={() => navigate('/auth?returnTo=/takeaway/checkout')}
            >
              Accedi per ordinare
            </Button>
          ) : (
            <Button
              type="submit"
              size="lg"
              className="w-full"
              disabled={
                createOrder.isPending ||
                !meetsMinimum ||
                (orderType === 'pickup' && !pickupTime) ||
                (orderType === 'delivery' && !selectedZone)
              }
            >
              {createOrder.isPending ? 'Invio in corso...' : 'Conferma Ordine'}
            </Button>
          )}

          {!meetsMinimum && (
            <p className="text-center text-sm text-destructive">
              Ordine minimo per la consegna: €{minimumOrder.toFixed(2)}
            </p>
          )}
        </form>
      </div>
    </div>
    </>
  );
}
