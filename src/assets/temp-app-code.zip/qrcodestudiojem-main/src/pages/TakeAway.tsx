import { useState, useMemo, useRef, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useTakeAwaySettings } from '@/hooks/useTakeAwaySettings';
import { useDynamicSEO } from '@/hooks/useDynamicSEO';
import { useDesignTemplates } from '@/hooks/useDesignTemplates';
import { TakeAwayDishCard } from '@/components/takeaway/TakeAwayDishCard';
import { TakeAwayFloatingCart } from '@/components/takeaway/TakeAwayFloatingCart';
import { MenuFilterBar, type FilterState } from '@/components/client/MenuFilterBar';
import { MenuViewToggle } from '@/components/client/MenuViewToggle';
import { Badge } from '@/components/ui/badge';
import { Breadcrumb, BreadcrumbList, BreadcrumbItem, BreadcrumbLink, BreadcrumbSeparator, BreadcrumbPage } from '@/components/ui/breadcrumb';
import { Package, Clock, Truck, CreditCard, Phone, Info, ChevronLeft, ChevronRight, Heart } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { Skeleton } from '@/components/ui/skeleton';
import { BackButton } from '@/components/ui/BackButton';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { useRestaurantConfig, type MenuViewMode } from '@/hooks/useRestaurantConfig';
import { getLocalizedContent } from '@/lib/i18n';
import { useFavorites } from '@/hooks/useFavorites';

export default function TakeAway() {
  const { t, currentLanguage } = useLanguage();
  const isMobile = useIsMobile();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<MenuViewMode>('list');
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    allergens: [],
    dietTypes: [],
    priceRange: [0, 100],
  });
  
  // Category scroll
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    checkScroll();
    window.addEventListener('resize', checkScroll);
    return () => window.removeEventListener('resize', checkScroll);
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 200;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };
  
  // Dynamic SEO for takeaway page
  useDynamicSEO('takeaway');
  
  // Design templates
  const { getActiveTemplate, getMergedConfig } = useDesignTemplates('takeaway');
  const activeTakeawayTemplate = getActiveTemplate('takeaway');
  const takeawayConfig = getMergedConfig('takeaway');

  const { data: settings, isLoading: settingsLoading } = useTakeAwaySettings();
  const { config: restaurantConfig } = useRestaurantConfig();
  const { favorites } = useFavorites();

  // Fetch categories
  const { data: categories = [] } = useQuery({
    queryKey: ['takeaway-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('display_order');
      if (error) throw error;
      return data;
    },
  });

  // Fetch dishes available for takeaway with allergens
  const { data: rawDishes = [], isLoading: dishesLoading } = useQuery({
    queryKey: ['takeaway-dishes-full'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('dishes')
        .select(`
          *,
          categories(*),
          dish_allergens(allergen_code)
        `)
        .eq('is_available', true)
        .eq('available_for_takeaway', true)
        .order('display_order');

      if (error) throw error;
      
      // Map allergens to dish
      return data.map(dish => ({
        ...dish,
        allergens: dish.dish_allergens?.map((da: any) => da.allergen_code) || [],
      }));
    },
  });

  // Filter dishes by category, allergens, diet types
  const filteredDishes = useMemo(() => {
    return rawDishes.filter(dish => {
      // Category filter
      if (selectedCategory && dish.category_id !== selectedCategory) {
        return false;
      }
      
      // Allergen filter - exclude dishes containing selected allergens
      if (filters.allergens.length > 0) {
        const hasExcludedAllergen = filters.allergens.some(
          allergenCode => dish.allergens.includes(allergenCode)
        );
        if (hasExcludedAllergen) return false;
      }
      
      // Diet type filter
      if (filters.dietTypes.length > 0) {
        const hasDietTag = filters.dietTypes.some(
          diet => dish.tags?.includes(diet)
        );
        if (!hasDietTag) return false;
      }
      
      // Price filter (use takeaway_price if available)
      const price = dish.takeaway_price || dish.price;
      if (price < filters.priceRange[0] || price > filters.priceRange[1]) {
        return false;
      }
      
      return true;
    });
  }, [rawDishes, selectedCategory, filters]);

  // Group dishes by category for category titles
  const groupedDishes = useMemo(() => {
    if (selectedCategory) {
      const cat = categories.find(c => c.id === selectedCategory);
      return cat ? [{ category: cat, dishes: filteredDishes }] : [];
    }
    
    const groups: { category: any; dishes: typeof filteredDishes }[] = [];
    
    categories.forEach(cat => {
      const categoryDishes = filteredDishes.filter(d => d.category_id === cat.id);
      if (categoryDishes.length > 0) {
        groups.push({ category: cat, dishes: categoryDishes });
      }
    });
    
    return groups;
  }, [filteredDishes, categories, selectedCategory]);

  const isLoading = settingsLoading || dishesLoading;

  // Get favorite dishes that are available for takeaway - MUST be before early returns
  const favoriteDishes = useMemo(() => {
    return rawDishes.filter(dish => favorites.includes(dish.id));
  }, [rawDishes, favorites]);

  // Get grid classes based on view mode
  const getGridClasses = () => {
    switch (viewMode) {
      case 'list':
        return 'grid-cols-1 gap-3';
      case 'grid':
        return 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3';
      case 'cards':
      default:
        return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4';
    }
  };

  if (settingsLoading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <Skeleton className="h-8 w-48 mb-4" />
        <Skeleton className="h-10 w-full mb-4" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Skeleton key={i} className="h-64 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }
 
  if (!settings?.is_enabled) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center">
          <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h1 className="text-2xl font-bold mb-2">Servizio non disponibile</h1>
          <p className="text-muted-foreground">
            Il servizio asporto è momentaneamente sospeso.
          </p>
          <BackButton onClick={() => window.location.assign('/')} className="mt-4" />
        </div>
      </div>
    );
  }

  // Render dishes with category headers (like Menu page)
  const renderDishesWithCategories = () => (
    <AnimatePresence mode="wait">
      {isLoading ? (
        <div className={cn("grid", getGridClasses())}>
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Skeleton key={i} className="h-32 rounded-xl" />
          ))}
        </div>
      ) : groupedDishes.length === 0 ? (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12 text-muted-foreground"
        >
          <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Nessun piatto disponibile</p>
          {(filters.allergens.length > 0 || filters.dietTypes.length > 0) && (
            <button
              onClick={() => setFilters({ ...filters, allergens: [], dietTypes: [] })}
              className="text-accent hover:underline text-sm mt-2"
            >
              Rimuovi filtri
            </button>
          )}
        </motion.div>
      ) : (
        <motion.div 
          key={viewMode}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.2 }}
          className="space-y-8"
        >
          {groupedDishes.map(({ category, dishes }, groupIndex) => {
            const catName = currentLanguage === 'it' ? category.name_it : category.name_en || category.name_it;
            
            return (
              <motion.section
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: groupIndex * 0.1 }}
              >
                {/* Category Header */}
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-2xl">{category.icon}</span>
                  <div>
                    <h2 className="text-xl font-bold">{catName}</h2>
                    <p className="text-xs text-muted-foreground">
                      {dishes.length} {dishes.length === 1 ? 'piatto' : 'piatti'}
                    </p>
                  </div>
                </div>
                
                {/* Dishes Grid */}
                <div className={cn("grid", getGridClasses())}>
                  {dishes.map((dish, dishIndex) => (
                    <motion.div
                      key={dish.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: groupIndex * 0.05 + dishIndex * 0.02 }}
                    >
                      <TakeAwayDishCard 
                        dish={dish} 
                        viewMode={viewMode === 'cards' ? 'cards' : viewMode === 'grid' ? 'grid-2' : viewMode === 'compact' ? 'compact' : 'list'}
                      />
                    </motion.div>
                  ))}
                </div>
              </motion.section>
            );
          })}
        </motion.div>
      )}
    </AnimatePresence>
  );

  // Info Section Component - Compact version
  const TakeawayInfoSection = () => (
    <div className="bg-foreground/[0.02] dark:bg-foreground/[0.03] rounded-2xl p-4 border border-foreground/[0.05]">
      <div className="flex items-center gap-2 mb-3">
        <Info className="w-4 h-4 text-accent" />
        <h3 className="font-semibold text-sm">Informazioni Asporto</h3>
      </div>
      
      <div className="grid grid-cols-2 gap-2 text-sm">
        {/* Pickup Info */}
        {settings.accepts_pickup && (
          <div className="flex items-center gap-2 p-2 bg-background rounded-lg border border-foreground/[0.05]">
            <Clock className="w-4 h-4 text-accent flex-shrink-0" />
            <div className="min-w-0">
              <p className="font-medium text-xs">Ritiro</p>
              <p className="text-muted-foreground text-[10px]">
                {settings.min_prep_time}-{settings.max_prep_time} min
              </p>
            </div>
          </div>
        )}
        
        {/* Delivery Info */}
        {settings.accepts_delivery && (
          <div className="flex items-center gap-2 p-2 bg-background rounded-lg border border-foreground/[0.05]">
            <Truck className="w-4 h-4 text-accent flex-shrink-0" />
            <div className="min-w-0">
              <p className="font-medium text-xs">Consegna</p>
              <p className="text-muted-foreground text-[10px]">Disponibile</p>
            </div>
          </div>
        )}
        
        {/* Payment Methods */}
        <div className="flex items-center gap-2 p-2 bg-background rounded-lg border border-foreground/[0.05] col-span-2 sm:col-span-1">
          <CreditCard className="w-4 h-4 text-accent flex-shrink-0" />
          <div className="flex items-center gap-1 flex-wrap">
            {settings.accepts_cash && (
              <Badge variant="secondary" className="text-[9px] px-1.5 py-0">
                Contanti
              </Badge>
            )}
            {settings.accepts_card_on_delivery && (
              <Badge variant="secondary" className="text-[9px] px-1.5 py-0">
                Carta
              </Badge>
            )}
          </div>
        </div>
        
        {/* Contact */}
        {restaurantConfig?.phone && (
          <div className="flex items-center gap-2 p-2 bg-background rounded-lg border border-foreground/[0.05] col-span-2 sm:col-span-1">
            <Phone className="w-4 h-4 text-accent flex-shrink-0" />
            <a href={`tel:${restaurantConfig.phone}`} className="text-accent hover:underline text-xs truncate">
              {restaurantConfig.phone}
            </a>
          </div>
        )}
      </div>
    </div>
  );

  // Category Nav like Menu page
  const CategoryNav = () => (
    <div className="relative">
      {/* Scroll buttons */}
      {canScrollLeft && (
        <button
          onClick={() => scroll('left')}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-background border border-border shadow-soft flex items-center justify-center hover:bg-secondary transition-colors"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
      )}
      {canScrollRight && (
        <button
          onClick={() => scroll('right')}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-background border border-border shadow-soft flex items-center justify-center hover:bg-secondary transition-colors"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      )}

      {/* Categories */}
      <div
        ref={scrollRef}
        onScroll={checkScroll}
        className="flex gap-2 overflow-x-auto scrollbar-hide px-1 py-2 category-scroll"
      >
        {/* All button */}
        <button
          onClick={() => setSelectedCategory(null)}
          className={cn(
            "category-pill whitespace-nowrap flex-shrink-0 flex items-center gap-2",
            selectedCategory === null && "active"
          )}
        >
          <span>{t('allCategories')}</span>
        </button>

        {/* Category buttons */}
        {categories.filter(c => c.is_active).map((category, index) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={cn(
              "category-pill whitespace-nowrap flex-shrink-0 flex items-center gap-2",
              "animate-fade-in",
              selectedCategory === category.id && "active"
            )}
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <span className="text-base">{category.icon}</span>
            <span>{getLocalizedContent({ it: category.name_it, en: category.name_en }, currentLanguage)}</span>
          </button>
        ))}
      </div>
    </div>
  );


  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border pt-16 md:pt-0">
        <div className="container px-4 py-4">
          {/* Breadcrumb Row */}
          <div className="flex items-center justify-between mb-4">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink asChild>
                    <Link to="/">Home</Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator />
                <BreadcrumbItem>
                  <BreadcrumbPage>Asporto</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
            
            {/* Product count only - logo is in header */}
            <Badge variant="outline" className="text-xs font-medium">
              {filteredDishes.length} prodotti
            </Badge>
          </div>

          {/* Info Section - FIRST */}
          <div className="mb-4">
            <TakeawayInfoSection />
          </div>

          {/* Favorites Quick Access - AFTER Info */}
          {favoriteDishes.length > 0 && (
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                <Heart className="w-4 h-4 text-accent fill-accent" />
                <span className="text-sm font-medium">I tuoi preferiti</span>
                <Badge variant="secondary" className="text-[10px]">{favoriteDishes.length}</Badge>
              </div>
              <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
                {favoriteDishes.slice(0, 8).map((dish) => (
                  <div 
                    key={dish.id}
                    className="flex-shrink-0 w-40 sm:w-44"
                  >
                    <TakeAwayDishCard dish={dish} viewMode="compact" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Filters Row - Mobile: same line */}
          <div className="flex items-center gap-2 mb-4">
            <div className="flex-1 min-w-0">
              <MenuFilterBar
                filters={filters}
                onFiltersChange={setFilters}
                selectedMood={selectedMood}
                onSelectMood={setSelectedMood}
                maxPrice={100}
              />
            </div>
            <div className="flex-shrink-0">
              <MenuViewToggle
                currentView={viewMode}
                onViewChange={setViewMode}
              />
            </div>
          </div>

          {/* Category Pills - Same style as Menu */}
          <CategoryNav />
        </div>
      </div>

      {/* Content */}
      <div className="container px-4 py-4">
        {/* Dishes with Category Headers */}
        {renderDishesWithCategories()}
      </div>

      {/* Floating Cart */}
      <TakeAwayFloatingCart />
    </div>
  );
}