import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useQueryClient } from '@tanstack/react-query';
import { Loader2, Code, Rocket } from 'lucide-react';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { useOnboardingSteps } from '@/hooks/useOnboardingSteps';
import { useDynamicMoods } from '@/hooks/useDynamicMoods';
import { useStories } from '@/hooks/useStories';
import { useHomeSections } from '@/hooks/useHomeSections';
import { useLanguage } from '@/contexts/LanguageContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// New admin components
import { AdminSidebar, AdminSection } from '@/components/admin/AdminSidebar';
import { AdminHeader } from '@/components/admin/AdminHeader';

// Editor components
import { OnboardingEditor } from '@/components/admin/OnboardingEditor';
import { MoodsEditor } from '@/components/admin/MoodsEditor';
import { StoriesEditor } from '@/components/admin/StoriesEditor';
import { HomeSectionsEditor } from '@/components/admin/HomeSectionsEditor';
import { DishesEditor } from '@/components/admin/DishesEditor';
import { CategoriesEditor } from '@/components/admin/CategoriesEditor';
import { AllergensEditor } from '@/components/admin/AllergensEditor';
import { BusinessHoursEditor } from '@/components/admin/BusinessHoursEditor';
import { ReservationsAdmin } from '@/components/admin/ReservationsAdmin';
import { ClosedDatesEditor } from '@/components/admin/ClosedDatesEditor';
import { CapacitySettings } from '@/components/admin/CapacitySettings';
import { SocialIntegrationsEditor } from '@/components/admin/SocialIntegrationsEditor';
import { WhatsAppTemplatesEditor } from '@/components/admin/WhatsAppTemplatesEditor';
import { BroadcastManager } from '@/components/admin/BroadcastManager';
import { NavigationEditor } from '@/components/admin/NavigationEditor';
import { CustomersAdmin } from '@/components/admin/CustomersAdmin';
import { ActionButtonsEditor } from '@/components/admin/ActionButtonsEditor';
import { EventsEditor } from '@/components/admin/EventsEditor';
import { BrandingSection } from '@/components/admin/BrandingSection';
import { AboutUsEditor } from '@/components/admin/AboutUsEditor';
import { PWASettingsEditor } from '@/components/admin/PWASettingsEditor';
import { MenuViewEditor } from '@/components/admin/MenuViewEditor';
import { AdminOverview } from '@/components/admin/AdminOverview';
import { PromosEditor } from '@/components/admin/PromosEditor';
import { PromoCodesEditor } from '@/components/admin/PromoCodesEditor';
import { WhatsAppLogsViewer } from '@/components/admin/WhatsAppLogsViewer';
import { LoyaltyAdmin } from '@/components/admin/LoyaltyAdmin';
import { NotificationsAdmin } from '@/components/admin/NotificationsAdmin';
import { GamificationAdmin } from '@/components/admin/GamificationAdmin';
import { CacheManagement } from '@/components/admin/CacheManagement';
import { TakeAwayAdmin } from '@/components/admin/TakeAwayAdmin';
import { SEOEditor } from '@/components/admin/SEOEditor';
import { TemplateSelector } from '@/components/admin/TemplateSelector';
import { OnboardingActionsEditor } from '@/components/admin/OnboardingActionsEditor';
import { OnboardingVariantSelector } from '@/components/admin/OnboardingVariantSelector';

export default function Admin() {
  const queryClient = useQueryClient();
  const { currentLanguage } = useLanguage();
  const [activeSection, setActiveSection] = useState<AdminSection>('overview');
  const [isSaving, setIsSaving] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const { config, isLoading: configLoading } = useRestaurantConfig();
  const { steps, isLoading: stepsLoading } = useOnboardingSteps();
  const { moods, isLoading: moodsLoading } = useDynamicMoods();
  const { stories, isLoading: storiesLoading } = useStories();
  const { sections, isLoading: sectionsLoading } = useHomeSections();

  const isLoading = configLoading || stepsLoading || moodsLoading || storiesLoading || sectionsLoading;

  // Branding form state
  const [brandingForm, setBrandingForm] = useState({
    name: '',
    tagline_it: '',
    tagline_en: '',
    phone: '',
    whatsapp: '',
    email: '',
    address: '',
    city: '',
    instagram_url: '',
    facebook_url: '',
    tiktok_url: '',
    tripadvisor_url: '',
    google_maps_url: '',
    color_primary: '',
    color_secondary: '',
    color_accent: '',
    color_background: '',
    color_foreground: '',
  });

  useEffect(() => {
    if (config) {
      setBrandingForm({
        name: config.name || '',
        tagline_it: config.tagline?.it || '',
        tagline_en: config.tagline?.en || '',
        phone: config.phone || '',
        whatsapp: config.whatsapp || '',
        email: config.email || '',
        address: config.address || '',
        city: config.city || '',
        instagram_url: config.instagram_url || '',
        facebook_url: config.facebook_url || '',
        tiktok_url: config.tiktok_url || '',
        tripadvisor_url: config.tripadvisor_url || '',
        google_maps_url: config.google_maps_url || '',
        color_primary: config.color_primary || '',
        color_secondary: config.color_secondary || '',
        color_accent: config.color_accent || '',
        color_background: config.color_background || '',
        color_foreground: config.color_foreground || '',
      });
    }
  }, [config]);

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['onboarding-steps'] });
    queryClient.invalidateQueries({ queryKey: ['dynamic-moods'] });
    queryClient.invalidateQueries({ queryKey: ['stories'] });
    queryClient.invalidateQueries({ queryKey: ['home-sections'] });
    queryClient.invalidateQueries({ queryKey: ['restaurant-config'] });
  };

  const handleSaveBranding = async () => {
    if (!config?.id) return;
    
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('restaurant_config')
        .update({
          name: brandingForm.name,
          tagline: { it: brandingForm.tagline_it, en: brandingForm.tagline_en },
          phone: brandingForm.phone,
          whatsapp: brandingForm.whatsapp,
          email: brandingForm.email,
          address: brandingForm.address,
          city: brandingForm.city,
          instagram_url: brandingForm.instagram_url,
          facebook_url: brandingForm.facebook_url,
          tiktok_url: brandingForm.tiktok_url,
          tripadvisor_url: brandingForm.tripadvisor_url,
          google_maps_url: brandingForm.google_maps_url,
          color_primary: brandingForm.color_primary,
          color_secondary: brandingForm.color_secondary,
          color_accent: brandingForm.color_accent,
          color_background: brandingForm.color_background,
          color_foreground: brandingForm.color_foreground,
        })
        .eq('id', config.id);

      if (error) throw error;
      toast.success('Configurazione salvata!');
      handleRefresh();
    } catch (error) {
      console.error('Error saving config:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSectionChange = (section: AdminSection) => {
    setActiveSection(section);
    setMobileMenuOpen(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Render section content
  const renderContent = () => {
    const wrapperClass = "animate-in fade-in duration-300";

    switch (activeSection) {
      case 'overview':
        return <AdminOverview config={config} onNavigate={setActiveSection} />;
      
      case 'branding':
        return (
          <div className={wrapperClass}>
            <BrandingSection 
              config={config}
              brandingForm={brandingForm}
              setBrandingForm={setBrandingForm}
              isSaving={isSaving}
              onSave={handleSaveBranding}
              onRefresh={handleRefresh}
            />
          </div>
        );

      case 'about-us':
        return <div className={wrapperClass}><AboutUsEditor /></div>;

      case 'pwa':
        return <div className={wrapperClass}><PWASettingsEditor /></div>;

      case 'seo':
        return <div className={wrapperClass}><SEOEditor /></div>;

      case 'templates':
        return <div className={wrapperClass}><TemplateSelector /></div>;

      case 'whatsapp-logs':
        return <div className={wrapperClass}><WhatsAppLogsViewer /></div>;

      case 'loyalty':
        return <div className={wrapperClass}><LoyaltyAdmin /></div>;

      case 'gamification':
        return <div className={wrapperClass}><GamificationAdmin /></div>;

      case 'notifications':
        return <div className={wrapperClass}><NotificationsAdmin /></div>;

      case 'cache':
        return <div className={wrapperClass}><CacheManagement /></div>;

      case 'takeaway':
        return <div className={wrapperClass}><TakeAwayAdmin /></div>;

      case 'dishes':
        return <div className={wrapperClass}><DishesEditor /></div>;

      case 'categories':
        return <div className={wrapperClass}><CategoriesEditor /></div>;

      case 'allergens':
        return <div className={wrapperClass}><AllergensEditor /></div>;

      case 'menu-view':
        return <div className={wrapperClass}><MenuViewEditor /></div>;

      case 'onboarding':
        return (
          <div className={wrapperClass}>
            <div className="space-y-6">
              <OnboardingVariantSelector config={config} />
              <div className="border-t border-border pt-6">
                <h3 className="text-lg font-semibold mb-4">Quiz - Domande</h3>
                <OnboardingEditor steps={steps || []} currentLanguage={currentLanguage} onRefresh={handleRefresh} />
              </div>
            </div>
          </div>
        );

      case 'onboarding-actions':
        return (
          <div className={wrapperClass}>
            <OnboardingActionsEditor />
          </div>
        );

      case 'moods':
        return (
          <div className={wrapperClass}>
            <MoodsEditor moods={moods || []} currentLanguage={currentLanguage} onRefresh={handleRefresh} />
          </div>
        );

      case 'stories':
        return (
          <div className={wrapperClass}>
            <StoriesEditor stories={stories || []} currentLanguage={currentLanguage} onRefresh={handleRefresh} />
          </div>
        );

      case 'sections':
        return <div className={wrapperClass}><HomeSectionsEditor currentLanguage={currentLanguage} /></div>;

      case 'navigation':
        return <div className={wrapperClass}><NavigationEditor /></div>;

      case 'action-buttons':
        return <div className={wrapperClass}><ActionButtonsEditor /></div>;

      case 'events':
        return <div className={wrapperClass}><EventsEditor /></div>;

      case 'promos':
        return <div className={wrapperClass}><PromosEditor /></div>;

      case 'promo-codes':
        return <div className={wrapperClass}><PromoCodesEditor /></div>;

      case 'hours':
        return (
          <div className={wrapperClass}>
            <BusinessHoursEditor configId={config?.id || ''} initialHours={config?.business_hours} onSave={handleRefresh} />
          </div>
        );

      case 'closed-dates':
        return <div className={wrapperClass}><ClosedDatesEditor /></div>;

      case 'capacity':
        return (
          <div className={wrapperClass}>
            <CapacitySettings configId={config?.id || ''} initialCapacity={config?.max_guests_per_slot} />
          </div>
        );

      case 'reservations':
        return <div className={wrapperClass}><ReservationsAdmin /></div>;

      case 'customers':
        return <div className={wrapperClass}><CustomersAdmin /></div>;

      case 'social':
        return (
          <div className={wrapperClass}>
            <SocialIntegrationsEditor 
              configId={config?.id || ''} 
              initialGooglePlaceId={config?.google_place_id} 
              initialInstagramUsername={config?.instagram_username} 
            />
          </div>
        );

      case 'whatsapp':
        return <div className={wrapperClass}><WhatsAppTemplatesEditor /></div>;

      case 'broadcast':
        return <div className={wrapperClass}><BroadcastManager /></div>;

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <AdminHeader
        activeSection={activeSection}
        onRefresh={handleRefresh}
        onMobileMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)}
        isMobileMenuOpen={mobileMenuOpen}
      />

      <div className="flex flex-1 overflow-hidden">
        {/* Desktop/Tablet Sidebar - visible from md breakpoint */}
        <div className="hidden md:block h-[calc(100vh-56px)]">
          <AdminSidebar
            activeSection={activeSection}
            onSectionChange={handleSectionChange}
            isCollapsed={sidebarCollapsed}
            onCollapsedChange={setSidebarCollapsed}
          />
        </div>

        {/* Mobile Sidebar Overlay - only on small screens */}
        {mobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 md:hidden"
              onClick={() => setMobileMenuOpen(false)}
            />
            <motion.div 
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="fixed inset-y-0 left-0 z-50 md:hidden shadow-2xl"
            >
              <div className="h-full pt-14">
                <AdminSidebar
                  activeSection={activeSection}
                  onSectionChange={handleSectionChange}
                  isCollapsed={false}
                  onCollapsedChange={() => {}}
                />
              </div>
            </motion.div>
          </>
        )}

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto h-[calc(100vh-56px)]">
          <div className="p-3 sm:p-4 md:p-6 lg:p-8 max-w-7xl mx-auto pb-20">
            {renderContent()}
          </div>
          
          {/* Admin Footer with StudioJEM Credits */}
          <footer className="border-t border-border/20 bg-secondary/20 py-4 px-4">
            <div className="max-w-7xl mx-auto flex items-center justify-center gap-3">
              <a 
                href="https://studiojem.it" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-200 hover:scale-105 bg-card border border-border/20 text-muted-foreground hover:text-foreground"
              >
                <Code className="w-3.5 h-3.5" />
                <span>Sviluppato da</span>
                <span className="font-bold text-foreground">studiojem.it</span>
                <Rocket className="w-3.5 h-3.5 text-accent" />
              </a>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
}
