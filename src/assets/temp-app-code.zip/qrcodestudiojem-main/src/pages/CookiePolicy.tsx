import { motion } from 'framer-motion';
import { ArrowLeft, Cookie, Settings } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { Button } from '@/components/ui/button';

export default function CookiePolicy() {
  const { config } = useRestaurantConfig();
  const businessName = config?.name || 'Il Locale';
  const businessEmail = config?.email || 'info@example.com';

  const handleManageCookies = () => {
    // Clear consent to show the banner again
    localStorage.removeItem('cookie_consent');
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur-sm border-b border-border/20">
        <div className="container px-4 py-4 flex items-center gap-4">
          <Link 
            to="/" 
            className="p-2 rounded-full hover:bg-secondary/50 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </Link>
          <div className="flex items-center gap-2">
            <Cookie className="w-5 h-5 text-accent" />
            <h1 className="text-lg font-semibold text-foreground">Cookie Policy</h1>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="container px-4 py-8 max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="prose prose-sm dark:prose-invert max-w-none"
        >
          <p className="text-muted-foreground text-sm mb-8">
            Ultimo aggiornamento: {new Date().toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric' })}
          </p>

          {/* Manage cookies button */}
          <div className="p-4 rounded-xl bg-accent/10 border border-accent/20 mb-8 flex items-center justify-between gap-4 flex-wrap">
            <div>
              <p className="text-foreground font-medium text-sm">Gestisci le tue preferenze</p>
              <p className="text-muted-foreground text-xs">Modifica le impostazioni dei cookie in qualsiasi momento</p>
            </div>
            <Button 
              onClick={handleManageCookies}
              variant="outline" 
              size="sm"
              className="flex items-center gap-2"
            >
              <Settings className="w-4 h-4" />
              Gestisci Cookie
            </Button>
          </div>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">1. Cosa Sono i Cookie</h2>
            <p className="text-muted-foreground leading-relaxed">
              I cookie sono piccoli file di testo che i siti visitati dall'utente inviano e registrano sul suo 
              computer o dispositivo mobile, per essere poi ritrasmessi agli stessi siti alla visita successiva. 
              Proprio grazie ai cookie è possibile memorizzare le preferenze, personalizzare le pagine, 
              migliorare la navigazione.
            </p>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">2. Tipologie di Cookie Utilizzati</h2>
            
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-secondary/30 border border-border/20">
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-green-500"></span>
                  Cookie Tecnici (Necessari)
                </h3>
                <p className="text-muted-foreground text-sm mt-2">
                  Questi cookie sono essenziali per il corretto funzionamento dell'applicazione e non possono essere disattivati. 
                  Vengono utilizzati per:
                </p>
                <ul className="list-disc list-inside text-muted-foreground text-sm mt-2 space-y-1">
                  <li>Mantenere la sessione utente attiva</li>
                  <li>Ricordare le preferenze di tema (chiaro/scuro)</li>
                  <li>Memorizzare le preferenze linguistiche</li>
                  <li>Gestire il consenso ai cookie</li>
                  <li>Funzionalità di caching per prestazioni ottimali</li>
                </ul>
                <p className="text-xs text-muted-foreground/70 mt-3">
                  <strong>Durata:</strong> Sessione / 1 anno
                </p>
              </div>

              <div className="p-4 rounded-xl bg-secondary/30 border border-border/20">
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                  Cookie Analitici
                </h3>
                <p className="text-muted-foreground text-sm mt-2">
                  Questi cookie ci aiutano a capire come gli utenti interagiscono con l'applicazione, 
                  raccogliendo informazioni in forma anonima e aggregata:
                </p>
                <ul className="list-disc list-inside text-muted-foreground text-sm mt-2 space-y-1">
                  <li>Numero di visitatori e pagine visualizzate</li>
                  <li>Tempo di permanenza sull'applicazione</li>
                  <li>Percorsi di navigazione</li>
                  <li>Dispositivi e browser utilizzati</li>
                </ul>
                <p className="text-xs text-muted-foreground/70 mt-3">
                  <strong>Durata:</strong> 2 anni | <strong>Fornitore:</strong> Interno
                </p>
              </div>

              <div className="p-4 rounded-xl bg-secondary/30 border border-border/20">
                <h3 className="font-semibold text-foreground flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-purple-500"></span>
                  Cookie di Marketing
                </h3>
                <p className="text-muted-foreground text-sm mt-2">
                  Questi cookie vengono utilizzati per mostrare contenuti e offerte personalizzate 
                  in base agli interessi dell'utente:
                </p>
                <ul className="list-disc list-inside text-muted-foreground text-sm mt-2 space-y-1">
                  <li>Personalizzazione dei suggerimenti di piatti</li>
                  <li>Invio di promozioni mirate via WhatsApp (con consenso)</li>
                  <li>Memorizzazione delle preferenze alimentari</li>
                </ul>
                <p className="text-xs text-muted-foreground/70 mt-3">
                  <strong>Durata:</strong> 1 anno | <strong>Fornitore:</strong> Interno
                </p>
              </div>
            </div>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">3. Cookie di Terze Parti</h2>
            <p className="text-muted-foreground leading-relaxed">
              Questa applicazione potrebbe utilizzare cookie di terze parti per le seguenti finalità:
            </p>
            
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="border-b border-border/30">
                    <th className="text-left py-3 px-4 text-foreground font-medium">Servizio</th>
                    <th className="text-left py-3 px-4 text-foreground font-medium">Finalità</th>
                    <th className="text-left py-3 px-4 text-foreground font-medium">Privacy Policy</th>
                  </tr>
                </thead>
                <tbody className="text-muted-foreground">
                  <tr className="border-b border-border/20">
                    <td className="py-3 px-4">Google Fonts</td>
                    <td className="py-3 px-4">Caricamento font</td>
                    <td className="py-3 px-4">
                      <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">
                        Link
                      </a>
                    </td>
                  </tr>
                  <tr className="border-b border-border/20">
                    <td className="py-3 px-4">Supabase</td>
                    <td className="py-3 px-4">Backend e autenticazione</td>
                    <td className="py-3 px-4">
                      <a href="https://supabase.com/privacy" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">
                        Link
                      </a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">4. Local Storage e Session Storage</h2>
            <p className="text-muted-foreground leading-relaxed">
              Oltre ai cookie, questa applicazione utilizza tecnologie di archiviazione locale del browser:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2">
              <li><strong className="text-foreground">Local Storage:</strong> per memorizzare preferenze persistenti come tema, lingua, consenso cookie</li>
              <li><strong className="text-foreground">Session Storage:</strong> per dati temporanei di sessione come stato dell'onboarding</li>
              <li><strong className="text-foreground">Cache Storage:</strong> per funzionalità offline e prestazioni migliorate (PWA)</li>
            </ul>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">5. Come Gestire i Cookie</h2>
            <p className="text-muted-foreground leading-relaxed">
              Puoi gestire le tue preferenze sui cookie in diversi modi:
            </p>
            
            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-secondary/30 border border-border/20">
                <h4 className="font-medium text-foreground text-sm">Tramite questa applicazione</h4>
                <p className="text-muted-foreground text-xs mt-1">
                  Clicca sul pulsante "Gestisci Cookie" in cima a questa pagina per modificare le tue preferenze.
                </p>
              </div>
              
              <div className="p-4 rounded-xl bg-secondary/30 border border-border/20">
                <h4 className="font-medium text-foreground text-sm">Tramite il browser</h4>
                <p className="text-muted-foreground text-xs mt-1">
                  Puoi configurare il tuo browser per bloccare o eliminare i cookie. Ogni browser ha procedure diverse:
                </p>
                <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                  <li>• <a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">Google Chrome</a></li>
                  <li>• <a href="https://support.mozilla.org/it/kb/Gestione%20dei%20cookie" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">Mozilla Firefox</a></li>
                  <li>• <a href="https://support.apple.com/it-it/guide/safari/sfri11471/mac" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">Safari</a></li>
                  <li>• <a href="https://support.microsoft.com/it-it/microsoft-edge/eliminare-i-cookie-in-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">Microsoft Edge</a></li>
                </ul>
              </div>
            </div>
            
            <p className="text-muted-foreground leading-relaxed text-sm">
              <strong className="text-foreground">Nota:</strong> La disattivazione dei cookie tecnici potrebbe compromettere 
              il corretto funzionamento dell'applicazione.
            </p>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">6. Aggiornamenti</h2>
            <p className="text-muted-foreground leading-relaxed">
              Questa Cookie Policy può essere aggiornata periodicamente. Ti consigliamo di consultare 
              questa pagina regolarmente per essere informato su eventuali modifiche.
            </p>
          </section>

          <section className="space-y-4 mb-8">
            <h2 className="text-xl font-semibold text-foreground">7. Contatti</h2>
            <p className="text-muted-foreground leading-relaxed">
              Per qualsiasi domanda relativa all'utilizzo dei cookie, puoi contattarci:
            </p>
            <div className="p-4 rounded-xl bg-accent/10 border border-accent/20">
              <p className="text-foreground font-medium">{businessName}</p>
              <p className="text-muted-foreground text-sm">Email: {businessEmail}</p>
            </div>
          </section>

          <section className="space-y-4 pt-8 border-t border-border/20">
            <p className="text-xs text-muted-foreground text-center">
              Questa informativa è resa ai sensi dell'art. 122 del D.Lgs. 196/2003 e del Provvedimento 
              del Garante Privacy dell'8 maggio 2014 "Individuazione delle modalità semplificate per 
              l'informativa e l'acquisizione del consenso per l'uso dei cookie".
            </p>
            <p className="text-xs text-muted-foreground text-center">
              Per maggiori informazioni sul trattamento dei dati personali, consulta la nostra{' '}
              <Link to="/privacy-policy" className="text-accent hover:underline">Privacy Policy</Link>.
            </p>
          </section>
        </motion.div>
      </main>
    </div>
  );
}
