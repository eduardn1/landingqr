import { useState, useRef, useMemo, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { type Dish } from '@/lib/mockData';
import { useCategories, useDishes, type DbDish } from '@/hooks/useMenu';
import { useRestaurantConfig, type MenuViewMode } from '@/hooks/useRestaurantConfig';
import { useDynamicTheme } from '@/hooks/useDynamicTheme';
import { useDynamicSEO } from '@/hooks/useDynamicSEO';
import { useDynamicMoods } from '@/hooks/useDynamicMoods';
import { useDesignTemplates } from '@/hooks/useDesignTemplates';
import { DishDetailModal } from '@/components/client/DishDetailModal';
import { CategoryNav } from '@/components/CategoryNav';
import { DishCard } from '@/components/DishCard';
import { DishListCard } from '@/components/client/DishListCard';
import { DishGridCard } from '@/components/client/DishGridCard';
import { MenuViewToggle } from '@/components/client/MenuViewToggle';
import { MenuFilterBar, type FilterState } from '@/components/client/MenuFilterBar';
import { AppHeader } from '@/components/AppHeader';
import { DynamicHeader } from '@/components/layout/HeaderVariants';
import { Footer } from '@/components/Footer';
import { Breadcrumb, BreadcrumbList, BreadcrumbItem, BreadcrumbLink, BreadcrumbSeparator, BreadcrumbPage } from '@/components/ui/breadcrumb';
import { Badge } from '@/components/ui/badge';
import { useFavorites } from '@/hooks/useFavorites';
import { useOnboardingPreferences } from '@/hooks/useOnboardingPreferences';
import { DishGridSkeleton } from '@/components/client/DishCardSkeleton';
import { Heart, Sparkles, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
// Helper to convert database dish to Dish format for components
const dbDishToDish = (dbDish: DbDish, language: string): Dish => ({
  id: dbDish.id,
  categoryId: dbDish.category_id,
  name: { it: dbDish.name_it, en: dbDish.name_en },
  description: { it: dbDish.description_it || '', en: dbDish.description_en || '' },
  ingredients: { it: dbDish.ingredients_it || '', en: dbDish.ingredients_en || '' },
  images: dbDish.image_url && dbDish.image_url.trim() !== '' ? [dbDish.image_url] : [],
  price: Number(dbDish.price),
  originalPrice: dbDish.original_price ? Number(dbDish.original_price) : undefined,
  currency: dbDish.currency,
  tags: dbDish.tags || [],
  allergens: dbDish.allergens || [],
  spicyLevel: dbDish.spicy_level || undefined,
  portionSize: dbDish.portion_size || undefined,
  isAvailable: dbDish.is_available,
  isFeatured: dbDish.is_featured,
  isSeasonal: dbDish.is_seasonal,
  badge: dbDish.badge || undefined,
  displayOrder: dbDish.display_order,
});

const Menu = () => {
  const navigate = useNavigate();
  const { currentLanguage, t } = useLanguage();
  
  // Dynamic SEO for menu page
  useDynamicSEO('menu');
  
  const menuRef = useRef<HTMLDivElement>(null);
  const { favorites, toggleFavorite, isFavorite } = useFavorites();
  const { 
    preferences: onboardingAnswers, 
    isDishRecommended,
    hasPreferences,
  } = useOnboardingPreferences();

  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedDish, setSelectedDish] = useState<Dish | null>(null);
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    allergens: [],
    dietTypes: [],
    priceRange: [0, 50],
  });

  // Fetch data from database
  const { config: restaurantConfig } = useRestaurantConfig();
  useDynamicTheme();
  const { categories: dbCategories, isLoading: categoriesLoading } = useCategories();
  const { dishes: dbDishes, isLoading: dishesLoading } = useDishes(undefined, filters.allergens);
  const { moods: dynamicMoods } = useDynamicMoods();
  
  // Design templates for header
  const { activeConfig } = useDesignTemplates('homepage');
  const headerVariant = activeConfig?.header_variant as 'default' | 'minimal' | 'centered' | 'floating' | undefined;

  // Menu view mode - use backend config as default, allow client toggle
  const [menuViewMode, setMenuViewMode] = useState<MenuViewMode>('cards');
  
  useEffect(() => {
    if (restaurantConfig?.menu_view_mode) {
      setMenuViewMode(restaurantConfig.menu_view_mode);
    }
  }, [restaurantConfig?.menu_view_mode]);

  // Convert db dishes to Dish format
  const allDishes = useMemo(() => {
    return dbDishes.map(d => dbDishToDish(d, currentLanguage));
  }, [dbDishes, currentLanguage]);

  // Convert categories to the format needed
  const categories = useMemo(() => {
    return dbCategories.map(cat => ({
      id: cat.id,
      name: { it: cat.name_it, en: cat.name_en || cat.name_it },
      icon: cat.icon,
      displayOrder: cat.display_order,
    }));
  }, [dbCategories]);

  // Get favorite dishes
  const favoriteDishes = useMemo(() => {
    return allDishes.filter(dish => favorites.includes(dish.id));
  }, [allDishes, favorites]);

  // Get "Per Te" recommended dishes based on quiz answers
  const recommendedDishes = useMemo(() => {
    if (!hasPreferences) return [];
    return allDishes.filter(dish => isDishRecommended(dish)).slice(0, 8);
  }, [allDishes, hasPreferences, isDishRecommended]);

  // Count quiz answers (excluding welcome step)
  const quizAnswerCount = useMemo(() => {
    if (!onboardingAnswers) return 0;
    return Object.keys(onboardingAnswers).filter(key => key !== 'welcome').length;
  }, [onboardingAnswers]);

  // Check if dish matches mood
  const isDishMoodMatch = (dish: Dish) => {
    if (!selectedMood) return false;
    const mood = dynamicMoods.find((m) => m.mood_key === selectedMood);
    if (!mood?.filters) return false;
    
    if (mood.filters.is_featured && !dish.isFeatured) return false;
    if (mood.filters.is_seasonal && !dish.isSeasonal) return false;
    if (mood.filters.tags?.length) {
      return mood.filters.tags.some(tag => dish.tags.includes(tag));
    }
    return true;
  };

  // Filter dishes
  const filteredDishes = useMemo(() => {
    return allDishes.filter((dish) => {
      // Category filter
      if (selectedCategory && dish.categoryId !== selectedCategory) return false;
      
      // Mood filter
      if (selectedMood) {
        const mood = dynamicMoods.find((m) => m.mood_key === selectedMood);
        if (mood?.filters) {
          if (mood.filters.is_featured && !dish.isFeatured) return false;
          if (mood.filters.is_seasonal && !dish.isSeasonal) return false;
          if (mood.filters.tags?.length) {
            const hasTags = mood.filters.tags.some(tag => dish.tags.includes(tag));
            if (!hasTags && !dish.isFeatured) return false;
          }
        }
      }
      
      // Price filter
      if (filters.priceRange) {
        if (dish.price < filters.priceRange[0] || dish.price > filters.priceRange[1]) return false;
      }
      
      // Diet types filter
      if (filters.dietTypes.length > 0) {
        const hasDietType = filters.dietTypes.some(dt => dish.tags.includes(dt));
        if (!hasDietType) return false;
      }
      
      return dish.isAvailable;
    });
  }, [allDishes, selectedCategory, selectedMood, filters, dynamicMoods]);

  // Group dishes by category for display
  const groupedDishes = useMemo(() => {
    const groups: { category: typeof categories[0], dishes: Dish[] }[] = [];
    
    categories.forEach(category => {
      const categoryDishes = filteredDishes.filter(d => d.categoryId === category.id);
      if (categoryDishes.length > 0) {
        groups.push({ category, dishes: categoryDishes });
      }
    });
    
    return groups;
  }, [filteredDishes, categories]);

  const handleDishClick = (dish: Dish) => {
    setSelectedDish(dish);
  };

  const isLoading = categoriesLoading || dishesLoading;

  return (
    <div className="min-h-screen bg-background">
      {/* Header - Use dynamic variant or fallback to AppHeader */}
      {headerVariant && headerVariant !== 'default' ? (
        <DynamicHeader variant={headerVariant} />
      ) : (
        <AppHeader />
      )}

      {/* Main Content */}
      <main ref={menuRef} className="container px-4 pt-20 pb-6 md:pt-14">
        {/* Breadcrumb + Count */}
        <div className="flex items-center justify-between mb-4 relative z-40">
          <Breadcrumb>
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink asChild>
                  <Link to="/">Home</Link>
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>Menu</BreadcrumbPage>
              </BreadcrumbItem>
              {selectedCategory && (
                <>
                  <BreadcrumbSeparator />
                  <BreadcrumbItem>
                    <BreadcrumbPage>
                      {categories.find(c => c.id === selectedCategory)?.name?.it || 'Categoria'}
                    </BreadcrumbPage>
                  </BreadcrumbItem>
                </>
              )}
            </BreadcrumbList>
          </Breadcrumb>
          
          {/* Product count only - logo is in header */}
          <Badge variant="outline" className="text-xs font-medium">
            {filteredDishes.length} piatti
          </Badge>
        </div>

        {/* Quiz Card - Before filters */}
        {!hasPreferences ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4"
          >
            <Link to="/quiz">
              <div className="flex items-center justify-between p-3 rounded-xl bg-accent/10 border border-accent/20 hover:bg-accent/15 transition-colors group cursor-pointer">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">Scopri i piatti per te</p>
                    <p className="text-xs text-muted-foreground">Rispondi al quiz per consigli personalizzati</p>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-accent group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          </motion.div>
        ) : (
          <>
            {/* Quiz completed banner */}
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4"
            >
              <div className="flex items-center justify-between p-3 rounded-xl bg-foreground/[0.03] border border-foreground/[0.05]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-accent" />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Piatti consigliati in base al tuo quiz
                  </p>
                </div>
                <Link to="/quiz">
                  <Button variant="ghost" size="sm" className="text-xs text-accent hover:text-accent">
                    Rifai
                  </Button>
                </Link>
              </div>
            </motion.div>

            {/* Per Te - Recommended Dishes Section (ABOVE filters) */}
            {recommendedDishes.length > 0 && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-6"
              >
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="w-4 h-4 text-accent" />
                  <span className="font-semibold">Per Te</span>
                  <Badge variant="secondary" className="text-[10px]">{quizAnswerCount} risposte</Badge>
                </div>
                <p className="text-xs text-muted-foreground mb-4">
                  Piatti consigliati in base alle tue preferenze dal quiz
                </p>
                <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4">
                  {recommendedDishes.map((dish) => (
                    <div 
                      key={dish.id}
                      onClick={() => handleDishClick(dish)}
                      className="flex-shrink-0 w-40 sm:w-44 cursor-pointer"
                    >
                      <DishCard dish={dish} compact onClick={() => handleDishClick(dish)} />
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </>
        )}

        {/* Sticky Filters */}
        <div className="sticky top-14 z-30 bg-background/95 backdrop-blur-sm -mx-4 px-4 py-4 border-b border-border/20 mb-6">
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <MenuFilterBar 
                filters={filters} 
                onFiltersChange={setFilters} 
                selectedMood={selectedMood}
                onSelectMood={(mood) => {
                  setSelectedMood(mood);
                  if (mood) setSelectedCategory(null);
                }}
                maxPrice={50} 
              />
            </div>
            <MenuViewToggle 
              currentView={menuViewMode} 
              onViewChange={setMenuViewMode} 
            />
          </div>
          
          <div className="mt-4">
            <CategoryNav selectedCategory={selectedCategory} onSelectCategory={setSelectedCategory} />
          </div>
        </div>

        {/* Dishes Grid */}
        {isLoading ? (
          <DishGridSkeleton count={6} />
        ) : groupedDishes.length > 0 ? (
          <div className="space-y-8">
            {groupedDishes.map(({ category, dishes }, groupIndex) => (
              <motion.section 
                key={category.id} 
                initial={{ opacity: 0, y: 20 }} 
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: groupIndex * 0.1 }}
              >
                {!selectedCategory && (
                  <div className="mb-4">
                    <h3 className="text-base font-medium text-foreground/80 flex items-center gap-2">
                      <span className="opacity-60 text-lg">{category.icon}</span>
                      {getLocalizedContent(category.name, currentLanguage)}
                    </h3>
                  </div>
                )}
                
                {/* Render dishes based on view mode */}
                {menuViewMode === 'list' ? (
                  <div className="space-y-3">
                    {dishes.map((dish, dishIndex) => (
                      <motion.div
                        key={dish.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: groupIndex * 0.05 + dishIndex * 0.02 }}
                      >
                        <DishListCard 
                          dish={dish} 
                          onClick={() => handleDishClick(dish)} 
                          isRecommended={isDishRecommended(dish)}
                          isMoodMatch={isDishMoodMatch(dish)}
                          categoryIcon={category.icon}
                          placeholderType={restaurantConfig?.placeholder_type}
                          placeholderEmoji={restaurantConfig?.placeholder_emoji}
                          placeholderGradient={restaurantConfig?.placeholder_gradient}
                          placeholderImage={restaurantConfig?.placeholder_image || undefined}
                        />
                      </motion.div>
                    ))}
                  </div>
                ) : menuViewMode === 'grid' ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {dishes.map((dish, dishIndex) => (
                      <motion.div
                        key={dish.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: groupIndex * 0.05 + dishIndex * 0.02 }}
                      >
                        <DishGridCard 
                          dish={dish} 
                          onClick={() => handleDishClick(dish)} 
                          isRecommended={isDishRecommended(dish)}
                          isMoodMatch={isDishMoodMatch(dish)}
                          categoryIcon={category.icon}
                          placeholderType={restaurantConfig?.placeholder_type}
                          placeholderEmoji={restaurantConfig?.placeholder_emoji}
                          placeholderGradient={restaurantConfig?.placeholder_gradient}
                          placeholderImage={restaurantConfig?.placeholder_image || undefined}
                        />
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {dishes.map((dish, dishIndex) => (
                      <motion.div
                        key={dish.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: groupIndex * 0.05 + dishIndex * 0.02 }}
                      >
                        <DishCard 
                          dish={dish} 
                          onClick={() => handleDishClick(dish)}
                          isRecommended={isDishRecommended(dish)}
                          isMoodMatch={isDishMoodMatch(dish)}
                        />
                      </motion.div>
                    ))}
                  </div>
                )}
              </motion.section>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Nessun piatto trovato con i filtri selezionati</p>
          </div>
        )}

        {/* Favorites Quick Access - After dishes */}
        {favoriteDishes.length > 0 && (
          <div className="mt-8 pt-6 border-t border-border/20">
            <div className="flex items-center gap-2 mb-3">
              <Heart className="w-4 h-4 text-accent fill-accent" />
              <span className="text-sm font-medium">I tuoi preferiti</span>
              <Badge variant="secondary" className="text-[10px]">{favoriteDishes.length}</Badge>
            </div>
            <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
              {favoriteDishes.slice(0, 8).map((dish) => (
                <div 
                  key={dish.id}
                  onClick={() => handleDishClick(dish)}
                  className="flex-shrink-0 w-36 sm:w-40 cursor-pointer"
                >
                  <DishCard dish={dish} compact onClick={() => handleDishClick(dish)} />
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer />

      {/* Dish Detail Modal */}
      <DishDetailModal
        dish={selectedDish}
        isOpen={!!selectedDish}
        onClose={() => setSelectedDish(null)}
        isFavorite={selectedDish ? isFavorite(selectedDish.id) : false}
        onToggleFavorite={() => selectedDish && toggleFavorite(selectedDish.id)}
      />
    </div>
  );
};

export default Menu;
