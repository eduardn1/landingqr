import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, User, Bell, Globe, Heart, LogOut, Sparkles, 
  RefreshCw, X, Trash2, CalendarDays, Clock, 
  ChevronRight, Phone, MessageCircle, Settings, Star, Gift, ShoppingBag, MapPin, Home
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { getTranslation } from '@/lib/i18n';
import { useFavorites } from '@/hooks/useFavorites';
import { useOnboardingPreferences } from '@/hooks/useOnboardingPreferences';
import { useAuthSession } from '@/hooks/useAuthSession';
import { useReservations } from '@/hooks/useReservations';
import { useLoyalty } from '@/hooks/useLoyalty';
import { usePushNotifications } from '@/hooks/usePushNotifications';
import { useMyTakeAwayOrders } from '@/hooks/useTakeAwayOrders';

import { BackButton } from '@/components/ui/BackButton';
import { Footer } from '@/components/Footer';
import { GamificationCard } from '@/components/client/GamificationCard';
import { UnifiedOrderHistory } from '@/components/client/UnifiedOrderHistory';
import { CompleteProfileCard } from '@/components/client/CompleteProfileCard';
import { ProfileAvatar, ProfileTabs, PointsHistory, DeliveryAddresses, type ProfileTabKey } from '@/components/profile';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

interface ProfileData {
  display_name: string;
  phone: string;
  push_notifications: boolean;
  whatsapp_notifications: boolean;
  address: string;
  city: string;
  zip_code: string;
  apartment_floor: string;
  delivery_notes: string;
  avatar_emoji: string | null;
}

interface FavoriteDish {
  id: string;
  name_it: string;
  name_en: string;
  price: number;
  image_url: string | null;
}

export default function Profile() {
  const navigate = useNavigate();
  const { currentLanguage, setLanguage } = useLanguage();
  const language = currentLanguage;
  
  // Set noindex for profile page (private user data)
  useEffect(() => {
    document.title = 'Profilo | Menu Digitale';
    let meta = document.querySelector('meta[name="robots"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'robots');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', 'noindex, nofollow');
  }, []);
  
  const { favorites, favoritesCount, clearFavorites, toggleFavorite } = useFavorites();
  const { preferences, hasPreferences, isLoading: prefsLoading } = useOnboardingPreferences();
  const { user, isLoading: authLoading } = useAuthSession();
  const { reservations, refetch: refetchReservations } = useReservations();
  const { points, isActive: loyaltyActive, isLoading: loyaltyLoading } = useLoyalty();
  const { isSupported: pushSupported, isEnabled: pushEnabled, requestPermission } = usePushNotifications();
  const { data: takeawayOrders = [] } = useMyTakeAwayOrders();
  
  const [isLoadingProfile, setIsLoadingProfile] = useState(false);
  const [favoriteDishes, setFavoriteDishes] = useState<FavoriteDish[]>([]);
  const [activeTab, setActiveTab] = useState<ProfileTabKey>('profile');
  const addressSectionRef = useRef<HTMLDivElement>(null);
  
  const [profile, setProfile] = useState<ProfileData>({
    display_name: '',
    phone: '',
    push_notifications: true,
    whatsapp_notifications: true,
    address: '',
    city: '',
    zip_code: '',
    apartment_floor: '',
    delivery_notes: '',
    avatar_emoji: null,
  });

  // Refetch reservations when page loads
  useEffect(() => {
    if (user) {
      refetchReservations();
    }
  }, [user, refetchReservations]);

  // Load profile
  useEffect(() => {
    if (!user) return;
    
    setIsLoadingProfile(true);
    
    const fetchProfile = async () => {
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (profileData) {
        setProfile({
          display_name: profileData.display_name || '',
          phone: profileData.phone || '',
          push_notifications: profileData.push_notifications ?? true,
          whatsapp_notifications: profileData.whatsapp_notifications ?? true,
          address: (profileData as any).address || '',
          city: (profileData as any).city || '',
          zip_code: (profileData as any).zip_code || '',
          apartment_floor: (profileData as any).apartment_floor || '',
          delivery_notes: (profileData as any).delivery_notes || '',
          avatar_emoji: (profileData as any).avatar_emoji || null,
        });
      }
      setIsLoadingProfile(false);
    };
    
    fetchProfile();
  }, [user]);

  // Load favorite dishes
  useEffect(() => {
    if (favorites.length === 0) {
      setFavoriteDishes([]);
      return;
    }
    
    const fetchFavoriteDishes = async () => {
      const { data } = await supabase
        .from('dishes')
        .select('id, name_it, name_en, price, image_url')
        .in('id', favorites);
      
      if (data) {
        setFavoriteDishes(data);
      }
    };
    
    fetchFavoriteDishes();
  }, [favorites]);

  // Auto-save profile changes
  const autoSave = useCallback(async (updates: Partial<ProfileData>) => {
    if (!user) return;
    try {
      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('user_id', user.id);
      if (error) throw error;
    } catch (error) {
      console.error('Auto-save error:', error);
    }
  }, [user]);

  // Handle profile changes
  const handleProfileChange = useCallback((field: keyof ProfileData, value: string | boolean) => {
    setProfile(prev => {
      const updated = { ...prev, [field]: value };
      if (typeof value === 'boolean') {
        autoSave({ [field]: value });
        toast.success(language === 'it' ? 'Salvato!' : 'Saved!', { duration: 1500 });
      }
      return updated;
    });
  }, [autoSave, language]);

  // Save text fields on blur
  const handleTextBlur = useCallback((field: keyof ProfileData) => {
    autoSave({ [field]: profile[field] });
  }, [autoSave, profile]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/?skipOnboarding=true');
    toast.success(language === 'it' ? 'Disconnesso' : 'Logged out');
  };

  const handleClearFavorites = () => {
    clearFavorites();
    toast.success(language === 'it' ? 'Preferiti cancellati' : 'Favorites cleared');
  };

  const handleRedoOnboarding = () => {
    navigate('/quiz');
  };

  const handleEnablePushNotifications = async () => {
    const granted = await requestPermission();
    if (granted) {
      handleProfileChange('push_notifications', true);
    }
  };

  const handleAvatarChange = (emoji: string) => {
    setProfile(prev => ({ ...prev, avatar_emoji: emoji }));
  };

  // Translations
  const t = {
    title: getTranslation(language, 'myProfile'),
    personalInfo: getTranslation(language, 'personalInfo'),
    name: getTranslation(language, 'yourName'),
    phone: getTranslation(language, 'phone'),
    notifications: getTranslation(language, 'notifications'),
    pushNotifications: getTranslation(language, 'pushNotifications'),
    whatsappNotifications: getTranslation(language, 'whatsappNotifications'),
    preferences: getTranslation(language, 'preferences'),
    favorites: getTranslation(language, 'favorites'),
    logout: getTranslation(language, 'logout'),
    loginRequired: getTranslation(language, 'loginRequired'),
    login: getTranslation(language, 'login'),
    onboardingPrefs: getTranslation(language, 'quizPreferences'),
    noOnboarding: getTranslation(language, 'noOnboarding'),
    redoOnboarding: getTranslation(language, 'retakeQuiz'),
    reservations: getTranslation(language, 'reservations'),
  };
  
  const isLoading = authLoading || isLoadingProfile || prefsLoading;

  // Stats
  const upcomingReservations = reservations.filter(r => 
    r.status !== 'cancelled' && 
    r.status !== 'rejected' && 
    r.status !== 'completed' && 
    new Date(r.reservation_date) >= new Date()
  );
  
  const activeTakeawayOrders = takeawayOrders.filter(o => 
    ['pending', 'accepted', 'ready', 'delivering'].includes(o.status)
  );

  const totalOrders = reservations.length + takeawayOrders.length;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background overflow-x-hidden pb-24">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur-sm border-b border-border/50">
        <div className="flex items-center gap-4 p-4">
          <BackButton onClick={() => navigate('/?skipOnboarding=true')} />
          <h1 className="text-lg font-bold">{t.title}</h1>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {!user ? (
          /* Login CTA */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-12"
          >
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-accent/10 flex items-center justify-center">
              <User className="w-10 h-10 text-accent" />
            </div>
            <h2 className="text-xl font-bold mb-2">{t.loginRequired}</h2>
            <p className="text-muted-foreground text-sm mb-6">
              {language === 'it' ? 'Salva i tuoi preferiti e prenota facilmente' : 'Save favorites and book easily'}
            </p>
            <Button onClick={() => navigate('/auth')} size="lg" className="gap-2 px-8">
              <Phone className="w-4 h-4" />
              {t.login}
            </Button>
          </motion.div>
        ) : (
          <>
            {/* Profile Header with Avatar */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-4"
            >
              <ProfileAvatar
                userId={user.id}
                currentEmoji={profile.avatar_emoji}
                onEmojiChange={handleAvatarChange}
                size="lg"
              />
              <div className="flex-1 min-w-0">
                <h2 className="text-xl font-bold truncate">
                  {profile.display_name || (language === 'it' ? 'Ciao!' : 'Hello!')}
                </h2>
                <p className="text-sm text-muted-foreground truncate">{profile.phone}</p>
                {loyaltyActive && points && (
                  <div className="flex items-center gap-2 mt-1">
                    <Star className="w-4 h-4 text-accent" />
                    <span className="text-sm font-medium text-accent">{points.total_points} punti</span>
                    <span className="text-xs text-muted-foreground capitalize">• {points.tier}</span>
                  </div>
                )}
              </div>
            </motion.div>

            {/* Quick Stats - Compact */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 }}
              className="flex items-center gap-2 overflow-x-auto pb-1"
            >
              <button 
                onClick={() => setActiveTab('orders')}
                className="flex items-center gap-2 px-3 py-2 bg-card border border-border/50 rounded-full hover:bg-accent/5 transition-colors shrink-0"
              >
                <CalendarDays className="w-4 h-4 text-accent" />
                <span className="text-sm font-medium">{upcomingReservations.length}</span>
                <span className="text-xs text-muted-foreground">
                  {getTranslation(language, 'reservations')}
                </span>
              </button>
              <button 
                onClick={() => setActiveTab('orders')}
                className="flex items-center gap-2 px-3 py-2 bg-card border border-border/50 rounded-full hover:bg-accent/5 transition-colors shrink-0"
              >
                <ShoppingBag className="w-4 h-4 text-orange-500" />
                <span className="text-sm font-medium">{activeTakeawayOrders.length}</span>
                <span className="text-xs text-muted-foreground">
                  {language === 'it' ? 'Ordini' : 'Orders'}
                </span>
              </button>
              <button 
                onClick={() => setActiveTab('profile')}
                className="flex items-center gap-2 px-3 py-2 bg-card border border-border/50 rounded-full hover:bg-accent/5 transition-colors shrink-0"
              >
                <Heart className="w-4 h-4 text-red-500" />
                <span className="text-sm font-medium">{favoritesCount}</span>
                <span className="text-xs text-muted-foreground">
                  {getTranslation(language, 'favorites')}
                </span>
              </button>
            </motion.div>

            {/* Tab Navigation */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <ProfileTabs
                activeTab={activeTab}
                onTabChange={setActiveTab}
                pointsCount={points?.total_points || 0}
                ordersCount={totalOrders}
              />
            </motion.div>

            {/* Tab Content */}
            <AnimatePresence mode="wait">
              {activeTab === 'profile' && (
                <motion.div
                  key="profile"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-4"
                >
                  {/* Personal Info */}
                  <div className="bg-card border border-border/50 rounded-2xl p-4 space-y-4">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
                        <User className="w-5 h-5 text-blue-500" />
                      </div>
                      <h3 className="font-semibold">{t.personalInfo}</h3>
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">{t.name}</Label>
                      <Input
                        value={profile.display_name}
                        onChange={(e) => setProfile({ ...profile, display_name: e.target.value })}
                        onBlur={() => handleTextBlur('display_name')}
                        placeholder={language === 'it' ? 'Il tuo nome' : 'Your name'}
                        className="bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-xs text-muted-foreground">{t.phone}</Label>
                      <Input
                        value={profile.phone}
                        onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                        onBlur={() => handleTextBlur('phone')}
                        placeholder="+39 xxx xxx xxxx"
                        className="bg-background"
                      />
                    </div>
                  </div>

                  {/* Delivery Addresses */}
                  <div ref={addressSectionRef} className="bg-card border border-border/50 rounded-2xl p-4">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-green-500" />
                      </div>
                      <h3 className="font-semibold">
                        {language === 'it' ? 'Indirizzi di consegna' : 'Delivery Addresses'}
                      </h3>
                    </div>
                    
                    <DeliveryAddresses userId={user.id} />
                  </div>

                  {/* Favorites */}
                  <div className="bg-card border border-border/50 rounded-2xl p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
                          <Heart className="w-5 h-5 text-red-500" />
                        </div>
                        <div>
                          <h3 className="font-semibold">{t.favorites}</h3>
                          <p className="text-xs text-muted-foreground">
                            {favoritesCount} {language === 'it' ? 'piatti salvati' : 'saved dishes'}
                          </p>
                        </div>
                      </div>
                      {favoritesCount > 0 && (
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={handleClearFavorites}
                          className="text-red-500 hover:bg-red-500/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                    
                    {favoriteDishes.length === 0 ? (
                      <p className="text-muted-foreground text-sm text-center py-4">
                        {language === 'it' ? 'Nessun piatto salvato' : 'No saved dishes'}
                      </p>
                    ) : (
                      <div className="space-y-2 max-h-48 overflow-y-auto">
                        {favoriteDishes.map(dish => (
                          <div 
                            key={dish.id}
                            className="flex items-center gap-3 p-2 rounded-xl bg-background"
                          >
                            {dish.image_url ? (
                              <img 
                                src={dish.image_url} 
                                alt={language === 'it' ? dish.name_it : dish.name_en}
                                className="w-12 h-12 rounded-lg object-cover"
                              />
                            ) : (
                              <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center">
                                <span className="text-lg">🍽️</span>
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="font-medium truncate text-sm">
                                {language === 'it' ? dish.name_it : dish.name_en}
                              </p>
                              <p className="text-xs text-accent">€{dish.price.toFixed(2)}</p>
                            </div>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => toggleFavorite(dish.id)}
                              className="shrink-0 h-8 w-8"
                            >
                              <X className="w-4 h-4 text-muted-foreground" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Quiz Preferences */}
                  <div className="bg-card border border-border/50 rounded-2xl p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent/20 to-accent/10 flex items-center justify-center">
                        <Sparkles className="w-5 h-5 text-accent" />
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold">{t.onboardingPrefs}</p>
                        {hasPreferences && preferences ? (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {Object.entries(preferences)
                              .filter(([key]) => key !== 'welcome')
                              .slice(0, 3)
                              .map(([key, pref], idx) => (
                                <span 
                                  key={idx}
                                  className="text-xs px-2 py-0.5 rounded-full bg-accent/10 text-accent"
                                >
                                  {pref.emoji}
                                </span>
                              ))}
                          </div>
                        ) : (
                          <p className="text-xs text-muted-foreground">{t.noOnboarding}</p>
                        )}
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={handleRedoOnboarding}
                        className="shrink-0 gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        {t.redoOnboarding}
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'orders' && (
                <motion.div
                  key="orders"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-4"
                >
                  {/* Unified Order History */}
                  <div className="bg-card border border-border/50 rounded-2xl p-4">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
                        <CalendarDays className="w-5 h-5 text-accent" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{language === 'it' ? 'I miei ordini' : 'My Orders'}</h3>
                        <p className="text-xs text-muted-foreground">
                          {totalOrders} {language === 'it' ? 'totali' : 'total'}
                        </p>
                      </div>
                    </div>
                    
                    <UnifiedOrderHistory 
                      reservations={reservations}
                      takeawayOrders={takeawayOrders}
                    />
                  </div>
                </motion.div>
              )}

              {activeTab === 'points' && (
                <motion.div
                  key="points"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-4"
                >
                  {loyaltyActive ? (
                    <>
                      {/* Gamification Card */}
                      <GamificationCard />
                      
                      {/* Points History */}
                      <div className="bg-card border border-border/50 rounded-2xl p-4">
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
                            <Star className="w-5 h-5 text-accent" />
                          </div>
                          <h3 className="font-semibold">
                            {language === 'it' ? 'Cronologia punti' : 'Points History'}
                          </h3>
                        </div>
                        
                        <PointsHistory />
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-12">
                      <Star className="w-16 h-16 mx-auto mb-4 text-muted-foreground/30" />
                      <h3 className="font-semibold mb-2">
                        {language === 'it' ? 'Programma fedeltà' : 'Loyalty Program'}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {language === 'it' 
                          ? 'Il programma fedeltà non è attivo al momento' 
                          : 'The loyalty program is not active at the moment'}
                      </p>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'settings' && (
                <motion.div
                  key="settings"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="space-y-4"
                >
                  {/* Notifications */}
                  <div className="bg-card border border-border/50 rounded-2xl p-4 space-y-4">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
                        <Bell className="w-5 h-5 text-purple-500" />
                      </div>
                      <h3 className="font-semibold">{t.notifications}</h3>
                    </div>
                    
                    {/* Browser Push Permission */}
                    {pushSupported && !pushEnabled && (
                      <motion.button
                        onClick={handleEnablePushNotifications}
                        className="w-full p-3 rounded-xl bg-accent/10 border border-accent/20 text-left flex items-center gap-3 hover:bg-accent/20 transition-colors"
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                      >
                        <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                          <Bell className="w-4 h-4 text-accent" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-foreground">
                            {language === 'it' ? 'Attiva notifiche browser' : 'Enable browser notifications'}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {language === 'it' ? 'Ricevi avvisi in tempo reale' : 'Get real-time alerts'}
                          </p>
                        </div>
                        <Sparkles className="w-4 h-4 text-accent" />
                      </motion.button>
                    )}
                    
                    {pushSupported && pushEnabled && (
                      <div className="p-3 rounded-xl bg-green-500/10 border border-green-500/20 flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                          <Bell className="w-4 h-4 text-green-500" />
                        </div>
                        <p className="text-sm text-green-600 dark:text-green-400">
                          {language === 'it' ? '✓ Notifiche browser attive' : '✓ Browser notifications enabled'}
                        </p>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between p-3 rounded-xl bg-background">
                      <div className="flex items-center gap-3">
                        <Bell className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm">{t.pushNotifications}</span>
                      </div>
                      <Switch
                        checked={profile.push_notifications}
                        onCheckedChange={(checked) => handleProfileChange('push_notifications', checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-xl bg-background">
                      <div className="flex items-center gap-3">
                        <MessageCircle className="w-4 h-4 text-green-500" />
                        <span className="text-sm">{t.whatsappNotifications}</span>
                      </div>
                      <Switch
                        checked={profile.whatsapp_notifications}
                        onCheckedChange={(checked) => handleProfileChange('whatsapp_notifications', checked)}
                      />
                    </div>
                  </div>

                  {/* Language */}
                  <div className="bg-card border border-border/50 rounded-2xl p-4">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
                        <Globe className="w-5 h-5 text-blue-500" />
                      </div>
                      <h3 className="font-semibold">{t.preferences}</h3>
                    </div>
                    
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className="bg-background">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="it">🇮🇹 Italiano</SelectItem>
                        <SelectItem value="en">🇬🇧 English</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Logout */}
                  <Button 
                    variant="outline" 
                    onClick={handleLogout} 
                    className="w-full gap-2 text-muted-foreground hover:text-red-500 hover:border-red-500/30"
                  >
                    <LogOut className="w-4 h-4" />
                    {t.logout}
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}

        {/* Footer */}
        <div className="pt-8">
          <Footer />
        </div>
      </div>
    </div>
  );
}
