import { useState } from 'react';
import { Search, X, SlidersHorizontal } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAllergens } from '@/hooks/useAllergens';
import { useDietTypes } from '@/hooks/useDietTypes';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Slider } from '@/components/ui/slider';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

export interface FilterState {
  search: string;
  allergens: string[];
  dietTypes: string[];
  priceRange: [number, number];
}

interface SearchFilterBarProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  maxPrice?: number;
}

export function SearchFilterBar({ filters, onFiltersChange, maxPrice = 50 }: SearchFilterBarProps) {
  const { currentLanguage, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  
  // Fetch allergens and diet types from database
  const { allergens: dbAllergens, isLoading: allergensLoading } = useAllergens();
  const { dietTypes: dbDietTypes, isLoading: dietTypesLoading } = useDietTypes();

  const hasActiveFilters = 
    filters.allergens.length > 0 ||
    filters.dietTypes.length > 0 ||
    filters.priceRange[1] < maxPrice;

  const clearFilters = () => {
    onFiltersChange({
      ...filters,
      allergens: [],
      dietTypes: [],
      priceRange: [0, maxPrice],
    });
  };

  const toggleAllergen = (code: string) => {
    const newAllergens = filters.allergens.includes(code)
      ? filters.allergens.filter(a => a !== code)
      : [...filters.allergens, code];
    onFiltersChange({ ...filters, allergens: newAllergens });
  };

  const toggleDiet = (code: string) => {
    const newDiets = filters.dietTypes.includes(code)
      ? filters.dietTypes.filter(d => d !== code)
      : [...filters.dietTypes, code];
    onFiltersChange({ ...filters, dietTypes: newDiets });
  };

  // Helper to get localized allergen name
  const getAllergenName = (code: string) => {
    const allergen = dbAllergens.find(a => a.code === code);
    if (!allergen) return code;
    return currentLanguage === 'it' ? allergen.name_it : allergen.name_en;
  };

  // Helper to get localized diet type name
  const getDietName = (code: string) => {
    const diet = dbDietTypes.find(d => d.code === code);
    if (!diet) return code;
    return currentLanguage === 'it' ? diet.name.it : diet.name.en;
  };

  return (
    <div className="space-y-3">
      {/* Search Bar */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder={t('search')}
            value={filters.search}
            onChange={(e) => onFiltersChange({ ...filters, search: e.target.value })}
            className="pl-11 pr-10 h-12 rounded-full bg-secondary border-0 focus-visible:ring-1 focus-visible:ring-primary"
          />
          {filters.search && (
            <button
              onClick={() => onFiltersChange({ ...filters, search: '' })}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Filter Button */}
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button 
              variant="secondary" 
              size="icon" 
              className={cn(
                "h-12 w-12 rounded-full relative flex-shrink-0",
                hasActiveFilters && "bg-primary text-primary-foreground hover:bg-primary/90"
              )}
            >
              <SlidersHorizontal className="h-5 w-5" />
              {hasActiveFilters && (
                <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-accent text-accent-foreground text-[10px] flex items-center justify-center font-medium">
                  {filters.allergens.length + filters.dietTypes.length}
                </span>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent className="w-full sm:max-w-md overflow-y-auto" side="right">
            <SheetHeader>
              <SheetTitle className="text-2xl font-bold">{t('filters')}</SheetTitle>
            </SheetHeader>

            <div className="mt-8 space-y-8">
              {/* Diet Types */}
              <div className="space-y-4">
                <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">
                  {t('dietaryInfo')}
                </h4>
                {dietTypesLoading ? (
                  <div className="grid grid-cols-2 gap-3">
                    {[1, 2, 3, 4].map(i => (
                      <Skeleton key={i} className="h-16 rounded-xl" />
                    ))}
                  </div>
                ) : dbDietTypes.length > 0 ? (
                  <div className="grid grid-cols-2 gap-3">
                    {dbDietTypes.map((diet) => (
                      <button
                        key={diet.code}
                        onClick={() => toggleDiet(diet.code)}
                        className={cn(
                          "flex items-center gap-3 p-4 rounded-xl border transition-all text-left",
                          filters.dietTypes.includes(diet.code)
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/50"
                        )}
                      >
                        <span className="text-xl">{diet.icon}</span>
                        <span className="text-sm font-medium">
                          {currentLanguage === 'it' ? diet.name.it : diet.name.en}
                        </span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    {currentLanguage === 'it' ? 'Nessun tipo di dieta disponibile' : 'No diet types available'}
                  </p>
                )}
              </div>

              {/* Price Range */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">
                    {t('price')}
                  </h4>
                  <span className="text-sm font-medium">
                    €{filters.priceRange[0]} - €{filters.priceRange[1]}
                  </span>
                </div>
                <Slider
                  value={filters.priceRange}
                  onValueChange={(value) => onFiltersChange({ ...filters, priceRange: value as [number, number] })}
                  min={0}
                  max={maxPrice}
                  step={1}
                  className="py-4"
                />
              </div>

              {/* Allergens */}
              <div className="space-y-4">
                <h4 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground">
                  {t('allergens')} ({currentLanguage === 'it' ? 'Escludi' : 'Exclude'})
                </h4>
                {allergensLoading ? (
                  <div className="grid grid-cols-2 gap-2">
                    {[1, 2, 3, 4, 5, 6].map(i => (
                      <Skeleton key={i} className="h-12 rounded-xl" />
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    {dbAllergens.map((allergen) => (
                      <button
                        key={allergen.code}
                        onClick={() => toggleAllergen(allergen.code)}
                        className={cn(
                          "flex items-center gap-2 p-3 rounded-xl border text-left transition-all",
                          filters.allergens.includes(allergen.code)
                            ? "border-destructive bg-destructive/5 text-destructive"
                            : "border-border hover:border-destructive/50"
                        )}
                      >
                        <span>{allergen.icon}</span>
                        <span className="text-xs font-medium truncate">
                          {currentLanguage === 'it' ? allergen.name_it : allergen.name_en}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Clear Filters */}
              {hasActiveFilters && (
                <Button
                  variant="outline"
                  onClick={clearFilters}
                  className="w-full rounded-full"
                >
                  {t('clearFilters')}
                </Button>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-2 animate-fade-in">
          {filters.dietTypes.map((code) => {
            const diet = dbDietTypes.find(d => d.code === code);
            return diet ? (
              <Badge
                key={code}
                variant="secondary"
                className="gap-1.5 cursor-pointer hover:bg-destructive/10 rounded-full px-3 py-1"
                onClick={() => toggleDiet(code)}
              >
                {diet.icon} {getDietName(code)}
                <X className="h-3 w-3" />
              </Badge>
            ) : null;
          })}
          {filters.allergens.map((code) => {
            const allergen = dbAllergens.find(a => a.code === code);
            return allergen ? (
              <Badge
                key={code}
                variant="destructive"
                className="gap-1.5 cursor-pointer rounded-full px-3 py-1"
                onClick={() => toggleAllergen(code)}
              >
                {allergen.icon} No {getAllergenName(code)}
                <X className="h-3 w-3" />
              </Badge>
            ) : null;
          })}
        </div>
      )}
    </div>
  );
}
