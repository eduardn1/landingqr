import { useMemo, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Phone, Mail, MapPin, Instagram, Facebook, MessageCircle, Download, Smartphone, Share2, X, RefreshCw, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRestaurantConfig, type BusinessHour } from '@/hooks/useRestaurantConfig';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useAccentGradient } from '@/components/ui/AccentGradient';

// Install App Badge with modal instructions
function InstallAppBadge({ 
  deferredPrompt, 
  onInstallClick 
}: { 
  deferredPrompt: any; 
  onInstallClick: () => void;
}) {
  const [showModal, setShowModal] = useState(false);
  const { backgroundStyle, hasGradient } = useAccentGradient();

  const handleClick = () => {
    if (deferredPrompt) {
      onInstallClick();
    } else {
      setShowModal(true);
    }
  };

  return (
    <>
      <motion.button
        onClick={handleClick}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="group relative w-full overflow-hidden rounded-xl p-[1px]"
        style={hasGradient ? backgroundStyle : undefined}
      >
        {/* Fallback border if no gradient */}
        {!hasGradient && (
          <div className="absolute inset-0 bg-accent/30 rounded-xl" />
        )}
        
        {/* Glow effect on hover */}
        <div 
          className="absolute inset-0 opacity-0 group-hover:opacity-60 transition-opacity duration-500 blur-lg"
          style={backgroundStyle}
        />
        
        <div className="relative flex items-center justify-center gap-3 py-3 px-4 rounded-[11px] bg-card/95 backdrop-blur-sm">
          {/* Animated icon with gradient */}
          <div className="relative">
            <div 
              className="absolute inset-0 rounded-full blur-md opacity-40 group-hover:opacity-60 transition-opacity"
              style={backgroundStyle}
            />
            <div 
              className="relative w-8 h-8 rounded-full flex items-center justify-center shadow-lg"
              style={backgroundStyle}
            >
              <Download className="w-4 h-4 text-white group-hover:animate-bounce" />
            </div>
          </div>
          
          <div className="flex flex-col items-start">
            <span className="text-sm font-semibold text-foreground">Installa l'App</span>
            <span className="text-[10px] text-muted-foreground">Accesso rapido dalla home</span>
          </div>
          
          {/* Arrow indicator */}
          <svg 
            className="w-4 h-4 text-muted-foreground group-hover:text-accent group-hover:translate-x-0.5 transition-all ml-auto" 
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </motion.button>

      {/* Install Instructions Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-sm bg-card border border-border rounded-2xl p-5 shadow-xl"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-accent" />
                  <h3 className="font-semibold text-foreground">Installa l'App</h3>
                </div>
                <button
                  onClick={() => setShowModal(false)}
                  className="p-1.5 rounded-full hover:bg-secondary transition-colors"
                >
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>

              <p className="text-sm text-muted-foreground mb-4">
                Aggiungi l'app alla schermata home per un accesso rapido e un'esperienza migliore.
              </p>

              <div className="space-y-3">
                {/* iOS Instructions */}
                <div className="p-3 rounded-xl bg-secondary/50 border border-border/30">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">📱</span>
                    <span className="font-medium text-sm text-foreground">iPhone / iPad</span>
                  </div>
                  <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
                    <li>Tocca l'icona <Share2 className="w-3 h-3 inline mx-0.5" /> (Condividi)</li>
                    <li>Scorri e seleziona "Aggiungi a Home"</li>
                    <li>Tocca "Aggiungi" in alto a destra</li>
                  </ol>
                </div>

                {/* Android Instructions */}
                <div className="p-3 rounded-xl bg-secondary/50 border border-border/30">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">🤖</span>
                    <span className="font-medium text-sm text-foreground">Android</span>
                  </div>
                  <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
                    <li>Tocca il menu ⋮ (tre puntini)</li>
                    <li>Seleziona "Installa app" o "Aggiungi a Home"</li>
                    <li>Conferma l'installazione</li>
                  </ol>
                </div>
              </div>

              <Button
                onClick={() => setShowModal(false)}
                className="w-full mt-4"
                size="sm"
              >
                Ho capito
              </Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

// TikTok icon component
const TikTokIcon = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
  </svg>
);

// Helper to format ranges for display
const formatRanges = (hours: BusinessHour): string => {
  if (hours.closed) return 'Chiuso';
  
  if (hours.ranges && hours.ranges.length > 0) {
    return hours.ranges.map(r => `${r.open} - ${r.close}`).join(' / ');
  }
  
  if (hours.open && hours.close) {
    return `${hours.open} - ${hours.close}`;
  }
  
  return 'Chiuso';
};

// Check if currently open based on ranges
const isCurrentlyOpen = (hours: BusinessHour | null): boolean => {
  if (!hours || hours.closed) return false;
  
  const now = new Date();
  const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
  
  if (hours.ranges && hours.ranges.length > 0) {
    return hours.ranges.some(r => currentTime >= r.open && currentTime <= r.close);
  }
  
  if (hours.open && hours.close) {
    return currentTime >= hours.open && currentTime <= hours.close;
  }
  
  return false;
};

// Get next opening time
const getNextOpeningTime = (todayHours: BusinessHour | null, allHours: BusinessHour[] | null): string | null => {
  if (!allHours) return null;
  
  const now = new Date();
  const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const todayIndex = now.getDay();
  
  if (todayHours && !todayHours.closed) {
    const ranges = todayHours.ranges || (todayHours.open && todayHours.close ? [{ open: todayHours.open, close: todayHours.close }] : []);
    for (const range of ranges) {
      if (range.open > currentTime) {
        return range.open;
      }
    }
  }
  
  for (let i = 1; i <= 7; i++) {
    const nextDayIndex = (todayIndex + i) % 7;
    const nextDay = days[nextDayIndex];
    const nextDayHours = allHours.find(h => h.day === nextDay);
    
    if (nextDayHours && !nextDayHours.closed) {
      const ranges = nextDayHours.ranges || (nextDayHours.open && nextDayHours.close ? [{ open: nextDayHours.open, close: nextDayHours.close }] : []);
      if (ranges.length > 0) {
        const dayNames: Record<string, string> = {
          monday: 'Lun', tuesday: 'Mar', wednesday: 'Mer', thursday: 'Gio',
          friday: 'Ven', saturday: 'Sab', sunday: 'Dom'
        };
        if (i === 1) {
          return `domani ${ranges[0].open}`;
        }
        return `${dayNames[nextDay]} ${ranges[0].open}`;
      }
    }
  }
  
  return null;
};

interface RestaurantInfoCardProps {
  onResetQuiz?: () => void;
  hasQuizAnswers?: boolean;
}

export function RestaurantInfoCard({ onResetQuiz, hasQuizAnswers }: RestaurantInfoCardProps = {}) {
  const { t, currentLanguage } = useLanguage();
  const { config, isLoading } = useRestaurantConfig();
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const todayIndex = new Date().getDay();
  const today = days[todayIndex];
  
  // Get today's hours from config
  const todayHours = useMemo(() => {
    if (!config?.business_hours) return null;
    const hours = config.business_hours.find((h: BusinessHour) => h.day === today);
    return hours || null;
  }, [config?.business_hours, today]);
  
  const isOpen = useMemo(() => {
    return isCurrentlyOpen(todayHours);
  }, [todayHours]);

  // PWA install prompt
  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handler);
    
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setIsInstalled(true);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setIsInstalled(true);
    }
    setDeferredPrompt(null);
  };

  if (isLoading) {
    return (
      <div className="grid lg:grid-cols-2 gap-4">
        <div className="space-y-4">
          <Skeleton className="h-24 rounded-2xl" />
          <div className="grid grid-cols-2 gap-2">
            <Skeleton className="h-16 rounded-xl" />
            <Skeleton className="h-16 rounded-xl" />
          </div>
        </div>
        <Skeleton className="h-48 rounded-2xl" />
      </div>
    );
  }

  if (!config) return null;

  const openStatus = isOpen;
  const hasSocials = config.instagram_url || config.facebook_url || config.tiktok_url;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="grid lg:grid-cols-2 gap-4"
    >
      {/* Left Column - Contact Info */}
      <div className="space-y-3">
        {/* Logo & Status */}
        <div className="p-4 rounded-2xl bg-secondary/30 border border-border/30 space-y-3">
          <div className="flex items-center gap-3">
            {config.logo_url && (
              <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden">
                <img 
                  src={config.logo_url} 
                  alt={config.name} 
                  className="w-10 h-10 object-contain" 
                />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-semibold text-foreground text-lg">{config.name}</h3>
                <span className={cn(
                  "inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full",
                  openStatus 
                    ? "bg-green-500/20 text-green-600 dark:text-green-400" 
                    : "bg-red-500/20 text-red-600 dark:text-red-400"
                )}>
                  <span className={cn(
                    "w-1.5 h-1.5 rounded-full",
                    openStatus ? "bg-green-500 dark:bg-green-400" : "bg-red-500 dark:bg-red-400"
                  )} />
                  {openStatus ? t('openNow') : t('closed')}
                </span>
              </div>
              {!openStatus && (() => {
                const nextOpen = getNextOpeningTime(todayHours, config.business_hours);
                return nextOpen ? (
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Apre alle {nextOpen}
                  </p>
                ) : null;
              })()}
            </div>
          </div>
          
          {config.tagline && (config.tagline as any)[currentLanguage] && (
            <p className="text-sm text-muted-foreground italic">
              "{(config.tagline as any)[currentLanguage]}"
            </p>
          )}
        </div>

        {/* Contact Grid */}
        <div className="grid grid-cols-2 gap-2">
          {config.phone && (
            <a 
              href={`tel:${config.phone}`}
              className="group flex items-center gap-2 p-3 rounded-xl bg-foreground/5 border border-border/30 hover:bg-foreground/10 transition-colors"
            >
              <div className="w-8 h-8 rounded-lg bg-foreground/5 flex items-center justify-center flex-shrink-0 group-hover:bg-green-500/10 transition-colors">
                <Phone className="w-4 h-4 text-muted-foreground group-hover:text-green-500 transition-colors" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{t('phone')}</p>
                <p className="text-xs font-medium text-foreground truncate">{config.phone}</p>
              </div>
            </a>
          )}

          {config.whatsapp && (
            <a 
              href={`https://wa.me/${config.whatsapp.replace(/[^0-9]/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-2 p-3 rounded-xl bg-foreground/5 border border-border/30 hover:bg-foreground/10 transition-colors"
            >
              <div className="w-8 h-8 rounded-lg bg-foreground/5 flex items-center justify-center flex-shrink-0 group-hover:bg-green-500/10 transition-colors">
                <MessageCircle className="w-4 h-4 text-muted-foreground group-hover:text-green-500 transition-colors" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">WhatsApp</p>
                <p className="text-xs font-medium text-foreground truncate">Scrivici</p>
              </div>
            </a>
          )}

          {config.email && (
            <a 
              href={`mailto:${config.email}`}
              className="group flex items-center gap-2 p-3 rounded-xl bg-foreground/5 border border-border/30 hover:bg-foreground/10 transition-colors"
            >
              <div className="w-8 h-8 rounded-lg bg-foreground/5 flex items-center justify-center flex-shrink-0 group-hover:bg-green-500/10 transition-colors">
                <Mail className="w-4 h-4 text-muted-foreground group-hover:text-green-500 transition-colors" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{t('email')}</p>
                <p className="text-xs font-medium text-foreground truncate">{config.email}</p>
              </div>
            </a>
          )}

          {config.address && (
            <a 
              href={config.google_maps_url || `https://maps.google.com/?q=${encodeURIComponent(`${config.address}, ${config.city}`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-2 p-3 rounded-xl bg-foreground/5 border border-border/30 hover:bg-foreground/10 transition-colors"
            >
              <div className="w-8 h-8 rounded-lg bg-foreground/5 flex items-center justify-center flex-shrink-0 group-hover:bg-green-500/10 transition-colors">
                <MapPin className="w-4 h-4 text-muted-foreground group-hover:text-green-500 transition-colors" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Indirizzo</p>
                <p className="text-xs font-medium text-foreground truncate">{config.address}{config.city ? `, ${config.city}` : ''}</p>
              </div>
            </a>
          )}
        </div>

        {/* Hours */}
        {config.business_hours && config.business_hours.length > 0 && (
          <details className="group rounded-xl bg-foreground/5 border border-border/30 overflow-hidden">
            <summary className="flex items-center gap-3 p-3 cursor-pointer list-none hover:bg-foreground/10 transition-colors">
              <div className="w-8 h-8 rounded-lg bg-foreground/5 flex items-center justify-center flex-shrink-0">
                <Clock className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{t('hours')}</p>
                <p className="text-xs font-medium text-foreground">
                  {t('today')}: {todayHours ? formatRanges(todayHours) : 'Chiuso'}
                </p>
              </div>
              <svg className="w-4 h-4 text-muted-foreground transition-transform group-open:rotate-180 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </summary>
            <div className="px-3 pb-3 pt-1 space-y-1 border-t border-border/20 mt-1">
              {config.business_hours.map((hours: BusinessHour) => {
                const dayNames: Record<string, string> = {
                  monday: 'Lunedì',
                  tuesday: 'Martedì',
                  wednesday: 'Mercoledì',
                  thursday: 'Giovedì',
                  friday: 'Venerdì',
                  saturday: 'Sabato',
                  sunday: 'Domenica',
                };
                return (
                  <div key={hours.day} className="flex justify-between text-xs py-0.5">
                    <span className={cn(
                      "capitalize",
                      hours.day === today ? "text-foreground font-medium" : "text-muted-foreground"
                    )}>
                      {dayNames[hours.day] || hours.day}
                    </span>
                    <span className={cn(
                      hours.day === today ? "text-foreground font-medium" : "text-muted-foreground"
                    )}>
                      {formatRanges(hours)}
                    </span>
                  </div>
                );
              })}
            </div>
          </details>
        )}
      </div>

      {/* Right Column - Social + Tips + PWA */}
      <div className="space-y-3">
        {/* Social Links - Centered on mobile */}
        {hasSocials && (
          <div className="p-4 rounded-2xl bg-foreground/5 border border-border/30">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-3 text-center">
              Seguici sui Social
            </p>
            <div className="flex items-center justify-center gap-6">
              {config.instagram_url && (
                <a 
                  href={config.instagram_url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex flex-col items-center gap-1 text-muted-foreground hover:text-foreground transition-colors group"
                >
                  <div className="w-10 h-10 rounded-full bg-foreground/5 flex items-center justify-center group-hover:bg-foreground/10 transition-colors">
                    <Instagram className="w-5 h-5" />
                  </div>
                  <span className="text-[10px]">Instagram</span>
                </a>
              )}
              {config.facebook_url && (
                <a 
                  href={config.facebook_url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex flex-col items-center gap-1 text-muted-foreground hover:text-foreground transition-colors group"
                >
                  <div className="w-10 h-10 rounded-full bg-foreground/5 flex items-center justify-center group-hover:bg-foreground/10 transition-colors">
                    <Facebook className="w-5 h-5" />
                  </div>
                  <span className="text-[10px]">Facebook</span>
                </a>
              )}
              {config.tiktok_url && (
                <a 
                  href={config.tiktok_url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex flex-col items-center gap-1 text-muted-foreground hover:text-foreground transition-colors group"
                >
                  <div className="w-10 h-10 rounded-full bg-foreground/5 flex items-center justify-center group-hover:bg-foreground/10 transition-colors">
                    <TikTokIcon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px]">TikTok</span>
                </a>
              )}
            </div>
          </div>
        )}

        {/* Quick Tip Card */}
        <div className="p-3 rounded-xl bg-secondary/30 border border-border/30">
          <p className="text-xs text-muted-foreground text-center">
            💡 Aggiungi ai preferiti i tuoi piatti del cuore toccando il cuoricino!
          </p>
        </div>

        {/* PWA Install Badge - Full width after tip */}
        {!isInstalled && (
          <InstallAppBadge deferredPrompt={deferredPrompt} onInstallClick={handleInstallClick} />
        )}

        {/* Installed Badge */}
        {isInstalled && (
          <div className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-green-500/10 border border-green-500/20 w-full">
            <Smartphone className="w-4 h-4 text-green-500" />
            <span className="text-xs font-medium text-green-600 dark:text-green-400">App Installata</span>
          </div>
        )}

        {/* Rifai il quiz button - inside info card after InstallApp */}
        {hasQuizAnswers && onResetQuiz && (
          <button
            onClick={onResetQuiz}
            className="w-full p-3 rounded-xl bg-foreground/[0.04] border border-foreground/[0.06] hover:bg-foreground/[0.08] hover:border-foreground/[0.12] transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-accent/15 flex items-center justify-center group-hover:scale-110 transition-transform">
                <RefreshCw className="w-4 h-4 text-accent" />
              </div>
              <div className="text-left flex-1">
                <p className="font-medium text-foreground text-sm">Rifai il quiz</p>
                <p className="text-[11px] text-muted-foreground">Aggiorna le tue preferenze</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
            </div>
          </button>
        )}
      </div>
    </motion.div>
  );
}