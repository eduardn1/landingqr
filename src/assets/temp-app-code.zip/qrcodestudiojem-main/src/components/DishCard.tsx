import { forwardRef, useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { allergens as allergensData, dietTypes, type Dish } from '@/lib/mockData';
import { cn } from '@/lib/utils';
import { Flame, Plus, Sparkles } from 'lucide-react';
import { ProgressiveImage } from '@/components/ui/ProgressiveImage';

interface DishCardProps {
  dish: Dish;
  onClick?: () => void;
  compact?: boolean;
  isRecommended?: boolean;
  isMoodMatch?: boolean;
}

export const DishCard = forwardRef<HTMLDivElement, DishCardProps>(
  function DishCard({ dish, onClick, compact, isRecommended, isMoodMatch }, ref) {
    const { currentLanguage, t } = useLanguage();
    const [imageError, setImageError] = useState(false);

    const formatPrice = (price: number) => {
      return new Intl.NumberFormat(currentLanguage, {
        style: 'currency',
        currency: dish.currency || 'EUR',
      }).format(price);
    };

    const renderSpicyLevel = () => {
      if (!dish.spicyLevel || dish.spicyLevel === 0) return null;
      return (
        <div className="flex items-center gap-0.5" title={t('spicyLevel')}>
          {[1, 2, 3].map((level) => (
            <Flame
              key={level}
              className={cn(
                "h-3 w-3",
                level <= dish.spicyLevel! ? "text-accent" : "text-muted-foreground/20"
              )}
              fill={level <= dish.spicyLevel! ? "currentColor" : "none"}
            />
          ))}
        </div>
      );
    };

    const getDietTags = () => {
      return dish.tags
        .map(tag => dietTypes.find(d => d.code === tag))
        .filter(Boolean)
        .slice(0, 2);
    };

    // Compact card for home grid
    if (compact) {
      return (
        <div
          ref={ref}
          onClick={onClick}
          className={cn(
            "overflow-hidden cursor-pointer group rounded-2xl bg-secondary/20 border border-border/30",
            !dish.isAvailable && "opacity-50"
          )}
        >
          <div className="relative aspect-square overflow-hidden bg-secondary/30 rounded-t-2xl">
            {dish.images && dish.images[0] && !imageError ? (
              <ProgressiveImage
                src={dish.images[0]}
                alt={getLocalizedContent(dish.name, currentLanguage)}
                aspectRatio="square"
                onError={() => setImageError(true)}
                className="transition-transform duration-500 group-hover:scale-105"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-muted-foreground/30">
                <span className="text-3xl">🍽️</span>
              </div>
            )}
            {isRecommended && !dish.badge && (
              <div className="absolute top-2 left-2 px-2 py-0.5 bg-gradient-to-r from-primary to-accent text-primary-foreground text-[9px] font-semibold rounded-full flex items-center gap-1 shadow-lg z-20">
                <Sparkles className="w-2.5 h-2.5" />
                Per te
              </div>
            )}
            {dish.badge && (
              <div className="absolute top-2 left-2 px-2 py-0.5 bg-accent text-accent-foreground text-[10px] font-semibold rounded-full z-20 shadow-md backdrop-blur-sm">
                {dish.badge}
              </div>
            )}
          </div>
          <div className="p-3 space-y-1">
            <h3 className="font-medium text-sm leading-tight text-foreground line-clamp-1">
              {getLocalizedContent(dish.name, currentLanguage)}
            </h3>
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-foreground/80">{formatPrice(dish.price)}</span>
              {renderSpicyLevel()}
            </div>
          </div>
        </div>
      );
    }

    // Full card for menu
    return (
      <div
        ref={ref}
        onClick={onClick}
        className={cn(
          "overflow-hidden cursor-pointer group relative rounded-2xl bg-secondary/20 border border-border/30",
          !dish.isAvailable && "opacity-50",
          isMoodMatch && "ring-2 ring-accent ring-offset-2 ring-offset-background"
        )}
      >
        {/* Image */}
        <div className="relative aspect-[4/3] overflow-hidden bg-secondary/30 rounded-t-2xl">
          {dish.images && dish.images[0] && !imageError ? (
            <ProgressiveImage
              src={dish.images[0]}
              alt={getLocalizedContent(dish.name, currentLanguage)}
              aspectRatio="4/3"
              onError={() => setImageError(true)}
              className="transition-transform duration-500 group-hover:scale-105"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground/30">
              <span className="text-4xl">🍽️</span>
            </div>
          )}
          {isRecommended && !dish.badge && (
            <div className="absolute top-3 left-3 px-2.5 py-1 bg-gradient-to-r from-primary to-accent text-primary-foreground text-xs font-semibold rounded-full flex items-center gap-1.5 shadow-lg z-20">
              <Sparkles className="w-3 h-3" />
              Per te
            </div>
          )}
          {dish.badge && (
            <div className="absolute top-3 left-3 px-2.5 py-1 bg-accent text-accent-foreground text-xs font-semibold rounded-full z-20 shadow-lg backdrop-blur-sm">
              {dish.badge}
            </div>
          )}
          <button className="absolute bottom-3 right-3 w-9 h-9 bg-background rounded-full flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-accent hover:text-accent-foreground z-20">
            <Plus className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-medium text-base leading-tight text-foreground">
              {getLocalizedContent(dish.name, currentLanguage)}
            </h3>
            <span className="text-base font-semibold text-foreground/90 flex-shrink-0">{formatPrice(dish.price)}</span>
          </div>

          <p className="text-xs text-muted-foreground line-clamp-2">
            {getLocalizedContent(dish.description, currentLanguage)}
          </p>

          <div className="flex flex-wrap items-center gap-2 pt-1">
            {renderSpicyLevel()}
            {getDietTags().map((diet) => (
              <span
                key={diet!.code}
                className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium bg-secondary/50 text-muted-foreground"
              >
                <span>{diet!.icon}</span>
              </span>
            ))}
          </div>
        </div>

        {!dish.isAvailable && (
          <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
            <span className="bg-foreground text-background px-3 py-1.5 rounded-full text-xs font-medium">
              Non disponibile
            </span>
          </div>
        )}
      </div>
    );
  }
);

DishCard.displayName = 'DishCard';
