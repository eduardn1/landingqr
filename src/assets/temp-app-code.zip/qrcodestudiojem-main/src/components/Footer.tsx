import { useState, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Code, Rocket, Globe, Phone, ArrowRight } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { openCookieSettings } from '@/components/client/CookieConsent';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';

const APP_VERSION = '1.0.1';

function StudioJEMCredits() {
  const [isExpanded, setIsExpanded] = useState(false);
  
  return (
    <div 
      className="relative inline-flex justify-center"
      onMouseEnter={() => setIsExpanded(true)}
      onMouseLeave={() => setIsExpanded(false)}
    >
      <div 
        className="relative overflow-hidden rounded-xl transition-all duration-300 cursor-pointer bg-card backdrop-blur-sm border border-border/20"
      >
        {/* Shimmer effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-foreground/5 to-transparent -translate-x-full animate-[shimmer_2.5s_infinite]" />
        
        {/* Collapsed state */}
        <div 
          className={`
            relative z-10 transition-all duration-300 overflow-hidden
            ${isExpanded ? 'max-h-0 opacity-0 py-0 px-0' : 'max-h-20 opacity-100 px-4 py-2.5'}
          `}
        >
          <div className="flex items-center justify-center gap-2 whitespace-nowrap">
            <Code className="w-4 h-4 flex-shrink-0 text-foreground" />
            <span className="text-sm font-medium text-muted-foreground">
              Sviluppato da
            </span>
            <span className="font-bold text-foreground">
              studiojem.it
            </span>
            <Rocket className="w-4 h-4 flex-shrink-0 text-accent" />
          </div>
        </div>
        
        {/* Expanded state */}
        <div 
          className={`
            relative z-10 transition-all duration-300 overflow-hidden
            ${isExpanded ? 'max-h-96 opacity-100 p-5' : 'max-h-0 opacity-0 p-0'}
          `}
        >
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0 w-14 h-14 rounded-xl flex items-center justify-center bg-secondary">
              <Code className="w-7 h-7 text-foreground" />
            </div>
            
            <div className="flex-1 min-w-0">
              <h4 className="font-bold text-lg flex items-center gap-2 text-foreground">
                studiojem.it
                <Rocket className="w-4 h-4 text-accent" />
              </h4>
              <p className="text-sm mt-0.5 text-muted-foreground">
                Web Development & Digital Solutions
              </p>
              
              <div className="flex flex-wrap gap-2 mt-3">
                <a 
                  href="https://studiojem.it" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 hover:scale-105 bg-accent text-accent-foreground hover:bg-accent/90"
                >
                  <Globe className="w-3.5 h-3.5" />
                  Visita il sito
                  <ArrowRight className="w-3 h-3" />
                </a>
                <a 
                  href="tel:+393533811359"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 hover:scale-105 bg-secondary text-foreground hover:bg-secondary/80 border border-border/20"
                >
                  <Phone className="w-3.5 h-3.5" />
                  Contattaci
                </a>
              </div>
            </div>
          </div>
          
          <p className="text-xs mt-3 text-center text-muted-foreground/60">
            Trasformiamo le tue idee in esperienze digitali ✨
          </p>
        </div>
      </div>
    </div>
  );
}

// Version badge with long-press admin access
function VersionBadge() {
  const navigate = useNavigate();
  const pressTimer = useRef<NodeJS.Timeout | null>(null);
  const [isPressing, setIsPressing] = useState(false);

  const handlePressStart = useCallback(() => {
    setIsPressing(true);
    pressTimer.current = setTimeout(() => {
      // Navigate to admin login after 2 seconds of holding
      navigate('/auth?mode=admin');
    }, 2000);
  }, [navigate]);

  const handlePressEnd = useCallback(() => {
    setIsPressing(false);
    if (pressTimer.current) {
      clearTimeout(pressTimer.current);
      pressTimer.current = null;
    }
  }, []);

  return (
    <button
      onMouseDown={handlePressStart}
      onMouseUp={handlePressEnd}
      onMouseLeave={handlePressEnd}
      onTouchStart={handlePressStart}
      onTouchEnd={handlePressEnd}
      onTouchCancel={handlePressEnd}
      className={`
        text-[10px] text-muted-foreground/50 select-none transition-all duration-300
        ${isPressing ? 'scale-95 text-accent' : ''}
      `}
    >
      v{APP_VERSION}
    </button>
  );
}

export function Footer() {
  const currentYear = new Date().getFullYear();
  const { config } = useRestaurantConfig();
  const restaurantName = config?.name || 'Il Locale';

  return (
    <footer className="py-6 px-4 border-t border-border/20 bg-secondary/20">
      <div className="max-w-md mx-auto space-y-4">
        {/* Copyright */}
        <div className="text-center text-xs text-muted-foreground">
          <span>© {currentYear} {restaurantName}. Tutti i diritti riservati.</span>
        </div>

        {/* Links */}
        <div className="flex items-center justify-center gap-4 text-xs">
          <Link 
            to="/privacy-policy" 
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            Privacy Policy
          </Link>
          <span className="text-border">•</span>
          <Link 
            to="/cookie-policy" 
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            Cookie Policy
          </Link>
          <span className="text-border">•</span>
          <button 
            onClick={openCookieSettings}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            Gestione Cookie
          </button>
        </div>

        {/* StudioJem Badge */}
        <div className="flex justify-center pt-2">
          <StudioJEMCredits />
        </div>
      </div>
    </footer>
  );
}

export function FooterSimple() {
  const currentYear = new Date().getFullYear();
  const { config } = useRestaurantConfig();
  const restaurantName = config?.name || 'Il Locale';

  return (
    <footer className="py-4 px-4 border-t border-border/10">
      <div className="text-center text-xs text-muted-foreground flex items-center justify-center gap-2">
        <span>© {currentYear} {restaurantName}</span>
        <VersionBadge />
      </div>
    </footer>
  );
}
