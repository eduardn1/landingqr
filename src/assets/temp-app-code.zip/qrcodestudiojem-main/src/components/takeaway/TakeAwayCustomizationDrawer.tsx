import { useState, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Minus, Check, MessageSquare, Ruler, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useLanguage } from '@/contexts/LanguageContext';
import { BackButton } from '@/components/ui/BackButton';
import { cn } from '@/lib/utils';

interface SizeVariant {
  id: string;
  name_it: string;
  name_en: string;
  price: number;
}

interface DishExtra {
  id: string;
  name_it: string;
  name_en: string;
  price: number;
  type: 'add' | 'remove' | 'option';
  is_default?: boolean;
}

interface DishData {
  id: string;
  name_it: string;
  name_en: string;
  description_it?: string | null;
  description_en?: string | null;
  ingredients_it?: string | null;
  ingredients_en?: string | null;
  price: number;
  takeaway_price?: number | null;
  image_url?: string | null;
  size_variants?: SizeVariant[] | null;
  extras?: DishExtra[] | null;
  categories?: { icon: string };
}

interface TakeAwayCustomizationDrawerProps {
  dish: DishData;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (item: {
    dish_id: string;
    name: string;
    price: number;
    quantity: number;
    image_url?: string;
    customizations?: {
      selectedSize?: SizeVariant;
      selectedExtras?: DishExtra[];
      removedIngredients?: string[];
      notes?: string;
      sizeLabel?: string;
    };
  }) => void;
}

export function TakeAwayCustomizationDrawer({ 
  dish, 
  isOpen, 
  onClose, 
  onAddToCart 
}: TakeAwayCustomizationDrawerProps) {
  const { currentLanguage } = useLanguage();
  
  const name = currentLanguage === 'it' ? dish.name_it : dish.name_en || dish.name_it;
  const description = currentLanguage === 'it' ? dish.description_it : dish.description_en || dish.description_it;
  const ingredientsText = currentLanguage === 'it' ? dish.ingredients_it : dish.ingredients_en || dish.ingredients_it;
  
  // Parse ingredients from text (comma-separated)
  const availableIngredients = useMemo(() => {
    if (!ingredientsText) return [];
    return ingredientsText.split(',').map(i => i.trim()).filter(Boolean);
  }, [ingredientsText]);
  
  const hasVariants = dish.size_variants && dish.size_variants.length > 0;
  const hasExtras = dish.extras && dish.extras.length > 0;
  const hasRemovableIngredients = availableIngredients.length > 0;
  
  const addExtras = dish.extras?.filter(e => e.type === 'add') || [];
  const optionExtras = dish.extras?.filter(e => e.type === 'option') || [];
  
  // State
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState<SizeVariant | null>(
    hasVariants ? dish.size_variants![0] : null
  );
  const [selectedExtras, setSelectedExtras] = useState<DishExtra[]>([]);
  const [removedIngredients, setRemovedIngredients] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  
  // Calculate total price
  const basePrice = hasVariants && selectedSize 
    ? selectedSize.price 
    : (dish.takeaway_price ?? dish.price);
  
  const extrasTotal = selectedExtras.reduce((sum, e) => sum + (e.price || 0), 0);
  const unitPrice = basePrice + extrasTotal;
  const totalPrice = unitPrice * quantity;
  
  const toggleExtra = (extra: DishExtra) => {
    setSelectedExtras(prev => 
      prev.find(e => e.id === extra.id)
        ? prev.filter(e => e.id !== extra.id)
        : [...prev, extra]
    );
  };
  
  const toggleIngredient = (ingredient: string) => {
    setRemovedIngredients(prev =>
      prev.includes(ingredient)
        ? prev.filter(i => i !== ingredient)
        : [...prev, ingredient]
    );
  };
  
  const handleAddToCart = () => {
    const sizeLabel = selectedSize 
      ? (currentLanguage === 'it' ? selectedSize.name_it : selectedSize.name_en)
      : undefined;
    
    onAddToCart({
      dish_id: dish.id,
      name: name, // Keep original name clean
      price: unitPrice,
      quantity,
      image_url: dish.image_url || undefined,
      customizations: {
        selectedSize: selectedSize || undefined,
        selectedExtras: selectedExtras.length > 0 ? selectedExtras : undefined,
        removedIngredients: removedIngredients.length > 0 ? removedIngredients : undefined,
        notes: notes.trim() || undefined,
        sizeLabel, // Pass size label separately for display
      }
    });
    onClose();
    // Reset state
    setQuantity(1);
    setSelectedExtras([]);
    setRemovedIngredients([]);
    setNotes('');
  };
  
  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[9999]"
          onClick={onClose}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-background/80 backdrop-blur-md" />

          {/* Panel */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="absolute left-0 right-0 bottom-0 max-h-[90vh] bg-secondary/60 backdrop-blur-xl border-t border-border/30 rounded-t-3xl overflow-hidden"
          >
            {/* Header */}
            <div className="p-4 border-b border-border/20 flex items-start gap-3">
              {dish.image_url ? (
                <img 
                  src={dish.image_url} 
                  alt={name}
                  className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                />
              ) : (
                <div className="w-16 h-16 rounded-xl bg-secondary/50 flex items-center justify-center text-2xl flex-shrink-0">
                  {dish.categories?.icon || '🍽️'}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h2 className="font-semibold text-lg">{name}</h2>
                {description && (
                  <p className="text-sm text-muted-foreground line-clamp-2">{description}</p>
                )}
              </div>
              <BackButton onClick={onClose} variant="close" size="md" />
            </div>

            {/* Content */}
            <div className="p-4 overflow-y-auto max-h-[60vh] space-y-5">
              {/* Size Variants */}
              {hasVariants && dish.size_variants && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Ruler className="w-4 h-4 text-blue-500" />
                    <span>{currentLanguage === 'it' ? 'Scegli dimensione' : 'Choose size'} *</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {dish.size_variants.map((variant) => (
                      <button
                        key={variant.id}
                        onClick={() => setSelectedSize(variant)}
                        className={cn(
                          "p-3 rounded-xl border transition-all text-left",
                          selectedSize?.id === variant.id
                            ? "border-accent bg-accent/10"
                            : "border-border/30 bg-background/20 hover:border-accent/50"
                        )}
                      >
                        <div className="font-medium text-sm">
                          {currentLanguage === 'it' ? variant.name_it : variant.name_en}
                        </div>
                        <div className="text-accent font-bold">€{variant.price.toFixed(2)}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Add Extras */}
              {addExtras.length > 0 && (
                <div className="space-y-2">
                  <div className="text-sm font-medium">
                    {currentLanguage === 'it' ? 'Aggiunte' : 'Add extras'}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {addExtras.map((extra) => {
                      const isSelected = selectedExtras.find(e => e.id === extra.id);
                      return (
                        <button
                          key={extra.id}
                          onClick={() => toggleExtra(extra)}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border",
                            isSelected
                              ? "border-accent bg-accent/20 text-accent"
                              : "border-border/30 bg-background/20 hover:border-accent/50"
                          )}
                        >
                          {isSelected && <Check className="w-3 h-3" />}
                          <Plus className="w-3 h-3" />
                          {currentLanguage === 'it' ? extra.name_it : extra.name_en}
                          {extra.price > 0 && (
                            <span className="text-muted-foreground">+€{extra.price.toFixed(2)}</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Options */}
              {optionExtras.length > 0 && (
                <div className="space-y-2">
                  <div className="text-sm font-medium">
                    {currentLanguage === 'it' ? 'Opzioni' : 'Options'}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {optionExtras.map((extra) => {
                      const isSelected = selectedExtras.find(e => e.id === extra.id);
                      return (
                        <button
                          key={extra.id}
                          onClick={() => toggleExtra(extra)}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border",
                            isSelected
                              ? "border-primary bg-primary/20 text-primary"
                              : "border-border/30 bg-background/20 hover:border-primary/50"
                          )}
                        >
                          {isSelected && <Check className="w-3 h-3" />}
                          {currentLanguage === 'it' ? extra.name_it : extra.name_en}
                          {extra.price > 0 && (
                            <span className="text-muted-foreground">+€{extra.price.toFixed(2)}</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Removable Ingredients */}
              {hasRemovableIngredients && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <Trash2 className="w-4 h-4 text-destructive" />
                    <span>{currentLanguage === 'it' ? 'Rimuovi ingredienti' : 'Remove ingredients'}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {availableIngredients.map((ingredient) => {
                      const isRemoved = removedIngredients.includes(ingredient);
                      return (
                        <button
                          key={ingredient}
                          onClick={() => toggleIngredient(ingredient)}
                          className={cn(
                            "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border",
                            isRemoved
                              ? "border-destructive bg-destructive/20 text-destructive line-through"
                              : "border-border/30 bg-background/20 hover:border-destructive/50"
                          )}
                        >
                          {isRemoved && <X className="w-3 h-3" />}
                          {ingredient}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Notes */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <MessageSquare className="w-4 h-4 text-muted-foreground" />
                  <span>{currentLanguage === 'it' ? 'Note personalizzate' : 'Custom notes'}</span>
                </div>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={currentLanguage === 'it' 
                    ? "Es. cottura media, basilico fuori cottura..."
                    : "E.g. medium rare, basil on the side..."
                  }
                  className="resize-none h-20"
                  maxLength={200}
                />
                <p className="text-xs text-muted-foreground text-right">{notes.length}/200</p>
              </div>
            </div>

            {/* Footer with quantity and add button */}
            <div className="p-4 border-t border-border/20 flex items-center gap-3">
              {/* Quantity */}
              <div className="flex items-center gap-2 bg-secondary/50 rounded-xl p-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                >
                  <Minus className="w-4 h-4" />
                </Button>
                <span className="w-8 text-center font-bold">{quantity}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setQuantity(quantity + 1)}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              
              {/* Add to cart button */}
              <Button 
                className="flex-1 h-12 text-base font-semibold"
                onClick={handleAddToCart}
                disabled={hasVariants && !selectedSize}
              >
                {currentLanguage === 'it' ? 'Aggiungi' : 'Add'} • €{totalPrice.toFixed(2)}
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}
