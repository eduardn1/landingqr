import { ShoppingBag, ChevronRight } from 'lucide-react';
import { useTakeAwayCart } from '@/contexts/TakeAwayCartContext';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '@/contexts/LanguageContext';

export function TakeAwayFloatingCart() {
  const navigate = useNavigate();
  const { itemCount, subtotal } = useTakeAwayCart();
  const { t } = useLanguage();

  if (itemCount === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
        className="fixed z-50 bottom-20 sm:bottom-6 left-0 right-0 px-3 sm:px-6"
      >
        <motion.button
          onClick={() => navigate('/takeaway/checkout')}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          className="w-full max-w-lg mx-auto flex items-center justify-between gap-2 sm:gap-4 px-3 sm:px-5 py-3 sm:py-4 rounded-2xl bg-accent text-accent-foreground shadow-lg"
        >
          {/* Left: Icon + Count - Compact on small screens */}
          <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
            <div className="relative">
              <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="absolute -top-1.5 -right-1.5 min-w-4 h-4 px-1 rounded-full bg-accent-foreground text-accent text-[10px] font-bold flex items-center justify-center">
                {itemCount}
              </span>
            </div>
            <span className="font-medium text-sm sm:text-base hidden xs:inline">
              {itemCount} {itemCount === 1 ? 'articolo' : 'articoli'}
            </span>
          </div>
          
          {/* Center: CTA - Simplified on small screens */}
          <span className="font-semibold flex items-center gap-1 text-sm sm:text-base flex-shrink-0">
            <span className="hidden xs:inline">Vai al</span> Carrello
            <ChevronRight className="w-4 h-4" />
          </span>
          
          {/* Right: Total */}
          <span className="font-bold text-base sm:text-lg flex-shrink-0">
            €{subtotal.toFixed(2)}
          </span>
        </motion.button>
      </motion.div>
    </AnimatePresence>
  );
}
