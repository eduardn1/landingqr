import { useState } from 'react';
import { Plus, Minus, Clock, Check, Sliders } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTakeAwayCart } from '@/contexts/TakeAwayCartContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { ProgressiveImage } from '@/components/ui/ProgressiveImage';
import { DishPlaceholder } from '@/components/client/DishPlaceholder';
import { TakeAwayCustomizationDrawer } from './TakeAwayCustomizationDrawer';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

type ViewMode = 'cards' | 'list' | 'grid-2' | 'compact';

interface SizeVariant {
  id: string;
  name_it: string;
  name_en: string;
  price: number;
}

interface DishExtra {
  id: string;
  name_it: string;
  name_en: string;
  price: number;
  type: 'add' | 'remove' | 'option';
  is_default?: boolean;
}

interface TakeAwayDishCardProps {
  dish: {
    id: string;
    name_it: string;
    name_en: string;
    description_it: string | null;
    description_en: string | null;
    ingredients_it?: string | null;
    ingredients_en?: string | null;
    price: number;
    original_price?: number | null;
    takeaway_price?: number | null;
    image_url: string | null;
    takeaway_prep_time?: number;
    size_variants?: SizeVariant[] | any;
    extras?: DishExtra[] | any;
    categories?: { name_it: string; name_en: string; icon: string };
  };
  viewMode?: ViewMode;
}

export function TakeAwayDishCard({ dish, viewMode = 'list' }: TakeAwayDishCardProps) {
  const { currentLanguage } = useLanguage();
  const { items, addItem, updateQuantity, removeItem } = useTakeAwayCart();
  const [showAdded, setShowAdded] = useState(false);
  const [isCustomizationOpen, setIsCustomizationOpen] = useState(false);

  const name = currentLanguage === 'it' ? dish.name_it : dish.name_en || dish.name_it;
  const description = currentLanguage === 'it' ? dish.description_it : dish.description_en || dish.description_it;
  
  // Check if dish has customization options
  const hasVariants = dish.size_variants && dish.size_variants.length > 0;
  const hasExtras = dish.extras && dish.extras.length > 0;
  const hasIngredients = !!(dish.ingredients_it || dish.ingredients_en);
  const needsCustomization = hasVariants || hasExtras || hasIngredients;
  
  // Use takeaway_price if available, otherwise use regular price
  const effectivePrice = dish.takeaway_price ?? dish.price;
  const hasDifferentPrice = dish.takeaway_price !== null && dish.takeaway_price !== undefined && dish.takeaway_price !== dish.price;
  
  // Calculate discount percentage from original_price
  const hasDiscount = dish.original_price && dish.original_price > effectivePrice;
  const discountPercent = hasDiscount 
    ? Math.round(((dish.original_price! - effectivePrice) / dish.original_price!) * 100)
    : 0;
  
  // For dishes with size variants, show price range (min-max)
  const variantPrices = hasVariants && dish.size_variants 
    ? dish.size_variants.map(v => v.price)
    : [];
  const minVariantPrice = variantPrices.length > 0 ? Math.min(...variantPrices) : 0;
  const maxVariantPrice = variantPrices.length > 0 ? Math.max(...variantPrices) : 0;
  const hasPriceRange = hasVariants && minVariantPrice !== maxVariantPrice;
  const priceRangeDisplay = hasPriceRange 
    ? `€${minVariantPrice.toFixed(2)} - €${maxVariantPrice.toFixed(2)}`
    : hasVariants 
      ? `€${minVariantPrice.toFixed(2)}`
      : `€${effectivePrice.toFixed(2)}`;

  const cartItem = items.find(i => i.dish_id === dish.id);
  const quantity = cartItem?.quantity || 0;

  const handleAdd = () => {
    if (needsCustomization) {
      setIsCustomizationOpen(true);
      return;
    }
    
    addItem({
      dish_id: dish.id,
      name: name,
      price: effectivePrice,
      quantity: 1,
      image_url: dish.image_url || undefined,
    });
    setShowAdded(true);
    setTimeout(() => setShowAdded(false), 1500);
  };

  const handleAddFromDrawer = (item: any) => {
    addItem(item);
    setShowAdded(true);
    setTimeout(() => setShowAdded(false), 1500);
  };

  const handleIncrement = () => {
    if (needsCustomization) {
      setIsCustomizationOpen(true);
      return;
    }
    updateQuantity(dish.id, quantity + 1);
  };

  const handleDecrement = () => {
    if (quantity <= 1) {
      removeItem(dish.id);
    } else {
      updateQuantity(dish.id, quantity - 1);
    }
  };

  // Compact view - vertical mini card for favorites section
  if (viewMode === 'compact') {
    return (
      <div 
        className={cn(
          "relative flex flex-col bg-foreground/[0.02] dark:bg-foreground/[0.04] rounded-xl border border-foreground/[0.06] hover:border-foreground/[0.12] transition-all cursor-pointer overflow-hidden",
          quantity > 0 && "border-accent ring-1 ring-accent/20"
        )}
        onClick={needsCustomization ? handleAdd : undefined}
      >
        {/* Image */}
        <div className="relative aspect-square overflow-hidden bg-secondary/30">
          {dish.image_url ? (
            <img
              src={dish.image_url}
              alt={name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-2xl">
              {dish.categories?.icon || '🍽️'}
            </div>
          )}
          
          {/* Quantity badge */}
          <AnimatePresence>
            {quantity > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="absolute top-1 left-1 bg-accent text-accent-foreground text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center"
              >
                {quantity}
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Add button overlay */}
          <div className="absolute bottom-1 right-1" onClick={(e) => e.stopPropagation()}>
            <Button
              size="icon"
              className="h-7 w-7 rounded-full shadow-lg"
              onClick={quantity > 0 ? handleIncrement : handleAdd}
            >
              <Plus className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
        
        {/* Info */}
        <div className="p-2 space-y-0.5">
          <h3 className="font-medium text-xs line-clamp-2 leading-tight">{name}</h3>
          <span className="text-accent font-bold text-sm">{priceRangeDisplay}</span>
        </div>

        {/* Customization Drawer */}
        <TakeAwayCustomizationDrawer
          dish={dish}
          isOpen={isCustomizationOpen}
          onClose={() => setIsCustomizationOpen(false)}
          onAddToCart={handleAddFromDrawer}
        />
      </div>
    );
  }

  // Cards view - large vertical card with big image on top
  if (viewMode === 'cards') {
    return (
      <div className={cn(
        "relative bg-foreground/[0.02] dark:bg-foreground/[0.04] rounded-2xl border border-foreground/[0.06] overflow-hidden hover:border-foreground/[0.12] transition-all group",
        quantity > 0 && "border-accent ring-1 ring-accent/20"
      )}>
        {/* Large image */}
        <div className="relative aspect-[4/3] overflow-hidden">
          {dish.image_url ? (
            <ProgressiveImage
              src={dish.image_url}
              alt={name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <DishPlaceholder categoryIcon={dish.categories?.icon} />
          )}
          
          {/* Quantity badge */}
          <AnimatePresence>
            {quantity > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="absolute top-2 right-2 bg-accent text-accent-foreground text-sm font-bold w-7 h-7 rounded-full flex items-center justify-center shadow-lg"
              >
                {quantity}
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* Add button overlay */}
          <Button
            size="icon"
            className="absolute bottom-2 right-2 h-9 w-9 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={quantity > 0 ? handleIncrement : handleAdd}
          >
            <Plus className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Content */}
        <div className="p-4 space-y-2">
          <h3 className="font-semibold text-base line-clamp-2">{name}</h3>
          {description && (
            <p className="text-sm text-muted-foreground line-clamp-2">{description}</p>
          )}
          
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-accent font-bold text-lg">{priceRangeDisplay}</span>
              {hasDiscount && !hasVariants && (
                <>
                  <span className="text-sm text-muted-foreground line-through">€{dish.original_price!.toFixed(2)}</span>
                  <span className="text-xs font-medium bg-accent text-accent-foreground px-1.5 py-0.5 rounded-full">-{discountPercent}%</span>
                </>
              )}
            </div>
            
            {quantity > 0 ? (
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={handleDecrement}
                >
                  <Minus className="w-4 h-4" />
                </Button>
                <span className="font-bold text-base w-6 text-center">{quantity}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 bg-accent/20"
                  onClick={handleIncrement}
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <Button size="sm" onClick={handleAdd}>
                <Plus className="w-4 h-4 mr-1" />
                Aggiungi
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Grid view (2x2)
  if (viewMode === 'grid-2') {
    return (
      <div className={cn(
        "relative bg-foreground/[0.02] dark:bg-foreground/[0.04] rounded-xl border border-foreground/[0.06] overflow-hidden hover:border-foreground/[0.12] transition-all group p-3",
        quantity > 0 && "border-accent ring-1 ring-accent/20"
      )}>
        {/* Image */}
        <div className="relative rounded-lg overflow-hidden mb-2 aspect-[4/3]">
          {dish.image_url ? (
            <ProgressiveImage
              src={dish.image_url}
              alt={name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <DishPlaceholder categoryIcon={dish.categories?.icon} />
          )}
          
          {/* Quantity badge */}
          <AnimatePresence>
            {quantity > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="absolute top-1 right-1 bg-accent text-accent-foreground text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center"
              >
                {quantity}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        {/* Info */}
        <div className="space-y-1">
          <h3 className="font-medium line-clamp-2 text-sm">{name}</h3>
          
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-accent font-bold text-base">{priceRangeDisplay}</span>
              {hasDiscount && !hasVariants && (
                <div className="flex items-center gap-1">
                  <span className="text-[10px] text-muted-foreground line-through">€{dish.original_price!.toFixed(2)}</span>
                  <span className="text-[9px] font-medium bg-accent text-accent-foreground px-1 rounded">-{discountPercent}%</span>
                </div>
              )}
            </div>
            
            <Button
              size="icon"
              className="h-7 w-7"
              onClick={quantity > 0 ? handleIncrement : handleAdd}
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // List view (default)
  return (
    <div className={cn(
      "flex gap-3 p-3 bg-foreground/[0.02] dark:bg-foreground/[0.04] rounded-xl border border-foreground/[0.06] hover:border-foreground/[0.12] transition-all group",
      quantity > 0 && "border-accent ring-1 ring-accent/20"
    )}>
      {/* Image */}
      <div className="relative w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
        {dish.image_url ? (
          <ProgressiveImage
            src={dish.image_url}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <DishPlaceholder categoryIcon={dish.categories?.icon} />
        )}
        
        {/* Added feedback */}
        <AnimatePresence>
          {showAdded && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute inset-0 bg-accent/90 flex items-center justify-center"
            >
              <Check className="w-8 h-8 text-accent-foreground" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      
      {/* Content */}
      <div className="flex-1 min-w-0 flex flex-col justify-between">
        <div>
          <h3 className="font-semibold text-sm line-clamp-1">{name}</h3>
          {description && (
            <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{description}</p>
          )}
          
          {/* Prep time */}
          {dish.takeaway_prep_time && (
            <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
              <Clock className="w-3 h-3" />
              <span>~{dish.takeaway_prep_time} min</span>
            </div>
          )}
        </div>
        
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-accent font-bold">{priceRangeDisplay}</span>
            {hasDiscount && !hasVariants && (
              <>
                <span className="text-xs text-muted-foreground line-through">€{dish.original_price!.toFixed(2)}</span>
                <span className="text-[10px] font-medium bg-accent text-accent-foreground px-1.5 py-0.5 rounded-full">-{discountPercent}%</span>
              </>
            )}
          </div>
          
          {quantity > 0 ? (
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={handleDecrement}
              >
                <Minus className="w-4 h-4" />
              </Button>
              <span className="font-bold text-base w-6 text-center">{quantity}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 bg-accent/20"
                onClick={handleIncrement}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <Button
              size="icon"
              className="h-8 w-8 rounded-full sm:w-auto sm:px-4 sm:rounded-md"
              onClick={handleAdd}
            >
              <Plus className="w-4 h-4 sm:mr-1" />
              <span className="hidden sm:inline">Aggiungi</span>
            </Button>
          )}
        </div>
      </div>

      {/* Customization Drawer */}
      <TakeAwayCustomizationDrawer
        dish={dish}
        isOpen={isCustomizationOpen}
        onClose={() => setIsCustomizationOpen(false)}
        onAddToCart={handleAddFromDrawer}
      />
    </div>
  );
}
