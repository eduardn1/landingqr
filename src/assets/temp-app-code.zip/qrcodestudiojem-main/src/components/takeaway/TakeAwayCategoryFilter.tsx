import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { cn } from '@/lib/utils';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';

interface TakeAwayCategoryFilterProps {
  selected: string;
  onChange: (categoryId: string) => void;
}

export function TakeAwayCategoryFilter({ selected, onChange }: TakeAwayCategoryFilterProps) {
  const { currentLanguage } = useLanguage();

  const { data: categories = [] } = useQuery({
    queryKey: ['takeaway-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('display_order');

      if (error) throw error;
      return data;
    },
  });

  return (
    <ScrollArea className="w-full whitespace-nowrap">
      <div className="flex gap-2 pb-2">
        <button
          onClick={() => onChange('all')}
          className={cn(
            "px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap",
            selected === 'all'
              ? "bg-accent text-accent-foreground"
              : "bg-secondary/50 text-muted-foreground hover:bg-secondary"
          )}
        >
          🍽️ Tutto
        </button>
        
        {categories.map(category => {
          const name = currentLanguage === 'it' 
            ? category.name_it 
            : category.name_en || category.name_it;
          
          return (
            <button
              key={category.id}
              onClick={() => onChange(category.id)}
              className={cn(
                "px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap flex items-center gap-1",
                selected === category.id
                  ? "bg-accent text-accent-foreground"
                  : "bg-secondary/50 text-muted-foreground hover:bg-secondary"
              )}
            >
              <span>{category.icon}</span>
              <span>{name}</span>
            </button>
          );
        })}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  );
}
