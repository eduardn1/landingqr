export { DynamicHeader, HeaderMinimal, HeaderCentered, HeaderFloating } from './HeaderVariants';
export { DynamicFooter, FooterMinimal, FooterExpanded, FooterSplit } from './FooterVariants';
