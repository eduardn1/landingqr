import { motion } from 'framer-motion';
import { Heart, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { LanguageSwitcher } from '../LanguageSwitcher';
import { ThemeToggle } from '../ThemeToggle';
import { NotificationBell } from '../client/NotificationBell';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { useNavigationConfig } from '@/hooks/useNavigationConfig';
import { useFavorites } from '@/hooks/useFavorites';
import { useAuth } from '@/hooks/useAuth';
import { BackButton } from '@/components/ui/BackButton';
import { useHeaderVisibility } from '@/hooks/useHeaderVisibility';

interface HeaderProps {
  showBack?: boolean;
  onBack?: () => void;
  onOpenFavorites?: () => void;
  variant?: 'default' | 'minimal' | 'centered' | 'floating';
}

// Minimal Header - Just logo and essential actions
export function HeaderMinimal({ showBack, onBack, onOpenFavorites }: HeaderProps) {
  const { config: restaurantConfig } = useRestaurantConfig();
  const { isAuthenticated } = useAuth();
  const visibility = useHeaderVisibility();

  return (
    <motion.header 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="sticky top-0 z-50 bg-transparent"
    >
      <div className="container flex items-center justify-between h-14 px-4">
        <div className="flex items-center -my-3">
          {showBack && onBack ? (
            <BackButton onClick={onBack} size="sm" />
          ) : visibility.logo && restaurantConfig?.logo_url && (
            <motion.img 
              src={restaurantConfig.logo_url} 
              alt={restaurantConfig?.name || 'Logo'} 
              className="w-16 h-16 object-contain drop-shadow-lg"
              animate={{ rotate: [0, 3, -3, 3, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              whileHover={{ scale: 1.1 }}
            />
          )}
        </div>

        <div className="flex items-center gap-2">
          {visibility.notifications && isAuthenticated && <NotificationBell />}
          {visibility.theme && <ThemeToggle />}
          {visibility.language && <LanguageSwitcher />}
        </div>
      </div>
    </motion.header>
  );
}

// Centered Header - Logo in center, actions on sides
export function HeaderCentered({ showBack, onBack, onOpenFavorites }: HeaderProps) {
  const { favoritesCount } = useFavorites();
  const { isAuthenticated } = useAuth();
  const { config: restaurantConfig } = useRestaurantConfig();
  const visibility = useHeaderVisibility();

  return (
    <motion.header 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="sticky top-0 z-50"
    >
      <div className="absolute inset-0 bg-background/80 backdrop-blur-xl border-b border-border/10" />
      
      <div className="container relative flex items-center justify-between h-16 px-4">
        {/* Left Section */}
        <div className="flex items-center gap-2 w-1/3">
          {showBack && onBack ? (
            <BackButton onClick={onBack} />
          ) : (
            <>
              {visibility.notifications && isAuthenticated && <NotificationBell />}
              {visibility.theme && <ThemeToggle />}
            </>
          )}
        </div>

        {/* Center - Logo */}
        <div className="flex-1 flex justify-center -my-4">
          {visibility.logo && restaurantConfig?.logo_url && (
            <motion.img 
              src={restaurantConfig.logo_url} 
              alt={restaurantConfig?.name || 'Logo'} 
              className="w-20 h-20 object-contain drop-shadow-lg"
              animate={{ rotate: [0, 3, -3, 3, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              whileHover={{ scale: 1.1 }}
            />
          )}
        </div>

        {/* Right Section */}
        <div className="flex items-center justify-end gap-2 w-1/3">
          {visibility.favorites && favoritesCount > 0 && onOpenFavorites && (
            <motion.button
              onClick={onOpenFavorites}
              className="relative w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center"
              whileTap={{ scale: 0.95 }}
            >
              <Heart className="w-4 h-4 text-accent" fill="currentColor" />
              <span className="absolute -top-1 -right-1 min-w-4 h-4 px-1 rounded-full bg-accent text-accent-foreground text-[10px] font-bold flex items-center justify-center">
                {favoritesCount}
              </span>
            </motion.button>
          )}
          {visibility.profile && (
            <Link to={isAuthenticated ? '/profile' : '/auth'}>
              <motion.div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  isAuthenticated ? 'bg-accent/20 text-accent' : 'bg-secondary/50 text-muted-foreground'
                }`}
                whileTap={{ scale: 0.95 }}
              >
                <User className="w-4 h-4" />
              </motion.div>
            </Link>
          )}
          {visibility.language && <LanguageSwitcher />}
        </div>
      </div>
    </motion.header>
  );
}

// Floating Header - Detached from top with rounded corners
export function HeaderFloating({ showBack, onBack, onOpenFavorites }: HeaderProps) {
  const { favoritesCount } = useFavorites();
  const { isAuthenticated } = useAuth();
  const { config: restaurantConfig } = useRestaurantConfig();
  const visibility = useHeaderVisibility();

  return (
    <motion.header 
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="fixed top-4 left-4 right-4 z-50"
    >
      <div className="container max-w-3xl mx-auto">
        <div className="flex items-center justify-between h-14 px-4 rounded-2xl bg-background/80 backdrop-blur-xl border border-border/30 shadow-lg">
          {/* Left */}
          <div className="flex items-center gap-3 -my-3">
            {showBack && onBack ? (
              <BackButton onClick={onBack} size="sm" />
            ) : visibility.logo && restaurantConfig?.logo_url && (
              <motion.img 
                src={restaurantConfig.logo_url} 
                alt={restaurantConfig?.name || 'Logo'} 
                className="w-16 h-16 object-contain drop-shadow-lg"
                animate={{ rotate: [0, 3, -3, 3, 0] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                whileHover={{ scale: 1.1 }}
              />
            )}
          </div>

          {/* Right */}
          <div className="flex items-center gap-2">
            {visibility.notifications && isAuthenticated && <NotificationBell />}
            
            {visibility.favorites && favoritesCount > 0 && onOpenFavorites && (
              <motion.button
                onClick={onOpenFavorites}
                className="relative w-9 h-9 rounded-xl bg-accent/10 flex items-center justify-center"
                whileTap={{ scale: 0.95 }}
              >
                <Heart className="w-4 h-4 text-accent" fill="currentColor" />
                <span className="absolute -top-1 -right-1 min-w-4 h-4 px-1 rounded-full bg-accent text-accent-foreground text-[9px] font-bold flex items-center justify-center">
                  {favoritesCount}
                </span>
              </motion.button>
            )}

            {visibility.profile && (
              <Link to={isAuthenticated ? '/profile' : '/auth'}>
                <motion.div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                    isAuthenticated ? 'bg-accent/20 text-accent' : 'bg-secondary text-muted-foreground'
                  }`}
                  whileTap={{ scale: 0.95 }}
                >
                  <User className="w-4 h-4" />
                </motion.div>
              </Link>
            )}

            {visibility.theme && <ThemeToggle />}
            {visibility.language && <LanguageSwitcher />}
          </div>
        </div>
      </div>
    </motion.header>
  );
}

// Export a dynamic header that uses variants
export function DynamicHeader({ variant = 'default', ...props }: HeaderProps) {
  switch (variant) {
    case 'minimal':
      return <HeaderMinimal {...props} />;
    case 'centered':
      return <HeaderCentered {...props} />;
    case 'floating':
      return <HeaderFloating {...props} />;
    default:
      // Return null - use default AppHeader
      return null;
  }
}
