import { useState, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Code, Rocket, Globe, Phone, ArrowRight, MapPin, Clock, Mail, Instagram, Facebook } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { openCookieSettings } from '@/components/client/CookieConsent';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';

const APP_VERSION = '1.0.1';

// Version badge with long-press admin access
function VersionBadge() {
  const navigate = useNavigate();
  const pressTimer = useRef<NodeJS.Timeout | null>(null);
  const [isPressing, setIsPressing] = useState(false);

  const handlePressStart = useCallback(() => {
    setIsPressing(true);
    pressTimer.current = setTimeout(() => {
      navigate('/auth?mode=admin');
    }, 2000);
  }, [navigate]);

  const handlePressEnd = useCallback(() => {
    setIsPressing(false);
    if (pressTimer.current) {
      clearTimeout(pressTimer.current);
      pressTimer.current = null;
    }
  }, []);

  return (
    <button
      onMouseDown={handlePressStart}
      onMouseUp={handlePressEnd}
      onMouseLeave={handlePressEnd}
      onTouchStart={handlePressStart}
      onTouchEnd={handlePressEnd}
      onTouchCancel={handlePressEnd}
      className={`text-[10px] text-muted-foreground/50 select-none transition-all duration-300 ${isPressing ? 'scale-95 text-accent' : ''}`}
    >
      v{APP_VERSION}
    </button>
  );
}

// StudioJEM Credits Component
function StudioJEMCredits({ compact = false }: { compact?: boolean }) {
  if (compact) {
    return (
      <a 
        href="https://studiojem.it" 
        target="_blank" 
        rel="noopener noreferrer"
        className="text-xs text-muted-foreground/60 hover:text-accent transition-colors flex items-center gap-1"
      >
        <Code className="w-3 h-3" />
        studiojem.it
      </a>
    );
  }

  return (
    <a 
      href="https://studiojem.it" 
      target="_blank" 
      rel="noopener noreferrer"
      className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-card border border-border/20 hover:border-accent/30 transition-all"
    >
      <Code className="w-4 h-4 text-foreground" />
      <span className="text-sm text-muted-foreground">Sviluppato da</span>
      <span className="font-semibold text-foreground">studiojem.it</span>
      <Rocket className="w-4 h-4 text-accent" />
    </a>
  );
}

interface FooterProps {
  variant?: 'default' | 'minimal' | 'expanded' | 'split';
}

// Minimal Footer - Just essentials
export function FooterMinimal() {
  const currentYear = new Date().getFullYear();
  const { config } = useRestaurantConfig();

  return (
    <footer className="py-4 px-4 border-t border-border/10">
      <div className="container max-w-md mx-auto flex items-center justify-between text-xs text-muted-foreground">
        <span>© {currentYear} {config?.name || 'Il Locale'}</span>
        <div className="flex items-center gap-3">
          <Link to="/privacy-policy" className="hover:text-foreground transition-colors">Privacy</Link>
          <StudioJEMCredits compact />
          <VersionBadge />
        </div>
      </div>
    </footer>
  );
}

// Expanded Footer - Full info with social links
export function FooterExpanded() {
  const currentYear = new Date().getFullYear();
  const { config } = useRestaurantConfig();

  return (
    <footer className="pt-12 pb-6 bg-secondary/30 border-t border-border/20">
      <div className="container px-4">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Brand */}
          <div className="space-y-4">
            {config?.logo_url && (
              <img src={config.logo_url} alt={config?.name} className="h-12 object-contain" />
            )}
            <h3 className="text-xl font-bold text-foreground">{config?.name || 'Il Locale'}</h3>
            <p className="text-sm text-muted-foreground max-w-xs">
              {config?.tagline?.it || 'La migliore esperienza culinaria'}
            </p>
          </div>

          {/* Contact */}
          <div className="space-y-3">
            <h4 className="font-semibold text-foreground">Contatti</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              {config?.address && (
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-0.5 text-accent" />
                  <span>{config.address}{config.city && `, ${config.city}`}</span>
                </div>
              )}
              {config?.phone && (
                <a href={`tel:${config.phone}`} className="flex items-center gap-2 hover:text-accent transition-colors">
                  <Phone className="w-4 h-4 text-accent" />
                  <span>{config.phone}</span>
                </a>
              )}
              {config?.email && (
                <a href={`mailto:${config.email}`} className="flex items-center gap-2 hover:text-accent transition-colors">
                  <Mail className="w-4 h-4 text-accent" />
                  <span>{config.email}</span>
                </a>
              )}
            </div>
          </div>

          {/* Social & Links */}
          <div className="space-y-3">
            <h4 className="font-semibold text-foreground">Seguici</h4>
            <div className="flex gap-3">
              {config?.instagram_url && (
                <a 
                  href={config.instagram_url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center hover:bg-accent/20 transition-colors"
                >
                  <Instagram className="w-5 h-5 text-accent" />
                </a>
              )}
              {config?.facebook_url && (
                <a 
                  href={config.facebook_url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center hover:bg-accent/20 transition-colors"
                >
                  <Facebook className="w-5 h-5 text-accent" />
                </a>
              )}
            </div>
            <div className="flex flex-wrap gap-2 text-xs">
              <Link to="/privacy-policy" className="text-muted-foreground hover:text-foreground transition-colors">Privacy Policy</Link>
              <span className="text-border">•</span>
              <Link to="/cookie-policy" className="text-muted-foreground hover:text-foreground transition-colors">Cookie Policy</Link>
              <span className="text-border">•</span>
              <button onClick={openCookieSettings} className="text-muted-foreground hover:text-foreground transition-colors">
                Gestione Cookie
              </button>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 border-t border-border/20 flex flex-col md:flex-row items-center justify-between gap-4">
          <span className="text-xs text-muted-foreground">
            © {currentYear} {config?.name}. Tutti i diritti riservati.
          </span>
          <div className="flex items-center gap-4">
            <StudioJEMCredits />
            <VersionBadge />
          </div>
        </div>
      </div>
    </footer>
  );
}

// Split Footer - Two columns layout
export function FooterSplit() {
  const currentYear = new Date().getFullYear();
  const { config } = useRestaurantConfig();

  return (
    <footer className="py-8 px-4 bg-card border-t border-border/20">
      <div className="container max-w-4xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Left - Brand */}
          <div className="flex items-center gap-4">
            {config?.logo_url && (
              <img src={config.logo_url} alt={config?.name} className="h-10 object-contain" />
            )}
            <div>
              <h3 className="font-bold text-foreground">{config?.name || 'Il Locale'}</h3>
              <p className="text-xs text-muted-foreground">© {currentYear}</p>
            </div>
          </div>

          {/* Right - Links */}
          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
            <div className="flex items-center gap-4 text-sm">
              <Link to="/privacy-policy" className="text-muted-foreground hover:text-foreground transition-colors">
                Privacy
              </Link>
              <Link to="/cookie-policy" className="text-muted-foreground hover:text-foreground transition-colors">
                Cookie
              </Link>
              <button onClick={openCookieSettings} className="text-muted-foreground hover:text-foreground transition-colors">
                Preferenze
              </button>
            </div>
            
            <div className="flex items-center gap-3">
              {config?.instagram_url && (
                <a href={config.instagram_url} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
              )}
              {config?.facebook_url && (
                <a href={config.facebook_url} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors">
                  <Facebook className="w-5 h-5" />
                </a>
              )}
            </div>

            <StudioJEMCredits compact />
            <VersionBadge />
          </div>
        </div>
      </div>
    </footer>
  );
}

// Dynamic Footer that uses variants
export function DynamicFooter({ variant = 'default' }: FooterProps) {
  switch (variant) {
    case 'minimal':
      return <FooterMinimal />;
    case 'expanded':
      return <FooterExpanded />;
    case 'split':
      return <FooterSplit />;
    default:
      return null; // Use default Footer
  }
}
