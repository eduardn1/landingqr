import { useRef, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import { useCategories } from '@/hooks/useMenu';

interface CategoryNavProps {
  selectedCategory: string | null;
  onSelectCategory: (categoryId: string | null) => void;
}

export function CategoryNav({ selectedCategory, onSelectCategory }: CategoryNavProps) {
  const { currentLanguage, t } = useLanguage();
  const { categories: dbCategories, isLoading } = useCategories();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    checkScroll();
    window.addEventListener('resize', checkScroll);
    return () => window.removeEventListener('resize', checkScroll);
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 200;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  // Convert db categories to local format
  const activeCategories = dbCategories.filter(c => c.is_active).map(c => ({
    id: c.id,
    name: { it: c.name_it, en: c.name_en },
    icon: c.icon,
  }));

  return (
    <div className="relative">
      {/* Scroll buttons */}
      {canScrollLeft && (
        <button
          onClick={() => scroll('left')}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-background border border-border shadow-soft flex items-center justify-center hover:bg-secondary transition-colors"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
      )}
      {canScrollRight && (
        <button
          onClick={() => scroll('right')}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-8 h-8 rounded-full bg-background border border-border shadow-soft flex items-center justify-center hover:bg-secondary transition-colors"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      )}

      {/* Categories */}
      <div
        ref={scrollRef}
        onScroll={checkScroll}
        className="flex gap-2 overflow-x-auto scrollbar-hide px-1 py-2 category-scroll"
      >
        {/* All button */}
        <button
          onClick={() => onSelectCategory(null)}
          className={cn(
            "category-pill whitespace-nowrap flex-shrink-0 flex items-center gap-2",
            selectedCategory === null && "active"
          )}
        >
          <span>{t('allCategories')}</span>
        </button>

        {/* Category buttons */}
        {activeCategories.map((category, index) => (
          <button
            key={category.id}
            onClick={() => onSelectCategory(category.id)}
            className={cn(
              "category-pill whitespace-nowrap flex-shrink-0 flex items-center gap-2",
              "animate-fade-in",
              selectedCategory === category.id && "active"
            )}
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <span className="text-base">{category.icon}</span>
            <span>{getLocalizedContent(category.name, currentLanguage)}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
