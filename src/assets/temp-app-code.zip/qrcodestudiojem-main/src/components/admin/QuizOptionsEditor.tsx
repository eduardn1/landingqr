import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Save, Loader2, GripVertical, Edit2, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { OnboardingStep, OnboardingStepOption } from '@/hooks/useOnboardingSteps';

interface QuizOptionsEditorProps {
  step: OnboardingStep;
  currentLanguage: string;
  onRefresh: () => void;
}

export function QuizOptionsEditor({ step, currentLanguage, onRefresh }: QuizOptionsEditorProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [editingOption, setEditingOption] = useState<OnboardingStepOption | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isAddingOption, setIsAddingOption] = useState(false);
  const [newOption, setNewOption] = useState({
    id: '',
    emoji: '🍽️',
    label_it: '',
    label_en: '',
    gradient: 'from-accent/20 to-accent/5',
    tags: '',
  });

  const handleSaveOption = async (option: OnboardingStepOption, isNew: boolean = false) => {
    setIsSaving(true);
    
    try {
      const currentOptions = step.options || [];
      let updatedOptions: OnboardingStepOption[];
      
      if (isNew) {
        updatedOptions = [...currentOptions, option];
      } else {
        updatedOptions = currentOptions.map(o => o.id === option.id ? option : o);
      }
      
      const { error } = await supabase
        .from('onboarding_steps')
        .update({ options: updatedOptions as unknown as any })
        .eq('id', step.id);

      if (error) throw error;
      toast.success(isNew ? 'Opzione aggiunta' : 'Opzione aggiornata');
      setEditingOption(null);
      setIsAddingOption(false);
      onRefresh();
    } catch (error) {
      console.error('Error saving option:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteOption = async (optionId: string) => {
    if (!confirm('Eliminare questa opzione?')) return;
    
    try {
      const updatedOptions = step.options.filter(o => o.id !== optionId);
      
      const { error } = await supabase
        .from('onboarding_steps')
        .update({ options: updatedOptions as unknown as any })
        .eq('id', step.id);

      if (error) throw error;
      toast.success('Opzione eliminata');
      onRefresh();
    } catch (error) {
      console.error('Error deleting option:', error);
      toast.error('Errore nell\'eliminazione');
    }
  };

  const handleAddNewOption = () => {
    if (!newOption.id || !newOption.label_it) {
      toast.error('Compila ID e label IT');
      return;
    }
    
    const option: OnboardingStepOption = {
      id: newOption.id,
      emoji: newOption.emoji,
      label: { it: newOption.label_it, en: newOption.label_en || newOption.label_it },
      gradient: newOption.gradient,
      filters: newOption.tags ? { tags: newOption.tags.split(',').map(t => t.trim()) } : undefined,
    };
    
    handleSaveOption(option, true);
    setNewOption({ id: '', emoji: '🍽️', label_it: '', label_en: '', gradient: 'from-accent/20 to-accent/5', tags: '' });
  };

  return (
    <div className="mt-3 pt-3 border-t border-border/20">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        {step.options.length} opzioni
      </button>
      
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="pt-3 space-y-2">
              {step.options.map((option) => (
                <div 
                  key={option.id} 
                  className="flex items-center gap-3 p-2 rounded-lg bg-background/50 border border-border/20"
                >
                  <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
                  <span className="text-lg">{option.emoji}</span>
                  <span className="flex-1 text-sm font-medium">
                    {option.label[currentLanguage as 'it' | 'en'] || option.label.it}
                  </span>
                  {option.filters?.tags && (
                    <span className="text-xs text-muted-foreground">
                      Tags: {option.filters.tags.join(', ')}
                    </span>
                  )}
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditingOption(option)}>
                        <Edit2 className="w-3.5 h-3.5" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Modifica Opzione</DialogTitle>
                      </DialogHeader>
                      {editingOption && editingOption.id === option.id && (
                        <div className="space-y-4 pt-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Emoji</label>
                              <Input
                                value={editingOption.emoji}
                                onChange={(e) => setEditingOption({ ...editingOption, emoji: e.target.value })}
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Gradient CSS</label>
                              <Input
                                value={editingOption.gradient}
                                onChange={(e) => setEditingOption({ ...editingOption, gradient: e.target.value })}
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Label IT</label>
                              <Input
                                value={editingOption.label.it}
                                onChange={(e) => setEditingOption({
                                  ...editingOption,
                                  label: { ...editingOption.label, it: e.target.value }
                                })}
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm text-muted-foreground">Label EN</label>
                              <Input
                                value={editingOption.label.en || ''}
                                onChange={(e) => setEditingOption({
                                  ...editingOption,
                                  label: { ...editingOption.label, en: e.target.value }
                                })}
                              />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm text-muted-foreground">Tags filtro (separati da virgola)</label>
                            <Input
                              value={editingOption.filters?.tags?.join(', ') || ''}
                              onChange={(e) => setEditingOption({
                                ...editingOption,
                                filters: { ...editingOption.filters, tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean) }
                              })}
                              placeholder="pranzo, veloce, leggero"
                            />
                          </div>
                          <div className="flex gap-2">
                            <Switch
                              checked={editingOption.filters?.is_featured || false}
                              onCheckedChange={(checked) => setEditingOption({
                                ...editingOption,
                                filters: { ...editingOption.filters, is_featured: checked }
                              })}
                            />
                            <span className="text-sm">Filtra per piatti in evidenza</span>
                          </div>
                          <div className="flex gap-2">
                            <Switch
                              checked={editingOption.filters?.is_seasonal || false}
                              onCheckedChange={(checked) => setEditingOption({
                                ...editingOption,
                                filters: { ...editingOption.filters, is_seasonal: checked }
                              })}
                            />
                            <span className="text-sm">Filtra per piatti di stagione</span>
                          </div>
                          <Button onClick={() => handleSaveOption(editingOption)} disabled={isSaving} className="w-full">
                            {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                            Salva
                          </Button>
                        </div>
                      )}
                    </DialogContent>
                  </Dialog>
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleDeleteOption(option.id)}>
                    <Trash2 className="w-3.5 h-3.5 text-destructive" />
                  </Button>
                </div>
              ))}
              
              {/* Add new option */}
              <Dialog open={isAddingOption} onOpenChange={setIsAddingOption}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="w-full mt-2">
                    <Plus className="w-4 h-4 mr-2" />
                    Aggiungi opzione
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Nuova Opzione</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm text-muted-foreground">ID (univoco)</label>
                        <Input
                          value={newOption.id}
                          onChange={(e) => setNewOption({ ...newOption, id: e.target.value })}
                          placeholder="es: pranzo_veloce"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm text-muted-foreground">Emoji</label>
                        <Input
                          value={newOption.emoji}
                          onChange={(e) => setNewOption({ ...newOption, emoji: e.target.value })}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm text-muted-foreground">Label IT</label>
                        <Input
                          value={newOption.label_it}
                          onChange={(e) => setNewOption({ ...newOption, label_it: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm text-muted-foreground">Label EN</label>
                        <Input
                          value={newOption.label_en}
                          onChange={(e) => setNewOption({ ...newOption, label_en: e.target.value })}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm text-muted-foreground">Tags filtro (separati da virgola)</label>
                      <Input
                        value={newOption.tags}
                        onChange={(e) => setNewOption({ ...newOption, tags: e.target.value })}
                        placeholder="pranzo, veloce, leggero"
                      />
                    </div>
                    <Button onClick={handleAddNewOption} disabled={isSaving} className="w-full">
                      {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                      Aggiungi
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
