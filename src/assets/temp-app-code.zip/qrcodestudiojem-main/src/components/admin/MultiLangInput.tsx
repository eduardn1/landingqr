import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';

interface Language {
  code: string;
  label: string;
  flag: string;
}

const LANGUAGES: Language[] = [
  { code: 'it', label: 'Italiano', flag: '🇮🇹' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
  { code: 'es', label: 'Español', flag: '🇪🇸' },
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
];

export type MultiLangValue = {
  it?: string;
  en?: string;
  de?: string;
  es?: string;
  fr?: string;
};

interface MultiLangInputProps {
  label?: string;
  value: MultiLangValue;
  onChange: (value: MultiLangValue) => void;
  placeholder?: string;
  multiline?: boolean;
  rows?: number;
  required?: boolean;
  languages?: string[]; // Subset of languages to show
}

export function MultiLangInput({
  label,
  value = {},
  onChange,
  placeholder = '',
  multiline = false,
  rows = 2,
  required = false,
  languages = ['it', 'en', 'de', 'es', 'fr'],
}: MultiLangInputProps) {
  const [activeTab, setActiveTab] = useState('it');
  const filteredLangs = LANGUAGES.filter(l => languages.includes(l.code));

  const handleChange = (langCode: string, newValue: string) => {
    onChange({
      ...value,
      [langCode]: newValue,
    });
  };

  return (
    <div className="space-y-2">
      {label && (
        <Label className="text-xs text-muted-foreground">
          {label} {required && <span className="text-destructive">*</span>}
        </Label>
      )}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="h-8 w-full grid" style={{ gridTemplateColumns: `repeat(${filteredLangs.length}, 1fr)` }}>
          {filteredLangs.map((lang) => (
            <TabsTrigger
              key={lang.code}
              value={lang.code}
              className="text-xs gap-1 px-1 data-[state=active]:bg-accent"
            >
              <span>{lang.flag}</span>
              <span className="hidden sm:inline">{lang.code.toUpperCase()}</span>
            </TabsTrigger>
          ))}
        </TabsList>
        {filteredLangs.map((lang) => (
          <TabsContent key={lang.code} value={lang.code} className="mt-2">
            {multiline ? (
              <Textarea
                value={value[lang.code as keyof MultiLangValue] || ''}
                onChange={(e) => handleChange(lang.code, e.target.value)}
                placeholder={`${placeholder} (${lang.label})`}
                rows={rows}
                className="text-sm"
              />
            ) : (
              <Input
                value={value[lang.code as keyof MultiLangValue] || ''}
                onChange={(e) => handleChange(lang.code, e.target.value)}
                placeholder={`${placeholder} (${lang.label})`}
                className="text-sm"
              />
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

// Simple version with side-by-side inputs for 2 languages (IT/EN primary)
interface TwoLangInputProps {
  labelIt?: string;
  labelEn?: string;
  valueIt: string;
  valueEn: string;
  onChangeIt: (value: string) => void;
  onChangeEn: (value: string) => void;
  placeholderIt?: string;
  placeholderEn?: string;
  multiline?: boolean;
  rows?: number;
}

export function TwoLangInput({
  labelIt = 'IT',
  labelEn = 'EN',
  valueIt,
  valueEn,
  onChangeIt,
  onChangeEn,
  placeholderIt = '',
  placeholderEn = '',
  multiline = false,
  rows = 2,
}: TwoLangInputProps) {
  const InputComponent = multiline ? Textarea : Input;

  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="space-y-1.5">
        <Label className="text-xs text-muted-foreground flex items-center gap-1">
          🇮🇹 {labelIt}
        </Label>
        <InputComponent
          value={valueIt}
          onChange={(e) => onChangeIt(e.target.value)}
          placeholder={placeholderIt}
          {...(multiline ? { rows } : {})}
        />
      </div>
      <div className="space-y-1.5">
        <Label className="text-xs text-muted-foreground flex items-center gap-1">
          🇬🇧 {labelEn}
        </Label>
        <InputComponent
          value={valueEn}
          onChange={(e) => onChangeEn(e.target.value)}
          placeholder={placeholderEn}
          {...(multiline ? { rows } : {})}
        />
      </div>
    </div>
  );
}

export { LANGUAGES };
