import { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, MessageSquare, Save, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';
import type { RestaurantConfig } from '@/hooks/useRestaurantConfig';

interface OnboardingVariantSelectorProps {
  config: RestaurantConfig | undefined;
}

export function OnboardingVariantSelector({ config }: OnboardingVariantSelectorProps) {
  const queryClient = useQueryClient();
  const [variant, setVariant] = useState<string>(config?.onboarding_variant || 'interactive');
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    if (!config?.id) return;
    setIsSaving(true);

    try {
      const { error } = await supabase
        .from('restaurant_config')
        .update({ onboarding_variant: variant })
        .eq('id', config.id);

      if (error) throw error;
      toast.success('Variante salvata!');
      queryClient.invalidateQueries({ queryKey: ['restaurant-config'] });
    } catch (error) {
      console.error('Error saving variant:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  const variants = [
    {
      key: 'interactive',
      icon: Sparkles,
      title: 'Onboarding Interattivo',
      description: 'Scelta tema + azioni rapide (Menu, Prenota, Ordina...)',
      color: 'text-purple-500 bg-purple-500/10',
    },
    {
      key: 'quiz',
      icon: MessageSquare,
      title: 'Quiz Preferenze',
      description: 'Questionario personalizzato per scoprire preferenze',
      color: 'text-blue-500 bg-blue-500/10',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Variante Onboarding</h2>
      </div>
      
      <p className="text-sm text-muted-foreground">
        Scegli quale esperienza mostrare ai nuovi utenti quando aprono l'app
      </p>

      <RadioGroup
        value={variant}
        onValueChange={setVariant}
        className="grid grid-cols-1 sm:grid-cols-2 gap-4"
      >
        {variants.map((v) => {
          const Icon = v.icon;
          const isSelected = variant === v.key;
          
          return (
            <Label
              key={v.key}
              htmlFor={v.key}
              className={`
                relative flex flex-col p-4 rounded-xl border-2 cursor-pointer transition-all
                ${isSelected 
                  ? 'border-accent bg-accent/5' 
                  : 'border-border hover:border-accent/50'
                }
              `}
            >
              <RadioGroupItem value={v.key} id={v.key} className="sr-only" />
              
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${v.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-semibold">{v.title}</p>
                  <p className="text-xs text-muted-foreground mt-1">{v.description}</p>
                </div>
              </div>
              
              {isSelected && (
                <div className="absolute top-2 right-2 w-3 h-3 rounded-full bg-accent" />
              )}
            </Label>
          );
        })}
      </RadioGroup>

      <Button onClick={handleSave} disabled={isSaving} className="w-full">
        {isSaving ? (
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        ) : (
          <Save className="w-4 h-4 mr-2" />
        )}
        Salva Variante
      </Button>
    </motion.div>
  );
}
