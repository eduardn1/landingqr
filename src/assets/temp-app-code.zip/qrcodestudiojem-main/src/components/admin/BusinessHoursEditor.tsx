import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Clock, Info, AlertCircle, CheckCircle2, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';

interface TimeRange {
  open: string;
  close: string;
}

interface BusinessDay {
  day: string;
  ranges: TimeRange[];
  closed: boolean;
}

// Legacy format support
interface LegacyBusinessDay {
  day: string;
  open: string;
  close: string;
  closed: boolean;
}

const DAYS_IT: Record<string, string> = {
  monday: 'Lunedì',
  tuesday: 'Martedì',
  wednesday: 'Mercoledì',
  thursday: 'Giovedì',
  friday: 'Venerdì',
  saturday: 'Sabato',
  sunday: 'Domenica'
};

const DEFAULT_HOURS: BusinessDay[] = [
  { day: 'monday', ranges: [{ open: '12:00', close: '14:30' }, { open: '19:00', close: '23:00' }], closed: false },
  { day: 'tuesday', ranges: [{ open: '12:00', close: '14:30' }, { open: '19:00', close: '23:00' }], closed: false },
  { day: 'wednesday', ranges: [{ open: '12:00', close: '14:30' }, { open: '19:00', close: '23:00' }], closed: false },
  { day: 'thursday', ranges: [{ open: '12:00', close: '14:30' }, { open: '19:00', close: '23:00' }], closed: false },
  { day: 'friday', ranges: [{ open: '12:00', close: '14:30' }, { open: '19:00', close: '23:00' }], closed: false },
  { day: 'saturday', ranges: [{ open: '12:00', close: '14:30' }, { open: '19:00', close: '23:00' }], closed: false },
  { day: 'sunday', ranges: [{ open: '12:00', close: '14:30' }, { open: '19:00', close: '23:00' }], closed: true },
];

// Convert legacy format to new format
function convertToNewFormat(hours: (BusinessDay | LegacyBusinessDay)[]): BusinessDay[] {
  return hours.map(h => {
    if ('ranges' in h) {
      return h as BusinessDay;
    }
    // Legacy format
    const legacy = h as LegacyBusinessDay;
    return {
      day: legacy.day,
      ranges: legacy.closed ? [] : [{ open: legacy.open, close: legacy.close }],
      closed: legacy.closed
    };
  });
}

interface BusinessHoursEditorProps {
  configId: string;
  initialHours?: (BusinessDay | LegacyBusinessDay)[];
  onSave?: () => void;
}

export function BusinessHoursEditor({ configId, initialHours, onSave }: BusinessHoursEditorProps) {
  const { toast } = useToast();
  const [hours, setHours] = useState<BusinessDay[]>(DEFAULT_HOURS);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (initialHours && initialHours.length > 0) {
      setHours(convertToNewFormat(initialHours));
    }
  }, [initialHours]);

  const updateDay = (dayIndex: number, updates: Partial<BusinessDay>) => {
    const newHours = [...hours];
    newHours[dayIndex] = { ...newHours[dayIndex], ...updates };
    setHours(newHours);
  };

  const updateRange = (dayIndex: number, rangeIndex: number, updates: Partial<TimeRange>) => {
    const newHours = [...hours];
    newHours[dayIndex].ranges[rangeIndex] = { ...newHours[dayIndex].ranges[rangeIndex], ...updates };
    setHours(newHours);
  };

  const addRange = (dayIndex: number) => {
    const newHours = [...hours];
    newHours[dayIndex].ranges.push({ open: '19:00', close: '23:00' });
    setHours(newHours);
  };

  const removeRange = (dayIndex: number, rangeIndex: number) => {
    const newHours = [...hours];
    newHours[dayIndex].ranges.splice(rangeIndex, 1);
    setHours(newHours);
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('restaurant_config')
        .update({ business_hours: hours as any })
        .eq('id', configId);

      if (error) throw error;
      
      toast({ title: 'Orari salvati!', description: 'Gli orari sono sincronizzati con il sistema prenotazioni.' });
      onSave?.();
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    } finally {
      setIsSaving(false);
    }
  };

  const copyToAll = (sourceIndex: number) => {
    const source = hours[sourceIndex];
    const newHours = hours.map((h, i) => 
      i === sourceIndex ? h : { ...h, ranges: [...source.ranges.map(r => ({ ...r }))], closed: source.closed }
    );
    setHours(newHours);
  };

  return (
    <div className="space-y-6">
      {/* Info Banner */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-start gap-3 p-4 rounded-xl bg-accent/10 border border-accent/20"
      >
        <Info className="w-5 h-5 text-accent mt-0.5 shrink-0" />
        <div className="space-y-1">
          <p className="text-sm font-medium text-foreground">Orari con fasce multiple</p>
          <p className="text-xs text-muted-foreground">
            Puoi aggiungere più fasce orarie per ogni giorno (es: pranzo 12:00-14:30 e cena 19:00-23:00). 
            I clienti potranno prenotare solo negli orari di apertura.
          </p>
        </div>
      </motion.div>

      {/* Hours Grid */}
      <div className="space-y-3">
        {hours.map((day, dayIndex) => (
          <motion.div
            key={day.day}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: dayIndex * 0.05 }}
            className={cn(
              "p-4 rounded-xl border transition-all",
              day.closed 
                ? "bg-muted/30 border-border/30" 
                : "bg-card border-border hover:border-accent/30"
            )}
          >
            <div className="flex items-center justify-between mb-3">
              {/* Day Name */}
              <div className="flex items-center gap-2">
                {day.closed ? (
                  <AlertCircle className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                )}
                <span className={cn(
                  "font-medium",
                  day.closed ? "text-muted-foreground" : "text-foreground"
                )}>
                  {DAYS_IT[day.day]}
                </span>
              </div>

              {/* Closed Toggle */}
              <div className="flex items-center gap-2">
                <Switch
                  checked={!day.closed}
                  onCheckedChange={(checked) => {
                    updateDay(dayIndex, { 
                      closed: !checked,
                      ranges: !checked ? [] : (day.ranges.length === 0 ? [{ open: '12:00', close: '23:00' }] : day.ranges)
                    });
                  }}
                />
                <Label className="text-xs text-muted-foreground w-14">
                  {day.closed ? 'Chiuso' : 'Aperto'}
                </Label>
              </div>
            </div>

            {/* Time Ranges */}
            {!day.closed && (
              <div className="space-y-2">
                {day.ranges.map((range, rangeIndex) => (
                  <div key={rangeIndex} className="flex items-center gap-2 flex-wrap">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <Input
                      type="time"
                      value={range.open}
                      onChange={(e) => updateRange(dayIndex, rangeIndex, { open: e.target.value })}
                      className="w-28 h-9"
                    />
                    <span className="text-muted-foreground">-</span>
                    <Input
                      type="time"
                      value={range.close}
                      onChange={(e) => updateRange(dayIndex, rangeIndex, { close: e.target.value })}
                      className="w-28 h-9"
                    />
                    {day.ranges.length > 1 && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-9 w-9 text-red-500 hover:text-red-600 hover:bg-red-500/10"
                        onClick={() => removeRange(dayIndex, rangeIndex)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
                
                <div className="flex items-center gap-2 mt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => addRange(dayIndex)}
                    className="text-xs"
                  >
                    <Plus className="w-3 h-3 mr-1" />
                    Aggiungi fascia
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToAll(dayIndex)}
                    className="text-xs text-muted-foreground hover:text-foreground"
                  >
                    Applica a tutti
                  </Button>
                </div>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Tips */}
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30 border border-border/30">
          <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center shrink-0">
            <Clock className="w-4 h-4 text-blue-500" />
          </div>
          <div>
            <p className="text-xs font-medium">Orario spezzato</p>
            <p className="text-xs text-muted-foreground">Aggiungi due fasce per pranzo e cena separati.</p>
          </div>
        </div>
        <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30 border border-border/30">
          <div className="w-8 h-8 rounded-full bg-orange-500/10 flex items-center justify-center shrink-0">
            <AlertCircle className="w-4 h-4 text-orange-500" />
          </div>
          <div>
            <p className="text-xs font-medium">Giorni di chiusura</p>
            <p className="text-xs text-muted-foreground">I giorni chiusi non saranno disponibili nel calendario prenotazioni.</p>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <Button onClick={handleSave} disabled={isSaving} className="w-full">
        {isSaving ? 'Salvataggio...' : 'Salva Orari'}
      </Button>
    </div>
  );
}
