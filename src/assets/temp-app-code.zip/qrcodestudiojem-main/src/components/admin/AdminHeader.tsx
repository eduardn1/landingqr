import { useNavigate } from 'react-router-dom';
import { RefreshCw, Menu, X, Home, Sun, Moon } from 'lucide-react';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { AdminNotificationBell } from './AdminNotificationBell';
import { getSectionTitle, getGroupTitle, AdminSection } from './AdminSidebar';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';

interface AdminHeaderProps {
  activeSection: AdminSection;
  onRefresh: () => void;
  onMobileMenuToggle: () => void;
  isMobileMenuOpen: boolean;
}

export function AdminHeader({ 
  activeSection, 
  onRefresh, 
  onMobileMenuToggle, 
  isMobileMenuOpen 
}: AdminHeaderProps) {
  const navigate = useNavigate();
  const { setTheme, resolvedTheme } = useTheme();
  const groupTitle = getGroupTitle(activeSection);
  const sectionTitle = getSectionTitle(activeSection);
  const isDark = resolvedTheme === 'dark';

  const handleThemeToggle = () => {
    const newTheme = isDark ? 'light' : 'dark';
    setTheme(newTheme);
    if (newTheme === 'light') {
      document.documentElement.classList.remove('dark');
      document.documentElement.style.colorScheme = 'light';
    } else {
      document.documentElement.classList.add('dark');
      document.documentElement.style.colorScheme = 'dark';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border">
      <div className="flex items-center justify-between h-14 px-3 sm:px-4">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          {/* Mobile menu toggle - only show on small screens */}
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onMobileMenuToggle} 
            className="md:hidden h-9 w-9 shrink-0"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>

          {/* Back to app */}
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate('/')} 
            className="h-9 w-9 shrink-0"
            title="Torna all'app"
          >
            <Home className="w-4 h-4" />
          </Button>

          {/* Breadcrumb - hide on very small screens */}
          <Breadcrumb className="hidden sm:flex min-w-0">
            <BreadcrumbList className="flex-wrap">
              <BreadcrumbItem className="hidden lg:flex">
                <BreadcrumbLink 
                  onClick={() => navigate('/')}
                  className="cursor-pointer"
                >
                  App
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator className="hidden lg:flex" />
              <BreadcrumbItem>
                <BreadcrumbLink className="text-xs sm:text-sm">
                  {groupTitle}
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage className="font-medium text-xs sm:text-sm truncate max-w-[120px] sm:max-w-none">
                  {sectionTitle}
                </BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>

          {/* Mobile title - very compact */}
          <h1 className="sm:hidden text-sm font-semibold truncate">{sectionTitle}</h1>
        </div>

        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleThemeToggle}
            className="h-9 w-9"
            title={isDark ? 'Modalità chiara' : 'Modalità scura'}
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
          <AdminNotificationBell />
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={onRefresh}
            className="h-9 w-9"
            title="Aggiorna"
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
