import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Info, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface CapacitySettingsProps {
  configId: string;
  initialCapacity?: number;
  onSave?: () => void;
}

export function CapacitySettings({ configId, initialCapacity = 20, onSave }: CapacitySettingsProps) {
  const { toast } = useToast();
  const [maxGuests, setMaxGuests] = useState(initialCapacity);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (initialCapacity) {
      setMaxGuests(initialCapacity);
    }
  }, [initialCapacity]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('restaurant_config')
        .update({ max_guests_per_slot: maxGuests })
        .eq('id', configId);

      if (error) throw error;
      
      toast({ title: 'Capacità salvata!' });
      onSave?.();
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Info Banner */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-start gap-3 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20"
      >
        <Info className="w-5 h-5 text-blue-500 mt-0.5 shrink-0" />
        <div className="space-y-1">
          <p className="text-sm font-medium text-foreground">Capacità massima</p>
          <p className="text-xs text-muted-foreground">
            Imposta il numero massimo di ospiti che possono prenotare per ogni fascia oraria. 
            Quando si raggiunge il limite, lo slot non sarà più disponibile.
          </p>
        </div>
      </motion.div>

      {/* Capacity Setting */}
      <div className="p-6 rounded-xl bg-secondary/30 border border-border/30 space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-accent/10 flex items-center justify-center">
            <Users className="w-7 h-7 text-accent" />
          </div>
          <div>
            <h3 className="font-semibold text-lg">Coperti per fascia oraria</h3>
            <p className="text-sm text-muted-foreground">
              Massimo ospiti contemporanei per ogni slot di 30 minuti
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-sm">Numero massimo ospiti</Label>
            <div className="flex items-center gap-2">
              <Input
                type="number"
                min={1}
                max={200}
                value={maxGuests}
                onChange={(e) => setMaxGuests(parseInt(e.target.value) || 1)}
                className="w-20 h-9 text-center"
              />
              <span className="text-sm text-muted-foreground">persone</span>
            </div>
          </div>

          <Slider
            value={[maxGuests]}
            onValueChange={([value]) => setMaxGuests(value)}
            min={1}
            max={100}
            step={1}
            className="py-4"
          />

          <div className="flex justify-between text-xs text-muted-foreground">
            <span>1</span>
            <span>25</span>
            <span>50</span>
            <span>75</span>
            <span>100</span>
          </div>
        </div>

        {/* Preview */}
        <div className="p-4 rounded-lg bg-background/50 border border-border/30">
          <p className="text-sm text-muted-foreground mb-2">Esempio:</p>
          <p className="text-sm">
            Se hai <span className="font-semibold text-accent">{maxGuests} coperti</span> per fascia oraria, 
            e qualcuno prenota per 4 persone alle 20:00, rimarranno disponibili{' '}
            <span className="font-semibold">{Math.max(0, maxGuests - 4)} posti</span> per lo stesso orario.
          </p>
        </div>
      </div>

      {/* Save Button */}
      <Button onClick={handleSave} disabled={isSaving} className="w-full">
        <Save className="w-4 h-4 mr-2" />
        {isSaving ? 'Salvataggio...' : 'Salva Capacità'}
      </Button>
    </div>
  );
}
