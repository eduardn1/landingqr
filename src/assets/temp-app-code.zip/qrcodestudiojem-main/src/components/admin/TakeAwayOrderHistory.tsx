import { useState } from 'react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { 
  Calendar, Search, Package, Truck, CheckCircle2, XCircle, 
  Clock, User, Phone, MapPin, TrendingUp, Euro, Filter, ChevronRight
} from 'lucide-react';
import { useTakeAwayOrderHistory, useTakeAwayStats } from '@/hooks/useTakeAwayOrderHistory';
import { TakeAwayOrder, useUpdateTakeAwayOrderStatus } from '@/hooks/useTakeAwayOrders';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';

const statusConfig: Record<string, { label: string; color: string; icon: any }> = {
  pending: { label: 'In attesa', color: 'bg-yellow-500', icon: Clock },
  accepted: { label: 'Accettato', color: 'bg-blue-500', icon: CheckCircle2 },
  preparing: { label: 'In preparazione', color: 'bg-purple-500', icon: Package },
  ready: { label: 'Pronto', color: 'bg-green-500', icon: Package },
  delivering: { label: 'In consegna', color: 'bg-indigo-500', icon: Truck },
  completed: { label: 'Completato', color: 'bg-emerald-600', icon: CheckCircle2 },
  rejected: { label: 'Rifiutato', color: 'bg-red-500', icon: XCircle },
  cancelled: { label: 'Annullato', color: 'bg-gray-500', icon: XCircle },
};

// Active statuses that should still be manageable
const activeStatuses = ['pending', 'accepted', 'preparing', 'ready', 'delivering'];

export function TakeAwayOrderHistory() {
  const queryClient = useQueryClient();
  const updateStatus = useUpdateTakeAwayOrderStatus();
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [statsPeriod, setStatsPeriod] = useState<'today' | 'week' | 'month'>('week');

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      await updateStatus.mutateAsync({ orderId, status: newStatus, sendWhatsApp: false });
      toast.success(`Stato aggiornato: ${statusConfig[newStatus]?.label}`);
      queryClient.invalidateQueries({ queryKey: ['takeaway-order-history'] });
    } catch (error: any) {
      toast.error(error.message || 'Errore aggiornamento');
    }
  };

  const { data: orders = [], isLoading } = useTakeAwayOrderHistory({
    startDate,
    endDate,
    status: statusFilter,
    orderType: typeFilter,
  });

  const { data: stats } = useTakeAwayStats(statsPeriod);

  // Filter by search query
  const filteredOrders = orders.filter(order => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      order.order_number?.toLowerCase().includes(query) ||
      order.customer_name.toLowerCase().includes(query) ||
      order.customer_phone.includes(query)
    );
  });

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-secondary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-accent/20 rounded-lg">
                <Package className="w-5 h-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats?.totalOrders || 0}</p>
                <p className="text-xs text-muted-foreground">Ordini totali</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <Euro className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">€{stats?.totalRevenue?.toFixed(0) || 0}</p>
                <p className="text-xs text-muted-foreground">Incasso</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <TrendingUp className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">€{stats?.averageOrderValue?.toFixed(0) || 0}</p>
                <p className="text-xs text-muted-foreground">Media ordine</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <Clock className="w-5 h-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats?.averageDeliveryTime || 0}m</p>
                <p className="text-xs text-muted-foreground">Tempo medio</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Stats Period Selector */}
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground">Statistiche:</span>
        <div className="flex gap-1">
          {(['today', 'week', 'month'] as const).map((period) => (
            <Button
              key={period}
              variant={statsPeriod === period ? 'default' : 'outline'}
              size="sm"
              onClick={() => setStatsPeriod(period)}
            >
              {period === 'today' ? 'Oggi' : period === 'week' ? '7 giorni' : '30 giorni'}
            </Button>
          ))}
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtri
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="text-sm"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">—</span>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="text-sm"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Stato" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutti gli stati</SelectItem>
                <SelectItem value="pending">In attesa</SelectItem>
                <SelectItem value="completed">Completati</SelectItem>
                <SelectItem value="cancelled">Annullati</SelectItem>
                <SelectItem value="rejected">Rifiutati</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tutti i tipi</SelectItem>
                <SelectItem value="pickup">Solo ritiro</SelectItem>
                <SelectItem value="delivery">Solo consegna</SelectItem>
              </SelectContent>
            </Select>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Cerca ordine, cliente..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Orders Table */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 text-center text-muted-foreground">Caricamento...</div>
          ) : filteredOrders.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              Nessun ordine trovato con i filtri selezionati
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Ordine</TableHead>
                    <TableHead>Data/Ora</TableHead>
                    <TableHead>Cliente</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Stato</TableHead>
                    <TableHead className="text-right">Totale</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders.map((order) => (
                    <Collapsible key={order.id} asChild>
                      <>
                        <CollapsibleTrigger asChild>
                          <TableRow 
                            className="cursor-pointer hover:bg-secondary/30"
                            onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                          >
                            <TableCell className="font-medium">
                              #{order.order_number}
                            </TableCell>
                            <TableCell>
                              <div className="text-sm">
                                {format(new Date(order.created_at), 'dd/MM/yy', { locale: it })}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {format(new Date(order.created_at), 'HH:mm', { locale: it })}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <User className="w-3 h-3 text-muted-foreground" />
                                <span className="truncate max-w-[120px]">{order.customer_name}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant={order.order_type === 'pickup' ? 'secondary' : 'outline'} className="text-xs">
                                {order.order_type === 'pickup' ? 'Ritiro' : 'Consegna'}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge 
                                variant="outline" 
                                className={cn("text-xs text-white border-0", statusConfig[order.status]?.color)}
                              >
                                {statusConfig[order.status]?.label}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right font-bold">
                              €{order.total.toFixed(2)}
                            </TableCell>
                          </TableRow>
                        </CollapsibleTrigger>
                        {expandedOrder === order.id && (
                          <TableRow>
                            <TableCell colSpan={6} className="bg-secondary/10 p-4">
                              <OrderDetails order={order} onStatusChange={handleStatusChange} />
                            </TableCell>
                          </TableRow>
                        )}
                      </>
                    </Collapsible>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results count */}
      <p className="text-sm text-muted-foreground text-center">
        {filteredOrders.length} ordini trovati
      </p>
    </div>
  );
}

function OrderDetails({ order, onStatusChange }: { order: TakeAwayOrder; onStatusChange: (orderId: string, status: string) => void }) {
  const isActive = activeStatuses.includes(order.status);
  
  return (
    <div className="grid md:grid-cols-2 gap-4">
      {/* Customer Info */}
      <div className="space-y-2">
        <h4 className="font-semibold text-sm">Dettagli Cliente</h4>
        <div className="space-y-1 text-sm">
          <div className="flex items-center gap-2">
            <User className="w-3 h-3 text-muted-foreground" />
            <span>{order.customer_name}</span>
          </div>
          <div className="flex items-center gap-2">
            <Phone className="w-3 h-3 text-muted-foreground" />
            <a href={`tel:${order.customer_phone}`} className="text-accent hover:underline">
              {order.customer_phone}
            </a>
          </div>
          {order.delivery_address && (
            <div className="flex items-start gap-2">
              <MapPin className="w-3 h-3 text-muted-foreground mt-0.5" />
              <span>
                {order.delivery_address.street}, {order.delivery_address.city}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Order Items */}
      <div className="space-y-2">
        <h4 className="font-semibold text-sm">Articoli ordinati</h4>
        <ul className="space-y-1 text-sm">
          {order.items.map((item: any, idx: number) => (
            <li key={idx} className="flex justify-between">
              <span>{item.quantity}x {item.name}</span>
              <span className="text-muted-foreground">€{(item.price * item.quantity).toFixed(2)}</span>
            </li>
          ))}
        </ul>
        <div className="border-t pt-2 mt-2 flex justify-between font-semibold">
          <span>Totale</span>
          <span className="text-accent">€{order.total.toFixed(2)}</span>
        </div>
      </div>

      {/* Timestamps */}
      <div className="md:col-span-2 space-y-2">
        <h4 className="font-semibold text-sm">Timeline</h4>
        <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
          <span>Creato: {format(new Date(order.created_at), 'dd/MM HH:mm')}</span>
          {order.accepted_at && (
            <span>Accettato: {format(new Date(order.accepted_at), 'HH:mm')}</span>
          )}
          {order.ready_at && (
            <span>Pronto: {format(new Date(order.ready_at), 'HH:mm')}</span>
          )}
          {order.completed_at && (
            <span>Completato: {format(new Date(order.completed_at), 'HH:mm')}</span>
          )}
        </div>
        {order.special_notes && (
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-2 mt-2">
            <p className="text-sm"><strong>Note:</strong> {order.special_notes}</p>
          </div>
        )}
      </div>

      {/* Status change actions for stuck/active orders */}
      {isActive && (
        <div className="md:col-span-2 pt-2 border-t">
          <h4 className="font-semibold text-sm mb-2 text-yellow-600">⚠️ Ordine ancora attivo - Cambia stato:</h4>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => onStatusChange(order.id, 'completed')}>
              <CheckCircle2 className="w-3 h-3 mr-1" /> Completa
            </Button>
            <Button size="sm" variant="outline" onClick={() => onStatusChange(order.id, 'cancelled')}>
              <XCircle className="w-3 h-3 mr-1" /> Annulla
            </Button>
            <Button size="sm" variant="destructive" onClick={() => onStatusChange(order.id, 'rejected')}>
              <XCircle className="w-3 h-3 mr-1" /> Rifiuta
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}