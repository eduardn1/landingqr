import { useState } from 'react';
import { motion } from 'framer-motion';
import { Save, Loader2, Edit2, Eye, EyeOff, ChevronUp, ChevronDown, Plus, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAllHomeSections, type HomeSection } from '@/hooks/useHomeSections';
import { MultiLangInput, type MultiLangValue } from './MultiLangInput';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

interface HomeSectionsEditorProps {
  currentLanguage: string;
}

// Section labels for display
const sectionLabels: Record<string, string> = {
  stories: 'Stories',
  action_grid: 'Pulsanti Azione',
  action_buttons: 'Pulsanti Azione',
  mood_selector: 'Mood Selector',
  featured: 'Piatti in Evidenza / Per Te',
  recommended: 'Consigliati per Te',
  shareable: 'Da Condividere',
  sharing: 'Da Condividere',
  favorites_shortcut: 'Preferiti (Shortcut)',
  restaurant_info: 'Info & Contatti',
  account: 'Account Utente',
  events: 'Eventi & Musica',
  promos: 'Promozioni',
  categories: 'Categorie',
  google_reviews: 'Recensioni Google',
  instagram_feed: 'Feed Instagram',
};

// Section icons for visual identification
const sectionIcons: Record<string, string> = {
  stories: '📸',
  action_grid: '🔲',
  action_buttons: '🔲',
  mood_selector: '😊',
  featured: '⭐',
  recommended: '✨',
  shareable: '👥',
  sharing: '👥',
  favorites_shortcut: '❤️',
  restaurant_info: '📍',
  account: '👤',
  events: '🎉',
  promos: '🏷️',
  categories: '📂',
  google_reviews: '⭐',
  instagram_feed: '📷',
};

export function HomeSectionsEditor({ currentLanguage }: HomeSectionsEditorProps) {
  const { sections, isLoading, invalidateAll, refetch } = useAllHomeSections();
  const [editingSection, setEditingSection] = useState<HomeSection | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [titleValue, setTitleValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });
  const [subtitleValue, setSubtitleValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });

  const handleToggleActive = async (section: HomeSection) => {
    try {
      const { error } = await supabase
        .from('home_sections')
        .update({ is_active: !section.is_active })
        .eq('id', section.id);

      if (error) throw error;
      toast.success(section.is_active ? 'Sezione nascosta dall\'homepage' : 'Sezione visibile in homepage');
      invalidateAll();
    } catch (error) {
      console.error('Error toggling section:', error);
      toast.error('Errore nell\'aggiornamento');
    }
  };

  const openEditDialog = (section: HomeSection) => {
    setEditingSection(section);
    setTitleValue({
      it: section.title?.it || '',
      en: section.title?.en || '',
      de: (section.title as any)?.de || '',
      es: (section.title as any)?.es || '',
      fr: (section.title as any)?.fr || '',
    });
    setSubtitleValue({
      it: section.subtitle?.it || '',
      en: section.subtitle?.en || '',
      de: (section.subtitle as any)?.de || '',
      es: (section.subtitle as any)?.es || '',
      fr: (section.subtitle as any)?.fr || '',
    });
  };

  const handleSaveEdit = async () => {
    if (!editingSection) return;
    setIsSaving(true);

    try {
      const { error } = await supabase
        .from('home_sections')
        .update({
          title: titleValue,
          subtitle: subtitleValue,
        })
        .eq('id', editingSection.id);

      if (error) throw error;
      toast.success('Sezione aggiornata');
      setEditingSection(null);
      invalidateAll();
    } catch (error) {
      console.error('Error saving section:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  const handleMoveUp = async (section: HomeSection, index: number) => {
    if (index === 0) return;
    const prevSection = sections[index - 1];
    const prevOrder = prevSection.display_order;
    const currentOrder = section.display_order;
    
    try {
      await Promise.all([
        supabase.from('home_sections').update({ display_order: currentOrder }).eq('id', prevSection.id),
        supabase.from('home_sections').update({ display_order: prevOrder }).eq('id', section.id)
      ]);
      
      toast.success('Ordine aggiornato');
      invalidateAll();
    } catch (error) {
      console.error('Error reordering:', error);
      toast.error('Errore nel riordinamento');
    }
  };

  const handleMoveDown = async (section: HomeSection, index: number) => {
    if (index === sections.length - 1) return;
    const nextSection = sections[index + 1];
    const nextOrder = nextSection.display_order;
    const currentOrder = section.display_order;
    
    try {
      await Promise.all([
        supabase.from('home_sections').update({ display_order: currentOrder }).eq('id', nextSection.id),
        supabase.from('home_sections').update({ display_order: nextOrder }).eq('id', section.id)
      ]);
      
      toast.success('Ordine aggiornato');
      invalidateAll();
    } catch (error) {
      console.error('Error reordering:', error);
      toast.error('Errore nel riordinamento');
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        {[1, 2, 3, 4, 5].map(i => (
          <Skeleton key={i} className="h-20 w-full rounded-2xl" />
        ))}
      </div>
    );
  }

  const activeSections = sections.filter(s => s.is_active);
  const inactiveSections = sections.filter(s => !s.is_active);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Gestione Sezioni Homepage</h2>
          <p className="text-sm text-muted-foreground">
            {activeSections.length} attive · {inactiveSections.length} nascoste
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={() => refetch()}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Aggiorna
        </Button>
      </div>

      {/* Active Sections */}
      <div className="space-y-3">
        <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
          <Eye className="w-4 h-4" />
          Sezioni Visibili ({activeSections.length})
        </h3>
        {activeSections.map((section, index) => (
          <SectionItem
            key={section.id}
            section={section}
            index={index}
            totalCount={activeSections.length}
            currentLanguage={currentLanguage}
            onMoveUp={() => handleMoveUp(section, sections.indexOf(section))}
            onMoveDown={() => handleMoveDown(section, sections.indexOf(section))}
            onToggle={() => handleToggleActive(section)}
            onEdit={() => openEditDialog(section)}
          />
        ))}
      </div>

      {/* Inactive Sections */}
      {inactiveSections.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <EyeOff className="w-4 h-4" />
            Sezioni Nascoste ({inactiveSections.length})
          </h3>
          {inactiveSections.map((section) => (
            <SectionItem
              key={section.id}
              section={section}
              index={0}
              totalCount={1}
              currentLanguage={currentLanguage}
              onMoveUp={() => {}}
              onMoveDown={() => {}}
              onToggle={() => handleToggleActive(section)}
              onEdit={() => openEditDialog(section)}
              isInactive
            />
          ))}
        </div>
      )}

      {/* Edit Dialog */}
      <Dialog open={!!editingSection} onOpenChange={(open) => !open && setEditingSection(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              Modifica: {editingSection && (sectionLabels[editingSection.section_key] || editingSection.section_key)}
            </DialogTitle>
          </DialogHeader>
          {editingSection && (
            <div className="space-y-4 pt-4">
              <MultiLangInput
                label="Titolo"
                value={titleValue}
                onChange={setTitleValue}
                placeholder="Titolo sezione"
              />
              <MultiLangInput
                label="Sottotitolo"
                value={subtitleValue}
                onChange={setSubtitleValue}
                placeholder="Sottotitolo sezione (opzionale)"
              />
              <Button onClick={handleSaveEdit} disabled={isSaving} className="w-full">
                {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                Salva Modifiche
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}

// Individual section item component
interface SectionItemProps {
  section: HomeSection;
  index: number;
  totalCount: number;
  currentLanguage: string;
  onMoveUp: () => void;
  onMoveDown: () => void;
  onToggle: () => void;
  onEdit: () => void;
  isInactive?: boolean;
}

function SectionItem({ 
  section, 
  index, 
  totalCount, 
  currentLanguage, 
  onMoveUp, 
  onMoveDown, 
  onToggle, 
  onEdit,
  isInactive 
}: SectionItemProps) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "p-4 rounded-2xl border flex items-center justify-between gap-4 transition-colors",
        isInactive 
          ? "bg-secondary/20 border-border/20 opacity-60" 
          : "bg-secondary/40 border-border/30"
      )}
    >
      <div className="flex items-center gap-3 flex-1 min-w-0">
        {/* Reorder buttons */}
        {!isInactive && (
          <div className="flex flex-col gap-0.5">
            <button
              onClick={onMoveUp}
              disabled={index === 0}
              className="p-1 hover:bg-secondary rounded disabled:opacity-20 transition-colors"
            >
              <ChevronUp className="w-4 h-4" />
            </button>
            <button
              onClick={onMoveDown}
              disabled={index === totalCount - 1}
              className="p-1 hover:bg-secondary rounded disabled:opacity-20 transition-colors"
            >
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Order badge */}
        {!isInactive && (
          <span className="w-7 h-7 rounded-full bg-accent/20 text-accent flex items-center justify-center text-xs font-bold flex-shrink-0">
            {index + 1}
          </span>
        )}

        {/* Icon */}
        <span className="text-xl flex-shrink-0">
          {sectionIcons[section.section_key] || '📄'}
        </span>

        {/* Info */}
        <div className="min-w-0 flex-1">
          <h3 className="font-medium text-sm truncate">
            {sectionLabels[section.section_key] || section.section_key.replace(/_/g, ' ')}
          </h3>
          {section.title?.[currentLanguage as 'it' | 'en'] && (
            <p className="text-xs text-muted-foreground truncate">
              {section.title[currentLanguage as 'it' | 'en']}
            </p>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 flex-shrink-0">
        <Button variant="ghost" size="icon" onClick={onEdit} className="h-8 w-8">
          <Edit2 className="w-4 h-4" />
        </Button>
        <Switch
          checked={section.is_active}
          onCheckedChange={onToggle}
        />
      </div>
    </motion.div>
  );
}
