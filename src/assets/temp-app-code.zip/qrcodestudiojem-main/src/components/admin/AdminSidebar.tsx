import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, UtensilsCrossed, CalendarDays, Users, 
  Megaphone, Settings, ChevronLeft, ChevronRight,
  ShoppingBag, Palette, MessageSquare, BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

export type AdminSection = 
  | 'overview' | 'branding' | 'about-us' | 'pwa' | 'seo' | 'templates' 
  | 'hours' | 'social' | 'closed-dates' | 'capacity' | 'reservations' 
  | 'customers' | 'whatsapp' | 'whatsapp-logs' | 'broadcast' | 'notifications' 
  | 'loyalty' | 'gamification' | 'cache' | 'dishes' | 'categories' 
  | 'allergens' | 'menu-view' | 'onboarding' | 'onboarding-actions' | 'moods' | 'stories' 
  | 'sections' | 'navigation' | 'action-buttons' | 'events' | 'promos' | 'promo-codes' | 'takeaway';

interface MenuGroup {
  id: string;
  label: string;
  icon: any;
  items: { id: AdminSection; label: string }[];
}

const menuGroups: MenuGroup[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    items: [
      { id: 'overview', label: 'Panoramica' },
    ]
  },
  {
    id: 'menu',
    label: 'Menu',
    icon: UtensilsCrossed,
    items: [
      { id: 'dishes', label: 'Piatti' },
      { id: 'categories', label: 'Categorie' },
      { id: 'allergens', label: 'Allergeni' },
      { id: 'menu-view', label: 'Vista Menu' },
    ]
  },
  {
    id: 'orders',
    label: 'Ordini',
    icon: CalendarDays,
    items: [
      { id: 'reservations', label: 'Prenotazioni' },
      { id: 'takeaway', label: 'Asporto & Delivery' },
      { id: 'hours', label: 'Orari' },
      { id: 'closed-dates', label: 'Chiusure' },
      { id: 'capacity', label: 'Capacità' },
    ]
  },
  {
    id: 'customers',
    label: 'Clienti',
    icon: Users,
    items: [
      { id: 'customers', label: 'Anagrafica' },
      { id: 'loyalty', label: 'Fedeltà' },
      { id: 'gamification', label: 'Gamification' },
    ]
  },
  {
    id: 'marketing',
    label: 'Marketing',
    icon: Megaphone,
    items: [
      { id: 'broadcast', label: 'Broadcast' },
      { id: 'notifications', label: 'Notifiche' },
      { id: 'promos', label: 'Banner Promo' },
      { id: 'promo-codes', label: 'Codici Sconto' },
      { id: 'events', label: 'Eventi' },
    ]
  },
  {
    id: 'content',
    label: 'Contenuti',
    icon: Palette,
    items: [
      { id: 'sections', label: 'Sezioni Home' },
      { id: 'action-buttons', label: 'Pulsanti' },
      { id: 'about-us', label: 'Chi Siamo' },
      { id: 'stories', label: 'Stories' },
      { id: 'moods', label: 'Mood' },
      { id: 'onboarding', label: 'Quiz' },
      { id: 'onboarding-actions', label: 'Onboarding Interattivo' },
    ]
  },
  {
    id: 'settings',
    label: 'Impostazioni',
    icon: Settings,
    items: [
      { id: 'branding', label: 'Brand & Contatti' },
      { id: 'templates', label: 'Template' },
      { id: 'navigation', label: 'Navigazione' },
      { id: 'social', label: 'Social' },
      { id: 'whatsapp', label: 'WhatsApp' },
      { id: 'whatsapp-logs', label: 'Log WA' },
      { id: 'seo', label: 'SEO' },
      { id: 'pwa', label: 'PWA' },
      { id: 'cache', label: 'Cache' },
    ]
  },
];

interface AdminSidebarProps {
  activeSection: AdminSection;
  onSectionChange: (section: AdminSection) => void;
  isCollapsed: boolean;
  onCollapsedChange: (collapsed: boolean) => void;
}

export function AdminSidebar({ 
  activeSection, 
  onSectionChange, 
  isCollapsed, 
  onCollapsedChange 
}: AdminSidebarProps) {
  const [expandedGroup, setExpandedGroup] = useState<string | null>(() => {
    // Find which group contains the active section
    const group = menuGroups.find(g => g.items.some(item => item.id === activeSection));
    return group?.id || 'dashboard';
  });

  const handleGroupClick = (groupId: string, firstItemId: AdminSection) => {
    if (isCollapsed) {
      // In collapsed mode, clicking goes directly to first item
      onSectionChange(firstItemId);
      onCollapsedChange(false);
    } else {
      setExpandedGroup(expandedGroup === groupId ? null : groupId);
    }
  };

  return (
    <TooltipProvider delayDuration={0}>
      <aside 
        className={cn(
          "h-full bg-card border-r border-border flex flex-col transition-all duration-300",
          isCollapsed ? "w-16" : "w-60"
        )}
      >
        {/* Collapse toggle - hide on smaller screens where sidebar is overlay */}
        <div className="p-2 border-b border-border hidden md:block">
          <Button
            variant="ghost"
            size="sm"
            className="w-full justify-center"
            onClick={() => onCollapsedChange(!isCollapsed)}
          >
            {isCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-2 space-y-1 overscroll-contain">
          {menuGroups.map((group) => {
            const isExpanded = expandedGroup === group.id;
            const isGroupActive = group.items.some(item => item.id === activeSection);
            const Icon = group.icon;

            return (
              <div key={group.id}>
                {isCollapsed ? (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        onClick={() => handleGroupClick(group.id, group.items[0].id)}
                        className={cn(
                          "w-full flex items-center justify-center p-3 rounded-lg transition-colors",
                          isGroupActive 
                            ? "bg-accent text-accent-foreground" 
                            : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                        )}
                      >
                        <Icon className="w-5 h-5" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="font-medium">
                      {group.label}
                    </TooltipContent>
                  </Tooltip>
                ) : (
                  <>
                    <button
                      onClick={() => handleGroupClick(group.id, group.items[0].id)}
                      className={cn(
                        "w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-colors text-sm font-medium touch-manipulation",
                        isGroupActive 
                          ? "bg-accent/10 text-accent" 
                          : "text-muted-foreground hover:bg-secondary hover:text-foreground active:bg-secondary/80"
                      )}
                    >
                      <Icon className="w-5 h-5 shrink-0" />
                      <span className="flex-1 text-left">{group.label}</span>
                      <ChevronRight className={cn(
                        "w-4 h-4 transition-transform shrink-0",
                        isExpanded && "rotate-90"
                      )} />
                    </button>

                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="ml-4 mt-1 space-y-0.5 border-l border-border pl-3"
                      >
                        {group.items.map((item) => (
                          <button
                            key={item.id}
                            onClick={() => onSectionChange(item.id)}
                            className={cn(
                              "w-full text-left px-3 py-2.5 rounded-md text-sm transition-colors touch-manipulation",
                              activeSection === item.id
                                ? "bg-accent text-accent-foreground font-medium"
                                : "text-muted-foreground hover:text-foreground hover:bg-secondary/50 active:bg-secondary"
                            )}
                          >
                            {item.label}
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </>
                )}
              </div>
            );
          })}
        </nav>

        {/* Bottom safe area for mobile */}
        <div className="h-safe-area-inset-bottom md:hidden" />
      </aside>
    </TooltipProvider>
  );
}

// Helper to get section title
export function getSectionTitle(section: AdminSection): string {
  for (const group of menuGroups) {
    const item = group.items.find(i => i.id === section);
    if (item) return item.label;
  }
  return 'Dashboard';
}

// Helper to get group title
export function getGroupTitle(section: AdminSection): string {
  for (const group of menuGroups) {
    if (group.items.some(i => i.id === section)) {
      return group.label;
    }
  }
  return 'Dashboard';
}
