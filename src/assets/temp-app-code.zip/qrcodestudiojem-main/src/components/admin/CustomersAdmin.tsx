import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, Users, Phone, Calendar, Heart, Bell, MapPin, Package, ChevronRight, X } from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';

interface CustomerProfile {
  id: string;
  user_id: string;
  phone: string;
  display_name: string | null;
  address: string | null;
  city: string | null;
  zip_code: string | null;
  apartment_floor: string | null;
  delivery_notes: string | null;
  push_notifications: boolean;
  whatsapp_notifications: boolean;
  created_at: string;
  updated_at: string;
  favorites_count?: number;
  reservations_count?: number;
  orders_count?: number;
}

interface Reservation {
  id: string;
  reservation_date: string;
  reservation_time: string;
  guests: number;
  status: string;
  notes: string | null;
}

interface TakeawayOrder {
  id: string;
  order_number: string;
  created_at: string;
  order_type: string;
  status: string;
  total: number;
}

export function CustomersAdmin() {
  const [customers, setCustomers] = useState<CustomerProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerProfile | null>(null);
  const [customerReservations, setCustomerReservations] = useState<Reservation[]>([]);
  const [customerOrders, setCustomerOrders] = useState<TakeawayOrder[]>([]);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [stats, setStats] = useState({
    total: 0,
    withNotifications: 0,
    thisMonth: 0,
  });

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async () => {
    setIsLoading(true);
    try {
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const { data: favoritesData } = await supabase
        .from('favorites')
        .select('user_id');

      const { data: reservationsData } = await supabase
        .from('reservations')
        .select('user_id');

      const { data: ordersData } = await supabase
        .from('takeaway_orders')
        .select('user_id');

      const favoritesCount: Record<string, number> = {};
      const reservationsCount: Record<string, number> = {};
      const ordersCount: Record<string, number> = {};

      favoritesData?.forEach(f => {
        favoritesCount[f.user_id] = (favoritesCount[f.user_id] || 0) + 1;
      });

      reservationsData?.forEach(r => {
        reservationsCount[r.user_id] = (reservationsCount[r.user_id] || 0) + 1;
      });

      ordersData?.forEach(o => {
        ordersCount[o.user_id] = (ordersCount[o.user_id] || 0) + 1;
      });

      const enrichedProfiles = (profiles || []).map(p => ({
        ...p,
        favorites_count: favoritesCount[p.user_id] || 0,
        reservations_count: reservationsCount[p.user_id] || 0,
        orders_count: ordersCount[p.user_id] || 0,
      }));

      setCustomers(enrichedProfiles);

      const now = new Date();
      const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      
      setStats({
        total: enrichedProfiles.length,
        withNotifications: enrichedProfiles.filter(p => p.whatsapp_notifications || p.push_notifications).length,
        thisMonth: enrichedProfiles.filter(p => new Date(p.created_at) >= thisMonthStart).length,
      });
    } catch (error) {
      console.error('Error fetching customers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const openCustomerDetails = async (customer: CustomerProfile) => {
    setSelectedCustomer(customer);
    setLoadingDetails(true);
    
    try {
      const [reservationsRes, ordersRes] = await Promise.all([
        supabase
          .from('reservations')
          .select('id, reservation_date, reservation_time, guests, status, notes')
          .eq('user_id', customer.user_id)
          .order('reservation_date', { ascending: false }),
        supabase
          .from('takeaway_orders')
          .select('id, order_number, created_at, order_type, status, total')
          .eq('user_id', customer.user_id)
          .order('created_at', { ascending: false })
      ]);
      
      setCustomerReservations(reservationsRes.data || []);
      setCustomerOrders(ordersRes.data || []);
    } catch (error) {
      console.error('Error fetching customer details:', error);
    } finally {
      setLoadingDetails(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { label: string; className: string }> = {
      pending: { label: 'In attesa', className: 'bg-yellow-500/20 text-yellow-500' },
      confirmed: { label: 'Confermata', className: 'bg-green-500/20 text-green-500' },
      cancelled: { label: 'Annullata', className: 'bg-red-500/20 text-red-500' },
      completed: { label: 'Completato', className: 'bg-green-500/20 text-green-500' },
      accepted: { label: 'Accettato', className: 'bg-blue-500/20 text-blue-500' },
      preparing: { label: 'In preparazione', className: 'bg-orange-500/20 text-orange-500' },
      ready: { label: 'Pronto', className: 'bg-purple-500/20 text-purple-500' },
      delivering: { label: 'In consegna', className: 'bg-cyan-500/20 text-cyan-500' },
      rejected: { label: 'Rifiutato', className: 'bg-red-500/20 text-red-500' },
    };
    const config = statusConfig[status] || { label: status, className: 'bg-muted' };
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const filteredCustomers = customers.filter(customer => {
    const query = searchQuery.toLowerCase();
    return (
      customer.phone?.toLowerCase().includes(query) ||
      customer.display_name?.toLowerCase().includes(query)
    );
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-xl" />
          ))}
        </div>
        <Skeleton className="h-12 rounded-xl" />
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <Skeleton key={i} className="h-20 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
                <Users className="w-5 h-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-xs text-muted-foreground">Clienti totali</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center">
                <Bell className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.withNotifications}</p>
                <p className="text-xs text-muted-foreground">Con notifiche</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.thisMonth}</p>
                <p className="text-xs text-muted-foreground">Questo mese</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Cerca per nome o telefono..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Customers List */}
      <div className="space-y-3">
        {filteredCustomers.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              {searchQuery ? 'Nessun cliente trovato' : 'Nessun cliente registrato'}
            </CardContent>
          </Card>
        ) : (
          filteredCustomers.map((customer) => (
            <Card 
              key={customer.id} 
              className="hover:bg-secondary/20 transition-colors cursor-pointer"
              onClick={() => openCustomerDetails(customer)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                      <span className="text-lg font-semibold text-accent">
                        {(customer.display_name || customer.phone)?.[0]?.toUpperCase() || '?'}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">
                        {customer.display_name || 'Cliente'}
                      </p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Phone className="w-3 h-3" />
                        {customer.phone || 'N/A'}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      {(customer.favorites_count || 0) > 0 && (
                        <Badge variant="secondary" className="gap-1">
                          <Heart className="w-3 h-3" />
                          {customer.favorites_count}
                        </Badge>
                      )}
                      {(customer.reservations_count || 0) > 0 && (
                        <Badge variant="secondary" className="gap-1">
                          <Calendar className="w-3 h-3" />
                          {customer.reservations_count}
                        </Badge>
                      )}
                      {(customer.orders_count || 0) > 0 && (
                        <Badge variant="secondary" className="gap-1">
                          <Package className="w-3 h-3" />
                          {customer.orders_count}
                        </Badge>
                      )}
                    </div>

                    <div className="flex gap-1">
                      {customer.whatsapp_notifications && (
                        <Badge variant="outline" className="text-green-500 border-green-500/30">
                          WA
                        </Badge>
                      )}
                      {customer.push_notifications && (
                        <Badge variant="outline" className="text-blue-500 border-blue-500/30">
                          Push
                        </Badge>
                      )}
                    </div>

                    <span className="text-xs text-muted-foreground whitespace-nowrap hidden sm:block">
                      {format(new Date(customer.created_at), 'dd MMM yyyy', { locale: it })}
                    </span>
                    
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Customer Detail Modal */}
      <Dialog open={!!selectedCustomer} onOpenChange={() => setSelectedCustomer(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] p-0 overflow-hidden">
          <DialogHeader className="p-6 pb-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-accent/10 flex items-center justify-center">
                  <span className="text-xl font-semibold text-accent">
                    {(selectedCustomer?.display_name || selectedCustomer?.phone)?.[0]?.toUpperCase() || '?'}
                  </span>
                </div>
                <div>
                  <DialogTitle className="text-xl">
                    {selectedCustomer?.display_name || 'Cliente'}
                  </DialogTitle>
                  <p className="text-sm text-muted-foreground flex items-center gap-1">
                    <Phone className="w-3 h-3" />
                    {selectedCustomer?.phone}
                  </p>
                </div>
              </div>
            </div>
          </DialogHeader>

          <div className="p-6 pt-4">
            {/* Address Section */}
            {(selectedCustomer?.address || selectedCustomer?.city) && (
              <div className="mb-4 p-4 rounded-xl bg-secondary/30 border border-border">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-accent mt-0.5" />
                  <div>
                    <p className="font-medium text-sm">Indirizzo di consegna</p>
                    <p className="text-muted-foreground">
                      {selectedCustomer?.address}
                      {selectedCustomer?.apartment_floor && `, Piano ${selectedCustomer.apartment_floor}`}
                    </p>
                    <p className="text-muted-foreground">
                      {selectedCustomer?.zip_code} {selectedCustomer?.city}
                    </p>
                    {selectedCustomer?.delivery_notes && (
                      <p className="text-sm text-muted-foreground mt-1 italic">
                        Note: {selectedCustomer.delivery_notes}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            <Tabs defaultValue="reservations" className="w-full">
              <TabsList className="w-full mb-4">
                <TabsTrigger value="reservations" className="flex-1 gap-2">
                  <Calendar className="w-4 h-4" />
                  Prenotazioni ({customerReservations.length})
                </TabsTrigger>
                <TabsTrigger value="orders" className="flex-1 gap-2">
                  <Package className="w-4 h-4" />
                  Ordini ({customerOrders.length})
                </TabsTrigger>
              </TabsList>

              <TabsContent value="reservations">
                <ScrollArea className="h-[300px]">
                  {loadingDetails ? (
                    <div className="space-y-3">
                      {[...Array(3)].map((_, i) => (
                        <Skeleton key={i} className="h-16 rounded-lg" />
                      ))}
                    </div>
                  ) : customerReservations.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      Nessuna prenotazione
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {customerReservations.map(res => (
                        <div key={res.id} className="p-3 rounded-lg bg-secondary/20 border border-border">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">
                                {format(new Date(res.reservation_date), 'dd MMMM yyyy', { locale: it })}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                Ore {res.reservation_time} • {res.guests} ospiti
                              </p>
                              {res.notes && (
                                <p className="text-xs text-muted-foreground italic mt-1">{res.notes}</p>
                              )}
                            </div>
                            {getStatusBadge(res.status)}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>

              <TabsContent value="orders">
                <ScrollArea className="h-[300px]">
                  {loadingDetails ? (
                    <div className="space-y-3">
                      {[...Array(3)].map((_, i) => (
                        <Skeleton key={i} className="h-16 rounded-lg" />
                      ))}
                    </div>
                  ) : customerOrders.length === 0 ? (
                    <div className="text-center text-muted-foreground py-8">
                      Nessun ordine
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {customerOrders.map(order => (
                        <div key={order.id} className="p-3 rounded-lg bg-secondary/20 border border-border">
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium">
                                #{order.order_number}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {format(new Date(order.created_at), 'dd MMM yyyy HH:mm', { locale: it })}
                                {' • '}
                                {order.order_type === 'pickup' ? 'Ritiro' : 'Consegna'}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-semibold">€{order.total?.toFixed(2)}</p>
                              {getStatusBadge(order.status)}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
