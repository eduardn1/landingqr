import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Save, Loader2, GripVertical, Eye, EyeOff, Globe, Menu, Smartphone, ChevronUp, ChevronDown, Home, UtensilsCrossed, Sparkles, Heart, User, CalendarDays, Search, Settings, Info, MapPin, Phone, Star, Clock, ShoppingBag, Gift, Ticket, Music, Camera, Bell, MessageCircle, HelpCircle, Bookmark, Share2, LogIn, LogOut, Plus, Trash2 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

// Available icons for navbar items
const AVAILABLE_ICONS = [
  { name: 'Home', icon: Home },
  { name: 'UtensilsCrossed', icon: UtensilsCrossed },
  { name: 'CalendarDays', icon: CalendarDays },
  { name: 'Sparkles', icon: Sparkles },
  { name: 'Heart', icon: Heart },
  { name: 'User', icon: User },
  { name: 'Search', icon: Search },
  { name: 'Settings', icon: Settings },
  { name: 'Info', icon: Info },
  { name: 'MapPin', icon: MapPin },
  { name: 'Phone', icon: Phone },
  { name: 'Star', icon: Star },
  { name: 'Clock', icon: Clock },
  { name: 'ShoppingBag', icon: ShoppingBag },
  { name: 'Gift', icon: Gift },
  { name: 'Ticket', icon: Ticket },
  { name: 'Music', icon: Music },
  { name: 'Camera', icon: Camera },
  { name: 'Bell', icon: Bell },
  { name: 'MessageCircle', icon: MessageCircle },
  { name: 'HelpCircle', icon: HelpCircle },
  { name: 'Bookmark', icon: Bookmark },
  { name: 'Share2', icon: Share2 },
];

// Available tab keys
const AVAILABLE_KEYS = [
  { key: 'home', label: 'Home' },
  { key: 'menu', label: 'Menu' },
  { key: 'reservations', label: 'Prenotazioni' },
  { key: 'discover', label: 'Scopri' },
  { key: 'favorites', label: 'Preferiti' },
  { key: 'profile', label: 'Profilo' },
];

interface NavbarItem {
  key: string;
  icon: string;
  label: { it: string; en: string };
  visible: boolean;
  order: number;
}

interface LanguageOption {
  code: string;
  label: string;
  flag: string;
  visible: boolean;
}

interface NavigationConfig {
  id: string;
  header_logo_visible: boolean;
  header_favorites_visible: boolean;
  header_profile_visible: boolean;
  header_language_switcher_visible: boolean;
  header_theme_toggle_visible: boolean;
  navbar_items: NavbarItem[];
  available_languages: LanguageOption[];
  default_language: string;
}

export function NavigationEditor() {
  const queryClient = useQueryClient();
  
  const { data: config, isLoading } = useQuery({
    queryKey: ['navigation-config-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('navigation_config')
        .select('*')
        .maybeSingle();

      if (error) throw error;
      return data as unknown as NavigationConfig;
    },
  });

  const [localConfig, setLocalConfig] = useState<NavigationConfig | null>(null);

  // Initialize local config when data loads
  if (config && !localConfig) {
    setLocalConfig({
      ...config,
      header_theme_toggle_visible: (config as any).header_theme_toggle_visible ?? true,
      navbar_items: config.navbar_items as unknown as NavbarItem[],
      available_languages: config.available_languages as unknown as LanguageOption[],
    });
  }

  const updateMutation = useMutation({
    mutationFn: async (updates: NavigationConfig) => {
      if (!config?.id) throw new Error('No config found');
      
      // Cast JSONB fields for Supabase
      const dbUpdates = {
        header_logo_visible: updates.header_logo_visible,
        header_favorites_visible: updates.header_favorites_visible,
        header_profile_visible: updates.header_profile_visible,
        header_language_switcher_visible: updates.header_language_switcher_visible,
        header_theme_toggle_visible: updates.header_theme_toggle_visible,
        navbar_items: updates.navbar_items as unknown as any,
        available_languages: updates.available_languages as unknown as any,
        default_language: updates.default_language,
      };
      
      const { error } = await supabase
        .from('navigation_config')
        .update(dbUpdates)
        .eq('id', config.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['navigation-config'] });
      queryClient.invalidateQueries({ queryKey: ['navigation-config-admin'] });
      toast.success('Configurazione salvata!');
    },
    onError: (error) => {
      toast.error('Errore nel salvare');
      console.error(error);
    },
  });

  const handleSave = () => {
    if (!localConfig) return;
    updateMutation.mutate(localConfig);
  };

  const updateNavbarItem = (index: number, updates: Partial<NavbarItem>) => {
    if (!localConfig) return;
    const items = [...localConfig.navbar_items];
    items[index] = { ...items[index], ...updates };
    setLocalConfig({ ...localConfig, navbar_items: items });
  };

  const updateLanguage = (index: number, updates: Partial<LanguageOption>) => {
    if (!localConfig) return;
    const languages = [...localConfig.available_languages];
    languages[index] = { ...languages[index], ...updates };
    setLocalConfig({ ...localConfig, available_languages: languages });
  };

  const moveItem = (index: number, direction: 'up' | 'down') => {
    if (!localConfig) return;
    const items = [...localConfig.navbar_items].sort((a, b) => a.order - b.order);
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex < 0 || targetIndex >= items.length) return;
    
    // Swap orders
    const tempOrder = items[index].order;
    items[index].order = items[targetIndex].order;
    items[targetIndex].order = tempOrder;
    
    setLocalConfig({ ...localConfig, navbar_items: items });
  };

  const addNavbarItem = () => {
    if (!localConfig) return;
    const maxOrder = Math.max(...localConfig.navbar_items.map(i => i.order), 0);
    const usedKeys = localConfig.navbar_items.map(i => i.key);
    const availableKey = AVAILABLE_KEYS.find(k => !usedKeys.includes(k.key));
    
    if (!availableKey) {
      toast.error('Tutti i tab disponibili sono già in uso');
      return;
    }
    
    const newItem: NavbarItem = {
      key: availableKey.key,
      icon: 'Home',
      label: { it: availableKey.label, en: availableKey.label },
      visible: true,
      order: maxOrder + 1,
    };
    
    setLocalConfig({
      ...localConfig,
      navbar_items: [...localConfig.navbar_items, newItem],
    });
  };

  const removeNavbarItem = (index: number) => {
    if (!localConfig) return;
    const items = [...localConfig.navbar_items];
    items.splice(index, 1);
    // Reorder remaining items
    items.sort((a, b) => a.order - b.order).forEach((item, i) => {
      item.order = i + 1;
    });
    setLocalConfig({ ...localConfig, navbar_items: items });
  };

  const getIconComponent = (iconName: string) => {
    const found = AVAILABLE_ICONS.find(i => i.name === iconName);
    return found ? found.icon : Home;
  };

  if (isLoading || !localConfig) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  const sortedItems = [...localConfig.navbar_items].sort((a, b) => a.order - b.order);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Navigazione</h2>
          <p className="text-sm text-muted-foreground">Configura header, navbar e lingue</p>
        </div>
        <Button onClick={handleSave} disabled={updateMutation.isPending}>
          {updateMutation.isPending ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          Salva
        </Button>
      </div>

      <Tabs defaultValue="navbar">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="header" className="gap-2">
            <Menu className="w-4 h-4" />
            Header
          </TabsTrigger>
          <TabsTrigger value="navbar" className="gap-2">
            <Smartphone className="w-4 h-4" />
            Navbar Mobile
          </TabsTrigger>
          <TabsTrigger value="languages" className="gap-2">
            <Globe className="w-4 h-4" />
            Lingue
          </TabsTrigger>
        </TabsList>

        {/* Header Settings */}
        <TabsContent value="header">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Impostazioni Header</CardTitle>
              <CardDescription>Configura gli elementi visibili nell'header</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="logo">Logo visibile</Label>
                <Switch
                  id="logo"
                  checked={localConfig.header_logo_visible}
                  onCheckedChange={(checked) => 
                    setLocalConfig({ ...localConfig, header_logo_visible: checked })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="themeToggle">Toggle Tema (Light/Dark)</Label>
                <Switch
                  id="themeToggle"
                  checked={localConfig.header_theme_toggle_visible}
                  onCheckedChange={(checked) => 
                    setLocalConfig({ ...localConfig, header_theme_toggle_visible: checked })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="favorites">Pulsante Preferiti</Label>
                <Switch
                  id="favorites"
                  checked={localConfig.header_favorites_visible}
                  onCheckedChange={(checked) => 
                    setLocalConfig({ ...localConfig, header_favorites_visible: checked })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="profile">Pulsante Profilo</Label>
                <Switch
                  id="profile"
                  checked={localConfig.header_profile_visible}
                  onCheckedChange={(checked) => 
                    setLocalConfig({ ...localConfig, header_profile_visible: checked })
                  }
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="langSwitcher">Selettore Lingua</Label>
                <Switch
                  id="langSwitcher"
                  checked={localConfig.header_language_switcher_visible}
                  onCheckedChange={(checked) => 
                    setLocalConfig({ ...localConfig, header_language_switcher_visible: checked })
                  }
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Navbar Settings */}
        <TabsContent value="navbar">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Navbar Mobile</CardTitle>
              <CardDescription>Configura, riordina e gestisci gli elementi della barra di navigazione mobile</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {sortedItems.map((item, index) => {
                const IconComponent = getIconComponent(item.icon);
                const originalIndex = localConfig.navbar_items.findIndex(i => i.key === item.key);
                
                return (
                  <div 
                    key={item.key}
                    className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${
                      item.visible 
                        ? 'bg-secondary/20 border-border' 
                        : 'bg-muted/30 border-muted opacity-60'
                    }`}
                  >
                    {/* Order controls */}
                    <div className="flex flex-col gap-0.5">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5"
                        onClick={() => moveItem(index, 'up')}
                        disabled={index === 0}
                      >
                        <ChevronUp className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-5 w-5"
                        onClick={() => moveItem(index, 'down')}
                        disabled={index === sortedItems.length - 1}
                      >
                        <ChevronDown className="w-3 h-3" />
                      </Button>
                    </div>
                    
                    {/* Icon preview */}
                    <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                      <IconComponent className="w-5 h-5 text-accent" />
                    </div>
                    
                    <div className="flex-1 min-w-0 space-y-2">
                      {/* Tab key info */}
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                          Tab: {item.key}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          (Ordine: {item.order})
                        </span>
                      </div>
                      
                      {/* Icon selector */}
                      <Select
                        value={item.icon}
                        onValueChange={(value) => updateNavbarItem(originalIndex, { icon: value })}
                      >
                        <SelectTrigger className="h-8 text-xs">
                          <SelectValue placeholder="Scegli icona" />
                        </SelectTrigger>
                        <SelectContent>
                          {AVAILABLE_ICONS.map((iconOption) => {
                            const Icon = iconOption.icon;
                            return (
                              <SelectItem key={iconOption.name} value={iconOption.name}>
                                <div className="flex items-center gap-2">
                                  <Icon className="w-4 h-4" />
                                  <span>{iconOption.name}</span>
                                </div>
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                      
                      {/* Labels */}
                      <div className="flex gap-2">
                        <div className="flex-1">
                          <Label className="text-[10px] text-muted-foreground">Italiano</Label>
                          <Input
                            value={item.label.it}
                            onChange={(e) => updateNavbarItem(originalIndex, { 
                              label: { ...item.label, it: e.target.value } 
                            })}
                            placeholder="Label IT"
                            className="h-8 text-xs"
                          />
                        </div>
                        <div className="flex-1">
                          <Label className="text-[10px] text-muted-foreground">English</Label>
                          <Input
                            value={item.label.en}
                            onChange={(e) => updateNavbarItem(originalIndex, { 
                              label: { ...item.label, en: e.target.value } 
                            })}
                            placeholder="Label EN"
                            className="h-8 text-xs"
                          />
                        </div>
                      </div>
                    </div>
                    
                    {/* Action buttons */}
                    <div className="flex flex-col gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => updateNavbarItem(originalIndex, { visible: !item.visible })}
                      >
                        {item.visible ? (
                          <Eye className="w-4 h-4 text-green-500" />
                        ) : (
                          <EyeOff className="w-4 h-4 text-muted-foreground" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => removeNavbarItem(originalIndex)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
              
              {/* Add new item button */}
              <Button
                variant="outline"
                className="w-full mt-4"
                onClick={addNavbarItem}
                disabled={localConfig.navbar_items.length >= AVAILABLE_KEYS.length}
              >
                <Plus className="w-4 h-4 mr-2" />
                Aggiungi elemento
              </Button>
              
              {/* Preview */}
              <div className="mt-6 pt-4 border-t">
                <Label className="text-sm font-medium">Anteprima Navbar</Label>
                <div className="mt-3 p-4 rounded-xl bg-background border">
                  <div className="flex items-center justify-around">
                    {sortedItems.filter(i => i.visible).map((item) => {
                      const IconComponent = getIconComponent(item.icon);
                      return (
                        <div key={item.key} className="flex flex-col items-center gap-1">
                          <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
                            <IconComponent className="w-5 h-5 text-accent" />
                          </div>
                          <span className="text-[10px] text-muted-foreground">{item.label.it}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-2 text-center">
                  {sortedItems.filter(i => i.visible).length} elementi visibili
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Languages Settings */}
        <TabsContent value="languages">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Lingue Disponibili</CardTitle>
              <CardDescription>Configura le lingue visibili nel selettore</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {localConfig.available_languages.map((lang, index) => (
                <div 
                  key={lang.code}
                  className="flex items-center gap-3 p-3 rounded-lg border bg-secondary/20"
                >
                  <span className="text-xl">{lang.flag}</span>
                  <div className="flex-1">
                    <p className="font-medium text-sm">{lang.label}</p>
                    <p className="text-xs text-muted-foreground">{lang.code}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => updateLanguage(index, { visible: !lang.visible })}
                  >
                    {lang.visible ? (
                      <Eye className="w-4 h-4 text-green-500" />
                    ) : (
                      <EyeOff className="w-4 h-4 text-muted-foreground" />
                    )}
                  </Button>
                </div>
              ))}
              
              <div className="pt-4 border-t">
                <Label>Lingua predefinita</Label>
                <select
                  value={localConfig.default_language}
                  onChange={(e) => setLocalConfig({ ...localConfig, default_language: e.target.value })}
                  className="mt-2 w-full px-3 py-2 rounded-md border bg-background"
                >
                  {localConfig.available_languages
                    .filter(l => l.visible)
                    .map(lang => (
                      <option key={lang.code} value={lang.code}>
                        {lang.flag} {lang.label}
                      </option>
                    ))}
                </select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
