import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Bell, Trash2, Calendar, ShoppingBag, Gift, PartyPopper, 
  Info, Users, CheckCheck, X, Clock 
} from 'lucide-react';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface Notification {
  id: string;
  user_id: string;
  title: string;
  body: string;
  type: string;
  is_read: boolean;
  action_url: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
}

interface NotificationsHistoryModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  notifications: Notification[];
  onMarkAsRead: (id: string) => Promise<void>;
  onMarkAllAsRead: () => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  onDeleteAll: () => Promise<void>;
}

const typeIcons: Record<string, typeof Bell> = {
  reservation: Calendar,
  takeaway_order: ShoppingBag,
  promo: Gift,
  event: PartyPopper,
  loyalty: Gift,
  info: Info,
  new_customer: Users,
};

const typeLabels: Record<string, string> = {
  reservation: 'Prenotazioni',
  takeaway_order: 'Ordini Asporto',
  promo: 'Promozioni',
  event: 'Eventi',
  loyalty: 'Fedeltà',
  info: 'Info',
  new_customer: 'Nuovi Clienti',
};

export function NotificationsHistoryModal({
  open,
  onOpenChange,
  notifications,
  onMarkAsRead,
  onMarkAllAsRead,
  onDelete,
  onDeleteAll,
}: NotificationsHistoryModalProps) {
  const [activeTab, setActiveTab] = useState('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filteredNotifications = activeTab === 'all' 
    ? notifications 
    : activeTab === 'unread'
    ? notifications.filter(n => !n.is_read)
    : notifications.filter(n => n.type === activeTab);

  const unreadCount = notifications.filter(n => !n.is_read).length;

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    await onDelete(id);
    setDeletingId(null);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, "d MMM yyyy 'alle' HH:mm", { locale: it });
  };

  const getNotificationTypes = () => {
    const types = new Set(notifications.map(n => n.type));
    return Array.from(types);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] p-0">
        <DialogHeader className="p-4 pb-0">
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Cronologia Notifiche
              {unreadCount > 0 && (
                <span className="px-2 py-0.5 text-xs bg-accent text-accent-foreground rounded-full">
                  {unreadCount} non lette
                </span>
              )}
            </DialogTitle>
            <div className="flex items-center gap-2">
              {unreadCount > 0 && (
                <Button variant="ghost" size="sm" onClick={onMarkAllAsRead}>
                  <CheckCheck className="w-4 h-4 mr-1" />
                  Segna tutte lette
                </Button>
              )}
              {notifications.length > 0 && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
                      <Trash2 className="w-4 h-4 mr-1" />
                      Elimina tutte
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Eliminare tutte le notifiche?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Questa azione non può essere annullata. Tutte le notifiche verranno eliminate permanentemente.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Annulla</AlertDialogCancel>
                      <AlertDialogAction 
                        onClick={onDeleteAll}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        Elimina tutte
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
            </div>
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-4 border-b border-border">
            <TabsList className="w-full justify-start h-auto p-1 bg-transparent gap-1 flex-wrap">
              <TabsTrigger 
                value="all" 
                className="data-[state=active]:bg-secondary rounded-full px-3 py-1.5 text-sm"
              >
                Tutte ({notifications.length})
              </TabsTrigger>
              {unreadCount > 0 && (
                <TabsTrigger 
                  value="unread" 
                  className="data-[state=active]:bg-secondary rounded-full px-3 py-1.5 text-sm"
                >
                  Non lette ({unreadCount})
                </TabsTrigger>
              )}
              {getNotificationTypes().map(type => (
                <TabsTrigger 
                  key={type}
                  value={type} 
                  className="data-[state=active]:bg-secondary rounded-full px-3 py-1.5 text-sm"
                >
                  {typeLabels[type] || type} ({notifications.filter(n => n.type === type).length})
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <TabsContent value={activeTab} className="mt-0">
            <ScrollArea className="h-[500px]">
              {filteredNotifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <Bell className="w-12 h-12 mb-3 opacity-30" />
                  <p className="text-sm">Nessuna notifica</p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  <AnimatePresence>
                    {filteredNotifications.map((notification) => {
                      const Icon = typeIcons[notification.type] || Info;
                      return (
                        <motion.div
                          key={notification.id}
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className={`p-4 hover:bg-secondary/30 transition-colors ${
                            !notification.is_read ? 'bg-accent/5' : ''
                          }`}
                        >
                          <div className="flex gap-3">
                            <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                              !notification.is_read 
                                ? 'bg-accent/20 text-accent' 
                                : 'bg-secondary text-muted-foreground'
                            }`}>
                              <Icon className="w-5 h-5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2">
                                    <p className={`font-medium ${
                                      !notification.is_read ? 'text-foreground' : 'text-muted-foreground'
                                    }`}>
                                      {notification.title}
                                    </p>
                                    {!notification.is_read && (
                                      <span className="w-2 h-2 rounded-full bg-accent flex-shrink-0" />
                                    )}
                                  </div>
                                  <p className="text-sm text-muted-foreground mt-0.5">
                                    {notification.body}
                                  </p>
                                  <div className="flex items-center gap-3 mt-2">
                                    <span className="flex items-center gap-1 text-xs text-muted-foreground/70">
                                      <Clock className="w-3 h-3" />
                                      {formatDate(notification.created_at)}
                                    </span>
                                    <span className="text-xs text-muted-foreground/50 px-2 py-0.5 bg-secondary/50 rounded-full">
                                      {typeLabels[notification.type] || notification.type}
                                    </span>
                                  </div>
                                </div>
                                <div className="flex items-center gap-1 flex-shrink-0">
                                  {!notification.is_read && (
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-8 w-8 p-0"
                                      onClick={() => onMarkAsRead(notification.id)}
                                      title="Segna come letta"
                                    >
                                      <CheckCheck className="w-4 h-4" />
                                    </Button>
                                  )}
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                                    onClick={() => handleDelete(notification.id)}
                                    disabled={deletingId === notification.id}
                                    title="Elimina"
                                  >
                                    {deletingId === notification.id ? (
                                      <motion.div
                                        animate={{ rotate: 360 }}
                                        transition={{ repeat: Infinity, duration: 1 }}
                                      >
                                        <X className="w-4 h-4" />
                                      </motion.div>
                                    ) : (
                                      <Trash2 className="w-4 h-4" />
                                    )}
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              )}
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}