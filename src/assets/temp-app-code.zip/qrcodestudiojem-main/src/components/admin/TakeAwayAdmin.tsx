import { useState, useRef } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import { 
  Package, Truck, Clock, CheckCircle2, XCircle, ChefHat, 
  Phone, User, MapPin, Calendar, RefreshCw, Settings,
  PlayCircle, PauseCircle, MapPinned, Users2, History, Timer
} from 'lucide-react';
import { useAdminTakeAwayOrders, useUpdateTakeAwayOrderStatus, TakeAwayOrder } from '@/hooks/useTakeAwayOrders';
import { useTakeAwaySettings } from '@/hooks/useTakeAwaySettings';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { DeliveryZonesEditor } from './DeliveryZonesEditor';
import { DriversEditor } from './DriversEditor';
import { OrderDetailModal } from './OrderDetailModal';
import { TakeAwayOrderHistory } from './TakeAwayOrderHistory';

// WhatsApp rate limit: 1 message per 5 seconds minimum
const MIN_MESSAGE_INTERVAL_MS = 6000;

const statusConfig = {
  pending: { label: 'In attesa', color: 'bg-yellow-500', icon: Clock },
  accepted: { label: 'Accettato', color: 'bg-blue-500', icon: CheckCircle2 },
  preparing: { label: 'In preparazione', color: 'bg-purple-500', icon: ChefHat },
  ready: { label: 'Pronto', color: 'bg-green-500', icon: Package },
  delivering: { label: 'In consegna', color: 'bg-indigo-500', icon: Truck },
  completed: { label: 'Completato', color: 'bg-emerald-600', icon: CheckCircle2 },
  rejected: { label: 'Rifiutato', color: 'bg-red-500', icon: XCircle },
  cancelled: { label: 'Annullato', color: 'bg-gray-500', icon: XCircle },
};

type OrderStatus = keyof typeof statusConfig;

export function TakeAwayAdmin() {
  const queryClient = useQueryClient();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [activeTab, setActiveTab] = useState<'orders' | 'history' | 'zones' | 'drivers' | 'settings'>('orders');
  const [selectedOrder, setSelectedOrder] = useState<TakeAwayOrder | null>(null);
  const [cooldownRemaining, setCooldownRemaining] = useState(0);
  const lastMessageTimeRef = useRef<number>(0);
  const cooldownIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  const { data: orders = [], isLoading: ordersLoading } = useAdminTakeAwayOrders(selectedDate);
  const { data: settings, isLoading: settingsLoading } = useTakeAwaySettings();
  const updateStatus = useUpdateTakeAwayOrderStatus();

  // Start cooldown timer
  const startCooldownTimer = (remainingMs: number) => {
    if (cooldownIntervalRef.current) {
      clearInterval(cooldownIntervalRef.current);
    }
    setCooldownRemaining(Math.ceil(remainingMs / 1000));
    cooldownIntervalRef.current = setInterval(() => {
      setCooldownRemaining(prev => {
        if (prev <= 1) {
          if (cooldownIntervalRef.current) {
            clearInterval(cooldownIntervalRef.current);
            cooldownIntervalRef.current = null;
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Check if we can send a message
  const canSendMessage = (): boolean => {
    const now = Date.now();
    const timeSinceLastMessage = now - lastMessageTimeRef.current;
    return timeSinceLastMessage >= MIN_MESSAGE_INTERVAL_MS;
  };

  // Get wait time
  const getWaitTime = (): number => {
    const now = Date.now();
    const timeSinceLastMessage = now - lastMessageTimeRef.current;
    return Math.max(0, MIN_MESSAGE_INTERVAL_MS - timeSinceLastMessage);
  };

  const handleStatusChange = async (orderId: string, newStatus: OrderStatus, additionalData?: Record<string, any>) => {
    // Check rate limit before proceeding
    const waitTime = getWaitTime();
    if (waitTime > 0) {
      toast.warning(`Attendi ${Math.ceil(waitTime / 1000)}s prima del prossimo cambio stato (limite WhatsApp)`, {
        duration: 3000,
        id: 'whatsapp-cooldown'
      });
      startCooldownTimer(waitTime);
      return;
    }

    try {
      await updateStatus.mutateAsync({ orderId, status: newStatus, additionalData });
      toast.success(`Ordine aggiornato: ${statusConfig[newStatus].label}`);
      
      // Mark message as sent and start cooldown
      lastMessageTimeRef.current = Date.now();
      startCooldownTimer(MIN_MESSAGE_INTERVAL_MS);
      
      // Send WhatsApp notification on status change
      const order = orders.find(o => o.id === orderId);
      if (order) {
        await sendTakeawayNotification(order, newStatus);
        
        // Trigger gamification when order is completed
        if (newStatus === 'completed' && order.user_id) {
          try {
            await supabase.functions.invoke('process-gamification', {
              body: {
                user_id: order.user_id,
                action_type: 'order_completed',
                order_id: orderId,
              },
            });
          } catch (gamErr) {
            console.error('Gamification processing error:', gamErr);
          }
        }
        
        // Update driver stats when order is completed
        if (newStatus === 'completed' && order.driver_id) {
          try {
            const { data: driver } = await supabase
              .from('takeaway_drivers')
              .select('total_deliveries')
              .eq('id', order.driver_id)
              .single();
            if (driver) {
              await supabase
                .from('takeaway_drivers')
                .update({ total_deliveries: (driver.total_deliveries || 0) + 1 })
                .eq('id', order.driver_id);
            }
          } catch (driverErr) {
            console.error('Driver stats update error:', driverErr);
          }
        }
      }
    } catch (error: any) {
      toast.error(error.message || 'Errore aggiornamento ordine');
    }
  };

  const sendTakeawayNotification = async (order: TakeAwayOrder, status: OrderStatus) => {
    let templateKey = '';
    let variables: Record<string, string> = {
      customer_name: order.customer_name,
      order_number: order.order_number || '',
      total: order.total.toFixed(2),
    };

    switch (status) {
      case 'accepted':
        templateKey = 'takeaway_order_confirmed';
        variables.ready_time = order.estimated_ready_at 
          ? format(new Date(order.estimated_ready_at), 'HH:mm')
          : 'presto';
        break;
      case 'preparing':
        templateKey = 'takeaway_order_preparing';
        break;
      case 'ready':
        templateKey = 'takeaway_order_ready';
        break;
      case 'delivering':
        templateKey = 'takeaway_order_delivering';
        variables.driver_name = order.takeaway_drivers?.name || 'Il driver';
        variables.driver_phone = order.takeaway_drivers?.phone || '';
        break;
      default:
        return; // No notification for other statuses
    }

    if (templateKey) {
      try {
        // Send WhatsApp notification
        await supabase.functions.invoke('send-whatsapp', {
          body: {
            phone: order.customer_phone,
            templateKey,
            variables,
            recipientName: order.customer_name,
          },
        });
        console.log(`WhatsApp notification sent for status: ${status}`);
      } catch (error) {
        console.error('Failed to send WhatsApp notification:', error);
      }

      // Send push notification to customer if they have an account
      if (order.user_id) {
        try {
          await supabase.functions.invoke('send-push-notification', {
            body: {
              user_id: order.user_id,
              title: getNotificationTitle(status),
              body: getNotificationBody(status, order),
              type: 'order_update',
              action_url: `/takeaway/order/${order.id}`,
              metadata: { order_id: order.id, status },
            },
          });
          console.log(`Push notification sent to user ${order.user_id}`);
        } catch (error) {
          console.error('Failed to send push notification:', error);
        }
      }

      // If status is 'delivering', also notify the driver
      if (status === 'delivering' && order.driver_id) {
        try {
          await supabase.functions.invoke('send-push-notification', {
            body: {
              driver_id: order.driver_id,
              title: 'Nuova consegna assegnata!',
              body: `Ordine #${order.order_number} - ${order.customer_name}`,
              type: 'driver_assignment',
              metadata: { order_id: order.id },
            },
          });
          console.log(`Driver notification sent to driver ${order.driver_id}`);
        } catch (error) {
          console.error('Failed to send driver notification:', error);
        }
      }
    }
  };

  const getNotificationTitle = (status: OrderStatus): string => {
    switch (status) {
      case 'accepted': return 'Ordine confermato!';
      case 'preparing': return 'In preparazione!';
      case 'ready': return 'Ordine pronto!';
      case 'delivering': return 'In consegna!';
      default: return 'Aggiornamento ordine';
    }
  };

  const getNotificationBody = (status: OrderStatus, order: TakeAwayOrder): string => {
    switch (status) {
      case 'accepted': return `Il tuo ordine #${order.order_number} è stato accettato`;
      case 'preparing': return `Stiamo preparando il tuo ordine #${order.order_number}`;
      case 'ready': return order.order_type === 'pickup' 
        ? `Il tuo ordine #${order.order_number} è pronto per il ritiro!`
        : `Il tuo ordine #${order.order_number} è pronto per la consegna!`;
      case 'delivering': return `Il tuo ordine #${order.order_number} è in consegna!`;
      default: return `Ordine #${order.order_number} aggiornato`;
    }
  };

  const handleToggleTakeaway = async (enabled: boolean) => {
    try {
      const { error } = await supabase
        .from('takeaway_settings')
        .update({ is_enabled: enabled })
        .eq('id', settings?.id);
      
      if (error) throw error;
      queryClient.invalidateQueries({ queryKey: ['takeaway-settings'] });
      toast.success(enabled ? 'Asporto attivato' : 'Asporto disattivato');
    } catch (error) {
      toast.error('Errore aggiornamento impostazioni');
    }
  };

  // Group orders by status for Kanban view
  const ordersByStatus = orders.reduce((acc, order) => {
    const status = order.status as OrderStatus;
    if (!acc[status]) acc[status] = [];
    acc[status].push(order);
    return acc;
  }, {} as Record<OrderStatus, TakeAwayOrder[]>);

  const kanbanColumns: OrderStatus[] = ['pending', 'accepted', 'preparing', 'ready', 'delivering'];

  if (ordersLoading || settingsLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {[1, 2, 3, 4, 5].map(i => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4 sm:space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold">Gestione Asporto</h2>
            <p className="text-xs sm:text-sm text-muted-foreground">
              Gestisci ordini e impostazioni
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            {/* WhatsApp Cooldown Indicator */}
            {cooldownRemaining > 0 && (
              <Badge variant="outline" className="gap-1 text-amber-600 border-amber-500/30 bg-amber-500/10">
                <Timer className="w-3 h-3" />
                <span className="text-xs">{cooldownRemaining}s</span>
              </Badge>
            )}
            
            <Button
              variant={settings?.is_enabled ? 'default' : 'outline'}
              size="sm"
              onClick={() => handleToggleTakeaway(!settings?.is_enabled)}
              className="gap-1.5"
            >
              {settings?.is_enabled ? (
                <>
                  <PlayCircle className="w-4 h-4" />
                  <span className="hidden sm:inline">Attivo</span>
                </>
              ) : (
                <>
                  <PauseCircle className="w-4 h-4" />
                  <span className="hidden sm:inline">Off</span>
                </>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => queryClient.invalidateQueries({ queryKey: ['admin-takeaway-orders'] })}
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
        <TabsList className="w-full grid grid-cols-5 h-auto p-1">
          <TabsTrigger value="orders" className="gap-1 text-xs sm:text-sm py-2">
            <Package className="w-4 h-4" />
            <span className="hidden sm:inline">Ordini</span>
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-1 text-xs sm:text-sm py-2">
            <History className="w-4 h-4" />
            <span className="hidden sm:inline">Storico</span>
          </TabsTrigger>
          <TabsTrigger value="zones" className="gap-1 text-xs sm:text-sm py-2">
            <MapPinned className="w-4 h-4" />
            <span className="hidden sm:inline">Zone</span>
          </TabsTrigger>
          <TabsTrigger value="drivers" className="gap-1 text-xs sm:text-sm py-2">
            <Users2 className="w-4 h-4" />
            <span className="hidden sm:inline">Driver</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="gap-1 text-xs sm:text-sm py-2">
            <Settings className="w-4 h-4" />
            <span className="hidden sm:inline">Impost.</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="orders" className="space-y-4 mt-4">
          {/* Date Selector */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-2 bg-secondary/30 rounded-lg px-3 py-2">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-auto border-0 bg-transparent p-0 h-auto text-sm"
              />
            </div>
            <Badge variant="secondary" className="text-xs">
              {orders.length} ordini
            </Badge>
          </div>

          {/* Mobile: Stacked columns, Tablet: 3 cols, Desktop: 5 cols */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3 sm:gap-4">
            {kanbanColumns.map(status => (
              <div key={status} className="space-y-2">
                <div className="flex items-center gap-2 px-2 py-1 bg-secondary/20 rounded-lg sticky top-0">
                  <div className={cn("w-2.5 h-2.5 rounded-full", statusConfig[status].color)} />
                  <h3 className="font-medium text-xs sm:text-sm">{statusConfig[status].label}</h3>
                  <Badge variant="secondary" className="ml-auto text-xs h-5">
                    {ordersByStatus[status]?.length || 0}
                  </Badge>
                </div>
                
                <div className="space-y-2 min-h-[100px] sm:min-h-[150px]">
                  {ordersByStatus[status]?.map(order => (
                    <OrderCard 
                      key={order.id} 
                      order={order} 
                      onStatusChange={handleStatusChange}
                      onSelect={() => setSelectedOrder(order)}
                    />
                  ))}
                  {(!ordersByStatus[status] || ordersByStatus[status].length === 0) && (
                    <p className="text-xs text-muted-foreground text-center py-6 bg-secondary/10 rounded-lg">
                      Nessun ordine
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          <TakeAwayOrderHistory />
        </TabsContent>

        <TabsContent value="zones" className="mt-4">
          <DeliveryZonesEditor />
        </TabsContent>

        <TabsContent value="drivers" className="mt-4">
          <DriversEditor />
        </TabsContent>

        <TabsContent value="settings" className="mt-4">
          <TakeAwaySettingsPanel settings={settings} />
        </TabsContent>
      </Tabs>

      {/* Order Detail Modal */}
      <OrderDetailModal
        order={selectedOrder}
        open={!!selectedOrder}
        onClose={() => setSelectedOrder(null)}
      />
    </motion.div>
  );
}

function OrderCard({ order, onStatusChange, onSelect }: { 
  order: TakeAwayOrder; 
  onStatusChange: (id: string, status: OrderStatus, data?: Record<string, any>) => void;
  onSelect: () => void;
}) {
  const status = order.status as OrderStatus;
  const StatusIcon = statusConfig[status]?.icon || Clock;

  const getNextActions = (): { label: string; status: OrderStatus; variant?: 'default' | 'destructive' }[] => {
    switch (status) {
      case 'pending':
        return [
          { label: 'Accetta', status: 'accepted' },
          { label: 'Rifiuta', status: 'rejected', variant: 'destructive' },
        ];
      case 'accepted':
        return [{ label: 'In preparazione', status: 'preparing' }];
      case 'preparing':
        return [{ label: 'Pronto', status: 'ready' }];
      case 'ready':
        return order.order_type === 'delivery' 
          ? [{ label: 'In consegna', status: 'delivering' }]
          : [{ label: 'Completato', status: 'completed' }];
      case 'delivering':
        return [{ label: 'Consegnato', status: 'completed' }];
      default:
        return [];
    }
  };

  return (
    <Card className="bg-card border-border/50 cursor-pointer hover:border-accent/50 transition-colors" onClick={onSelect}>
      <CardHeader className="p-3 pb-2">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-sm font-bold">
              #{order.order_number}
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              {format(new Date(order.created_at), 'HH:mm', { locale: it })}
            </p>
          </div>
          <Badge variant={order.order_type === 'pickup' ? 'secondary' : 'outline'} className="text-xs">
            {order.order_type === 'pickup' ? (
              <><Package className="w-3 h-3 mr-1" /> Ritiro</>
            ) : (
              <><Truck className="w-3 h-3 mr-1" /> Consegna</>
            )}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-3 pt-0 space-y-2">
        {/* Customer */}
        <div className="flex items-center gap-2 text-xs">
          <User className="w-3 h-3 text-muted-foreground" />
          <span className="truncate">{order.customer_name}</span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <Phone className="w-3 h-3 text-muted-foreground" />
          <a href={`tel:${order.customer_phone}`} className="text-accent hover:underline">
            {order.customer_phone}
          </a>
        </div>

        {/* Delivery Address */}
        {order.order_type === 'delivery' && order.delivery_address && (
          <div className="flex items-start gap-2 text-xs">
            <MapPin className="w-3 h-3 text-muted-foreground mt-0.5" />
            <span className="truncate">
              {order.delivery_address.street}, {order.delivery_address.city}
            </span>
          </div>
        )}

        {/* Pickup Time */}
        {order.order_type === 'pickup' && order.pickup_time && (
          <div className="flex items-center gap-2 text-xs">
            <Clock className="w-3 h-3 text-muted-foreground" />
            <span>Ritiro: {format(new Date(order.pickup_time), 'HH:mm')}</span>
          </div>
        )}

        {/* Items Summary */}
        <div className="text-xs text-muted-foreground">
          {order.items.length} articoli
        </div>

        {/* Total */}
        <div className="flex justify-between items-center pt-2 border-t border-border/50">
          <span className="text-xs text-muted-foreground">Totale</span>
          <span className="font-bold text-accent">€{order.total.toFixed(2)}</span>
        </div>

        {/* Actions */}
        {getNextActions().length > 0 && (
          <div className="flex gap-2 pt-2">
            {getNextActions().map(action => (
              <Button
                key={action.status}
                size="sm"
                variant={action.variant || 'default'}
                className="flex-1 text-xs h-8"
                onClick={() => onStatusChange(order.id, action.status)}
              >
                {action.label}
              </Button>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function TakeAwaySettingsPanel({ settings }: { settings: any }) {
  const queryClient = useQueryClient();
  const [form, setForm] = useState({
    min_prep_time: settings?.min_prep_time || 15,
    max_prep_time: settings?.max_prep_time || 45,
    pickup_intervals: settings?.pickup_intervals || 15,
    accepts_pickup: settings?.accepts_pickup ?? true,
    accepts_delivery: settings?.accepts_delivery ?? true,
    accepts_cash: settings?.accepts_cash ?? true,
    accepts_card_on_delivery: settings?.accepts_card_on_delivery ?? true,
    auto_accept_orders: settings?.auto_accept_orders ?? false,
    max_concurrent_orders: settings?.max_concurrent_orders || 10,
    max_daily_orders: settings?.max_daily_orders || 100,
  });

  const handleSave = async () => {
    try {
      const { error } = await supabase
        .from('takeaway_settings')
        .update(form)
        .eq('id', settings?.id);
      
      if (error) throw error;
      queryClient.invalidateQueries({ queryKey: ['takeaway-settings'] });
      toast.success('Impostazioni salvate');
    } catch (error) {
      toast.error('Errore salvataggio impostazioni');
    }
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Tempi di preparazione</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-muted-foreground">Min (minuti)</label>
              <Input
                type="number"
                value={form.min_prep_time}
                onChange={(e) => setForm({ ...form, min_prep_time: parseInt(e.target.value) })}
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Max (minuti)</label>
              <Input
                type="number"
                value={form.max_prep_time}
                onChange={(e) => setForm({ ...form, max_prep_time: parseInt(e.target.value) })}
              />
            </div>
          </div>
          <div>
            <label className="text-sm text-muted-foreground">Intervallo ritiro (minuti)</label>
            <Input
              type="number"
              value={form.pickup_intervals}
              onChange={(e) => setForm({ ...form, pickup_intervals: parseInt(e.target.value) })}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Tipi di ordine</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm">Ritiro in sede</span>
            <input
              type="checkbox"
              checked={form.accepts_pickup}
              onChange={(e) => setForm({ ...form, accepts_pickup: e.target.checked })}
              className="w-4 h-4"
            />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Consegna a domicilio</span>
            <input
              type="checkbox"
              checked={form.accepts_delivery}
              onChange={(e) => setForm({ ...form, accepts_delivery: e.target.checked })}
              className="w-4 h-4"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Pagamenti</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm">Contanti</span>
            <input
              type="checkbox"
              checked={form.accepts_cash}
              onChange={(e) => setForm({ ...form, accepts_cash: e.target.checked })}
              className="w-4 h-4"
            />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Carta alla consegna</span>
            <input
              type="checkbox"
              checked={form.accepts_card_on_delivery}
              onChange={(e) => setForm({ ...form, accepts_card_on_delivery: e.target.checked })}
              className="w-4 h-4"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Limiti ordini</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-muted-foreground">Ordini contemporanei max</label>
            <Input
              type="number"
              value={form.max_concurrent_orders}
              onChange={(e) => setForm({ ...form, max_concurrent_orders: parseInt(e.target.value) })}
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground">Ordini giornalieri max</label>
            <Input
              type="number"
              value={form.max_daily_orders}
              onChange={(e) => setForm({ ...form, max_daily_orders: parseInt(e.target.value) })}
            />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Auto-accetta ordini</span>
            <input
              type="checkbox"
              checked={form.auto_accept_orders}
              onChange={(e) => setForm({ ...form, auto_accept_orders: e.target.checked })}
              className="w-4 h-4"
            />
          </div>
        </CardContent>
      </Card>

      <div className="md:col-span-2">
        <Button onClick={handleSave} className="w-full">
          Salva impostazioni
        </Button>
      </div>
    </div>
  );
}
