import { useState, useRef, forwardRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Upload, X, Loader2, Image as ImageIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { compressImage, getCompressionStats } from '@/lib/imageCompression';

interface ImageUploadProps {
  value?: string | null;
  onChange: (url: string | null) => void;
  bucket?: string;
  folder?: string;
  className?: string;
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
}

export const ImageUpload = forwardRef<HTMLDivElement, ImageUploadProps>(({ 
  value, 
  onChange, 
  bucket = 'restaurant-assets',
  folder = 'images',
  className,
  maxWidth = 1200,
  maxHeight = 1200,
  quality = 0.8,
}, ref) => {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    e.stopPropagation();
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({ title: 'Errore', description: 'Seleziona un\'immagine valida', variant: 'destructive' });
      return;
    }

    // Validate file size (max 10MB before compression)
    if (file.size > 10 * 1024 * 1024) {
      toast({ title: 'Errore', description: 'L\'immagine deve essere inferiore a 10MB', variant: 'destructive' });
      return;
    }

    setIsUploading(true);

    try {
      // Compress the image
      const compressedFile = await compressImage(file, {
        maxWidth,
        maxHeight,
        quality,
        mimeType: 'image/webp',
      });

      // Log compression stats
      const stats = getCompressionStats(file, compressedFile);
      if (stats.wasCompressed) {
        console.log(`Image compressed: ${stats.originalSize} → ${stats.compressedSize} (${stats.savedPercent} saved)`);
      }

      const fileExt = compressedFile.name.split('.').pop();
      const fileName = `${folder}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from(bucket)
        .upload(fileName, compressedFile, {
          cacheControl: '31536000', // 1 year cache
          upsert: false,
          contentType: compressedFile.type,
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from(bucket)
        .getPublicUrl(fileName);

      console.log('Image uploaded, publicUrl:', publicUrl);
      onChange(publicUrl);
      
      if (stats.wasCompressed) {
        toast({ 
          title: 'Immagine caricata!', 
          description: `Compressa: ${stats.savedPercent} risparmiato` 
        });
      } else {
        toast({ title: 'Immagine caricata!' });
      }
    } catch (error: any) {
      console.error('Upload error:', error);
      toast({ title: 'Errore upload', description: error.message, variant: 'destructive' });
    } finally {
      setIsUploading(false);
      if (inputRef.current) {
        inputRef.current.value = '';
      }
    }
  };

  const handleRemove = () => {
    onChange(null);
  };

  return (
    <div ref={ref} className={cn("space-y-2", className)}>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        onChange={handleUpload}
        onClick={(e) => e.stopPropagation()}
        className="hidden"
      />

      {value ? (
        <div className="relative group">
          <img
            src={value}
            alt="Preview"
            className="w-full h-32 object-cover rounded-lg border border-border"
          />
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center gap-2">
            <Button
              type="button"
              size="sm"
              variant="secondary"
              onClick={() => inputRef.current?.click()}
              disabled={isUploading}
            >
              {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            </Button>
            <Button
              type="button"
              size="sm"
              variant="destructive"
              onClick={handleRemove}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={isUploading}
          className="w-full h-32 border-2 border-dashed border-border rounded-lg flex flex-col items-center justify-center gap-2 text-muted-foreground hover:border-accent hover:text-accent transition-colors"
        >
          {isUploading ? (
            <Loader2 className="w-6 h-6 animate-spin" />
          ) : (
            <>
              <ImageIcon className="w-6 h-6" />
              <span className="text-sm">Carica immagine</span>
            </>
          )}
        </button>
      )}
    </div>
  );
});

ImageUpload.displayName = 'ImageUpload';
