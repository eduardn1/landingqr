import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, Edit2, Save, X, Plus, Trash2, Variable, Eye, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface WhatsAppTemplate {
  id: string;
  template_key: string;
  name: string;
  description: string | null;
  message_template: string;
  variables: string[];
  is_active: boolean;
}

export function WhatsAppTemplatesEditor() {
  const { toast } = useToast();
  const [templates, setTemplates] = useState<WhatsAppTemplate[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingTemplate, setEditingTemplate] = useState<WhatsAppTemplate | null>(null);
  const [previewTemplate, setPreviewTemplate] = useState<WhatsAppTemplate | null>(null);
  const [showAddNew, setShowAddNew] = useState(false);

  const [newTemplate, setNewTemplate] = useState({
    template_key: '',
    name: '',
    description: '',
    message_template: '',
    variables: [] as string[]
  });

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('whatsapp_templates')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) throw error;
      
      const typedData = (data || []).map(t => ({
        ...t,
        variables: Array.isArray(t.variables) ? t.variables as string[] : []
      }));
      
      setTemplates(typedData);
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveTemplate = async (template: WhatsAppTemplate) => {
    try {
      const { error } = await supabase
        .from('whatsapp_templates')
        .update({
          name: template.name,
          description: template.description,
          message_template: template.message_template,
          variables: template.variables,
          is_active: template.is_active
        })
        .eq('id', template.id);

      if (error) throw error;
      
      toast({ title: 'Template salvato!' });
      setEditingTemplate(null);
      fetchTemplates();
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  };

  const handleAddTemplate = async () => {
    if (!newTemplate.template_key || !newTemplate.name || !newTemplate.message_template) {
      toast({ title: 'Compila tutti i campi obbligatori', variant: 'destructive' });
      return;
    }

    try {
      const { error } = await supabase
        .from('whatsapp_templates')
        .insert({
          template_key: newTemplate.template_key,
          name: newTemplate.name,
          description: newTemplate.description || null,
          message_template: newTemplate.message_template,
          variables: extractVariables(newTemplate.message_template)
        });

      if (error) throw error;
      
      toast({ title: 'Template creato!' });
      setShowAddNew(false);
      setNewTemplate({ template_key: '', name: '', description: '', message_template: '', variables: [] });
      fetchTemplates();
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  };

  const handleDeleteTemplate = async (id: string) => {
    if (!confirm('Eliminare questo template?')) return;

    try {
      const { error } = await supabase
        .from('whatsapp_templates')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      toast({ title: 'Template eliminato!' });
      fetchTemplates();
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  };

  const toggleTemplateActive = async (template: WhatsAppTemplate) => {
    try {
      const { error } = await supabase
        .from('whatsapp_templates')
        .update({ is_active: !template.is_active })
        .eq('id', template.id);

      if (error) throw error;
      fetchTemplates();
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  };

  const extractVariables = (text: string): string[] => {
    const matches = text.match(/\{\{(\w+)\}\}/g) || [];
    return [...new Set(matches.map(m => m.replace(/\{\{|\}\}/g, '')))];
  };

  const copyTemplate = (template: WhatsAppTemplate) => {
    navigator.clipboard.writeText(template.message_template);
    toast({ title: 'Template copiato!' });
  };

  const getPreviewMessage = (template: WhatsAppTemplate) => {
    let message = template.message_template;
    const sampleValues: Record<string, string> = {
      name: 'Mario Rossi',
      date: 'Venerdì 15 Dicembre',
      time: '20:00',
      guests: '4',
      guests_label: 'persone',
      locale_name: 'Il Locale',
      title: 'Offerta Speciale',
      message: 'Sconto del 20% su tutti i secondi!',
      validity: 'fino al 31 Dicembre',
      event_date: 'Sabato 20 Dicembre',
      event_time: '21:00'
    };
    
    template.variables.forEach(v => {
      message = message.replace(new RegExp(`\\{\\{${v}\\}\\}`, 'g'), sampleValues[v] || `[${v}]`);
    });
    
    return message;
  };

  if (isLoading) {
    return <div className="animate-pulse space-y-4">
      {[1, 2, 3].map(i => <div key={i} className="h-24 bg-secondary/30 rounded-xl" />)}
    </div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-green-500/10 flex items-center justify-center">
            <MessageCircle className="w-5 h-5 text-green-500" />
          </div>
          <div>
            <h3 className="font-semibold">Template WhatsApp</h3>
            <p className="text-xs text-muted-foreground">Gestisci i messaggi automatici</p>
          </div>
        </div>
        <Button onClick={() => setShowAddNew(true)} size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Nuovo
        </Button>
      </div>

      {/* Add New Template Form */}
      <AnimatePresence>
        {showAddNew && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="p-4 rounded-xl bg-accent/5 border border-accent/20 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Nuovo Template</h4>
              <Button variant="ghost" size="sm" onClick={() => setShowAddNew(false)}>
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="grid gap-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Chiave (unica)</Label>
                  <Input
                    value={newTemplate.template_key}
                    onChange={e => setNewTemplate({ ...newTemplate, template_key: e.target.value.toLowerCase().replace(/\s/g, '_') })}
                    placeholder="custom_message"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Nome</Label>
                  <Input
                    value={newTemplate.name}
                    onChange={e => setNewTemplate({ ...newTemplate, name: e.target.value })}
                    placeholder="Messaggio Personalizzato"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Descrizione</Label>
                <Input
                  value={newTemplate.description}
                  onChange={e => setNewTemplate({ ...newTemplate, description: e.target.value })}
                  placeholder="Descrizione opzionale"
                />
              </div>
              <div className="space-y-2">
                <Label>Messaggio (usa {"{{variabile}}"} per valori dinamici)</Label>
                <Textarea
                  value={newTemplate.message_template}
                  onChange={e => setNewTemplate({ ...newTemplate, message_template: e.target.value })}
                  placeholder="Ciao {{name}}! Ti aspettiamo..."
                  rows={5}
                />
              </div>
              <Button onClick={handleAddTemplate}>
                <Save className="w-4 h-4 mr-2" />
                Crea Template
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Templates List */}
      <div className="space-y-3">
        {templates.map((template) => (
          <motion.div
            key={template.id}
            layout
            className="p-4 rounded-xl bg-secondary/30 border border-border/30"
          >
            {editingTemplate?.id === template.id ? (
              // Edit Mode
              <div className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Nome</Label>
                    <Input
                      value={editingTemplate.name}
                      onChange={e => setEditingTemplate({ ...editingTemplate, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Descrizione</Label>
                    <Input
                      value={editingTemplate.description || ''}
                      onChange={e => setEditingTemplate({ ...editingTemplate, description: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Messaggio</Label>
                  <Textarea
                    value={editingTemplate.message_template}
                    onChange={e => setEditingTemplate({ 
                      ...editingTemplate, 
                      message_template: e.target.value,
                      variables: extractVariables(e.target.value)
                    })}
                    rows={6}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={() => handleSaveTemplate(editingTemplate)} size="sm">
                    <Save className="w-4 h-4 mr-2" />
                    Salva
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setEditingTemplate(null)}>
                    Annulla
                  </Button>
                </div>
              </div>
            ) : (
              // View Mode
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium">{template.name}</h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
                        {template.template_key}
                      </span>
                    </div>
                    {template.description && (
                      <p className="text-xs text-muted-foreground mt-1">{template.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={template.is_active}
                      onCheckedChange={() => toggleTemplateActive(template)}
                    />
                    <Button variant="ghost" size="sm" onClick={() => setPreviewTemplate(template)}>
                      <Eye className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => copyTemplate(template)}>
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => setEditingTemplate(template)}>
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    {!template.template_key.startsWith('reservation_') && (
                      <Button variant="ghost" size="sm" onClick={() => handleDeleteTemplate(template.id)}>
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    )}
                  </div>
                </div>

                {/* Variables */}
                {template.variables.length > 0 && (
                  <div className="flex items-center gap-2 flex-wrap">
                    <Variable className="w-3 h-3 text-muted-foreground" />
                    {template.variables.map(v => (
                      <span key={v} className="text-[10px] px-2 py-0.5 rounded-full bg-accent/10 text-accent">
                        {`{{${v}}}`}
                      </span>
                    ))}
                  </div>
                )}

                {/* Preview */}
                <div className="p-3 rounded-lg bg-background/50 text-xs text-muted-foreground whitespace-pre-wrap line-clamp-3">
                  {template.message_template}
                </div>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Preview Modal */}
      <AnimatePresence>
        {previewTemplate && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setPreviewTemplate(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="w-full max-w-sm bg-background rounded-2xl border shadow-xl overflow-hidden"
              onClick={e => e.stopPropagation()}
            >
              <div className="p-4 bg-green-500 text-white flex items-center gap-3">
                <MessageCircle className="w-5 h-5" />
                <span className="font-medium">Anteprima WhatsApp</span>
              </div>
              <div className="p-4 bg-[#e5ddd5]">
                <div className="bg-white rounded-lg p-3 shadow-sm max-w-[85%] ml-auto">
                  <p className="text-sm whitespace-pre-wrap text-gray-800">
                    {getPreviewMessage(previewTemplate)}
                  </p>
                  <p className="text-[10px] text-gray-500 text-right mt-1">12:00</p>
                </div>
              </div>
              <div className="p-4 flex justify-end">
                <Button onClick={() => setPreviewTemplate(null)}>Chiudi</Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}