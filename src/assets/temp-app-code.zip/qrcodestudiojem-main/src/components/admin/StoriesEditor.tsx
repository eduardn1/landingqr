import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Save, Loader2, Edit2, GripVertical, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ImageUpload } from './ImageUpload';
import { MultiLangInput, type MultiLangValue } from './MultiLangInput';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { Story, StorySlide } from '@/hooks/useStories';
import type { Json } from '@/integrations/supabase/types';

interface StoriesEditorProps {
  stories: Story[];
  currentLanguage: string;
  onRefresh: () => void;
}

export function StoriesEditor({ stories, currentLanguage, onRefresh }: StoriesEditorProps) {
  const [editingStory, setEditingStory] = useState<Story | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [editingSlidesFor, setEditingSlidesFor] = useState<Story | null>(null);
  
  const [labelValue, setLabelValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });
  const [newStory, setNewStory] = useState({
    story_key: '',
    icon: '📖',
    thumbnail_url: '',
  });

  const handleToggleActive = async (story: Story) => {
    try {
      const { error } = await supabase
        .from('stories')
        .update({ is_active: !story.is_active })
        .eq('id', story.id);

      if (error) throw error;
      toast.success(story.is_active ? 'Story disattivata' : 'Story attivata');
      onRefresh();
    } catch (error) {
      console.error('Error toggling story:', error);
      toast.error("Errore nell'aggiornamento");
    }
  };

  const handleToggleNew = async (story: Story) => {
    try {
      const { error } = await supabase
        .from('stories')
        .update({ has_new: !story.has_new })
        .eq('id', story.id);

      if (error) throw error;
      toast.success('Badge NEW aggiornato');
      onRefresh();
    } catch (error) {
      console.error('Error toggling new badge:', error);
      toast.error("Errore nell'aggiornamento");
    }
  };

  const handleDelete = async (storyId: string) => {
    if (!confirm('Sei sicuro di voler eliminare questa story?')) return;
    
    try {
      const { error } = await supabase
        .from('stories')
        .delete()
        .eq('id', storyId);

      if (error) throw error;
      toast.success('Story eliminata');
      onRefresh();
    } catch (error) {
      console.error('Error deleting story:', error);
      toast.error("Errore nell'eliminazione");
    }
  };

  const openEditDialog = (story: Story) => {
    setEditingStory(story);
    setLabelValue({
      it: story.label.it || '',
      en: story.label.en || '',
      de: (story.label as any).de || '',
      es: (story.label as any).es || '',
      fr: (story.label as any).fr || '',
    });
  };

  const handleSaveEdit = async () => {
    if (!editingStory) return;
    setIsSaving(true);

    try {
      const { error } = await supabase
        .from('stories')
        .update({
          icon: editingStory.icon,
          label: labelValue,
          thumbnail_url: editingStory.thumbnail_url,
        })
        .eq('id', editingStory.id);

      if (error) throw error;
      toast.success('Story aggiornata');
      setEditingStory(null);
      onRefresh();
    } catch (error) {
      console.error('Error saving story:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateStory = async () => {
    if (!newStory.story_key || !labelValue.it) {
      toast.error('Compila almeno chiave e label IT');
      return;
    }
    setIsSaving(true);

    try {
      const maxOrder = Math.max(...stories.map(s => s.display_order), 0);
      const { error } = await supabase
        .from('stories')
        .insert({
          story_key: newStory.story_key,
          icon: newStory.icon,
          label: labelValue,
          thumbnail_url: newStory.thumbnail_url || null,
          slides: [],
          display_order: maxOrder + 1,
          is_active: true,
          has_new: true,
        });

      if (error) throw error;
      toast.success('Story creata');
      setIsCreating(false);
      setNewStory({ story_key: '', icon: '📖', thumbnail_url: '' });
      setLabelValue({ it: '', en: '', de: '', es: '', fr: '' });
      onRefresh();
    } catch (error) {
      console.error('Error creating story:', error);
      toast.error('Errore nella creazione');
    } finally {
      setIsSaving(false);
    }
  };

  // Slide management
  const handleAddSlide = async (story: Story) => {
    const newSlide: StorySlide = {
      id: crypto.randomUUID(),
      type: 'image',
      url: '',
      caption: { it: '', en: '' },
      duration: 5,
    };
    const updatedSlides = [...story.slides, newSlide];
    
    try {
      const { error } = await supabase
        .from('stories')
        .update({ slides: updatedSlides as unknown as Json })
        .eq('id', story.id);

      if (error) throw error;
      setEditingSlidesFor({ ...story, slides: updatedSlides });
      onRefresh();
    } catch (error) {
      console.error('Error adding slide:', error);
      toast.error("Errore nell'aggiunta della slide");
    }
  };

  const handleUpdateSlide = async (story: Story, slideIndex: number, updates: Partial<StorySlide>) => {
    const updatedSlides = story.slides.map((slide, idx) => 
      idx === slideIndex ? { ...slide, ...updates } : slide
    );
    
    try {
      const { error } = await supabase
        .from('stories')
        .update({ slides: updatedSlides as unknown as Json })
        .eq('id', story.id);

      if (error) throw error;
      setEditingSlidesFor({ ...story, slides: updatedSlides });
      onRefresh();
    } catch (error) {
      console.error('Error updating slide:', error);
      toast.error("Errore nell'aggiornamento della slide");
    }
  };

  const handleDeleteSlide = async (story: Story, slideIndex: number) => {
    const updatedSlides = story.slides.filter((_, idx) => idx !== slideIndex);
    
    try {
      const { error } = await supabase
        .from('stories')
        .update({ slides: updatedSlides as unknown as Json })
        .eq('id', story.id);

      if (error) throw error;
      setEditingSlidesFor({ ...story, slides: updatedSlides });
      toast.success('Slide eliminata');
      onRefresh();
    } catch (error) {
      console.error('Error deleting slide:', error);
      toast.error("Errore nell'eliminazione della slide");
    }
  };

  const iconOptions = ['📖', '👨‍🍳', '🍅', '🏆', '⭐', '🎉', '🍷', '🌿', '🔥', '💝', '🍕', '🍝', '🥗', '🎂', '☕'];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Stories ({stories.length})</h2>
        <Dialog open={isCreating} onOpenChange={(open) => {
          setIsCreating(open);
          if (!open) setLabelValue({ it: '', en: '', de: '', es: '', fr: '' });
        }}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Nuova Story
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Crea Nuova Story</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Chiave (univoca)</label>
                <Input
                  value={newStory.story_key}
                  onChange={(e) => setNewStory({ ...newStory, story_key: e.target.value })}
                  placeholder="es: chef_story"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Icona/Emoji (se non usi immagine)</label>
                <div className="flex flex-wrap gap-2">
                  {iconOptions.map((icon) => (
                    <button
                      key={icon}
                      onClick={() => setNewStory({ ...newStory, icon })}
                      className={`w-10 h-10 rounded-lg text-xl flex items-center justify-center transition-all ${
                        newStory.icon === icon ? 'bg-accent ring-2 ring-foreground' : 'bg-secondary/50 hover:bg-secondary'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Immagine cerchio (opzionale - sovrascrive icona)</label>
                <ImageUpload
                  value={newStory.thumbnail_url}
                  onChange={(url) => setNewStory({ ...newStory, thumbnail_url: url || '' })}
                  bucket="restaurant-assets"
                  folder="stories/thumbnails"
                />
              </div>
              <MultiLangInput
                label="Label"
                value={labelValue}
                onChange={setLabelValue}
                placeholder="Nome story"
                required
              />
              <Button onClick={handleCreateStory} disabled={isSaving} className="w-full">
                {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                Crea Story
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {stories.map((story) => (
          <div key={story.id} className="p-4 rounded-2xl bg-secondary/30 border border-border/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                {story.thumbnail_url ? (
                  <img 
                    src={story.thumbnail_url} 
                    alt="" 
                    className="w-12 h-12 rounded-full object-cover"
                  />
                ) : (
                  <span className="text-2xl">{story.icon}</span>
                )}
                <div>
                  <h3 className="font-medium">
                    {story.label[currentLanguage as 'it' | 'en'] || story.label.it}
                  </h3>
                  <p className="text-xs text-muted-foreground">{story.story_key}</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-border/30">
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <button 
                  onClick={() => setEditingSlidesFor(story)}
                  className="hover:text-foreground transition-colors"
                >
                  {story.slides.length} slides
                </button>
                {story.has_new && (
                  <span className="px-2 py-0.5 text-xs bg-accent/20 text-accent rounded-full">
                    NEW
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1">
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleToggleNew(story)}
                  className="text-xs"
                >
                  {story.has_new ? 'Rimuovi NEW' : 'Aggiungi NEW'}
                </Button>
                <Switch
                  checked={story.is_active}
                  onCheckedChange={() => handleToggleActive(story)}
                />
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={() => openEditDialog(story)}>
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Modifica Story</DialogTitle>
                    </DialogHeader>
                    {editingStory && (
                      <div className="space-y-4 pt-4">
                        <div className="space-y-2">
                          <label className="text-sm text-muted-foreground">Icona/Emoji</label>
                          <div className="flex flex-wrap gap-2">
                            {iconOptions.map((icon) => (
                              <button
                                key={icon}
                                onClick={() => setEditingStory({ ...editingStory, icon })}
                                className={`w-10 h-10 rounded-lg text-xl flex items-center justify-center transition-all ${
                                  editingStory.icon === icon ? 'bg-accent ring-2 ring-foreground' : 'bg-secondary/50 hover:bg-secondary'
                                }`}
                              >
                                {icon}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm text-muted-foreground">Immagine cerchio</label>
                          <ImageUpload
                            value={editingStory.thumbnail_url || ''}
                            onChange={(url) => setEditingStory({ ...editingStory, thumbnail_url: url })}
                            bucket="restaurant-assets"
                            folder="stories/thumbnails"
                          />
                        </div>
                        <MultiLangInput
                          label="Label"
                          value={labelValue}
                          onChange={setLabelValue}
                          placeholder="Nome story"
                          required
                        />
                        <Button onClick={handleSaveEdit} disabled={isSaving} className="w-full">
                          {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                          Salva
                        </Button>
                      </div>
                    )}
                  </DialogContent>
                </Dialog>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(story.id)}>
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Slides Editor Dialog */}
      <Dialog open={!!editingSlidesFor} onOpenChange={(open) => !open && setEditingSlidesFor(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Gestione Slides - {editingSlidesFor?.label[currentLanguage as 'it' | 'en'] || editingSlidesFor?.label.it}
            </DialogTitle>
          </DialogHeader>
          {editingSlidesFor && (
            <div className="space-y-4 pt-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  {editingSlidesFor.slides.length} slide{editingSlidesFor.slides.length !== 1 ? 's' : ''}
                </p>
                <Button size="sm" onClick={() => handleAddSlide(editingSlidesFor)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Aggiungi Slide
                </Button>
              </div>

              <div className="space-y-4">
                {editingSlidesFor.slides.map((slide, index) => (
                  <div key={index} className="p-4 rounded-xl bg-secondary/30 border border-border/30 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Slide {index + 1}</span>
                      </div>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => handleDeleteSlide(editingSlidesFor, index)}
                      >
                        <X className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                    
                    <ImageUpload
                      value={slide.url}
                      onChange={(url) => handleUpdateSlide(editingSlidesFor, index, { url: url || '' })}
                      bucket="restaurant-assets"
                      folder="stories/slides"
                    />

                    <div className="grid grid-cols-2 gap-3">
                      <Input
                        placeholder="Didascalia IT"
                        value={slide.caption?.it || ''}
                        onChange={(e) => handleUpdateSlide(editingSlidesFor, index, { 
                          caption: { ...slide.caption, it: e.target.value } 
                        })}
                      />
                      <Input
                        placeholder="Caption EN"
                        value={slide.caption?.en || ''}
                        onChange={(e) => handleUpdateSlide(editingSlidesFor, index, { 
                          caption: { ...slide.caption, en: e.target.value } 
                        })}
                      />
                    </div>
                  </div>
                ))}

                {editingSlidesFor.slides.length === 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    Nessuna slide. Clicca "Aggiungi Slide" per iniziare.
                  </p>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
