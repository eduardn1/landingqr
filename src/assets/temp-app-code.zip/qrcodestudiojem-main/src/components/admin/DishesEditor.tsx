import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash2, Loader2, GripVertical, Image } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { DishForm } from './DishForm';

interface Dish {
  id: string;
  name_it: string;
  name_en: string;
  description_it: string | null;
  description_en: string | null;
  ingredients_it?: string | null;
  ingredients_en?: string | null;
  price: number;
  original_price: number | null;
  takeaway_price?: number | null;
  category_id: string;
  image_url: string | null;
  is_available: boolean;
  is_featured: boolean;
  is_seasonal: boolean;
  available_for_takeaway?: boolean;
  available_for_delivery?: boolean;
  has_extras?: boolean;
  extras?: any[] | null;
  size_variants?: any[] | null;
  badge: string | null;
  tags: string[] | null;
  display_order: number;
  // Cocktail fields
  alcohol_level: 'analcolico' | 'leggero' | 'medio' | 'forte' | null;
  // Wine fields
  wine_year: number | null;
  wine_region: string | null;
  wine_pairing_it: string | null;
  wine_pairing_en: string | null;
}

interface Category {
  id: string;
  name_it: string;
  name_en: string;
}

interface Allergen {
  code: string;
  name_it: string;
  icon: string;
}

export function DishesEditor() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingDish, setEditingDish] = useState<Dish | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const { data: dishes = [], isLoading } = useQuery({
    queryKey: ['admin-dishes'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('dishes')
        .select('*')
        .order('display_order');
      if (error) throw error;
      return data as Dish[];
    }
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['admin-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('id, name_it, name_en')
        .order('display_order');
      if (error) throw error;
      return data as Category[];
    }
  });

  const { data: allergens = [] } = useQuery({
    queryKey: ['admin-allergens'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('allergens')
        .select('code, name_it, icon')
        .order('code');
      if (error) throw error;
      return data as Allergen[];
    }
  });

  const { data: dishAllergens = [] } = useQuery({
    queryKey: ['admin-dish-allergens'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('dish_allergens')
        .select('dish_id, allergen_code');
      if (error) throw error;
      return data as { dish_id: string; allergen_code: string }[];
    }
  });

  const getDishAllergens = (dishId: string) => {
    return dishAllergens.filter(da => da.dish_id === dishId).map(da => da.allergen_code);
  };

  const saveMutation = useMutation({
    mutationFn: async ({ dish, selectedAllergens }: { dish: Partial<Dish> & { id?: string }; selectedAllergens: string[] }) => {
      let dishId = dish.id;
      
      if (dish.id) {
        const { error } = await supabase
          .from('dishes')
          .update(dish)
          .eq('id', dish.id);
        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('dishes')
          .insert([dish as any])
          .select('id')
          .single();
        if (error) throw error;
        dishId = data.id;
      }

      // Update allergens
      if (dishId) {
        // Delete existing allergens
        await supabase
          .from('dish_allergens')
          .delete()
          .eq('dish_id', dishId);

        // Insert new allergens
        if (selectedAllergens.length > 0) {
          const { error: allergenError } = await supabase
            .from('dish_allergens')
            .insert(selectedAllergens.map(code => ({ dish_id: dishId, allergen_code: code })));
          if (allergenError) throw allergenError;
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-dishes'] });
      queryClient.invalidateQueries({ queryKey: ['admin-dish-allergens'] });
      setIsDialogOpen(false);
      setEditingDish(null);
      toast({ title: 'Piatto salvato!' });
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('dishes').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-dishes'] });
      toast({ title: 'Piatto eliminato!' });
    }
  });

  const filteredDishes = selectedCategory === 'all' 
    ? dishes 
    : dishes.filter(d => d.category_id === selectedCategory);

  if (isLoading) {
    return <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin" /></div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Tutte le categorie" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tutte le categorie</SelectItem>
            {categories.map(cat => (
              <SelectItem key={cat.id} value={cat.id}>{cat.name_it}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingDish(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Nuovo Piatto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingDish ? 'Modifica' : 'Nuovo'} Piatto</DialogTitle>
            </DialogHeader>
            <DishForm
              key={editingDish?.id || 'new'}
              dish={editingDish}
              categories={categories}
              allergens={allergens}
              initialAllergens={editingDish ? getDishAllergens(editingDish.id) : []}
              defaultDisplayOrder={dishes.length}
              onSave={(data) => saveMutation.mutate({ 
                dish: editingDish ? { ...data.dish, id: editingDish.id } : data.dish, 
                selectedAllergens: data.selectedAllergens 
              })}
            />
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2">
        {filteredDishes.map((dish) => (
          <div
            key={dish.id}
            className="flex items-center gap-3 p-3 bg-card border border-border rounded-lg"
          >
            <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
            
            {dish.image_url ? (
              <img src={dish.image_url} alt="" className="w-12 h-12 rounded-lg object-cover" />
            ) : (
              <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center">
                <Image className="w-5 h-5 text-muted-foreground" />
              </div>
            )}

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-medium truncate">{dish.name_it}</span>
                {dish.badge && (
                  <span className="text-xs px-2 py-0.5 bg-accent/10 text-accent rounded-full">{dish.badge}</span>
                )}
                {!dish.is_available && (
                  <span className="text-xs px-2 py-0.5 bg-destructive/10 text-destructive rounded-full">Non disponibile</span>
                )}
              </div>
              <p className="text-sm text-muted-foreground">
                €{dish.price.toFixed(2)} • {categories.find(c => c.id === dish.category_id)?.name_it}
              </p>
            </div>

            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setEditingDish(dish);
                  setIsDialogOpen(true);
                }}
              >
                <Pencil className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  if (confirm('Eliminare questo piatto?')) {
                    deleteMutation.mutate(dish.id);
                  }
                }}
              >
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          </div>
        ))}

        {filteredDishes.length === 0 && (
          <p className="text-center text-muted-foreground py-8">Nessun piatto trovato</p>
        )}
      </div>
    </div>
  );
}
