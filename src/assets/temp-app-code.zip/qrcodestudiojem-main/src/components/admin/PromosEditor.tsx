import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Edit2, Image, Link, Eye, EyeOff, GripVertical, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { usePromos, type Promo } from '@/hooks/usePromos';
import { ImageUpload } from './ImageUpload';
import { MultiLangInput, type MultiLangValue } from './MultiLangInput';

export function PromosEditor() {
  const { toast } = useToast();
  const { promos, isLoading, createPromo, updatePromo, deletePromo } = usePromos();
  const [editingPromo, setEditingPromo] = useState<Promo | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  
  const [titleValue, setTitleValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });
  const [descValue, setDescValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });
  const [formData, setFormData] = useState({
    image_url: '',
    link_url: '',
    link_type: 'none',
    is_active: true,
    starts_at: '',
    expires_at: ''
  });

  const resetForm = () => {
    setTitleValue({ it: '', en: '', de: '', es: '', fr: '' });
    setDescValue({ it: '', en: '', de: '', es: '', fr: '' });
    setFormData({
      image_url: '',
      link_url: '',
      link_type: 'none',
      is_active: true,
      starts_at: '',
      expires_at: ''
    });
  };

  const handleCreate = async () => {
    if (!titleValue.it || !formData.image_url) {
      toast({ title: 'Errore', description: 'Titolo e immagine sono obbligatori', variant: 'destructive' });
      return;
    }

    try {
      await createPromo.mutateAsync({
        title_it: titleValue.it,
        title_en: titleValue.en || null,
        description_it: descValue.it || null,
        description_en: descValue.en || null,
        image_url: formData.image_url,
        link_url: formData.link_url || null,
        link_type: formData.link_type,
        display_order: promos.length,
        is_active: formData.is_active,
        starts_at: formData.starts_at || null,
        expires_at: formData.expires_at || null
      });
      toast({ title: 'Promo creata!' });
      setIsCreateOpen(false);
      resetForm();
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  };

  const handleUpdate = async () => {
    if (!editingPromo) return;

    try {
      await updatePromo.mutateAsync({
        id: editingPromo.id,
        title_it: titleValue.it,
        title_en: titleValue.en || null,
        description_it: descValue.it || null,
        description_en: descValue.en || null,
        image_url: formData.image_url,
        link_url: formData.link_url || null,
        link_type: formData.link_type,
        is_active: formData.is_active,
        starts_at: formData.starts_at || null,
        expires_at: formData.expires_at || null
      });
      toast({ title: 'Promo aggiornata!' });
      setEditingPromo(null);
      resetForm();
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deletePromo.mutateAsync(id);
      toast({ title: 'Promo eliminata!' });
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  };

  const handleToggleActive = async (promo: Promo) => {
    try {
      await updatePromo.mutateAsync({
        id: promo.id,
        is_active: !promo.is_active
      });
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  };

  const openEditDialog = (promo: Promo) => {
    setEditingPromo(promo);
    setTitleValue({
      it: promo.title_it,
      en: promo.title_en || '',
      de: (promo as any).title_de || '',
      es: (promo as any).title_es || '',
      fr: (promo as any).title_fr || '',
    });
    setDescValue({
      it: promo.description_it || '',
      en: promo.description_en || '',
      de: (promo as any).description_de || '',
      es: (promo as any).description_es || '',
      fr: (promo as any).description_fr || '',
    });
    setFormData({
      image_url: promo.image_url,
      link_url: promo.link_url || '',
      link_type: promo.link_type || 'none',
      is_active: promo.is_active,
      starts_at: promo.starts_at ? promo.starts_at.split('T')[0] : '',
      expires_at: promo.expires_at ? promo.expires_at.split('T')[0] : ''
    });
  };

  if (isLoading) {
    return <div className="animate-pulse space-y-4">
      {[1, 2].map(i => <div key={i} className="h-24 bg-secondary/30 rounded-xl" />)}
    </div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Promozioni</h2>
          <p className="text-sm text-muted-foreground">Gestisci banner e promo sulla homepage</p>
        </div>
        <Button onClick={() => setIsCreateOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nuova Promo
        </Button>
      </div>

      {promos.length === 0 ? (
        <div className="text-center py-12 bg-secondary/20 rounded-xl border border-dashed border-border">
          <Image className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
          <p className="text-muted-foreground">Nessuna promo. Creane una per iniziare!</p>
        </div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {promos.map((promo) => (
              <motion.div
                key={promo.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border"
              >
                <GripVertical className="w-5 h-5 text-muted-foreground cursor-grab" />
                
                <div className="w-20 h-14 rounded-lg overflow-hidden bg-secondary flex-shrink-0">
                  <img 
                    src={promo.image_url} 
                    alt={promo.title_it}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-medium truncate">{promo.title_it}</h3>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    {promo.link_type !== 'none' && (
                      <span className="flex items-center gap-1">
                        <Link className="w-3 h-3" />
                        {promo.link_type}
                      </span>
                    )}
                    {promo.expires_at && (
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        Scade: {new Date(promo.expires_at).toLocaleDateString('it-IT')}
                      </span>
                    )}
                  </div>
                </div>

                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleToggleActive(promo)}
                  className={promo.is_active ? 'text-green-600' : 'text-muted-foreground'}
                >
                  {promo.is_active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </Button>

                <Button variant="ghost" size="icon" onClick={() => openEditDialog(promo)}>
                  <Edit2 className="w-4 h-4" />
                </Button>

                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-red-600"
                  onClick={() => handleDelete(promo.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={isCreateOpen || !!editingPromo} onOpenChange={(open) => {
        if (!open) {
          setIsCreateOpen(false);
          setEditingPromo(null);
          resetForm();
        }
      }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPromo ? 'Modifica Promo' : 'Nuova Promo'}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <MultiLangInput
              label="Titolo"
              value={titleValue}
              onChange={setTitleValue}
              placeholder="Titolo promo"
              required
            />

            <MultiLangInput
              label="Descrizione"
              value={descValue}
              onChange={setDescValue}
              placeholder="Descrizione opzionale"
              multiline
              rows={2}
            />

            <div className="space-y-2">
              <Label>Immagine *</Label>
              <ImageUpload
                value={formData.image_url}
                onChange={(url) => setFormData({ ...formData, image_url: url || '' })}
                folder="promos"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Tipo Link</Label>
                <Select
                  value={formData.link_type}
                  onValueChange={(value) => setFormData({ ...formData, link_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nessun link</SelectItem>
                    <SelectItem value="internal">Link interno</SelectItem>
                    <SelectItem value="external">Link esterno</SelectItem>
                    <SelectItem value="whatsapp">WhatsApp</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.link_type !== 'none' && (
                <div className="space-y-2">
                  <Label>URL Link</Label>
                  <Input
                    value={formData.link_url}
                    onChange={(e) => setFormData({ ...formData, link_url: e.target.value })}
                    placeholder={formData.link_type === 'whatsapp' ? '+39 333 1234567' : 'https://...'}
                  />
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Data inizio</Label>
                <Input
                  type="date"
                  value={formData.starts_at}
                  onChange={(e) => setFormData({ ...formData, starts_at: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Data scadenza</Label>
                <Input
                  type="date"
                  value={formData.expires_at}
                  onChange={(e) => setFormData({ ...formData, expires_at: e.target.value })}
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
              />
              <Label>Attiva</Label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsCreateOpen(false);
              setEditingPromo(null);
              resetForm();
            }}>
              Annulla
            </Button>
            <Button onClick={editingPromo ? handleUpdate : handleCreate}>
              {editingPromo ? 'Salva' : 'Crea'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
