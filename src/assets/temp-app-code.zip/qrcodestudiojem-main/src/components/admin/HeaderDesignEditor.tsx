import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Save, Loader2, Smartphone, Tablet, Monitor, Image, Heart, User, Globe, Sun, Bell } from 'lucide-react';

interface HeaderVisibilityConfig {
  id: string;
  header_logo_visible_mobile: boolean;
  header_logo_visible_tablet: boolean;
  header_logo_visible_desktop: boolean;
  header_favorites_visible_mobile: boolean;
  header_favorites_visible_tablet: boolean;
  header_favorites_visible_desktop: boolean;
  header_profile_visible_mobile: boolean;
  header_profile_visible_tablet: boolean;
  header_profile_visible_desktop: boolean;
  header_language_visible_mobile: boolean;
  header_language_visible_tablet: boolean;
  header_language_visible_desktop: boolean;
  header_theme_visible_mobile: boolean;
  header_theme_visible_tablet: boolean;
  header_theme_visible_desktop: boolean;
  header_notifications_visible_mobile: boolean;
  header_notifications_visible_tablet: boolean;
  header_notifications_visible_desktop: boolean;
}

const HEADER_ELEMENTS = [
  { key: 'logo', label: 'Logo', icon: Image, description: 'Logo del ristorante' },
  { key: 'notifications', label: 'Notifiche', icon: Bell, description: 'Campanella notifiche' },
  { key: 'favorites', label: 'Preferiti', icon: Heart, description: 'Pulsante preferiti' },
  { key: 'profile', label: 'Profilo', icon: User, description: 'Pulsante profilo utente' },
  { key: 'theme', label: 'Tema', icon: Sun, description: 'Toggle light/dark mode' },
  { key: 'language', label: 'Lingua', icon: Globe, description: 'Selettore lingua' },
] as const;

const DEVICES = [
  { key: 'mobile', label: 'Mobile', icon: Smartphone, description: '<640px' },
  { key: 'tablet', label: 'Tablet', icon: Tablet, description: '640-1024px' },
  { key: 'desktop', label: 'Desktop', icon: Monitor, description: '>1024px' },
] as const;

export function HeaderDesignEditor() {
  const queryClient = useQueryClient();

  const { data: config, isLoading } = useQuery({
    queryKey: ['header-visibility-config'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('navigation_config')
        .select('id, header_logo_visible_mobile, header_logo_visible_tablet, header_logo_visible_desktop, header_favorites_visible_mobile, header_favorites_visible_tablet, header_favorites_visible_desktop, header_profile_visible_mobile, header_profile_visible_tablet, header_profile_visible_desktop, header_language_visible_mobile, header_language_visible_tablet, header_language_visible_desktop, header_theme_visible_mobile, header_theme_visible_tablet, header_theme_visible_desktop, header_notifications_visible_mobile, header_notifications_visible_tablet, header_notifications_visible_desktop')
        .maybeSingle();
      if (error) throw error;
      return data as HeaderVisibilityConfig;
    },
  });

  const [localConfig, setLocalConfig] = useState<HeaderVisibilityConfig | null>(null);

  useEffect(() => {
    if (config && !localConfig) {
      setLocalConfig(config);
    }
  }, [config, localConfig]);

  const updateMutation = useMutation({
    mutationFn: async (updates: Partial<HeaderVisibilityConfig>) => {
      if (!config?.id) throw new Error('No config found');
      const { error } = await supabase
        .from('navigation_config')
        .update(updates)
        .eq('id', config.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['navigation-config'] });
      queryClient.invalidateQueries({ queryKey: ['header-visibility-config'] });
      toast.success('Impostazioni header salvate!');
    },
    onError: () => toast.error('Errore nel salvare'),
  });

  const handleSave = () => {
    if (!localConfig) return;
    const { id, ...updates } = localConfig;
    updateMutation.mutate(updates);
  };

  const toggleVisibility = (element: string, device: string, value: boolean) => {
    if (!localConfig) return;
    const key = `header_${element}_visible_${device}` as keyof HeaderVisibilityConfig;
    setLocalConfig({ ...localConfig, [key]: value });
  };

  const getVisibility = (element: string, device: string): boolean => {
    if (!localConfig) return true;
    const key = `header_${element}_visible_${device}` as keyof HeaderVisibilityConfig;
    return localConfig[key] as boolean;
  };

  if (isLoading || !localConfig) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  // Live preview of header elements for each device
  const renderPreview = (device: 'mobile' | 'tablet' | 'desktop') => {
    const elements = HEADER_ELEMENTS.filter(el => getVisibility(el.key, device));
    return (
      <div className="flex items-center justify-between p-2 bg-card rounded-lg border border-border/50 min-h-[40px]">
        {/* Logo on left */}
        {getVisibility('logo', device) && (
          <div className="w-6 h-6 rounded bg-accent/20 flex items-center justify-center">
            <Image className="w-3 h-3 text-accent" />
          </div>
        )}
        {!getVisibility('logo', device) && <div />}
        
        {/* Right side elements */}
        <div className="flex items-center gap-1.5">
          {getVisibility('notifications', device) && <Bell className="w-3.5 h-3.5 text-muted-foreground" />}
          {getVisibility('favorites', device) && <Heart className="w-3.5 h-3.5 text-muted-foreground" />}
          {getVisibility('theme', device) && <Sun className="w-3.5 h-3.5 text-muted-foreground" />}
          {getVisibility('profile', device) && <User className="w-3.5 h-3.5 text-muted-foreground" />}
          {getVisibility('language', device) && <Globe className="w-3.5 h-3.5 text-muted-foreground" />}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Visibilità Header</h3>
          <p className="text-sm text-muted-foreground">Scegli cosa mostrare per ogni dispositivo</p>
        </div>
        <Button onClick={handleSave} disabled={updateMutation.isPending} size="sm">
          {updateMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          Salva
        </Button>
      </div>

      {/* Live Preview Section */}
      <Card className="bg-secondary/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            Anteprima Live
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Smartphone className="w-3 h-3" /> Mobile
              </div>
              {renderPreview('mobile')}
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Tablet className="w-3 h-3" /> Tablet
              </div>
              {renderPreview('tablet')}
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Monitor className="w-3 h-3" /> Desktop
              </div>
              {renderPreview('desktop')}
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="byElement">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="byElement">Per Elemento</TabsTrigger>
          <TabsTrigger value="byDevice">Per Dispositivo</TabsTrigger>
        </TabsList>

        <TabsContent value="byElement" className="mt-4 space-y-3">
          {HEADER_ELEMENTS.map((element) => {
            const Icon = element.icon;
            return (
              <Card key={element.key} className="overflow-hidden">
                <div className="flex items-center justify-between p-3">
                  <div className="flex items-center gap-3">
                    <div className="p-1.5 rounded-lg bg-accent/10">
                      <Icon className="w-4 h-4 text-accent" />
                    </div>
                    <div>
                      <div className="text-sm font-medium">{element.label}</div>
                      <div className="text-xs text-muted-foreground">{element.description}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {DEVICES.map((device) => {
                      const DeviceIcon = device.icon;
                      const isVisible = getVisibility(element.key, device.key);
                      return (
                        <button
                          key={device.key}
                          onClick={() => toggleVisibility(element.key, device.key, !isVisible)}
                          className={`p-1.5 rounded-md transition-all ${
                            isVisible 
                              ? 'bg-accent text-accent-foreground' 
                              : 'bg-secondary/50 text-muted-foreground hover:bg-secondary'
                          }`}
                          title={`${device.label}: ${isVisible ? 'Visibile' : 'Nascosto'}`}
                        >
                          <DeviceIcon className="w-3.5 h-3.5" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              </Card>
            );
          })}
        </TabsContent>

        <TabsContent value="byDevice" className="mt-4 space-y-4">
          {DEVICES.map((device) => {
            const DeviceIcon = device.icon;
            const visibleCount = HEADER_ELEMENTS.filter(el => getVisibility(el.key, device.key)).length;
            return (
              <Card key={device.key}>
                <CardHeader className="py-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-accent/10">
                        <DeviceIcon className="w-5 h-5 text-accent" />
                      </div>
                      <div>
                        <CardTitle className="text-sm">{device.label}</CardTitle>
                        <CardDescription className="text-xs">{device.description}</CardDescription>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">{visibleCount}/{HEADER_ELEMENTS.length} visibili</span>
                  </div>
                </CardHeader>
                <CardContent className="py-2">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {HEADER_ELEMENTS.map((element) => {
                      const Icon = element.icon;
                      const isVisible = getVisibility(element.key, device.key);
                      return (
                        <button
                          key={element.key}
                          onClick={() => toggleVisibility(element.key, device.key, !isVisible)}
                          className={`flex items-center gap-2 p-2 rounded-lg transition-all ${
                            isVisible 
                              ? 'bg-accent/20 border border-accent/30' 
                              : 'bg-secondary/30 border border-transparent hover:bg-secondary/50'
                          }`}
                        >
                          <Icon className={`w-4 h-4 ${isVisible ? 'text-accent' : 'text-muted-foreground'}`} />
                          <span className={`text-xs ${isVisible ? 'text-foreground' : 'text-muted-foreground'}`}>
                            {element.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>
      </Tabs>
    </div>
  );
}