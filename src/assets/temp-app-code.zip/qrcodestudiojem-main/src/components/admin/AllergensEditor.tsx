import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash2, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { MultiLangInput, type MultiLangValue } from './MultiLangInput';

interface Allergen {
  code: string;
  name_it: string;
  name_en: string;
  name_de?: string | null;
  name_es?: string | null;
  name_fr?: string | null;
  icon: string;
  color: string;
}

export function AllergensEditor() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAllergen, setEditingAllergen] = useState<Allergen | null>(null);

  const { data: allergens = [], isLoading } = useQuery({
    queryKey: ['admin-allergens'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('allergens')
        .select('*')
        .order('code');
      if (error) throw error;
      return data as Allergen[];
    }
  });

  const saveMutation = useMutation({
    mutationFn: async (allergen: Partial<Allergen> & { code: string; isNew?: boolean }) => {
      const { isNew, ...data } = allergen;
      if (isNew) {
        const { error } = await supabase
          .from('allergens')
          .insert([data as any]);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('allergens')
          .update(data)
          .eq('code', allergen.code);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-allergens'] });
      setIsDialogOpen(false);
      setEditingAllergen(null);
      toast({ title: 'Allergene salvato!' });
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (code: string) => {
      const { error } = await supabase.from('allergens').delete().eq('code', code);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-allergens'] });
      toast({ title: 'Allergene eliminato!' });
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const AllergenForm = ({ allergen, onSave }: { allergen: Allergen | null; onSave: (data: Partial<Allergen> & { code: string; isNew?: boolean }) => void }) => {
    const [nameValue, setNameValue] = useState<MultiLangValue>({
      it: allergen?.name_it || '',
      en: allergen?.name_en || '',
      de: allergen?.name_de || '',
      es: allergen?.name_es || '',
      fr: allergen?.name_fr || '',
    });
    const [formData, setFormData] = useState({
      code: allergen?.code || '',
      icon: allergen?.icon || '⚠️',
      color: allergen?.color || '#666666'
    });

    const isNew = !allergen;

    const handleSave = () => {
      onSave({
        code: formData.code,
        name_it: nameValue.it || '',
        name_en: nameValue.en || '',
        name_de: nameValue.de || null,
        name_es: nameValue.es || null,
        name_fr: nameValue.fr || null,
        icon: formData.icon,
        color: formData.color,
        isNew
      });
    };

    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Codice</Label>
            <Input
              value={formData.code}
              onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
              placeholder="GLUTEN"
              disabled={!isNew}
              className="uppercase"
            />
          </div>
          <div className="space-y-2">
            <Label>Icona (emoji)</Label>
            <Input
              value={formData.icon}
              onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
              placeholder="🌾"
            />
          </div>
        </div>

        <MultiLangInput
          label="Nome allergene"
          value={nameValue}
          onChange={setNameValue}
          placeholder="Nome"
          required
        />

        <div className="space-y-2">
          <Label>Colore</Label>
          <div className="flex gap-2">
            <Input
              type="color"
              value={formData.color}
              onChange={(e) => setFormData({ ...formData, color: e.target.value })}
              className="w-16 h-10 p-1"
            />
            <Input
              value={formData.color}
              onChange={(e) => setFormData({ ...formData, color: e.target.value })}
              placeholder="#666666"
              className="flex-1"
            />
          </div>
        </div>

        <Button
          onClick={handleSave}
          disabled={!formData.code || !nameValue.it || !nameValue.en}
          className="w-full"
        >
          {isNew ? 'Crea' : 'Aggiorna'} Allergene
        </Button>
      </div>
    );
  };

  if (isLoading) {
    return <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin" /></div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingAllergen(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Nuovo Allergene
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{editingAllergen ? 'Modifica' : 'Nuovo'} Allergene</DialogTitle>
            </DialogHeader>
            <AllergenForm
              allergen={editingAllergen}
              onSave={(data) => saveMutation.mutate(data)}
            />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {allergens.map((allergen) => (
          <div
            key={allergen.code}
            className="flex items-center gap-3 p-3 bg-card border border-border rounded-lg"
          >
            <div 
              className="w-10 h-10 rounded-lg flex items-center justify-center text-xl"
              style={{ backgroundColor: allergen.color + '20' }}
            >
              {allergen.icon}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-medium text-sm">{allergen.name_it}</span>
                <span 
                  className="text-xs px-1.5 py-0.5 rounded"
                  style={{ backgroundColor: allergen.color + '30', color: allergen.color }}
                >
                  {allergen.code}
                </span>
              </div>
              <p className="text-xs text-muted-foreground">{allergen.name_en}</p>
            </div>

            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => {
                  setEditingAllergen(allergen);
                  setIsDialogOpen(true);
                }}
              >
                <Pencil className="w-3 h-3" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => {
                  if (confirm('Eliminare questo allergene?')) {
                    deleteMutation.mutate(allergen.code);
                  }
                }}
              >
                <Trash2 className="w-3 h-3 text-destructive" />
              </Button>
            </div>
          </div>
        ))}

        {allergens.length === 0 && (
          <p className="col-span-full text-center text-muted-foreground py-8">Nessun allergene</p>
        )}
      </div>
    </div>
  );
}
