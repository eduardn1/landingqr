import { motion } from 'framer-motion';
import { Save, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ImageUpload } from './ImageUpload';
import { GradientColorPicker, colorPresets } from './GradientColorPicker';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';
import type { RestaurantConfig } from '@/hooks/useRestaurantConfig';

interface BrandingForm {
  name: string;
  tagline_it: string;
  tagline_en: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  city: string;
  instagram_url: string;
  facebook_url: string;
  tiktok_url: string;
  tripadvisor_url: string;
  google_maps_url: string;
  color_primary: string;
  color_secondary: string;
  color_accent: string;
  color_background: string;
  color_foreground: string;
}

interface BrandingSectionProps {
  config: RestaurantConfig | undefined;
  brandingForm: BrandingForm;
  setBrandingForm: (form: BrandingForm) => void;
  isSaving: boolean;
  onSave: () => void;
  onRefresh: () => void;
}

export function BrandingSection({
  config,
  brandingForm,
  setBrandingForm,
  isSaving,
  onSave,
  onRefresh,
}: BrandingSectionProps) {
  const queryClient = useQueryClient();

  const handleLogoUpload = async (url: string) => {
    if (!config?.id) return;
    
    try {
      const { error } = await supabase
        .from('restaurant_config')
        .update({ logo_url: url })
        .eq('id', config.id);

      if (error) throw error;
      toast.success('Logo aggiornato!');
      queryClient.invalidateQueries({ queryKey: ['restaurant-config'] });
    } catch (error) {
      console.error('Error updating logo:', error);
      toast.error('Errore nel salvataggio del logo');
    }
  };

  const handleCoverUpload = async (url: string) => {
    if (!config?.id) return;
    
    try {
      const { error } = await supabase
        .from('restaurant_config')
        .update({ cover_image_url: url })
        .eq('id', config.id);

      if (error) throw error;
      toast.success('Immagine di copertina aggiornata!');
      queryClient.invalidateQueries({ queryKey: ['restaurant-config'] });
    } catch (error) {
      console.error('Error updating cover:', error);
      toast.error('Errore nel salvataggio');
    }
  };

  const handleFaviconUpload = async (url: string) => {
    if (!config?.id) return;
    
    try {
      const { error } = await supabase
        .from('restaurant_config')
        .update({ favicon_url: url })
        .eq('id', config.id);

      if (error) throw error;
      toast.success('Favicon aggiornato!');
      queryClient.invalidateQueries({ queryKey: ['restaurant-config'] });
    } catch (error) {
      console.error('Error updating favicon:', error);
      toast.error('Errore nel salvataggio del favicon');
    }
  };


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4 sm:space-y-6"
    >
      {/* Logo, Cover & Favicon */}
      <div className="p-4 sm:p-6 rounded-2xl bg-secondary/30 border border-border/30 space-y-4">
        <h2 className="text-lg font-semibold">Logo & Immagini</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Logo Ristorante</label>
            <ImageUpload
              value={config?.logo_url || ''}
              onChange={(url) => url && handleLogoUpload(url)}
              folder="branding"
            />
            <p className="text-xs text-muted-foreground">Consigliato: 200x200px, PNG/JPG</p>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Favicon</label>
            <ImageUpload
              value={config?.favicon_url || ''}
              onChange={(url) => url && handleFaviconUpload(url)}
              folder="branding"
            />
            <p className="text-xs text-muted-foreground">Consigliato: 32x32px o 64x64px, PNG</p>
          </div>
          <div className="space-y-2 sm:col-span-2 lg:col-span-1">
            <label className="text-sm text-muted-foreground">Immagine di Copertina</label>
            <ImageUpload
              value={config?.cover_image_url || ''}
              onChange={(url) => url && handleCoverUpload(url)}
              folder="branding"
            />
            <p className="text-xs text-muted-foreground">Consigliato: 1920x1080px, JPG</p>
          </div>
        </div>
      </div>

      {/* Info Ristorante */}
      <div className="p-4 sm:p-6 rounded-2xl bg-secondary/30 border border-border/30 space-y-4">
        <h2 className="text-lg font-semibold">Informazioni Ristorante</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Nome Ristorante</label>
            <Input
              value={brandingForm.name}
              onChange={(e) => setBrandingForm({ ...brandingForm, name: e.target.value })}
              placeholder="Nome del ristorante"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Telefono</label>
            <Input
              value={brandingForm.phone}
              onChange={(e) => setBrandingForm({ ...brandingForm, phone: e.target.value })}
              placeholder="+39 02 1234567"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">WhatsApp</label>
            <Input
              value={brandingForm.whatsapp}
              onChange={(e) => setBrandingForm({ ...brandingForm, whatsapp: e.target.value })}
              placeholder="+39 333 1234567"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Email</label>
            <Input
              value={brandingForm.email}
              onChange={(e) => setBrandingForm({ ...brandingForm, email: e.target.value })}
              placeholder="info@ristorante.it"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Tagline (IT)</label>
            <Input
              value={brandingForm.tagline_it}
              onChange={(e) => setBrandingForm({ ...brandingForm, tagline_it: e.target.value })}
              placeholder="Slogan in italiano"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Tagline (EN)</label>
            <Input
              value={brandingForm.tagline_en}
              onChange={(e) => setBrandingForm({ ...brandingForm, tagline_en: e.target.value })}
              placeholder="Slogan in inglese"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Indirizzo</label>
            <Input
              value={brandingForm.address}
              onChange={(e) => setBrandingForm({ ...brandingForm, address: e.target.value })}
              placeholder="Via Roma 123"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Città</label>
            <Input
              value={brandingForm.city}
              onChange={(e) => setBrandingForm({ ...brandingForm, city: e.target.value })}
              placeholder="Milano"
            />
          </div>
        </div>
      </div>

      {/* Social & Links */}
      <div className="p-4 sm:p-6 rounded-2xl bg-secondary/30 border border-border/30 space-y-4">
        <h2 className="text-lg font-semibold">Social & Link</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Instagram URL</label>
            <Input
              value={brandingForm.instagram_url}
              onChange={(e) => setBrandingForm({ ...brandingForm, instagram_url: e.target.value })}
              placeholder="https://instagram.com/..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Facebook URL</label>
            <Input
              value={brandingForm.facebook_url}
              onChange={(e) => setBrandingForm({ ...brandingForm, facebook_url: e.target.value })}
              placeholder="https://facebook.com/..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">TikTok URL</label>
            <Input
              value={brandingForm.tiktok_url}
              onChange={(e) => setBrandingForm({ ...brandingForm, tiktok_url: e.target.value })}
              placeholder="https://tiktok.com/@..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">TripAdvisor URL</label>
            <Input
              value={brandingForm.tripadvisor_url}
              onChange={(e) => setBrandingForm({ ...brandingForm, tripadvisor_url: e.target.value })}
              placeholder="https://tripadvisor.com/..."
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm text-muted-foreground">Google Maps URL</label>
          <Input
            value={brandingForm.google_maps_url}
            onChange={(e) => setBrandingForm({ ...brandingForm, google_maps_url: e.target.value })}
            placeholder="https://maps.google.com/..."
          />
        </div>
      </div>

      {/* Colori */}
      <div className="p-4 sm:p-6 rounded-2xl bg-secondary/30 border border-border/30 space-y-4">
        <h2 className="text-lg font-semibold">Colore Accent</h2>
        <p className="text-xs text-muted-foreground">Il colore principale che evidenzia elementi importanti. Puoi scegliere un colore solido o un gradiente.</p>
        
        <GradientColorPicker
          value={brandingForm.color_accent || ''}
          onChange={(value) => setBrandingForm({ ...brandingForm, color_accent: value })}
          type="both"
          label="Scegli colore o gradiente accent"
          placeholder="Seleziona un colore o gradiente..."
        />
        
        {/* Preview of current accent */}
        {brandingForm.color_accent && (
          <div className="flex items-center gap-3 p-3 rounded-lg bg-background/50 border border-border/30">
            <span className="text-xs text-muted-foreground">Anteprima:</span>
            {brandingForm.color_accent.includes('from-') ? (
              <div className={`w-20 h-8 rounded-lg bg-gradient-to-r ${brandingForm.color_accent}`} />
            ) : (
              <div 
                className="w-20 h-8 rounded-lg border border-border"
                style={{ backgroundColor: `hsl(${brandingForm.color_accent})` }}
              />
            )}
            <code className="text-[10px] text-muted-foreground bg-secondary/50 px-2 py-1 rounded truncate max-w-[150px]">
              {brandingForm.color_accent}
            </code>
          </div>
        )}
        
        <p className="text-xs text-muted-foreground">
          <strong>Suggerimento:</strong> Per gradienti personalizzati usa il formato: <code className="bg-secondary/50 px-1 rounded">from-[#colore1] to-[#colore2]</code>
        </p>
      </div>
      
      {/* Altri Colori Tema */}
      <div className="p-4 sm:p-6 rounded-2xl bg-secondary/30 border border-border/30 space-y-4">
        <h2 className="text-lg font-semibold">Altri Colori (Avanzato)</h2>
        <p className="text-xs text-muted-foreground">Modifica solo se necessario - il tema gestisce automaticamente la maggior parte dei colori</p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Primary</label>
            <div className="flex gap-2">
              <Input
                value={brandingForm.color_primary}
                onChange={(e) => setBrandingForm({ ...brandingForm, color_primary: e.target.value })}
                placeholder="0 0% 98%"
                className="flex-1"
              />
              <div 
                className="w-10 h-10 rounded-lg border border-border shrink-0"
                style={{ backgroundColor: `hsl(${brandingForm.color_primary})` }}
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Secondary</label>
            <div className="flex gap-2">
              <Input
                value={brandingForm.color_secondary}
                onChange={(e) => setBrandingForm({ ...brandingForm, color_secondary: e.target.value })}
                placeholder="0 0% 12%"
                className="flex-1"
              />
              <div 
                className="w-10 h-10 rounded-lg border border-border shrink-0"
                style={{ backgroundColor: `hsl(${brandingForm.color_secondary})` }}
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Background</label>
            <div className="flex gap-2">
              <Input
                value={brandingForm.color_background}
                onChange={(e) => setBrandingForm({ ...brandingForm, color_background: e.target.value })}
                placeholder="0 0% 4%"
                className="flex-1"
              />
              <div 
                className="w-10 h-10 rounded-lg border border-border shrink-0"
                style={{ backgroundColor: `hsl(${brandingForm.color_background})` }}
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Foreground</label>
            <div className="flex gap-2">
              <Input
                value={brandingForm.color_foreground}
                onChange={(e) => setBrandingForm({ ...brandingForm, color_foreground: e.target.value })}
                placeholder="0 0% 98%"
                className="flex-1"
              />
              <div 
                className="w-10 h-10 rounded-lg border border-border shrink-0"
                style={{ backgroundColor: `hsl(${brandingForm.color_foreground})` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* SEO Note */}
      <div className="p-3 sm:p-4 rounded-2xl bg-accent/10 border border-accent/30">
        <p className="text-xs sm:text-sm text-muted-foreground">
          <strong>SEO & Social Sharing:</strong> Gestisci le impostazioni SEO complete (meta tag, Open Graph, Twitter Cards, Schema.org) nella sezione dedicata <strong>"SEO & Meta"</strong> del menu admin.
        </p>
      </div>

      <Button onClick={onSave} disabled={isSaving} className="w-full touch-manipulation">
        {isSaving ? (
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        ) : (
          <Save className="w-4 h-4 mr-2" />
        )}
        Salva Tutte le Modifiche
      </Button>
    </motion.div>
  );
}
