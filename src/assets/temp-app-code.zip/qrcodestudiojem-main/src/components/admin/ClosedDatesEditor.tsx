import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format, parseISO } from 'date-fns';
import { it } from 'date-fns/locale';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Plus, Trash2, Info, RefreshCw } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface ClosedDate {
  id: string;
  date: string;
  reason: string | null;
  is_recurring: boolean;
}

export function ClosedDatesEditor() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newDate, setNewDate] = useState('');
  const [newReason, setNewReason] = useState('');
  const [isRecurring, setIsRecurring] = useState(false);

  const { data: closedDates = [], isLoading } = useQuery({
    queryKey: ['closed-dates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('closed_dates')
        .select('*')
        .order('date', { ascending: true });
      if (error) throw error;
      return data as ClosedDate[];
    }
  });

  const addMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from('closed_dates')
        .insert({
          date: newDate,
          reason: newReason || null,
          is_recurring: isRecurring
        });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['closed-dates'] });
      toast({ title: 'Data aggiunta!' });
      setNewDate('');
      setNewReason('');
      setIsRecurring(false);
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('closed_dates')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['closed-dates'] });
      toast({ title: 'Data rimossa!' });
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const upcomingDates = closedDates.filter(d => new Date(d.date) >= new Date() || d.is_recurring);

  return (
    <div className="space-y-6">
      {/* Info Banner */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-start gap-3 p-4 rounded-xl bg-orange-500/10 border border-orange-500/20"
      >
        <Info className="w-5 h-5 text-orange-500 mt-0.5 shrink-0" />
        <div className="space-y-1">
          <p className="text-sm font-medium text-foreground">Giorni di chiusura speciali</p>
          <p className="text-xs text-muted-foreground">
            Aggiungi festività, ferie o giorni di chiusura straordinaria. 
            Questi giorni non saranno disponibili per le prenotazioni.
          </p>
        </div>
      </motion.div>

      {/* Add New Date */}
      <div className="p-4 rounded-xl bg-secondary/30 border border-border/30 space-y-4">
        <h3 className="font-medium flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Aggiungi chiusura
        </h3>
        <div className="grid sm:grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Data</Label>
            <Input
              type="date"
              value={newDate}
              onChange={(e) => setNewDate(e.target.value)}
              min={format(new Date(), 'yyyy-MM-dd')}
            />
          </div>
          <div className="space-y-2">
            <Label className="text-xs text-muted-foreground">Motivo (opzionale)</Label>
            <Input
              value={newReason}
              onChange={(e) => setNewReason(e.target.value)}
              placeholder="Es: Natale, Ferie estive..."
            />
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Switch
              checked={isRecurring}
              onCheckedChange={setIsRecurring}
            />
            <Label className="text-sm text-muted-foreground">
              Ricorrente ogni anno
            </Label>
          </div>
          <Button
            onClick={() => addMutation.mutate()}
            disabled={!newDate || addMutation.isPending}
            size="sm"
          >
            <Plus className="w-4 h-4 mr-1" />
            Aggiungi
          </Button>
        </div>
      </div>

      {/* Dates List */}
      <div className="space-y-3">
        <h3 className="font-medium">Date di chiusura</h3>
        
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <RefreshCw className="w-5 h-5 animate-spin text-muted-foreground" />
          </div>
        ) : upcomingDates.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            Nessuna chiusura programmata
          </p>
        ) : (
          <AnimatePresence mode="popLayout">
            {upcomingDates.map((closedDate, index) => (
              <motion.div
                key={closedDate.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center justify-between p-4 rounded-xl border bg-card border-border hover:border-accent/30 transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-10 h-10 rounded-lg flex items-center justify-center",
                    closedDate.is_recurring ? "bg-purple-500/10" : "bg-red-500/10"
                  )}>
                    <Calendar className={cn(
                      "w-5 h-5",
                      closedDate.is_recurring ? "text-purple-500" : "text-red-500"
                    )} />
                  </div>
                  <div>
                    <p className="font-medium">
                      {format(parseISO(closedDate.date), 'EEEE d MMMM yyyy', { locale: it })}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      {closedDate.reason && <span>{closedDate.reason}</span>}
                      {closedDate.is_recurring && (
                        <span className="px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-600">
                          Ricorrente
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                  onClick={() => deleteMutation.mutate(closedDate.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
