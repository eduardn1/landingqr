import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format, parseISO, isToday, isTomorrow, isPast, startOfDay, addDays } from 'date-fns';
import { it } from 'date-fns/locale';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Calendar, Users, Phone, Clock, Check, X, 
  ChevronLeft, ChevronRight, MessageSquare, Filter,
  CalendarDays, List, AlertCircle, CheckCircle2, XCircle,
  Edit2, Trash2, Save, PartyPopper, Timer
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';

// WhatsApp rate limit: 1 message per 5 seconds minimum
const MIN_MESSAGE_INTERVAL_MS = 6000;

interface Reservation {
  id: string;
  name: string;
  phone: string;
  guests: number;
  reservation_date: string;
  reservation_time: string;
  notes: string | null;
  status: string | null;
  created_at: string;
  event_id: string | null;
  event?: {
    id: string;
    title_it: string;
    title_en: string | null;
  } | null;
}

const STATUS_CONFIG = {
  pending: { label: 'In attesa', color: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20', icon: AlertCircle },
  confirmed: { label: 'Confermata', color: 'bg-green-500/10 text-green-600 border-green-500/20', icon: CheckCircle2 },
  rejected: { label: 'Rifiutata', color: 'bg-red-500/10 text-red-600 border-red-500/20', icon: XCircle },
  completed: { label: 'Completata', color: 'bg-blue-500/10 text-blue-600 border-blue-500/20', icon: Check },
  cancelled: { label: 'Cancellata', color: 'bg-gray-500/10 text-gray-600 border-gray-500/20', icon: XCircle },
};

// Random welcome emojis and messages
const WELCOME_MESSAGES = [
  { emoji: '👨‍🍳', message: 'Buona giornata, Chef!' },
  { emoji: '🍽️', message: 'Pronto per una nuova giornata!' },
  { emoji: '☕', message: 'Un caffè e si parte!' },
  { emoji: '🌟', message: 'Brilliamo oggi!' },
  { emoji: '🎯', message: 'Focus e determinazione!' },
  { emoji: '🚀', message: 'Al massimo oggi!' },
  { emoji: '💪', message: 'Forza e coraggio!' },
  { emoji: '🔥', message: 'Accendiamo i fornelli!' },
];

export function ReservationsAdmin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');
  const [selectedReservation, setSelectedReservation] = useState<Reservation | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<Reservation>>({});
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [cooldownRemaining, setCooldownRemaining] = useState(0);
  const lastMessageTimeRef = useRef<number>(0);
  const cooldownIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const [welcomeMessage] = useState(() => {
    const dailySeed = new Date().toDateString();
    const index = dailySeed.split('').reduce((a, b) => a + b.charCodeAt(0), 0) % WELCOME_MESSAGES.length;
    return WELCOME_MESSAGES[index];
  });

  // Start cooldown timer
  const startCooldownTimer = (remainingMs: number) => {
    if (cooldownIntervalRef.current) {
      clearInterval(cooldownIntervalRef.current);
    }
    setCooldownRemaining(Math.ceil(remainingMs / 1000));
    cooldownIntervalRef.current = setInterval(() => {
      setCooldownRemaining(prev => {
        if (prev <= 1) {
          if (cooldownIntervalRef.current) {
            clearInterval(cooldownIntervalRef.current);
            cooldownIntervalRef.current = null;
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Get wait time
  const getWaitTime = (): number => {
    const now = Date.now();
    const timeSinceLastMessage = now - lastMessageTimeRef.current;
    return Math.max(0, MIN_MESSAGE_INTERVAL_MS - timeSinceLastMessage);
  };

  const { data: reservations = [], isLoading } = useQuery({
    queryKey: ['admin-reservations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('reservations')
        .select(`
          *,
          event:events(id, title_it, title_en)
        `)
        .order('reservation_date', { ascending: true })
        .order('reservation_time', { ascending: true });
      if (error) throw error;
      return data as Reservation[];
    }
  });

  const { data: config } = useQuery({
    queryKey: ['restaurant-config'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('restaurant_config')
        .select('whatsapp, name')
        .single();
      if (error) throw error;
      return data;
    }
  });

  // Set edit form when reservation is selected
  useEffect(() => {
    if (selectedReservation) {
      setEditForm({
        name: selectedReservation.name,
        phone: selectedReservation.phone,
        guests: selectedReservation.guests,
        reservation_date: selectedReservation.reservation_date,
        reservation_time: selectedReservation.reservation_time,
        notes: selectedReservation.notes,
      });
    }
  }, [selectedReservation]);

  const sendWhatsAppNotification = async (reservation: Reservation, templateKey: string) => {
    // Check rate limit
    const waitTime = getWaitTime();
    if (waitTime > 0) {
      toast({ 
        title: 'Attendi...', 
        description: `Prossimo invio WhatsApp disponibile tra ${Math.ceil(waitTime / 1000)}s`,
        variant: 'default'
      });
      startCooldownTimer(waitTime);
      return;
    }

    const localeName = config?.name || 'Il Locale';
    const dateFormatted = format(parseISO(reservation.reservation_date), 'EEEE d MMMM', { locale: it });
    
    // Check if this is an event reservation and adjust template
    const isEventReservation = !!reservation.event_id && !!reservation.event;
    const eventName = reservation.event?.title_it || reservation.event?.title_en || '';
    
    // Use event-specific templates when applicable
    let finalTemplateKey = templateKey;
    if (isEventReservation) {
      if (templateKey === 'reservation_confirmed') {
        finalTemplateKey = 'event_reservation_confirmed';
      }
    }
    
    const variables: Record<string, string> = {
      name: reservation.name,
      phone: reservation.phone,
      date: dateFormatted,
      time: reservation.reservation_time,
      guests: String(reservation.guests),
      notes: reservation.notes || 'Nessuna nota',
      locale_name: localeName
    };
    
    // Add event name if it's an event reservation
    if (isEventReservation && eventName) {
      variables.event_name = eventName;
    }
    
    try {
      // Mark message as sent and start cooldown
      lastMessageTimeRef.current = Date.now();
      startCooldownTimer(MIN_MESSAGE_INTERVAL_MS);

      const { data, error } = await supabase.functions.invoke('send-whatsapp', {
        body: {
          phone: reservation.phone,
          templateKey: finalTemplateKey,
          variables: variables
        }
      });

      if (error) {
        console.error('Error sending WhatsApp notification:', error);
        toast({ 
          title: 'Errore invio WhatsApp', 
          description: error.message, 
          variant: 'destructive' 
        });
      } else if (data?.success) {
        toast({ 
          title: 'Notifica inviata!', 
          description: `Messaggio WhatsApp inviato a ${reservation.name}` 
        });
      } else {
        toast({ 
          title: 'Errore invio WhatsApp', 
          description: data?.error || 'Errore sconosciuto', 
          variant: 'destructive' 
        });
      }
    } catch (err: any) {
      console.error('Error sending WhatsApp notification:', err);
      toast({ 
        title: 'Errore invio WhatsApp', 
        description: err.message, 
        variant: 'destructive' 
      });
    }
  };

  // Process gamification when reservation is confirmed
  const processGamification = async (userId: string, reservationId: string, guests: number) => {
    try {
      const { error } = await supabase.functions.invoke('process-gamification', {
        body: {
          userId,
          reservationId,
          guests,
          actionType: 'reservation_confirmed'
        }
      });
      
      if (error) {
        console.error('Gamification processing error:', error);
      } else {
        console.log('Gamification processed successfully');
      }
    } catch (err) {
      console.error('Failed to process gamification:', err);
    }
  };

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status, reservation }: { id: string; status: string; reservation?: Reservation }) => {
      const { error } = await supabase
        .from('reservations')
        .update({ status })
        .eq('id', id);
      if (error) throw error;
      return { status, reservation };
    },
    onSuccess: async (data) => {
      queryClient.invalidateQueries({ queryKey: ['admin-reservations'] });
      toast({ title: 'Stato aggiornato!' });
      
      if (data.reservation) {
        if (data.status === 'confirmed') {
          sendWhatsAppNotification(data.reservation, 'reservation_confirmed');
          
          // Trigger gamification processing for confirmed reservations
          // Get user_id from reservation
          const { data: reservationData } = await supabase
            .from('reservations')
            .select('user_id, guests')
            .eq('id', data.reservation.id)
            .single();
          
          if (reservationData?.user_id) {
            processGamification(
              reservationData.user_id, 
              data.reservation.id, 
              reservationData.guests
            );
          }
        } else if (data.status === 'rejected') {
          sendWhatsAppNotification(data.reservation, 'reservation_rejected');
        }
      }
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const updateReservationMutation = useMutation({
    mutationFn: async (updates: Partial<Reservation> & { id: string }) => {
      const { id, ...data } = updates;
      const { error } = await supabase
        .from('reservations')
        .update(data)
        .eq('id', id);
      if (error) throw error;
      return { id, data };
    },
    onSuccess: async ({ id, data }) => {
      queryClient.invalidateQueries({ queryKey: ['admin-reservations'] });
      toast({ title: 'Prenotazione aggiornata!' });
      setIsEditing(false);
      
      // Send modification notification to customer
      const reservation = reservations.find(r => r.id === id);
      if (reservation) {
        const updatedReservation = { ...reservation, ...data };
        sendWhatsAppNotification(updatedReservation, 'reservation_modified');
      }
      
      setSelectedReservation(null);
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const deleteReservationMutation = useMutation({
    mutationFn: async (id: string) => {
      // Get reservation details before deleting
      const reservation = reservations.find(r => r.id === id);
      
      const { error } = await supabase
        .from('reservations')
        .delete()
        .eq('id', id);
      if (error) throw error;
      
      return reservation;
    },
    onSuccess: (reservation) => {
      queryClient.invalidateQueries({ queryKey: ['admin-reservations'] });
      toast({ title: 'Prenotazione eliminata!' });
      setDeleteConfirmOpen(false);
      setSelectedReservation(null);
      
      // Send cancellation notification to customer
      if (reservation) {
        sendWhatsAppNotification(reservation, 'reservation_cancelled');
      }
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const handleSaveEdit = () => {
    if (!selectedReservation) return;
    updateReservationMutation.mutate({
      id: selectedReservation.id,
      ...editForm
    });
  };

  const getDateLabel = (date: string) => {
    const parsed = parseISO(date);
    if (isToday(parsed)) return 'Oggi';
    if (isTomorrow(parsed)) return 'Domani';
    return format(parsed, 'EEEE d MMMM', { locale: it });
  };

  const filteredReservations = reservations.filter(r => {
    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    return true;
  });

  const todayReservations = filteredReservations.filter(r => isToday(parseISO(r.reservation_date)));
  const upcomingReservations = filteredReservations.filter(r => !isPast(startOfDay(parseISO(r.reservation_date))));
  const pendingCount = reservations.filter(r => r.status === 'pending').length;

  const getReservationsForDate = (date: Date) => {
    return filteredReservations.filter(r => 
      format(parseISO(r.reservation_date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );
  };

  const calendarDays = Array.from({ length: 7 }, (_, i) => addDays(startOfDay(selectedDate), i - 3));

  const ReservationCard = ({ reservation }: { reservation: Reservation }) => {
    const status = STATUS_CONFIG[reservation.status as keyof typeof STATUS_CONFIG] || STATUS_CONFIG.pending;
    const StatusIcon = status.icon;
    const isPastReservation = isPast(parseISO(`${reservation.reservation_date}T${reservation.reservation_time}`));

    return (
      <motion.div
        layout
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        className={cn(
          "p-4 rounded-xl border transition-all cursor-pointer hover:shadow-md",
          isPastReservation && reservation.status !== 'completed' ? "opacity-60" : "",
          "bg-card border-border hover:border-accent/30"
        )}
        onClick={() => setSelectedReservation(reservation)}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="font-semibold truncate">{reservation.name}</span>
              <Badge variant="outline" className={cn("text-xs", status.color)}>
                <StatusIcon className="w-3 h-3 mr-1" />
                {status.label}
              </Badge>
              {reservation.event && (
                <Badge variant="outline" className="text-xs bg-accent/10 text-accent border-accent/30">
                  <PartyPopper className="w-3 h-3 mr-1" />
                  {reservation.event.title_it || reservation.event.title_en}
                </Badge>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {getDateLabel(reservation.reservation_date)}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {reservation.reservation_time}
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-3.5 h-3.5" />
                {reservation.guests} {reservation.guests === 1 ? 'persona' : 'persone'}
              </span>
            </div>
          </div>
          
          {reservation.status === 'pending' && (
            <div className="flex gap-1">
              <Button
                size="icon"
                variant="ghost"
                className="h-8 w-8 text-green-600 hover:bg-green-500/10"
                onClick={(e) => {
                  e.stopPropagation();
                  updateStatusMutation.mutate({ id: reservation.id, status: 'confirmed', reservation });
                }}
              >
                <Check className="w-4 h-4" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="h-8 w-8 text-red-600 hover:bg-red-500/10"
                onClick={(e) => {
                  e.stopPropagation();
                  updateStatusMutation.mutate({ id: reservation.id, status: 'rejected', reservation });
                }}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </motion.div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Welcome Message */}
      <div className="p-4 rounded-xl bg-accent/10 border border-accent/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{welcomeMessage.emoji}</span>
            <p className="text-lg font-medium">{welcomeMessage.message}</p>
          </div>
          
          {/* WhatsApp Cooldown Indicator */}
          {cooldownRemaining > 0 && (
            <Badge variant="outline" className="gap-1 text-amber-600 border-amber-500/30 bg-amber-500/10">
              <Timer className="w-3 h-3" />
              <span className="text-xs">WhatsApp: {cooldownRemaining}s</span>
            </Badge>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl bg-secondary/30 border border-border/30">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Oggi</p>
          <p className="text-2xl font-bold mt-1">{todayReservations.length}</p>
        </div>
        <div className="p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
          <p className="text-xs text-yellow-600 uppercase tracking-wider">In attesa</p>
          <p className="text-2xl font-bold mt-1 text-yellow-600">{pendingCount}</p>
        </div>
        <div className="p-4 rounded-xl bg-secondary/30 border border-border/30">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Prossime</p>
          <p className="text-2xl font-bold mt-1">{upcomingReservations.length}</p>
        </div>
        <div className="p-4 rounded-xl bg-secondary/30 border border-border/30">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Totali</p>
          <p className="text-2xl font-bold mt-1">{reservations.length}</p>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('list')}
          >
            <List className="w-4 h-4 mr-1" />
            Lista
          </Button>
          <Button
            variant={viewMode === 'calendar' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('calendar')}
          >
            <CalendarDays className="w-4 h-4 mr-1" />
            Calendario
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-sm bg-transparent border border-border rounded-lg px-3 py-1.5"
          >
            <option value="all">Tutti gli stati</option>
            <option value="pending">In attesa</option>
            <option value="confirmed">Confermate</option>
            <option value="rejected">Rifiutate</option>
            <option value="completed">Completate</option>
            <option value="cancelled">Cancellate</option>
          </select>
        </div>
      </div>

      {/* Calendar View */}
      {viewMode === 'calendar' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedDate(addDays(selectedDate, -7))}
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <span className="font-medium">
              {format(calendarDays[0], 'd MMM', { locale: it })} - {format(calendarDays[6], 'd MMM yyyy', { locale: it })}
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedDate(addDays(selectedDate, 7))}
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>

          <div className="grid grid-cols-7 gap-2">
            {calendarDays.map((date) => {
              const dayReservations = getReservationsForDate(date);
              const isSelected = format(date, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd');
              
              return (
                <button
                  key={date.toISOString()}
                  onClick={() => setSelectedDate(date)}
                  className={cn(
                    "p-3 rounded-xl border text-center transition-all",
                    isToday(date) && "border-accent",
                    isSelected ? "bg-accent text-accent-foreground" : "bg-card border-border hover:border-accent/30"
                  )}
                >
                  <p className="text-xs text-muted-foreground mb-1">
                    {format(date, 'EEE', { locale: it })}
                  </p>
                  <p className="text-lg font-semibold">{format(date, 'd')}</p>
                  {dayReservations.length > 0 && (
                    <Badge className="mt-1 text-xs">{dayReservations.length}</Badge>
                  )}
                </button>
              );
            })}
          </div>

          <div className="space-y-2">
            <h3 className="font-medium">{getDateLabel(format(selectedDate, 'yyyy-MM-dd'))}</h3>
            <AnimatePresence mode="popLayout">
              {getReservationsForDate(selectedDate).map((reservation) => (
                <ReservationCard key={reservation.id} reservation={reservation} />
              ))}
            </AnimatePresence>
            {getReservationsForDate(selectedDate).length === 0 && (
              <p className="text-center text-muted-foreground py-8">Nessuna prenotazione per questa data</p>
            )}
          </div>
        </div>
      )}

      {/* List View */}
      {viewMode === 'list' && (
        <Tabs defaultValue="upcoming" className="space-y-4">
          <TabsList>
            <TabsTrigger value="upcoming">Prossime</TabsTrigger>
            <TabsTrigger value="today">Oggi ({todayReservations.length})</TabsTrigger>
            <TabsTrigger value="all">Tutte</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="space-y-2">
            <AnimatePresence mode="popLayout">
              {upcomingReservations.map((reservation) => (
                <ReservationCard key={reservation.id} reservation={reservation} />
              ))}
            </AnimatePresence>
            {upcomingReservations.length === 0 && (
              <p className="text-center text-muted-foreground py-8">Nessuna prenotazione futura</p>
            )}
          </TabsContent>

          <TabsContent value="today" className="space-y-2">
            <AnimatePresence mode="popLayout">
              {todayReservations.map((reservation) => (
                <ReservationCard key={reservation.id} reservation={reservation} />
              ))}
            </AnimatePresence>
            {todayReservations.length === 0 && (
              <p className="text-center text-muted-foreground py-8">Nessuna prenotazione per oggi</p>
            )}
          </TabsContent>

          <TabsContent value="all" className="space-y-2">
            <AnimatePresence mode="popLayout">
              {filteredReservations.map((reservation) => (
                <ReservationCard key={reservation.id} reservation={reservation} />
              ))}
            </AnimatePresence>
          </TabsContent>
        </Tabs>
      )}

      {/* Reservation Detail Modal */}
      <Dialog open={!!selectedReservation} onOpenChange={() => { setSelectedReservation(null); setIsEditing(false); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <span>Dettagli Prenotazione</span>
              <div className="flex gap-2">
                {!isEditing && (
                  <>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => setIsEditing(true)}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="text-destructive hover:bg-destructive/10"
                      onClick={() => setDeleteConfirmOpen(true)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </>
                )}
              </div>
            </DialogTitle>
          </DialogHeader>
          {selectedReservation && (
            <div className="space-y-4">
              {isEditing ? (
                // Edit Form
                <>
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-muted-foreground">Nome</label>
                      <Input
                        value={editForm.name || ''}
                        onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Telefono</label>
                      <Input
                        value={editForm.phone || ''}
                        onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-xs text-muted-foreground">Persone</label>
                        <Input
                          type="number"
                          min="1"
                          value={editForm.guests || 1}
                          onChange={(e) => setEditForm({ ...editForm, guests: parseInt(e.target.value) })}
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground">Ora</label>
                        <Input
                          type="time"
                          value={editForm.reservation_time || ''}
                          onChange={(e) => setEditForm({ ...editForm, reservation_time: e.target.value })}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Data</label>
                      <Input
                        type="date"
                        value={editForm.reservation_date || ''}
                        onChange={(e) => setEditForm({ ...editForm, reservation_date: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground">Note</label>
                      <Textarea
                        value={editForm.notes || ''}
                        onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                        rows={3}
                      />
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => setIsEditing(false)}
                    >
                      Annulla
                    </Button>
                    <Button
                      className="flex-1"
                      onClick={handleSaveEdit}
                      disabled={updateReservationMutation.isPending}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Salva
                    </Button>
                  </div>
                </>
              ) : (
                // View Mode
                <>
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                    <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                      <Users className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <p className="font-semibold text-lg">{selectedReservation.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {selectedReservation.guests} {selectedReservation.guests === 1 ? 'persona' : 'persone'}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg bg-secondary/30">
                      <div className="flex items-center gap-2 text-muted-foreground mb-1">
                        <Calendar className="w-4 h-4" />
                        <span className="text-xs">Data</span>
                      </div>
                      <p className="font-medium">{getDateLabel(selectedReservation.reservation_date)}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-secondary/30">
                      <div className="flex items-center gap-2 text-muted-foreground mb-1">
                        <Clock className="w-4 h-4" />
                        <span className="text-xs">Ora</span>
                      </div>
                      <p className="font-medium">{selectedReservation.reservation_time}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-2 text-sm flex-1">
                      <Phone className="w-4 h-4 text-muted-foreground" />
                      <a href={`tel:${selectedReservation.phone}`} className="text-accent hover:underline">
                        {selectedReservation.phone}
                      </a>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-green-600 border-green-600/30 hover:bg-green-500/10"
                      onClick={() => {
                        const phone = selectedReservation.phone.replace(/[^0-9+]/g, '');
                        window.open(`https://wa.me/${phone.startsWith('+') ? phone.substring(1) : phone}`, '_blank');
                      }}
                    >
                      <MessageSquare className="w-4 h-4 mr-1" />
                      WhatsApp
                    </Button>
                  </div>

                  {selectedReservation.notes && (
                    <div className="p-3 rounded-lg bg-secondary/30">
                      <div className="flex items-center gap-2 text-muted-foreground mb-1">
                        <MessageSquare className="w-4 h-4" />
                        <span className="text-xs">Note</span>
                      </div>
                      <p className="text-sm">{selectedReservation.notes}</p>
                    </div>
                  )}

                  {/* Status Actions */}
                  <div className="flex gap-2 pt-2">
                    {selectedReservation.status === 'pending' && (
                      <>
                        <Button
                          className="flex-1 bg-green-600 hover:bg-green-700"
                          onClick={() => {
                            updateStatusMutation.mutate({ id: selectedReservation.id, status: 'confirmed', reservation: selectedReservation });
                            setSelectedReservation(null);
                          }}
                        >
                          <Check className="w-4 h-4 mr-2" />
                          Conferma
                        </Button>
                        <Button
                          variant="destructive"
                          className="flex-1"
                          onClick={() => {
                            updateStatusMutation.mutate({ id: selectedReservation.id, status: 'rejected', reservation: selectedReservation });
                            setSelectedReservation(null);
                          }}
                        >
                          <X className="w-4 h-4 mr-2" />
                          Rifiuta
                        </Button>
                      </>
                    )}
                    {selectedReservation.status === 'confirmed' && (
                      <Button
                        className="w-full"
                        onClick={() => {
                          updateStatusMutation.mutate({ id: selectedReservation.id, status: 'completed' });
                          setSelectedReservation(null);
                        }}
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Segna come completata
                      </Button>
                    )}
                  </div>
                </>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Eliminare questa prenotazione?</AlertDialogTitle>
            <AlertDialogDescription>
              Questa azione non può essere annullata. Il cliente riceverà una notifica WhatsApp di cancellazione.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annulla</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => selectedReservation && deleteReservationMutation.mutate(selectedReservation.id)}
            >
              Elimina
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
