import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Gift, 
  Settings, 
  Plus, 
  Trash2, 
  Save,
  Star,
  Trophy,
  Users
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface LoyaltyConfig {
  id: string;
  points_per_reservation: number;
  points_per_guest: number;
  welcome_bonus: number;
  is_active: boolean;
}

interface LoyaltyReward {
  id: string;
  name_it: string;
  name_en: string | null;
  description_it: string | null;
  description_en: string | null;
  points_required: number;
  reward_type: string;
  reward_value: string | null;
  is_active: boolean;
  display_order: number;
}

export function LoyaltyAdmin() {
  const [config, setConfig] = useState<LoyaltyConfig | null>(null);
  const [rewards, setRewards] = useState<LoyaltyReward[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [stats, setStats] = useState({ totalUsers: 0, totalPoints: 0 });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Fetch config
      const { data: configData } = await supabase
        .from('loyalty_config')
        .select('*')
        .single();
      
      if (configData) setConfig(configData);

      // Fetch rewards
      const { data: rewardsData } = await supabase
        .from('loyalty_rewards')
        .select('*')
        .order('display_order', { ascending: true });
      
      if (rewardsData) setRewards(rewardsData);

      // Fetch stats
      const { count: usersCount } = await supabase
        .from('loyalty_points')
        .select('*', { count: 'exact', head: true });

      const { data: pointsData } = await supabase
        .from('loyalty_points')
        .select('total_points');

      const totalPoints = pointsData?.reduce((sum, p) => sum + p.total_points, 0) || 0;

      setStats({
        totalUsers: usersCount || 0,
        totalPoints,
      });
    } catch (error) {
      console.error('Error fetching loyalty data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveConfig = async () => {
    if (!config) return;
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('loyalty_config')
        .update({
          points_per_reservation: config.points_per_reservation,
          points_per_guest: config.points_per_guest,
          welcome_bonus: config.welcome_bonus,
          is_active: config.is_active,
        })
        .eq('id', config.id);

      if (error) throw error;
      toast.success('Configurazione salvata!');
    } catch (error) {
      console.error('Error saving config:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  const addReward = async () => {
    try {
      const { data, error } = await supabase
        .from('loyalty_rewards')
        .insert({
          name_it: 'Nuovo Premio',
          name_en: 'New Reward',
          points_required: 100,
          reward_type: 'discount',
          display_order: rewards.length,
        })
        .select()
        .single();

      if (error) throw error;
      if (data) setRewards([...rewards, data]);
      toast.success('Premio aggiunto!');
    } catch (error) {
      console.error('Error adding reward:', error);
      toast.error('Errore nell\'aggiunta del premio');
    }
  };

  const updateReward = async (reward: LoyaltyReward) => {
    try {
      const { error } = await supabase
        .from('loyalty_rewards')
        .update({
          name_it: reward.name_it,
          name_en: reward.name_en,
          description_it: reward.description_it,
          description_en: reward.description_en,
          points_required: reward.points_required,
          reward_type: reward.reward_type,
          reward_value: reward.reward_value,
          is_active: reward.is_active,
        })
        .eq('id', reward.id);

      if (error) throw error;
      toast.success('Premio aggiornato!');
    } catch (error) {
      console.error('Error updating reward:', error);
      toast.error('Errore nell\'aggiornamento');
    }
  };

  const deleteReward = async (id: string) => {
    try {
      const { error } = await supabase
        .from('loyalty_rewards')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setRewards(rewards.filter(r => r.id !== id));
      toast.success('Premio eliminato!');
    } catch (error) {
      console.error('Error deleting reward:', error);
      toast.error('Errore nell\'eliminazione');
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Caricamento...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/20">
                <Users className="w-5 h-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalUsers}</p>
                <p className="text-xs text-muted-foreground">Utenti iscritti</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-yellow-500/20">
                <Star className="w-5 h-5 text-yellow-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalPoints}</p>
                <p className="text-xs text-muted-foreground">Punti totali</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/20">
                <Gift className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{rewards.filter(r => r.is_active).length}</p>
                <p className="text-xs text-muted-foreground">Premi attivi</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Config */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Settings className="w-5 h-5 text-accent" />
            Configurazione Punti
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Sistema fedeltà attivo</Label>
              <p className="text-xs text-muted-foreground">
                Attiva/disattiva il programma fedeltà
              </p>
            </div>
            <Switch
              checked={config?.is_active ?? false}
              onCheckedChange={(checked) => setConfig(c => c ? { ...c, is_active: checked } : c)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label>Punti per prenotazione</Label>
              <Input
                type="number"
                value={config?.points_per_reservation ?? 10}
                onChange={(e) => setConfig(c => c ? { ...c, points_per_reservation: parseInt(e.target.value) || 0 } : c)}
              />
            </div>
            <div>
              <Label>Punti per ospite</Label>
              <Input
                type="number"
                value={config?.points_per_guest ?? 2}
                onChange={(e) => setConfig(c => c ? { ...c, points_per_guest: parseInt(e.target.value) || 0 } : c)}
              />
            </div>
            <div>
              <Label>Bonus benvenuto</Label>
              <Input
                type="number"
                value={config?.welcome_bonus ?? 50}
                onChange={(e) => setConfig(c => c ? { ...c, welcome_bonus: parseInt(e.target.value) || 0 } : c)}
              />
            </div>
          </div>

          <Button onClick={saveConfig} disabled={isSaving}>
            <Save className="w-4 h-4 mr-2" />
            {isSaving ? 'Salvataggio...' : 'Salva Configurazione'}
          </Button>
        </CardContent>
      </Card>

      {/* Rewards */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <Trophy className="w-5 h-5 text-accent" />
              Catalogo Premi
            </CardTitle>
            <Button onClick={addReward} size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Aggiungi Premio
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {rewards.map((reward) => (
            <div key={reward.id} className="p-4 rounded-lg border border-border bg-secondary/20">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Nome (IT)</Label>
                  <Input
                    value={reward.name_it}
                    onChange={(e) => {
                      const updated = { ...reward, name_it: e.target.value };
                      setRewards(rewards.map(r => r.id === reward.id ? updated : r));
                    }}
                    onBlur={() => updateReward(reward)}
                  />
                </div>
                <div>
                  <Label>Nome (EN)</Label>
                  <Input
                    value={reward.name_en || ''}
                    onChange={(e) => {
                      const updated = { ...reward, name_en: e.target.value };
                      setRewards(rewards.map(r => r.id === reward.id ? updated : r));
                    }}
                    onBlur={() => updateReward(reward)}
                  />
                </div>
                <div>
                  <Label>Descrizione (IT)</Label>
                  <Textarea
                    value={reward.description_it || ''}
                    onChange={(e) => {
                      const updated = { ...reward, description_it: e.target.value };
                      setRewards(rewards.map(r => r.id === reward.id ? updated : r));
                    }}
                    onBlur={() => updateReward(reward)}
                    rows={2}
                  />
                </div>
                <div>
                  <Label>Descrizione (EN)</Label>
                  <Textarea
                    value={reward.description_en || ''}
                    onChange={(e) => {
                      const updated = { ...reward, description_en: e.target.value };
                      setRewards(rewards.map(r => r.id === reward.id ? updated : r));
                    }}
                    onBlur={() => updateReward(reward)}
                    rows={2}
                  />
                </div>
                <div>
                  <Label>Punti richiesti</Label>
                  <Input
                    type="number"
                    value={reward.points_required}
                    onChange={(e) => {
                      const updated = { ...reward, points_required: parseInt(e.target.value) || 0 };
                      setRewards(rewards.map(r => r.id === reward.id ? updated : r));
                    }}
                    onBlur={() => updateReward(reward)}
                  />
                </div>
                <div>
                  <Label>Tipo premio</Label>
                  <Select
                    value={reward.reward_type}
                    onValueChange={(value) => {
                      const updated = { ...reward, reward_type: value };
                      setRewards(rewards.map(r => r.id === reward.id ? updated : r));
                      updateReward(updated);
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="discount">Sconto</SelectItem>
                      <SelectItem value="free_item">Omaggio</SelectItem>
                      <SelectItem value="experience">Esperienza</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={reward.is_active}
                    onCheckedChange={(checked) => {
                      const updated = { ...reward, is_active: checked };
                      setRewards(rewards.map(r => r.id === reward.id ? updated : r));
                      updateReward(updated);
                    }}
                  />
                  <Label className="text-sm">Attivo</Label>
                </div>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => deleteReward(reward.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}

          {rewards.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <Gift className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>Nessun premio configurato</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
