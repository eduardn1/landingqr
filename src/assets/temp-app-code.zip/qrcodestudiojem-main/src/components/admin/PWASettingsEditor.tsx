import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Smartphone, Save, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { ImageUpload } from './ImageUpload';

interface PWASettings {
  pwa_name: string;
  pwa_short_name: string;
  pwa_description: string;
  pwa_theme_color: string;
  pwa_background_color: string;
  pwa_icon_192: string | null;
  pwa_icon_512: string | null;
}

export function PWASettingsEditor() {
  const [settings, setSettings] = useState<PWASettings>({
    pwa_name: 'Menu Digitale',
    pwa_short_name: 'Menu',
    pwa_description: 'Menu digitale con prenotazioni, preferiti e altro',
    pwa_theme_color: '#722F37',
    pwa_background_color: '#0a0a0a',
    pwa_icon_192: null,
    pwa_icon_512: null,
  });
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('restaurant_config')
        .select('pwa_name, pwa_short_name, pwa_description, pwa_theme_color, pwa_background_color, pwa_icon_192, pwa_icon_512')
        .single();

      if (error) throw error;
      if (data) {
        setSettings({
          pwa_name: data.pwa_name || 'Menu Digitale',
          pwa_short_name: data.pwa_short_name || 'Menu',
          pwa_description: data.pwa_description || 'Menu digitale con prenotazioni, preferiti e altro',
          pwa_theme_color: data.pwa_theme_color || '#722F37',
          pwa_background_color: data.pwa_background_color || '#0a0a0a',
          pwa_icon_192: data.pwa_icon_192,
          pwa_icon_512: data.pwa_icon_512,
        });
      }
    } catch (error) {
      console.error('Error loading PWA settings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('restaurant_config')
        .update(settings)
        .eq('id', (await supabase.from('restaurant_config').select('id').single()).data?.id);

      if (error) throw error;
      toast.success('Impostazioni PWA salvate');
    } catch (error) {
      console.error('Error saving PWA settings:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center">
          <Smartphone className="w-5 h-5 text-accent" />
        </div>
        <div>
          <h2 className="text-lg font-semibold">Impostazioni PWA</h2>
          <p className="text-sm text-muted-foreground">Configura l'app installabile</p>
        </div>
      </div>

      <div className="grid gap-6">
        {/* App Identity */}
        <div className="p-6 rounded-2xl bg-secondary/30 border border-border/30 space-y-4">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Identità App</h3>
          
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Nome App</label>
              <Input
                value={settings.pwa_name}
                onChange={(e) => setSettings({ ...settings, pwa_name: e.target.value })}
                placeholder="Menu Digitale"
              />
              <p className="text-xs text-muted-foreground">Nome completo mostrato all'installazione</p>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Nome Breve</label>
              <Input
                value={settings.pwa_short_name}
                onChange={(e) => setSettings({ ...settings, pwa_short_name: e.target.value })}
                placeholder="Menu"
              />
              <p className="text-xs text-muted-foreground">Mostrato sotto l'icona nella home</p>
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm text-muted-foreground">Descrizione</label>
            <Input
              value={settings.pwa_description}
              onChange={(e) => setSettings({ ...settings, pwa_description: e.target.value })}
              placeholder="Menu digitale con prenotazioni..."
            />
          </div>
        </div>

        {/* Colors */}
        <div className="p-6 rounded-2xl bg-secondary/30 border border-border/30 space-y-4">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Colori</h3>
          
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Colore Tema</label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={settings.pwa_theme_color}
                  onChange={(e) => setSettings({ ...settings, pwa_theme_color: e.target.value })}
                  className="w-14 h-10 p-1 cursor-pointer"
                />
                <Input
                  value={settings.pwa_theme_color}
                  onChange={(e) => setSettings({ ...settings, pwa_theme_color: e.target.value })}
                  placeholder="#722F37"
                  className="flex-1"
                />
              </div>
              <p className="text-xs text-muted-foreground">Colore barra di stato</p>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground">Colore Sfondo</label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={settings.pwa_background_color}
                  onChange={(e) => setSettings({ ...settings, pwa_background_color: e.target.value })}
                  className="w-14 h-10 p-1 cursor-pointer"
                />
                <Input
                  value={settings.pwa_background_color}
                  onChange={(e) => setSettings({ ...settings, pwa_background_color: e.target.value })}
                  placeholder="#0a0a0a"
                  className="flex-1"
                />
              </div>
              <p className="text-xs text-muted-foreground">Sfondo splash screen</p>
            </div>
          </div>
        </div>

        {/* Icons */}
        <div className="p-6 rounded-2xl bg-secondary/30 border border-border/30 space-y-4">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Icone App</h3>
          <p className="text-sm text-muted-foreground">Le icone devono essere quadrate e in formato PNG</p>
          
          <div className="grid sm:grid-cols-2 gap-6">
            <div className="space-y-3">
              <label className="text-sm text-muted-foreground">Icona 192x192</label>
              <ImageUpload
                value={settings.pwa_icon_192}
                onChange={(url) => setSettings({ ...settings, pwa_icon_192: url })}
                folder="pwa-icons"
              />
            </div>
            
            <div className="space-y-3">
              <label className="text-sm text-muted-foreground">Icona 512x512</label>
              <ImageUpload
                value={settings.pwa_icon_512}
                onChange={(url) => setSettings({ ...settings, pwa_icon_512: url })}
                folder="pwa-icons"
              />
            </div>
          </div>
        </div>

        {/* Live Preview - Phone Simulation */}
        <div className="p-6 rounded-2xl bg-secondary/30 border border-border/30 space-y-4">
          <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Anteprima Live</h3>
          
          <div className="flex flex-col sm:flex-row gap-6">
            {/* Home Screen Icon Preview */}
            <div className="flex flex-col items-center gap-2">
              <p className="text-xs text-muted-foreground">Icona Home Screen</p>
              <div 
                className="w-20 h-20 rounded-[22px] flex items-center justify-center shadow-lg overflow-hidden"
                style={{ backgroundColor: settings.pwa_background_color }}
              >
                {settings.pwa_icon_192 ? (
                  <img src={settings.pwa_icon_192} alt="Icon" className="w-full h-full object-cover" />
                ) : (
                  <Smartphone className="w-10 h-10 text-white/50" />
                )}
              </div>
              <p className="text-xs font-medium text-center max-w-20 truncate">{settings.pwa_short_name}</p>
            </div>
            
            {/* Splash Screen Preview */}
            <div className="flex-1">
              <p className="text-xs text-muted-foreground mb-2">Splash Screen</p>
              <div 
                className="relative w-full max-w-48 h-72 rounded-3xl overflow-hidden shadow-xl mx-auto"
                style={{ backgroundColor: settings.pwa_background_color }}
              >
                {/* Status bar simulation */}
                <div 
                  className="absolute top-0 left-0 right-0 h-6 flex items-center justify-between px-4"
                  style={{ backgroundColor: settings.pwa_theme_color }}
                >
                  <span className="text-white/80 text-[8px]">9:41</span>
                  <div className="flex gap-1">
                    <div className="w-3 h-1.5 bg-white/80 rounded-sm" />
                    <div className="w-1.5 h-1.5 bg-white/80 rounded-full" />
                  </div>
                </div>
                
                {/* Content */}
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <div 
                    className="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg overflow-hidden mb-4"
                    style={{ backgroundColor: settings.pwa_theme_color }}
                  >
                    {settings.pwa_icon_192 ? (
                      <img src={settings.pwa_icon_192} alt="Icon" className="w-full h-full object-cover" />
                    ) : (
                      <Smartphone className="w-8 h-8 text-white/80" />
                    )}
                  </div>
                  <p className="text-white font-semibold text-sm">{settings.pwa_name}</p>
                  <p className="text-white/60 text-xs mt-1">Caricamento...</p>
                </div>
              </div>
            </div>

            {/* Install Prompt Preview */}
            <div className="flex-1">
              <p className="text-xs text-muted-foreground mb-2">Prompt Installazione</p>
              <div className="p-4 rounded-xl bg-background border border-border shadow-lg max-w-48 mx-auto">
                <div className="flex items-center gap-3 mb-3">
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center overflow-hidden"
                    style={{ backgroundColor: settings.pwa_background_color }}
                  >
                    {settings.pwa_icon_192 ? (
                      <img src={settings.pwa_icon_192} alt="Icon" className="w-full h-full object-cover" />
                    ) : (
                      <Smartphone className="w-5 h-5 text-white/50" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{settings.pwa_name}</p>
                    <p className="text-xs text-muted-foreground truncate">{settings.pwa_description.slice(0, 30)}...</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <div className="flex-1 py-1.5 rounded-lg bg-secondary text-center text-xs text-muted-foreground">
                    Annulla
                  </div>
                  <div 
                    className="flex-1 py-1.5 rounded-lg text-center text-xs text-white font-medium"
                    style={{ backgroundColor: settings.pwa_theme_color }}
                  >
                    Installa
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Button onClick={handleSave} disabled={isSaving} className="w-full sm:w-auto">
        {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
        Salva Impostazioni PWA
      </Button>
    </motion.div>
  );
}
