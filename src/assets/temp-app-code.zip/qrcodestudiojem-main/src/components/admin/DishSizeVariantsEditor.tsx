import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Trash2, ChevronDown, ChevronUp, Ruler } from 'lucide-react';

export interface SizeVariant {
  id: string;
  name_it: string;
  name_en: string;
  price: number;
}

interface DishSizeVariantsEditorProps {
  variants: SizeVariant[];
  onChange: (variants: SizeVariant[]) => void;
}

export function DishSizeVariantsEditor({ variants, onChange }: DishSizeVariantsEditorProps) {
  const [isExpanded, setIsExpanded] = useState(variants.length > 0);

  const addVariant = () => {
    const newVariant: SizeVariant = {
      id: crypto.randomUUID(),
      name_it: '',
      name_en: '',
      price: 0,
    };
    onChange([...variants, newVariant]);
    setIsExpanded(true);
  };

  const updateVariant = (id: string, updates: Partial<SizeVariant>) => {
    onChange(variants.map(v => v.id === id ? { ...v, ...updates } : v));
  };

  const removeVariant = (id: string) => {
    onChange(variants.filter(v => v.id !== id));
  };

  const moveVariant = (index: number, direction: 'up' | 'down') => {
    const newVariants = [...variants];
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= variants.length) return;
    [newVariants[index], newVariants[newIndex]] = [newVariants[newIndex], newVariants[index]];
    onChange(newVariants);
  };

  return (
    <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20 space-y-4">
      <button
        type="button"
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between w-full text-left"
      >
        <div className="flex items-center gap-2 text-sm font-medium text-blue-600 dark:text-blue-400">
          <Ruler className="w-4 h-4" />
          Varianti Dimensione ({variants.length})
        </div>
        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </button>

      {isExpanded && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-xs text-muted-foreground">
              Dimensioni con prezzi diversi (es. Piccola, Media, Grande)
            </Label>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={addVariant}
              className="h-7 text-xs"
            >
              <Plus className="w-3 h-3 mr-1" />
              Aggiungi
            </Button>
          </div>

          {variants.map((variant, idx) => (
            <div 
              key={variant.id} 
              className="flex items-center gap-2 p-2 bg-background/50 rounded-lg border border-border/50"
            >
              <div className="flex flex-col">
                <button
                  type="button"
                  onClick={() => moveVariant(idx, 'up')}
                  disabled={idx === 0}
                  className="p-0.5 hover:bg-secondary rounded disabled:opacity-30"
                >
                  <ChevronUp className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  onClick={() => moveVariant(idx, 'down')}
                  disabled={idx === variants.length - 1}
                  className="p-0.5 hover:bg-secondary rounded disabled:opacity-30"
                >
                  <ChevronDown className="w-3 h-3" />
                </button>
              </div>
              
              <Input
                placeholder="Nome IT (es. Piccola)"
                value={variant.name_it}
                onChange={(e) => updateVariant(variant.id, { name_it: e.target.value })}
                className="flex-1 h-8 text-sm"
              />
              <Input
                placeholder="Name EN (e.g. Small)"
                value={variant.name_en}
                onChange={(e) => updateVariant(variant.id, { name_en: e.target.value })}
                className="flex-1 h-8 text-sm"
              />
              
              <div className="flex items-center gap-1">
                <span className="text-xs text-muted-foreground">€</span>
                <Input
                  type="number"
                  step="0.50"
                  min="0"
                  placeholder="0.00"
                  value={variant.price || ''}
                  onChange={(e) => updateVariant(variant.id, { price: parseFloat(e.target.value) || 0 })}
                  className="w-20 h-8 text-sm"
                />
              </div>
              
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={() => removeVariant(variant.id)}
                className="h-7 w-7 text-destructive hover:text-destructive"
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          ))}

          {variants.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-2">
              Nessuna variante dimensione. Il prezzo base verrà utilizzato.
            </p>
          )}

          {variants.length > 0 && (
            <p className="text-xs text-muted-foreground">
              💡 Se definisci varianti, il prezzo base sarà ignorato e il cliente dovrà scegliere una dimensione.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
