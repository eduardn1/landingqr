import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Wine, ShoppingBag } from 'lucide-react';
import { ImageUpload } from './ImageUpload';
import { MultiLangInput, type MultiLangValue } from './MultiLangInput';
import { DishExtrasEditor, type DishExtra } from './DishExtrasEditor';
import { DishSizeVariantsEditor, type SizeVariant } from './DishSizeVariantsEditor';

interface Dish {
  id: string;
  name_it: string;
  name_en: string;
  name_de?: string | null;
  name_es?: string | null;
  name_fr?: string | null;
  description_it: string | null;
  description_en: string | null;
  description_de?: string | null;
  description_es?: string | null;
  description_fr?: string | null;
  ingredients_it?: string | null;
  ingredients_en?: string | null;
  ingredients_de?: string | null;
  ingredients_es?: string | null;
  ingredients_fr?: string | null;
  price: number;
  original_price: number | null;
  takeaway_price?: number | null;
  category_id: string;
  image_url: string | null;
  is_available: boolean;
  is_featured: boolean;
  is_seasonal: boolean;
  available_for_takeaway?: boolean;
  available_for_delivery?: boolean;
  takeaway_prep_time?: number | null;
  has_extras?: boolean;
  extras?: DishExtra[] | null;
  size_variants?: SizeVariant[] | null;
  badge: string | null;
  tags: string[] | null;
  display_order: number;
  alcohol_level: 'analcolico' | 'leggero' | 'medio' | 'forte' | null;
  wine_year: number | null;
  wine_region: string | null;
  wine_pairing_it: string | null;
  wine_pairing_en: string | null;
  wine_pairing_de?: string | null;
  wine_pairing_es?: string | null;
  wine_pairing_fr?: string | null;
}

interface Category {
  id: string;
  name_it: string;
  name_en: string;
}

interface Allergen {
  code: string;
  name_it: string;
  icon: string;
}

interface DishFormProps {
  dish: Dish | null;
  categories: Category[];
  allergens: Allergen[];
  initialAllergens: string[];
  defaultDisplayOrder: number;
  onSave: (data: { dish: Partial<Dish>; selectedAllergens: string[] }) => void;
}

export function DishForm({ 
  dish, 
  categories, 
  allergens, 
  initialAllergens,
  defaultDisplayOrder,
  onSave 
}: DishFormProps) {
  const [nameValue, setNameValue] = useState<MultiLangValue>({
    it: dish?.name_it || '',
    en: dish?.name_en || '',
    de: dish?.name_de || '',
    es: dish?.name_es || '',
    fr: dish?.name_fr || '',
  });
  const [descValue, setDescValue] = useState<MultiLangValue>({
    it: dish?.description_it || '',
    en: dish?.description_en || '',
    de: dish?.description_de || '',
    es: dish?.description_es || '',
    fr: dish?.description_fr || '',
  });
  const [ingredientsValue, setIngredientsValue] = useState<MultiLangValue>({
    it: dish?.ingredients_it || '',
    en: dish?.ingredients_en || '',
    de: dish?.ingredients_de || '',
    es: dish?.ingredients_es || '',
    fr: dish?.ingredients_fr || '',
  });
  const [winePairingValue, setWinePairingValue] = useState<MultiLangValue>({
    it: dish?.wine_pairing_it || '',
    en: dish?.wine_pairing_en || '',
    de: dish?.wine_pairing_de || '',
    es: dish?.wine_pairing_es || '',
    fr: dish?.wine_pairing_fr || '',
  });
  
  const [formData, setFormData] = useState({
    price: dish?.price || 0,
    original_price: dish?.original_price || null,
    takeaway_price: dish?.takeaway_price || null,
    takeaway_prep_time: dish?.takeaway_prep_time || 15,
    category_id: dish?.category_id || categories[0]?.id || '',
    image_url: dish?.image_url || '',
    is_available: dish?.is_available ?? true,
    is_featured: dish?.is_featured ?? false,
    is_seasonal: dish?.is_seasonal ?? false,
    available_for_takeaway: dish?.available_for_takeaway ?? true,
    available_for_delivery: dish?.available_for_delivery ?? true,
    has_extras: dish?.has_extras ?? false,
    badge: dish?.badge || '',
    tags: dish?.tags || [],
    display_order: dish?.display_order ?? defaultDisplayOrder,
    alcohol_level: dish?.alcohol_level || null,
    wine_year: dish?.wine_year || null,
    wine_region: dish?.wine_region || null,
  });
  const [extras, setExtras] = useState<DishExtra[]>((dish?.extras as DishExtra[]) || []);
  const [sizeVariants, setSizeVariants] = useState<SizeVariant[]>((dish?.size_variants as SizeVariant[]) || []);
  const [selectedAllergens, setSelectedAllergens] = useState<string[]>(initialAllergens);

  // Check if selected category is Cocktail or Vini
  const selectedCategoryName = categories.find(c => c.id === formData.category_id)?.name_it?.toLowerCase() || '';
  const isCocktailCategory = selectedCategoryName.includes('cocktail');
  const isWineCategory = selectedCategoryName.includes('vini') || selectedCategoryName.includes('wine');

  const toggleAllergen = (code: string) => {
    setSelectedAllergens(prev => 
      prev.includes(code) ? prev.filter(c => c !== code) : [...prev, code]
    );
  };

  const handleImageChange = (url: string | null) => {
    setFormData(prev => ({ ...prev, image_url: url }));
  };

  const handleSave = () => {
    onSave({
      dish: {
        name_it: nameValue.it || '',
        name_en: nameValue.en || '',
        name_de: nameValue.de || null,
        name_es: nameValue.es || null,
        name_fr: nameValue.fr || null,
        description_it: descValue.it || null,
        description_en: descValue.en || null,
        description_de: descValue.de || null,
        description_es: descValue.es || null,
        description_fr: descValue.fr || null,
        ingredients_it: ingredientsValue.it || null,
        ingredients_en: ingredientsValue.en || null,
        ingredients_de: ingredientsValue.de || null,
        ingredients_es: ingredientsValue.es || null,
        ingredients_fr: ingredientsValue.fr || null,
        wine_pairing_it: winePairingValue.it || null,
        wine_pairing_en: winePairingValue.en || null,
        wine_pairing_de: winePairingValue.de || null,
        wine_pairing_es: winePairingValue.es || null,
        wine_pairing_fr: winePairingValue.fr || null,
        ...formData,
        has_extras: extras.length > 0,
        extras: extras.length > 0 ? extras : null,
        size_variants: sizeVariants.length > 0 ? sizeVariants : null,
      },
      selectedAllergens
    });
  };

  return (
    <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
      <MultiLangInput
        label="Nome piatto"
        value={nameValue}
        onChange={setNameValue}
        placeholder="Nome"
        required
      />

      <MultiLangInput
        label="Descrizione"
        value={descValue}
        onChange={setDescValue}
        placeholder="Descrizione"
        multiline
        rows={2}
      />

      <MultiLangInput
        label="Ingredienti"
        value={ingredientsValue}
        onChange={setIngredientsValue}
        placeholder="Ingredienti"
        multiline
        rows={2}
      />

      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>Prezzo (€)</Label>
          <Input
            type="number"
            step="0.01"
            value={formData.price || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) }))}
          />
        </div>
        <div className="space-y-2">
          <Label>Prezzo originale</Label>
          <Input
            type="number"
            step="0.01"
            value={formData.original_price || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, original_price: e.target.value ? parseFloat(e.target.value) : null }))}
            placeholder="Per sconti"
          />
        </div>
        <div className="space-y-2">
          <Label>Categoria</Label>
          <Select
            value={formData.category_id || ''}
            onValueChange={(v) => setFormData(prev => ({ ...prev, category_id: v }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map(cat => (
                <SelectItem key={cat.id} value={cat.id}>{cat.name_it}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label>Immagine</Label>
        <ImageUpload
          value={formData.image_url}
          onChange={handleImageChange}
          folder="dishes"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Badge</Label>
          <Input
            value={formData.badge || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, badge: e.target.value }))}
            placeholder="Nuovo, Bestseller..."
          />
        </div>
        <div className="space-y-2">
          <Label>Tags (separati da virgola)</Label>
          <Input
            value={formData.tags?.join(', ') || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean) }))}
            placeholder="vegetariano, piccante..."
          />
        </div>
      </div>

      <div className="flex flex-wrap gap-6 pt-2">
        <div className="flex items-center gap-2">
          <Switch
            checked={formData.is_available}
            onCheckedChange={(v) => setFormData(prev => ({ ...prev, is_available: v }))}
          />
          <Label>Disponibile</Label>
        </div>
        <div className="flex items-center gap-2">
          <Switch
            checked={formData.is_featured}
            onCheckedChange={(v) => setFormData(prev => ({ ...prev, is_featured: v }))}
          />
          <Label>In evidenza</Label>
        </div>
        <div className="flex items-center gap-2">
          <Switch
            checked={formData.is_seasonal}
            onCheckedChange={(v) => setFormData(prev => ({ ...prev, is_seasonal: v }))}
          />
          <Label>Stagionale</Label>
        </div>
      </div>

      {/* Takeaway Section */}
      <div className="p-4 rounded-lg bg-orange-500/10 border border-orange-500/20 space-y-4">
        <div className="flex items-center gap-2 text-sm font-medium text-orange-600 dark:text-orange-400">
          <ShoppingBag className="w-4 h-4" />
          Asporto & Delivery
        </div>
        
        <div className="flex flex-wrap gap-6">
          <div className="flex items-center gap-2">
            <Switch
              checked={formData.available_for_takeaway}
              onCheckedChange={(v) => setFormData(prev => ({ ...prev, available_for_takeaway: v }))}
            />
            <Label>Disponibile per asporto</Label>
          </div>
          <div className="flex items-center gap-2">
            <Switch
              checked={formData.available_for_delivery}
              onCheckedChange={(v) => setFormData(prev => ({ ...prev, available_for_delivery: v }))}
            />
            <Label>Disponibile per delivery</Label>
          </div>
        </div>

        {(formData.available_for_takeaway || formData.available_for_delivery) && (
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Prezzo Asporto (€)</Label>
              <Input
                type="number"
                step="0.01"
                value={formData.takeaway_price || ''}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  takeaway_price: e.target.value ? parseFloat(e.target.value) : null 
                }))}
                placeholder={`€${formData.price || 0}`}
              />
              <p className="text-xs text-muted-foreground">Vuoto = prezzo normale</p>
            </div>
            <div className="space-y-2">
              <Label>Tempo preparazione (min)</Label>
              <Input
                type="number"
                min="5"
                step="5"
                value={formData.takeaway_prep_time || ''}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  takeaway_prep_time: e.target.value ? parseInt(e.target.value) : null 
                }))}
                placeholder="15"
              />
            </div>
          </div>
        )}
      </div>

      {/* Extras/Personalizzazioni Section */}
      <DishExtrasEditor
        extras={extras}
        onChange={setExtras}
      />

      {/* Size Variants Section */}
      <DishSizeVariantsEditor
        variants={sizeVariants}
        onChange={setSizeVariants}
      />

      {/* Cocktail/Wine specific fields */}
      {(isCocktailCategory || isWineCategory) && (
        <div className="p-4 rounded-lg bg-accent/10 border border-accent/20 space-y-4">
          <div className="flex items-center gap-2 text-sm font-medium text-accent">
            <Wine className="w-4 h-4" />
            {isCocktailCategory ? 'Dettagli Cocktail' : 'Dettagli Vino'}
          </div>
          
          {isCocktailCategory && (
            <div className="space-y-2">
              <Label>Livello Alcolico</Label>
              <Select
                value={formData.alcohol_level || ''}
                onValueChange={(v) => setFormData(prev => ({ ...prev, alcohol_level: v as any }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="analcolico">Analcolico</SelectItem>
                  <SelectItem value="leggero">Leggero</SelectItem>
                  <SelectItem value="medio">Medio</SelectItem>
                  <SelectItem value="forte">Forte</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {isWineCategory && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Annata</Label>
                  <Input
                    type="number"
                    value={formData.wine_year || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, wine_year: e.target.value ? parseInt(e.target.value) : null }))}
                    placeholder="2021"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Regione/Cantina</Label>
                  <Input
                    value={formData.wine_region || ''}
                    onChange={(e) => setFormData(prev => ({ ...prev, wine_region: e.target.value }))}
                    placeholder="Toscana, Chianti..."
                  />
                </div>
              </div>
              <MultiLangInput
                label="Abbinamenti"
                value={winePairingValue}
                onChange={setWinePairingValue}
                placeholder="Abbinamenti consigliati"
              />
            </>
          )}
        </div>
      )}

      {/* Allergens Section */}
      <div className="space-y-2">
        <Label>Allergeni</Label>
        <div className="p-3 rounded-lg bg-secondary/30 border border-border/30">
          <div className="flex flex-wrap gap-2">
            {allergens.map((allergen) => (
              <button
                key={allergen.code}
                type="button"
                onClick={() => toggleAllergen(allergen.code)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  selectedAllergens.includes(allergen.code)
                    ? 'bg-accent text-accent-foreground'
                    : 'bg-secondary/50 text-muted-foreground hover:bg-secondary'
                }`}
              >
                <span>{allergen.icon}</span>
                <span>{allergen.name_it}</span>
              </button>
            ))}
          </div>
          {allergens.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-2">
              Nessun allergene configurato. Aggiungi allergeni dalla sezione dedicata.
            </p>
          )}
        </div>
      </div>

      <Button
        type="button"
        onClick={handleSave}
        disabled={!nameValue.it || !formData.category_id || !formData.price}
        className="w-full"
      >
        {dish ? 'Aggiorna' : 'Crea'} Piatto
      </Button>
    </div>
  );
}
