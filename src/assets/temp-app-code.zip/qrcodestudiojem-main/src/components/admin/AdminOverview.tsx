import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { format, parseISO, isToday, isTomorrow, isPast, startOfDay, startOfWeek, endOfWeek, eachDayOfInterval } from 'date-fns';
import { it } from 'date-fns/locale';
import { 
  CalendarDays, Users, AlertCircle, 
  ChevronRight, UtensilsCrossed,
  TrendingUp, Heart, Star,
  ShoppingBag, Package, Euro, Clock,
  ArrowUpRight, ArrowDownRight
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, Area, AreaChart } from 'recharts';
import { cn } from '@/lib/utils';

interface Reservation {
  id: string;
  name: string;
  phone: string;
  guests: number;
  reservation_date: string;
  reservation_time: string;
  status: string | null;
  user_id: string;
}

interface TakeAwayOrderStats {
  id: string;
  order_number: string;
  status: string;
  order_type: string;
  total: number;
  created_at: string;
}

// Random welcome emojis and messages for admin
const WELCOME_MESSAGES = [
  { emoji: '👨‍🍳', message: 'Buona giornata, Chef!' },
  { emoji: '🍽️', message: 'Pronto per una nuova giornata!' },
  { emoji: '☕', message: 'Un caffè e si parte!' },
  { emoji: '🌟', message: 'Brilliamo oggi!' },
  { emoji: '🎯', message: 'Focus e determinazione!' },
  { emoji: '🚀', message: 'Al massimo oggi!' },
  { emoji: '💪', message: 'Forza e coraggio!' },
  { emoji: '🔥', message: 'Accendiamo i fornelli!' },
  { emoji: '✨', message: 'Oggi sarà speciale!' },
  { emoji: '🌈', message: 'Coloriamo la giornata!' },
];

type AdminSection = 'overview' | 'branding' | 'about-us' | 'pwa' | 'seo' | 'templates' | 'hours' | 'closed-dates' | 'capacity' | 'reservations' | 'customers' | 'whatsapp' | 'whatsapp-logs' | 'broadcast' | 'notifications' | 'loyalty' | 'gamification' | 'cache' | 'dishes' | 'categories' | 'allergens' | 'menu-view' | 'onboarding' | 'moods' | 'stories' | 'sections' | 'social' | 'navigation' | 'action-buttons' | 'events' | 'promos' | 'takeaway';

interface AdminOverviewProps {
  config: any;
  onNavigate: (section: AdminSection) => void;
}

export function AdminOverview({ config, onNavigate }: AdminOverviewProps) {
  const [welcomeMessage] = useState(() => {
    const dailySeed = new Date().toDateString();
    const index = dailySeed.split('').reduce((a, b) => a + b.charCodeAt(0), 0) % WELCOME_MESSAGES.length;
    return WELCOME_MESSAGES[index];
  });

  // Fetch reservations for quick overview
  const { data: reservations = [] } = useQuery({
    queryKey: ['admin-reservations-overview'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('reservations')
        .select('id, name, phone, guests, reservation_date, reservation_time, status, user_id')
        .order('reservation_date', { ascending: true })
        .order('reservation_time', { ascending: true });
      if (error) throw error;
      return data as Reservation[];
    }
  });

  // Fetch favorites count by dish for popular dishes
  const { data: favoritesData = [] } = useQuery({
    queryKey: ['admin-favorites-stats'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('favorites')
        .select('dish_id');
      if (error) throw error;
      return data || [];
    }
  });

  // Fetch dishes for names
  const { data: allDishes = [] } = useQuery({
    queryKey: ['admin-dishes-for-stats'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('dishes')
        .select('id, name_it');
      if (error) throw error;
      return data || [];
    }
  });

  // Fetch dishes and categories count
  const { data: dishesCount = 0 } = useQuery({
    queryKey: ['dishes-count'],
    queryFn: async () => {
      const { count, error } = await supabase
        .from('dishes')
        .select('*', { count: 'exact', head: true });
      if (error) throw error;
      return count || 0;
    }
  });

  const { data: categoriesCount = 0 } = useQuery({
    queryKey: ['categories-count'],
    queryFn: async () => {
      const { count, error } = await supabase
        .from('categories')
        .select('*', { count: 'exact', head: true });
      if (error) throw error;
      return count || 0;
    }
  });

  // Fetch takeaway orders for today
  const { data: takeawayOrders = [] } = useQuery({
    queryKey: ['admin-takeaway-overview'],
    queryFn: async () => {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('takeaway_orders')
        .select('id, order_number, status, order_type, total, created_at')
        .gte('created_at', `${today}T00:00:00`)
        .lte('created_at', `${today}T23:59:59`)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as TakeAwayOrderStats[];
    },
    refetchInterval: 10000 // Refresh every 10 seconds
  });

  // Calculate reservation stats
  const todayReservations = reservations.filter(r => isToday(parseISO(r.reservation_date)));
  const pendingReservations = reservations.filter(r => r.status === 'pending');
  const upcomingReservations = reservations.filter(r => !isPast(startOfDay(parseISO(r.reservation_date))));
  const todayGuests = todayReservations.reduce((sum, r) => sum + r.guests, 0);

  // Calculate takeaway stats
  const pendingTakeaway = takeawayOrders.filter(o => o.status === 'pending');
  const activeTakeaway = takeawayOrders.filter(o => ['accepted', 'preparing', 'ready', 'delivering'].includes(o.status));
  const todayTakeawayRevenue = takeawayOrders
    .filter(o => o.status === 'completed')
    .reduce((sum, o) => sum + o.total, 0);

  // Weekly reservations chart data
  const weeklyChartData = useMemo(() => {
    const today = new Date();
    const weekStart = startOfWeek(today, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(today, { weekStartsOn: 1 });
    const days = eachDayOfInterval({ start: weekStart, end: weekEnd });
    
    return days.map(day => {
      const dayStr = format(day, 'yyyy-MM-dd');
      const count = reservations.filter(r => r.reservation_date === dayStr).length;
      return {
        day: format(day, 'EEE', { locale: it }),
        count,
        isToday: isToday(day)
      };
    });
  }, [reservations]);

  // Popular dishes from favorites
  const popularDishes = useMemo(() => {
    const counts: Record<string, number> = {};
    favoritesData.forEach(f => {
      counts[f.dish_id] = (counts[f.dish_id] || 0) + 1;
    });
    
    return Object.entries(counts)
      .map(([dishId, count]) => {
        const dish = allDishes.find(d => d.id === dishId);
        return { name: dish?.name_it || 'Piatto', count };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [favoritesData, allDishes]);

  // Frequent customers
  const frequentCustomers = useMemo(() => {
    const counts: Record<string, { name: string; phone: string; count: number }> = {};
    reservations.forEach(r => {
      const key = r.phone;
      if (!counts[key]) {
        counts[key] = { name: r.name, phone: r.phone, count: 0 };
      }
      counts[key].count++;
    });
    return Object.values(counts).sort((a, b) => b.count - a.count).slice(0, 5);
  }, [reservations]);

  const getDateLabel = (date: string) => {
    const parsed = parseISO(date);
    if (isToday(parsed)) return 'Oggi';
    if (isTomorrow(parsed)) return 'Domani';
    return format(parsed, 'EEE d MMM', { locale: it });
  };

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-3">
            <span>{welcomeMessage.emoji}</span>
            <span>{welcomeMessage.message}</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            {format(new Date(), "EEEE d MMMM yyyy", { locale: it })}
          </p>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard
          label="Da gestire"
          value={pendingReservations.length}
          icon={AlertCircle}
          color="yellow"
          onClick={() => onNavigate('reservations')}
        />
        <StatCard
          label="Oggi"
          value={todayReservations.length}
          sublabel={`${todayGuests} ospiti`}
          icon={CalendarDays}
          color="green"
          onClick={() => onNavigate('reservations')}
        />
        <StatCard
          label="Ordini nuovi"
          value={pendingTakeaway.length}
          icon={ShoppingBag}
          color="orange"
          onClick={() => onNavigate('takeaway')}
        />
        <StatCard
          label="In corso"
          value={activeTakeaway.length}
          icon={Package}
          color="blue"
          onClick={() => onNavigate('takeaway')}
        />
        <StatCard
          label="Incasso oggi"
          value={`€${todayTakeawayRevenue.toFixed(0)}`}
          icon={Euro}
          color="emerald"
          onClick={() => onNavigate('takeaway')}
        />
        <StatCard
          label="Menu"
          value={dishesCount}
          sublabel={`${categoriesCount} cat.`}
          icon={UtensilsCrossed}
          color="accent"
          onClick={() => onNavigate('dishes')}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Chart Section */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-accent" />
              Prenotazioni Settimanali
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={weeklyChartData}>
                  <defs>
                    <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="day" 
                    axisLine={false} 
                    tickLine={false} 
                    fontSize={12}
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    fontSize={12}
                    tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      background: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))', 
                      borderRadius: '8px',
                      fontSize: '12px'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="count" 
                    stroke="hsl(var(--accent))" 
                    fillOpacity={1} 
                    fill="url(#colorCount)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Right Column */}
        <div className="space-y-4">
          {/* Popular Dishes */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Heart className="w-4 h-4 text-red-500" />
                Piatti Preferiti
              </CardTitle>
            </CardHeader>
            <CardContent>
              {popularDishes.length > 0 ? (
                <div className="space-y-2">
                  {popularDishes.slice(0, 4).map((dish, i) => (
                    <div key={i} className="flex items-center justify-between text-sm">
                      <span className="truncate text-muted-foreground">{dish.name}</span>
                      <Badge variant="secondary" className="text-xs shrink-0">
                        {dish.count}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">Nessun preferito</p>
              )}
            </CardContent>
          </Card>

          {/* Frequent Customers */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Star className="w-4 h-4 text-yellow-500" />
                Clienti Top
              </CardTitle>
            </CardHeader>
            <CardContent>
              {frequentCustomers.length > 0 ? (
                <div className="space-y-2">
                  {frequentCustomers.slice(0, 4).map((customer, i) => (
                    <div key={i} className="flex items-center justify-between text-sm">
                      <span className="truncate text-muted-foreground">{customer.name}</span>
                      <Badge variant="secondary" className="text-xs shrink-0">
                        {customer.count} visite
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">Nessuna prenotazione</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-sm font-medium text-muted-foreground mb-3">Azioni Rapide</h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <QuickActionCard
            title="Prenotazioni"
            description={`${upcomingReservations.length} prossime`}
            icon={CalendarDays}
            onClick={() => onNavigate('reservations')}
          />
          <QuickActionCard
            title="Asporto"
            description={`${takeawayOrders.length} ordini oggi`}
            icon={ShoppingBag}
            onClick={() => onNavigate('takeaway')}
          />
          <QuickActionCard
            title="Menu"
            description={`${dishesCount} piatti`}
            icon={UtensilsCrossed}
            onClick={() => onNavigate('dishes')}
          />
          <QuickActionCard
            title="Clienti"
            description="Gestisci anagrafica"
            icon={Users}
            onClick={() => onNavigate('customers')}
          />
        </div>
      </div>

      {/* Upcoming Reservations */}
      {upcomingReservations.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-muted-foreground">Prossime Prenotazioni</h3>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('reservations')}>
              Vedi tutte
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {upcomingReservations.slice(0, 6).map((res) => (
              <Card 
                key={res.id} 
                className="cursor-pointer hover:border-accent/50 transition-colors"
                onClick={() => onNavigate('reservations')}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-medium">{res.name}</p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                        <Clock className="w-3 h-3" />
                        <span>{getDateLabel(res.reservation_date)} • {res.reservation_time}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Users className="w-3 h-3" />
                        <span>{res.guests} ospiti</span>
                      </div>
                    </div>
                    <Badge 
                      variant={res.status === 'pending' ? 'outline' : 'secondary'}
                      className={cn(
                        "text-xs",
                        res.status === 'pending' && "border-yellow-500 text-yellow-600"
                      )}
                    >
                      {res.status === 'pending' ? 'In attesa' : 'Confermata'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Stat Card Component
function StatCard({ 
  label, 
  value, 
  sublabel,
  icon: Icon, 
  color, 
  onClick 
}: { 
  label: string; 
  value: string | number; 
  sublabel?: string;
  icon: any; 
  color: 'yellow' | 'green' | 'orange' | 'blue' | 'emerald' | 'accent';
  onClick?: () => void;
}) {
  const colorClasses = {
    yellow: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
    green: 'bg-green-500/10 text-green-600 border-green-500/20',
    orange: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
    blue: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
    emerald: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
    accent: 'bg-accent/10 text-accent border-accent/20',
  };

  return (
    <div 
      className={cn(
        "p-4 rounded-xl border cursor-pointer transition-all hover:scale-[1.02]",
        colorClasses[color]
      )}
      onClick={onClick}
    >
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4" />
        <span className="text-xs font-medium opacity-80">{label}</span>
      </div>
      <p className="text-2xl font-bold">{value}</p>
      {sublabel && <p className="text-xs opacity-60 mt-0.5">{sublabel}</p>}
    </div>
  );
}

// Quick Action Card Component
function QuickActionCard({
  title,
  description,
  icon: Icon,
  onClick
}: {
  title: string;
  description: string;
  icon: any;
  onClick: () => void;
}) {
  return (
    <Card 
      className="cursor-pointer hover:border-accent/50 transition-all hover:shadow-md group"
      onClick={onClick}
    >
      <CardContent className="p-4 flex items-center gap-4">
        <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center shrink-0 group-hover:bg-accent/20 transition-colors">
          <Icon className="w-5 h-5 text-accent" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium">{title}</p>
          <p className="text-xs text-muted-foreground truncate">{description}</p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
      </CardContent>
    </Card>
  );
}

function getDateLabel(date: string) {
  const parsed = parseISO(date);
  if (isToday(parsed)) return 'Oggi';
  if (isTomorrow(parsed)) return 'Domani';
  return format(parsed, 'EEE d MMM', { locale: it });
}
