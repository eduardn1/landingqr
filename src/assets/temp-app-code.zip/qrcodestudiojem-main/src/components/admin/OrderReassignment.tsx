import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Truck, User, Star, MapPin, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Driver {
  id: string;
  name: string;
  phone: string;
  vehicle_type: string | null;
  status: string;
  is_online: boolean;
  average_rating: number | null;
  current_orders_count: number | null;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
  orderNumber: string;
  currentDriverId: string | null;
  onReassigned: () => void;
}

export function OrderReassignment({
  isOpen,
  onClose,
  orderId,
  orderNumber,
  currentDriverId,
  onReassigned,
}: Props) {
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [selectedDriverId, setSelectedDriverId] = useState<string>(currentDriverId || '');
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchDrivers();
    }
  }, [isOpen]);

  const fetchDrivers = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('takeaway_drivers')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setDrivers(data || []);
    } catch (err) {
      console.error('Error fetching drivers:', err);
      toast.error('Errore caricamento driver');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReassign = async () => {
    if (!selectedDriverId) {
      toast.error('Seleziona un driver');
      return;
    }

    setIsSaving(true);
    try {
      // Update order with new driver
      const { error: updateError } = await supabase
        .from('takeaway_orders')
        .update({ driver_id: selectedDriverId })
        .eq('id', orderId);

      if (updateError) throw updateError;

      // Notify new driver
      const selectedDriver = drivers.find(d => d.id === selectedDriverId);
      if (selectedDriver) {
        await supabase.functions.invoke('send-push-notification', {
          body: {
            driver_id: selectedDriverId,
            title: 'Nuova consegna assegnata!',
            body: `Ordine #${orderNumber} è stato assegnato a te`,
            type: 'driver_assignment',
            metadata: { order_id: orderId },
          },
        });
      }

      toast.success(`Ordine riassegnato a ${selectedDriver?.name}`);
      onReassigned();
      onClose();
    } catch (err: any) {
      toast.error(err.message || 'Errore riassegnazione');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <RefreshCw className="w-5 h-5" />
            Riassegna ordine #{orderNumber}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {isLoading ? (
            <div className="text-center py-8 text-muted-foreground">
              Caricamento driver...
            </div>
          ) : drivers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Nessun driver disponibile
            </div>
          ) : (
            <RadioGroup value={selectedDriverId} onValueChange={setSelectedDriverId}>
              {drivers.map((driver) => (
                <div
                  key={driver.id}
                  className={cn(
                    "flex items-center space-x-3 p-3 rounded-lg border transition-colors cursor-pointer",
                    selectedDriverId === driver.id
                      ? "border-accent bg-accent/5"
                      : "border-border hover:bg-secondary/30",
                    driver.id === currentDriverId && "ring-2 ring-accent/30"
                  )}
                  onClick={() => setSelectedDriverId(driver.id)}
                >
                  <RadioGroupItem value={driver.id} id={driver.id} />
                  <Label htmlFor={driver.id} className="flex-1 cursor-pointer">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                          <User className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-medium">{driver.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {driver.vehicle_type || 'Driver'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {driver.is_online && (
                          <Badge variant="default" className="text-xs">
                            Online
                          </Badge>
                        )}
                        {driver.id === currentDriverId && (
                          <Badge variant="secondary" className="text-xs">
                            Attuale
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                        {driver.average_rating?.toFixed(1) || '-'}
                      </span>
                      <span className="flex items-center gap-1">
                        <Truck className="w-3 h-3" />
                        {driver.current_orders_count || 0} attivi
                      </span>
                      <Badge 
                        variant={driver.status === 'available' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {driver.status === 'available' ? 'Disponibile' : 
                         driver.status === 'busy' ? 'Occupato' : driver.status}
                      </Badge>
                    </div>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          )}

          <div className="flex gap-3 pt-4">
            <Button variant="outline" className="flex-1" onClick={onClose}>
              Annulla
            </Button>
            <Button
              className="flex-1"
              onClick={handleReassign}
              disabled={isSaving || !selectedDriverId || selectedDriverId === currentDriverId}
            >
              {isSaving ? 'Salvataggio...' : 'Riassegna'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
