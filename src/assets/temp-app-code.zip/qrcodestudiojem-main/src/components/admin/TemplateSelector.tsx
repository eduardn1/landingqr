import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Sparkles, Layout, ShoppingBag, MessageSquare, Loader2, PanelTop, PanelBottom, Settings2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useDesignTemplates, DesignTemplate } from '@/hooks/useDesignTemplates';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';
import { HeaderDesignEditor } from './HeaderDesignEditor';

const HEADER_VARIANTS = [
  { value: 'default', label: 'Default', description: 'Header classico con logo e azioni' },
  { value: 'minimal', label: 'Minimal', description: 'Essenziale, solo logo e icone' },
  { value: 'centered', label: 'Centered', description: 'Logo al centro, azioni ai lati' },
  { value: 'floating', label: 'Floating', description: 'Staccato dal bordo con bordi arrotondati' },
] as const;

const FOOTER_VARIANTS = [
  { value: 'default', label: 'Default', description: 'Footer standard con credits' },
  { value: 'minimal', label: 'Minimal', description: 'Compatto, solo essenziale' },
  { value: 'expanded', label: 'Expanded', description: 'Completo con contatti e social' },
  { value: 'split', label: 'Split', description: 'Due colonne, brand e link' },
] as const;

export function TemplateSelector() {
  const { currentLanguage } = useLanguage();
  const lang = currentLanguage || 'it';
  const [activeTab, setActiveTab] = useState<'homepage' | 'takeaway' | 'onboarding' | 'layout'>('homepage');
  
  const { 
    templates, 
    activeConfig, 
    isLoading, 
    getActiveTemplate,
    updateActiveTemplate,
    updateLayoutVariant,
    isUpdating,
    headerVariant,
    footerVariant,
  } = useDesignTemplates(activeTab === 'layout' ? 'homepage' : activeTab);
  
  const handleSelectTemplate = (templateKey: string) => {
    if (activeTab === 'layout') return;
    updateActiveTemplate(
      { templateType: activeTab, templateKey },
      {
        onSuccess: () => {
          toast.success('Template aggiornato!');
        },
        onError: () => {
          toast.error('Errore nell\'aggiornamento del template');
        },
      }
    );
  };

  const handleHeaderChange = (value: string) => {
    updateLayoutVariant(
      { headerVariant: value as any },
      {
        onSuccess: () => toast.success('Header aggiornato!'),
        onError: () => toast.error('Errore'),
      }
    );
  };

  const handleFooterChange = (value: string) => {
    updateLayoutVariant(
      { footerVariant: value as any },
      {
        onSuccess: () => toast.success('Footer aggiornato!'),
        onError: () => toast.error('Errore'),
      }
    );
  };
  
  const getActiveKey = () => {
    if (!activeConfig || activeTab === 'layout') return '';
    switch (activeTab) {
      case 'homepage': return activeConfig.homepage_template_key;
      case 'takeaway': return activeConfig.takeaway_template_key;
      case 'onboarding': return activeConfig.onboarding_template_key;
    }
  };
  
  const activeKey = getActiveKey();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }
  
  // Count templates by type
  const homepageCount = templates.filter(t => t.template_type === 'homepage').length;
  const takeawayCount = templates.filter(t => t.template_type === 'takeaway').length;
  const onboardingCount = templates.filter(t => t.template_type === 'onboarding').length;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-accent/20">
            <Sparkles className="w-6 h-6 text-accent" />
          </div>
          <div>
            <h2 className="text-xl font-semibold">Design Templates</h2>
            <p className="text-sm text-muted-foreground">
              Scegli il template per ogni sezione della tua app
            </p>
          </div>
        </div>
        {activeTab !== 'layout' && (
          <Badge variant="outline" className="text-xs">
            {templates.length} template{templates.length !== 1 ? 's' : ''}
          </Badge>
        )}
      </div>
      
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="homepage" className="flex items-center gap-1.5 text-xs sm:text-sm">
            <Layout className="w-4 h-4" />
            <span className="hidden xs:inline">Home</span>
            <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px]">{homepageCount || 8}</Badge>
          </TabsTrigger>
          <TabsTrigger value="takeaway" className="flex items-center gap-1.5 text-xs sm:text-sm">
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden xs:inline">Take</span>
            <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px]">{takeawayCount || 3}</Badge>
          </TabsTrigger>
          <TabsTrigger value="onboarding" className="flex items-center gap-1.5 text-xs sm:text-sm">
            <MessageSquare className="w-4 h-4" />
            <span className="hidden xs:inline">Quiz</span>
            <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px]">{onboardingCount || 3}</Badge>
          </TabsTrigger>
          <TabsTrigger value="layout" className="flex items-center gap-1.5 text-xs sm:text-sm">
            <PanelTop className="w-4 h-4" />
            <span className="hidden xs:inline">Layout</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Layout Tab - Header/Footer variants */}
        <TabsContent value="layout" className="mt-6 space-y-8">
          {/* Header Variants */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <PanelTop className="w-5 h-5 text-accent" />
              <h3 className="text-lg font-semibold">Stile Header</h3>
            </div>
            <RadioGroup value={headerVariant} onValueChange={handleHeaderChange} className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {HEADER_VARIANTS.map((variant) => (
                <Label
                  key={variant.value}
                  htmlFor={`header-${variant.value}`}
                  className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                    headerVariant === variant.value
                      ? 'border-accent bg-accent/10'
                      : 'border-border hover:border-accent/50'
                  }`}
                >
                  <RadioGroupItem value={variant.value} id={`header-${variant.value}`} />
                  <div>
                    <div className="font-medium">{variant.label}</div>
                    <div className="text-sm text-muted-foreground">{variant.description}</div>
                  </div>
                </Label>
              ))}
            </RadioGroup>
          </div>

          {/* Device-specific header visibility */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Settings2 className="w-5 h-5 text-accent" />
              <h3 className="text-lg font-semibold">Elementi Header per Dispositivo</h3>
            </div>
            <Card>
              <CardContent className="pt-6">
                <HeaderDesignEditor />
              </CardContent>
            </Card>
          </div>

          {/* Footer Variants */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <PanelBottom className="w-5 h-5 text-accent" />
              <h3 className="text-lg font-semibold">Stile Footer</h3>
            </div>
            <RadioGroup value={footerVariant} onValueChange={handleFooterChange} className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {FOOTER_VARIANTS.map((variant) => (
                <Label
                  key={variant.value}
                  htmlFor={`footer-${variant.value}`}
                  className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition-all ${
                    footerVariant === variant.value
                      ? 'border-accent bg-accent/10'
                      : 'border-border hover:border-accent/50'
                  }`}
                >
                  <RadioGroupItem value={variant.value} id={`footer-${variant.value}`} />
                  <div>
                    <div className="font-medium">{variant.label}</div>
                    <div className="text-sm text-muted-foreground">{variant.description}</div>
                  </div>
                </Label>
              ))}
            </RadioGroup>
          </div>
        </TabsContent>
        
        {/* Template Tabs */}
        {activeTab !== 'layout' && (
          <TabsContent value={activeTab} className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <AnimatePresence mode="popLayout">
                {templates.map((template, i) => (
                  <TemplateCard
                    key={template.id}
                    template={template}
                    isActive={template.template_key === activeKey}
                    lang={lang}
                    onSelect={() => handleSelectTemplate(template.template_key)}
                    isUpdating={isUpdating}
                    index={i}
                  />
                ))}
              </AnimatePresence>
            </div>
          </TabsContent>
        )}
      </Tabs>
    </motion.div>
  );
}

interface TemplateCardProps {
  template: DesignTemplate;
  isActive: boolean;
  lang: string;
  onSelect: () => void;
  isUpdating: boolean;
  index: number;
}

function TemplateCard({ template, isActive, lang, onSelect, isUpdating, index }: TemplateCardProps) {
  const name = template.template_name[lang] || template.template_name.it || template.template_key;
  const description = template.template_description?.[lang] || template.template_description?.it || '';
  
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ delay: index * 0.05 }}
    >
      <Card 
        className={`relative overflow-hidden cursor-pointer transition-all hover:shadow-lg ${
          isActive 
            ? 'ring-2 ring-accent border-accent' 
            : 'hover:border-accent/50'
        }`}
        onClick={onSelect}
      >
        {/* Active indicator */}
        {isActive && (
          <div className="absolute top-3 right-3 z-10">
            <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center">
              <Check className="w-4 h-4 text-accent-foreground" />
            </div>
          </div>
        )}
        
        {/* Preview area */}
        <div className="h-32 bg-gradient-to-br from-secondary/50 to-secondary/20 relative overflow-hidden">
          {template.preview_image_url ? (
            <img 
              src={template.preview_image_url} 
              alt={name}
              className="w-full h-full object-cover"
            />
          ) : (
            <TemplatePreviewPlaceholder templateKey={template.template_key} />
          )}
        </div>
        
        <CardHeader className="pb-2">
          <div className="flex items-start justify-between gap-2">
            <CardTitle className="text-base">{name}</CardTitle>
            {template.is_premium && (
              <Badge variant="secondary" className="bg-accent/20 text-accent text-xs">
                Premium
              </Badge>
            )}
          </div>
          {description && (
            <CardDescription className="text-xs line-clamp-2">
              {description}
            </CardDescription>
          )}
        </CardHeader>
        
        <CardContent className="pt-0">
          {/* Tags */}
          <div className="flex flex-wrap gap-1">
            {template.tags?.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="outline" className="text-xs px-1.5 py-0">
                {tag}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function TemplatePreviewPlaceholder({ templateKey }: { templateKey: string }) {
  // Simple visual placeholders based on template type
  const getPlaceholderStyle = () => {
    if (templateKey.includes('glass')) {
      return (
        <div className="absolute inset-0 bg-gradient-to-br from-accent/30 via-primary/20 to-secondary/30">
          <div className="absolute inset-4 rounded-lg backdrop-blur-sm bg-white/10 border border-white/20" />
        </div>
      );
    }
    if (templateKey.includes('bento')) {
      return (
        <div className="absolute inset-0 p-2 grid grid-cols-3 grid-rows-2 gap-1">
          <div className="col-span-2 bg-secondary/50 rounded" />
          <div className="bg-accent/30 rounded" />
          <div className="bg-accent/20 rounded" />
          <div className="col-span-2 bg-secondary/40 rounded" />
        </div>
      );
    }
    if (templateKey.includes('aurora')) {
      return (
        <div className="absolute inset-0 bg-[#0a0a0a]">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/30 via-cyan-500/20 to-pink-500/30 animate-pulse" />
        </div>
      );
    }
    if (templateKey.includes('parallax')) {
      return (
        <div className="absolute inset-0 bg-gradient-to-b from-secondary/60 to-secondary/20">
          <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-background/80" />
        </div>
      );
    }
    // Default
    return (
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/40 to-secondary/20">
        <div className="absolute top-4 left-4 right-4 h-8 bg-secondary/50 rounded" />
        <div className="absolute top-16 left-4 right-4 h-4 bg-secondary/30 rounded" />
      </div>
    );
  };
  
  return getPlaceholderStyle();
}