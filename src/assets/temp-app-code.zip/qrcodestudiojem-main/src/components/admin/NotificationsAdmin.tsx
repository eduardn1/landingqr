import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Bell, 
  Send, 
  Users,
  Calendar,
  Gift,
  PartyPopper,
  Info
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const notificationTypes = [
  { value: 'info', label: 'Informazione', icon: Info },
  { value: 'reservation', label: 'Prenotazione', icon: Calendar },
  { value: 'promo', label: 'Promozione', icon: Gift },
  { value: 'event', label: 'Evento', icon: PartyPopper },
  { value: 'loyalty', label: 'Fedeltà', icon: Gift },
];

export function NotificationsAdmin() {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [type, setType] = useState('info');
  const [actionUrl, setActionUrl] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [stats, setStats] = useState({ totalSent: 0, totalUsers: 0 });

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const { count: notifCount } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true });

      const { count: usersCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('push_notifications', true);

      setStats({
        totalSent: notifCount || 0,
        totalUsers: usersCount || 0,
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const sendNotification = async () => {
    if (!title || !body) {
      toast.error('Titolo e messaggio sono obbligatori');
      return;
    }

    setIsSending(true);
    try {
      // Get all users with push notifications enabled
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('user_id')
        .eq('push_notifications', true);

      if (profilesError) throw profilesError;

      if (!profiles || profiles.length === 0) {
        toast.error('Nessun utente con notifiche abilitate');
        setIsSending(false);
        return;
      }

      // Create notifications for all users
      const notifications = profiles.map(profile => ({
        user_id: profile.user_id,
        title,
        body,
        type,
        action_url: actionUrl || null,
      }));

      const { error } = await supabase
        .from('notifications')
        .insert(notifications);

      if (error) throw error;

      toast.success(`Notifica inviata a ${profiles.length} utenti!`);
      setTitle('');
      setBody('');
      setActionUrl('');
      fetchStats();
    } catch (error) {
      console.error('Error sending notification:', error);
      toast.error('Errore nell\'invio della notifica');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/20">
                <Bell className="w-5 h-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalSent}</p>
                <p className="text-xs text-muted-foreground">Notifiche inviate</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/20">
                <Users className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalUsers}</p>
                <p className="text-xs text-muted-foreground">Utenti abilitati</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Send Notification */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Send className="w-5 h-5 text-accent" />
            Invia Notifica Push
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Tipo notifica</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {notificationTypes.map((t) => (
                  <SelectItem key={t.value} value={t.value}>
                    <div className="flex items-center gap-2">
                      <t.icon className="w-4 h-4" />
                      {t.label}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Titolo</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Titolo della notifica"
            />
          </div>

          <div>
            <Label>Messaggio</Label>
            <Textarea
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Contenuto della notifica..."
              rows={3}
            />
          </div>

          <div>
            <Label>URL azione (opzionale)</Label>
            <Input
              value={actionUrl}
              onChange={(e) => setActionUrl(e.target.value)}
              placeholder="/profile o https://..."
            />
            <p className="text-xs text-muted-foreground mt-1">
              L'utente verrà reindirizzato a questo URL quando clicca sulla notifica
            </p>
          </div>

          <Button 
            onClick={sendNotification} 
            disabled={isSending || !title || !body}
            className="w-full"
          >
            <Send className="w-4 h-4 mr-2" />
            {isSending ? 'Invio in corso...' : `Invia a ${stats.totalUsers} utenti`}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
