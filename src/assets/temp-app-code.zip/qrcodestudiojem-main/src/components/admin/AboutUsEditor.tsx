import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Trash2, GripVertical, Image as ImageIcon, Save, Loader2 } from 'lucide-react';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { ImageUpload } from './ImageUpload';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useMutation, useQueryClient } from '@tanstack/react-query';

interface LocalizedText {
  it: string;
  en: string;
}

interface GalleryImage {
  url: string;
  caption_it: string;
  caption_en: string;
}

export function AboutUsEditor() {
  const { config, isLoading } = useRestaurantConfig();
  const queryClient = useQueryClient();
  
  const [description, setDescription] = useState<LocalizedText>({ it: '', en: '' });
  const [tagline, setTagline] = useState<LocalizedText>({ it: '', en: '' });
  const [keywords, setKeywords] = useState<LocalizedText[]>([]);
  const [gallery, setGallery] = useState<GalleryImage[]>([]);

  useEffect(() => {
    if (config) {
      const desc = config.description as LocalizedText | null;
      const tag = config.tagline as LocalizedText | null;
      const kw = (config as any).about_keywords as LocalizedText[] | null;
      const gal = (config as any).about_gallery as GalleryImage[] | null;
      
      setDescription(desc || { it: '', en: '' });
      setTagline(tag || { it: '', en: '' });
      setKeywords(kw || []);
      setGallery(gal || []);
    }
  }, [config]);

  const updateMutation = useMutation({
    mutationFn: async (updates: any) => {
      const { error } = await supabase
        .from('restaurant_config')
        .update(updates)
        .eq('id', config?.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['restaurant-config'] });
      toast.success('Sezione "Chi Siamo" aggiornata');
    },
    onError: () => {
      toast.error('Errore durante il salvataggio');
    }
  });

  const handleSave = () => {
    updateMutation.mutate({
      description,
      tagline,
      about_keywords: keywords,
      about_gallery: gallery,
    });
  };

  const addKeyword = () => {
    setKeywords([...keywords, { it: '', en: '' }]);
  };

  const removeKeyword = (index: number) => {
    setKeywords(keywords.filter((_, i) => i !== index));
  };

  const updateKeyword = (index: number, lang: 'it' | 'en', value: string) => {
    const updated = [...keywords];
    updated[index] = { ...updated[index], [lang]: value };
    setKeywords(updated);
  };

  const addGalleryImage = () => {
    setGallery([...gallery, { url: '', caption_it: '', caption_en: '' }]);
  };

  const removeGalleryImage = (index: number) => {
    setGallery(gallery.filter((_, i) => i !== index));
  };

  const updateGalleryImage = (index: number, field: keyof GalleryImage, value: string) => {
    const updated = [...gallery];
    updated[index] = { ...updated[index], [field]: value };
    setGallery(updated);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Chi Siamo</h2>
          <p className="text-muted-foreground">Configura la sezione "Chi Siamo" del locale</p>
        </div>
        <Button onClick={handleSave} disabled={updateMutation.isPending}>
          {updateMutation.isPending ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          Salva
        </Button>
      </div>

      <Tabs defaultValue="content" className="space-y-4">
        <TabsList>
          <TabsTrigger value="content">Contenuto</TabsTrigger>
          <TabsTrigger value="keywords">Badge/Tag</TabsTrigger>
          <TabsTrigger value="gallery">Galleria</TabsTrigger>
        </TabsList>

        {/* Content Tab */}
        <TabsContent value="content" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sottotitolo / Tagline</CardTitle>
              <CardDescription>Breve frase che appare sopra il titolo</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Italiano 🇮🇹</Label>
                <Input
                  value={tagline.it}
                  onChange={(e) => setTagline({ ...tagline, it: e.target.value })}
                  placeholder="es. 3 parole sul nostro locale"
                />
              </div>
              <div className="space-y-2">
                <Label>English 🇬🇧</Label>
                <Input
                  value={tagline.en}
                  onChange={(e) => setTagline({ ...tagline, en: e.target.value })}
                  placeholder="e.g. 3 words about us"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Descrizione</CardTitle>
              <CardDescription>Racconta la storia del locale</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Italiano 🇮🇹</Label>
                <Textarea
                  value={description.it}
                  onChange={(e) => setDescription({ ...description, it: e.target.value })}
                  placeholder="La storia del vostro locale..."
                  rows={6}
                />
              </div>
              <div className="space-y-2">
                <Label>English 🇬🇧</Label>
                <Textarea
                  value={description.en}
                  onChange={(e) => setDescription({ ...description, en: e.target.value })}
                  placeholder="Your story..."
                  rows={6}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Keywords/Badges Tab */}
        <TabsContent value="keywords" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Badge / Parole Chiave</CardTitle>
                <CardDescription>Aggiungi badge che descrivono il locale (es. Passione, Tradizione, Qualità)</CardDescription>
              </div>
              <Button onClick={addKeyword} size="sm">
                <Plus className="w-4 h-4 mr-1" />
                Aggiungi
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              {keywords.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Nessun badge configurato. Clicca "Aggiungi" per crearne uno.
                </p>
              ) : (
                keywords.map((keyword, index) => (
                  <div key={index} className="flex items-center gap-2 p-3 rounded-lg bg-muted/50">
                    <GripVertical className="w-4 h-4 text-muted-foreground" />
                    <div className="flex-1 grid gap-2 md:grid-cols-2">
                      <Input
                        value={keyword.it}
                        onChange={(e) => updateKeyword(index, 'it', e.target.value)}
                        placeholder="Italiano"
                      />
                      <Input
                        value={keyword.en}
                        onChange={(e) => updateKeyword(index, 'en', e.target.value)}
                        placeholder="English"
                      />
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeKeyword(index)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Gallery Tab */}
        <TabsContent value="gallery" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Galleria Immagini</CardTitle>
                <CardDescription>Aggiungi foto che verranno mostrate in stile masonry</CardDescription>
              </div>
              <Button onClick={addGalleryImage} size="sm">
                <Plus className="w-4 h-4 mr-1" />
                Aggiungi Foto
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              {gallery.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Nessuna immagine nella galleria. Clicca "Aggiungi Foto" per inserirne una.
                </p>
              ) : (
                gallery.map((image, index) => (
                  <div key={index} className="p-4 rounded-lg border border-border bg-card">
                    <div className="flex items-start gap-4">
                      {/* Preview & Upload */}
                      <div className="w-32 flex-shrink-0">
                        <ImageUpload
                          value={image.url || null}
                          onChange={(url) => updateGalleryImage(index, 'url', url || '')}
                          folder="about-gallery"
                        />
                      </div>
                      
                      {/* Fields */}
                      <div className="flex-1 space-y-3">
                        <div className="grid gap-2 md:grid-cols-2">
                          <div className="space-y-1">
                            <Label className="text-xs">Didascalia IT</Label>
                            <Input
                              value={image.caption_it}
                              onChange={(e) => updateGalleryImage(index, 'caption_it', e.target.value)}
                              placeholder="Didascalia italiana"
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs">Caption EN</Label>
                            <Input
                              value={image.caption_en}
                              onChange={(e) => updateGalleryImage(index, 'caption_en', e.target.value)}
                              placeholder="English caption"
                            />
                          </div>
                        </div>
                      </div>
                      
                      {/* Delete */}
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeGalleryImage(index)}
                        className="text-destructive hover:text-destructive flex-shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}