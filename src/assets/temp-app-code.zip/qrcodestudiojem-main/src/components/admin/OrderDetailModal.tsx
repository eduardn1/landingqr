import { useState } from 'react';
import { TakeAwayOrder, useUpdateTakeAwayOrderStatus } from '@/hooks/useTakeAwayOrders';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { it } from 'date-fns/locale';
import {
  Phone,
  MapPin,
  Clock,
  Package,
  Truck,
  User,
  MessageSquare,
  CheckCircle2,
  XCircle,
} from 'lucide-react';

interface OrderDetailModalProps {
  order: TakeAwayOrder | null;
  open: boolean;
  onClose: () => void;
}

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30',
  accepted: 'bg-blue-500/20 text-blue-600 border-blue-500/30',
  preparing: 'bg-blue-500/20 text-blue-600 border-blue-500/30',
  ready: 'bg-green-500/20 text-green-600 border-green-500/30',
  delivering: 'bg-purple-500/20 text-purple-600 border-purple-500/30',
  completed: 'bg-green-500/20 text-green-600 border-green-500/30',
  rejected: 'bg-red-500/20 text-red-600 border-red-500/30',
  cancelled: 'bg-red-500/20 text-red-600 border-red-500/30',
};

const statusLabels: Record<string, string> = {
  pending: 'In attesa',
  accepted: 'Accettato',
  preparing: 'In preparazione',
  ready: 'Pronto',
  delivering: 'In consegna',
  completed: 'Completato',
  rejected: 'Rifiutato',
  cancelled: 'Annullato',
};

export function OrderDetailModal({ order, open, onClose }: OrderDetailModalProps) {
  const [selectedDriver, setSelectedDriver] = useState<string>('');
  const updateStatus = useUpdateTakeAwayOrderStatus();

  const { data: drivers = [] } = useQuery({
    queryKey: ['active-drivers'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('takeaway_drivers')
        .select('*')
        .eq('is_active', true)
        .in('status', ['available', 'busy']);
      if (error) throw error;
      return data;
    },
    enabled: open && order?.order_type === 'delivery',
  });

  if (!order) return null;

  const handleStatusChange = async (newStatus: string) => {
    try {
      const additionalData: Record<string, any> = {};
      
      if (newStatus === 'delivering' && selectedDriver) {
        additionalData.driver_id = selectedDriver;
      }
      
      await updateStatus.mutateAsync({
        orderId: order.id,
        status: newStatus,
        additionalData,
      });
      
      toast.success(`Stato aggiornato: ${statusLabels[newStatus]}`);
      onClose(); // Close modal on success
    } catch (error: any) {
      console.error('Order status update error:', error);
      toast.error(error?.message || 'Errore nell\'aggiornamento dello stato');
    }
  };

  const deliveryAddress = order.delivery_address as {
    street?: string;
    city?: string;
    zip?: string;
    notes?: string;
  } | null;

  return (
    <Dialog open={open} onOpenChange={(isOpen) => { if (!isOpen) onClose(); }}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Ordine {order.order_number}</span>
            <Badge className={statusColors[order.status]}>
              {statusLabels[order.status]}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Customer Info */}
          <div className="space-y-2">
            <h3 className="font-semibold text-sm text-muted-foreground">Cliente</h3>
            <div className="flex items-center gap-3">
              <User className="w-4 h-4 text-muted-foreground" />
              <span className="font-medium">{order.customer_name}</span>
            </div>
            <a
              href={`tel:${order.customer_phone}`}
              className="flex items-center gap-3 text-accent hover:underline"
            >
              <Phone className="w-4 h-4" />
              <span>{order.customer_phone}</span>
            </a>
          </div>

          <Separator />

          {/* Order Type & Time */}
          <div className="space-y-2">
            <h3 className="font-semibold text-sm text-muted-foreground">Dettagli</h3>
            <div className="flex items-center gap-3">
              {order.order_type === 'pickup' ? (
                <Package className="w-4 h-4 text-muted-foreground" />
              ) : (
                <Truck className="w-4 h-4 text-muted-foreground" />
              )}
              <span className="font-medium">
                {order.order_type === 'pickup' ? 'Ritiro' : 'Consegna'}
              </span>
            </div>
            
            {order.pickup_time && (
              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span>Ritiro ore {format(new Date(order.pickup_time), 'HH:mm')}</span>
              </div>
            )}

            {deliveryAddress && (
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                <div>
                  <p>{deliveryAddress.street}</p>
                  <p className="text-sm text-muted-foreground">
                    {deliveryAddress.city}, {deliveryAddress.zip}
                  </p>
                  {deliveryAddress.notes && (
                    <p className="text-sm text-muted-foreground mt-1">
                      Note: {deliveryAddress.notes}
                    </p>
                  )}
                </div>
              </div>
            )}

            {order.special_notes && (
              <div className="flex items-start gap-3">
                <MessageSquare className="w-4 h-4 text-muted-foreground mt-0.5" />
                <p className="text-sm">{order.special_notes}</p>
              </div>
            )}
          </div>

          <Separator />

          {/* Items */}
          <div className="space-y-2">
            <h3 className="font-semibold text-sm text-muted-foreground">Articoli</h3>
            <div className="space-y-3">
              {order.items.map((item: any, index: number) => (
                <div key={index} className="border-b border-border/30 last:border-0 pb-2 last:pb-0">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">
                      {item.quantity}x {item.name}
                    </span>
                    <span className="font-medium">
                      €{(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                  
                  {/* Extras */}
                  {item.extras && item.extras.length > 0 && (
                    <div className="mt-1 pl-4">
                      {item.extras.map((extra: any, idx: number) => (
                        <p key={idx} className="text-xs text-accent">
                          + {extra.name} {extra.price > 0 && `(€${extra.price.toFixed(2)})`}
                        </p>
                      ))}
                    </div>
                  )}
                  
                  {/* Notes */}
                  {item.notes && (
                    <p className="text-xs text-muted-foreground mt-1 pl-4 italic">
                      "{item.notes}"
                    </p>
                  )}
                </div>
              ))}
            </div>
            
            <div className="border-t border-border pt-2 mt-3 space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotale</span>
                <span>€{order.subtotal.toFixed(2)}</span>
              </div>
              {order.delivery_fee > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Consegna</span>
                  <span>€{order.delivery_fee.toFixed(2)}</span>
                </div>
              )}
              {order.discount > 0 && (
                <div className="flex justify-between text-sm text-green-600">
                  <span>Sconto</span>
                  <span>-€{order.discount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold pt-1">
                <span>Totale</span>
                <span className="text-accent">€{order.total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Driver Assignment (for delivery orders) */}
          {order.order_type === 'delivery' && 
           ['accepted', 'preparing', 'ready'].includes(order.status) && (
            <div className="space-y-2">
              <h3 className="font-semibold text-sm text-muted-foreground">Assegna driver</h3>
              <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                <SelectTrigger>
                  <SelectValue placeholder="Seleziona driver" />
                </SelectTrigger>
                <SelectContent>
                  {drivers.map((driver: any) => (
                    <SelectItem key={driver.id} value={driver.id}>
                      {driver.name} - {driver.vehicle_type || 'N/A'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-wrap gap-2 pt-2">
            {order.status === 'pending' && (
              <>
                <Button
                  onClick={() => handleStatusChange('accepted')}
                  className="flex-1 gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Accetta
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => handleStatusChange('rejected')}
                  className="gap-2"
                >
                  <XCircle className="w-4 h-4" />
                  Rifiuta
                </Button>
              </>
            )}
            
            {order.status === 'accepted' && (
              <Button
                onClick={() => handleStatusChange('preparing')}
                className="flex-1"
              >
                Inizia preparazione
              </Button>
            )}
            
            {order.status === 'preparing' && (
              <Button
                onClick={() => handleStatusChange('ready')}
                className="flex-1"
              >
                Pronto
              </Button>
            )}
            
            {order.status === 'ready' && order.order_type === 'pickup' && (
              <Button
                onClick={() => handleStatusChange('completed')}
                className="flex-1"
              >
                Ritirato
              </Button>
            )}
            
            {order.status === 'ready' && order.order_type === 'delivery' && (
              <Button
                onClick={() => handleStatusChange('delivering')}
                className="flex-1"
                disabled={!selectedDriver}
              >
                Invia in consegna
              </Button>
            )}
            
            {order.status === 'delivering' && (
              <Button
                onClick={() => handleStatusChange('completed')}
                className="flex-1"
              >
                Consegnato
              </Button>
            )}
          </div>

          {/* Timestamps */}
          <div className="text-xs text-muted-foreground space-y-1">
            <p>Creato: {format(new Date(order.created_at), 'PPP p', { locale: it })}</p>
            {order.accepted_at && (
              <p>Accettato: {format(new Date(order.accepted_at), 'HH:mm')}</p>
            )}
            {order.ready_at && (
              <p>Pronto: {format(new Date(order.ready_at), 'HH:mm')}</p>
            )}
            {order.completed_at && (
              <p>Completato: {format(new Date(order.completed_at), 'HH:mm')}</p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
