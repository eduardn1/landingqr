import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Send, Users, MessageCircle, CheckCircle, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface WhatsAppTemplate {
  id: string;
  template_key: string;
  name: string;
  message_template: string;
  variables: string[];
}

interface Profile {
  id: string;
  phone: string;
  display_name: string | null;
  whatsapp_notifications: boolean | null;
}

interface SendResult {
  phone: string;
  name: string;
  status: 'pending' | 'sent' | 'failed';
  error?: string;
}

export function BroadcastManager() {
  const { toast } = useToast();
  const [templates, setTemplates] = useState<WhatsAppTemplate[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [customMessage, setCustomMessage] = useState('');
  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [filterOptedIn, setFilterOptedIn] = useState(true);
  const [sendResults, setSendResults] = useState<SendResult[]>([]);
  const [currentSendIndex, setCurrentSendIndex] = useState(-1);

  // Variable values for templates
  const [variableValues, setVariableValues] = useState<Record<string, string>>({
    title: '',
    message: '',
    validity: '',
    event_date: '',
    event_time: '',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [templatesRes, profilesRes, configRes] = await Promise.all([
        supabase
          .from('whatsapp_templates')
          .select('*')
          .eq('is_active', true)
          .like('template_key', 'broadcast_%'),
        supabase
          .from('profiles')
          .select('id, phone, display_name, whatsapp_notifications'),
        supabase
          .from('restaurant_config')
          .select('name')
          .maybeSingle()
      ]);

      if (templatesRes.data) {
        setTemplates(templatesRes.data.map(t => ({
          ...t,
          variables: Array.isArray(t.variables) ? t.variables as string[] : []
        })));
      }
      
      if (profilesRes.data) {
        setProfiles(profilesRes.data);
      }

      if (configRes.data) {
        setVariableValues(prev => ({ ...prev, locale_name: configRes.data.name }));
      }
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  };

  const filteredProfiles = filterOptedIn 
    ? profiles.filter(p => p.whatsapp_notifications !== false)
    : profiles;

  const handleSelectAll = (checked: boolean) => {
    setSelectAll(checked);
    if (checked) {
      setSelectedRecipients(filteredProfiles.map(p => p.id));
    } else {
      setSelectedRecipients([]);
    }
  };

  const handleSelectRecipient = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedRecipients([...selectedRecipients, id]);
    } else {
      setSelectedRecipients(selectedRecipients.filter(r => r !== id));
      setSelectAll(false);
    }
  };

  const getProcessedMessage = (): string => {
    const template = templates.find(t => t.id === selectedTemplate);
    if (!template) return customMessage;

    let message = template.message_template;
    Object.entries(variableValues).forEach(([key, value]) => {
      message = message.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value || `[${key}]`);
    });
    return message;
  };

  const sendBroadcastMessages = async () => {
    if (selectedRecipients.length === 0) {
      toast({ title: 'Seleziona almeno un destinatario', variant: 'destructive' });
      return;
    }

    const message = getProcessedMessage();
    if (!message.trim()) {
      toast({ title: 'Inserisci un messaggio', variant: 'destructive' });
      return;
    }

    setIsSending(true);
    setSendResults([]);
    setCurrentSendIndex(0);

    // Initialize results with pending status
    const initialResults: SendResult[] = selectedRecipients.map(id => {
      const profile = profiles.find(p => p.id === id);
      return {
        phone: profile?.phone || '',
        name: profile?.display_name || 'Cliente',
        status: 'pending' as const
      };
    });
    setSendResults(initialResults);

    // Send messages one by one via edge function
    const results: SendResult[] = [];
    
    for (let i = 0; i < selectedRecipients.length; i++) {
      const profileId = selectedRecipients[i];
      const profile = profiles.find(p => p.id === profileId);
      
      if (!profile) continue;

      setCurrentSendIndex(i);

      try {
        const { data, error } = await supabase.functions.invoke('send-whatsapp', {
          body: {
            phone: profile.phone,
            message: message
          }
        });

        if (error) {
          results.push({
            phone: profile.phone,
            name: profile.display_name || 'Cliente',
            status: 'failed',
            error: error.message
          });
        } else if (data?.success) {
          results.push({
            phone: profile.phone,
            name: profile.display_name || 'Cliente',
            status: 'sent'
          });
        } else {
          results.push({
            phone: profile.phone,
            name: profile.display_name || 'Cliente',
            status: 'failed',
            error: data?.error || 'Errore sconosciuto'
          });
        }
      } catch (err: any) {
        results.push({
          phone: profile.phone,
          name: profile.display_name || 'Cliente',
          status: 'failed',
          error: err.message
        });
      }

      // Update results in real-time
      setSendResults([...results, ...initialResults.slice(i + 1)]);
      
      // 7 second delay between messages to respect WaSender API rate limits (1 msg per 5 seconds + buffer)
      if (i < selectedRecipients.length - 1) {
        await new Promise(resolve => setTimeout(resolve, 7000));
      }
    }

    setSendResults(results);
    setCurrentSendIndex(-1);
    setIsSending(false);

    const successCount = results.filter(r => r.status === 'sent').length;
    const failedCount = results.filter(r => r.status === 'failed').length;

    // Save broadcast to history
    try {
      await supabase.from('broadcast_messages').insert({
        title: templates.find(t => t.id === selectedTemplate)?.name || 'Messaggio personalizzato',
        message: message,
        template_id: selectedTemplate && selectedTemplate !== 'custom' ? selectedTemplate : null,
        recipients_count: selectedRecipients.length,
        status: failedCount === 0 ? 'sent' : failedCount === results.length ? 'failed' : 'partial',
        sent_at: new Date().toISOString()
      });
    } catch (err) {
      console.error('Error saving broadcast history:', err);
    }

    toast({ 
      title: successCount > 0 ? 'Broadcast completato!' : 'Errore invio',
      description: `${successCount} inviati, ${failedCount} falliti`,
      variant: failedCount === results.length ? 'destructive' : 'default'
    });
  };

  const currentTemplate = templates.find(t => t.id === selectedTemplate);

  if (isLoading) {
    return <div className="animate-pulse space-y-4">
      <div className="h-32 bg-secondary/30 rounded-xl" />
      <div className="h-48 bg-secondary/30 rounded-xl" />
    </div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
          <Send className="w-5 h-5 text-purple-500" />
        </div>
        <div>
          <h3 className="font-semibold">Broadcast WhatsApp</h3>
          <p className="text-xs text-muted-foreground">Invia messaggi automatici a più clienti via WaSender API</p>
        </div>
      </div>

      {/* Message Composer */}
      <div className="p-6 rounded-xl bg-secondary/30 border border-border/30 space-y-4">
        <h4 className="font-medium">Componi Messaggio</h4>

        <div className="space-y-2">
          <Label>Template</Label>
          <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
            <SelectTrigger>
              <SelectValue placeholder="Seleziona un template" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="custom">Messaggio personalizzato</SelectItem>
              {templates.map(t => (
                <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Variable inputs for template */}
        {currentTemplate && (
          <div className="grid sm:grid-cols-2 gap-4 p-4 rounded-lg bg-background/50">
            {currentTemplate.variables
              .filter(v => v !== 'locale_name')
              .map(variable => (
                <div key={variable} className="space-y-2">
                  <Label className="capitalize">{variable.replace(/_/g, ' ')}</Label>
                  <Input
                    value={variableValues[variable] || ''}
                    onChange={e => setVariableValues({ ...variableValues, [variable]: e.target.value })}
                    placeholder={`Inserisci ${variable}`}
                  />
                </div>
              ))}
          </div>
        )}

        {/* Custom message */}
        {!selectedTemplate || selectedTemplate === 'custom' ? (
          <div className="space-y-2">
            <Label>Messaggio</Label>
            <Textarea
              value={customMessage}
              onChange={e => setCustomMessage(e.target.value)}
              placeholder="Scrivi il tuo messaggio..."
              rows={5}
            />
          </div>
        ) : (
          <div className="p-4 rounded-lg bg-background/50">
            <Label className="text-xs text-muted-foreground mb-2 block">Anteprima messaggio:</Label>
            <p className="text-sm whitespace-pre-wrap">{getProcessedMessage()}</p>
          </div>
        )}
      </div>

      {/* Recipients Selection */}
      <div className="p-6 rounded-xl bg-secondary/30 border border-border/30 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Users className="w-5 h-5 text-muted-foreground" />
            <h4 className="font-medium">Destinatari ({selectedRecipients.length}/{filteredProfiles.length})</h4>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox
              id="filterOptedIn"
              checked={filterOptedIn}
              onCheckedChange={(checked) => {
                setFilterOptedIn(checked as boolean);
                setSelectedRecipients([]);
                setSelectAll(false);
              }}
            />
            <Label htmlFor="filterOptedIn" className="text-xs">Solo con consenso</Label>
          </div>
        </div>

        <div className="flex items-center gap-2 pb-2 border-b border-border/30">
          <Checkbox
            id="selectAll"
            checked={selectAll}
            onCheckedChange={handleSelectAll}
            disabled={isSending}
          />
          <Label htmlFor="selectAll" className="text-sm">Seleziona tutti</Label>
        </div>

        <div className="max-h-48 overflow-y-auto space-y-2">
          {filteredProfiles.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              Nessun contatto disponibile
            </p>
          ) : (
            filteredProfiles.map(profile => (
              <div key={profile.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-background/50">
                <Checkbox
                  checked={selectedRecipients.includes(profile.id)}
                  onCheckedChange={(checked) => handleSelectRecipient(profile.id, checked as boolean)}
                  disabled={isSending}
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">
                    {profile.display_name || 'Cliente'}
                  </p>
                  <p className="text-xs text-muted-foreground">{profile.phone}</p>
                </div>
                {profile.whatsapp_notifications !== false && (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Send Button */}
      <Button 
        onClick={sendBroadcastMessages} 
        disabled={isSending || selectedRecipients.length === 0}
        className="w-full"
        size="lg"
      >
        {isSending ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Invio in corso... ({currentSendIndex + 1}/{selectedRecipients.length})
          </>
        ) : (
          <>
            <MessageCircle className="w-5 h-5 mr-2" />
            Invia Messaggi WhatsApp ({selectedRecipients.length})
          </>
        )}
      </Button>

      {/* Send Results */}
      {sendResults.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6 rounded-xl bg-secondary/30 border border-border/30 space-y-4"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h4 className="font-medium">Risultati Invio</h4>
              <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/10 text-green-500">
                {sendResults.filter(r => r.status === 'sent').length} inviati
              </span>
              {sendResults.filter(r => r.status === 'failed').length > 0 && (
                <span className="text-xs px-2 py-0.5 rounded-full bg-red-500/10 text-red-500">
                  {sendResults.filter(r => r.status === 'failed').length} falliti
                </span>
              )}
            </div>
            <Button variant="ghost" size="sm" onClick={() => setSendResults([])}>
              <X className="w-4 h-4" />
            </Button>
          </div>

          <div className="max-h-48 overflow-y-auto space-y-2">
            {sendResults.map((result, i) => (
              <div
                key={i}
                className={`flex items-center justify-between p-2 rounded-lg ${
                  result.status === 'sent' ? 'bg-green-500/10' : 
                  result.status === 'failed' ? 'bg-red-500/10' : 
                  'bg-background/50'
                }`}
              >
                <div className="flex items-center gap-2">
                  {result.status === 'sent' ? (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  ) : result.status === 'failed' ? (
                    <X className="w-4 h-4 text-red-500" />
                  ) : (
                    <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                  )}
                  <span className="text-sm">{result.name}</span>
                </div>
                <div className="text-right">
                  <span className="text-xs text-muted-foreground">{result.phone}</span>
                  {result.error && (
                    <p className="text-xs text-red-500">{result.error}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}
