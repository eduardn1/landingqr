import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, User, Phone, Car, Star, Copy, Link, Key } from 'lucide-react';

interface Driver {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  vehicle_type: string | null;
  vehicle_plate: string | null;
  vehicle_color: string | null;
  status: string;
  is_active: boolean;
  average_rating: number | null;
  total_deliveries: number | null;
  access_token: string | null;
  pin_code: string | null;
  emoji: string | null;
}

const statusColors: Record<string, string> = {
  available: 'bg-green-500',
  busy: 'bg-yellow-500',
  offline: 'bg-gray-500',
};

const statusLabels: Record<string, string> = {
  available: 'Disponibile',
  busy: 'Occupato',
  offline: 'Offline',
};

const vehicleTypes = [
  { value: 'bike', label: 'Bici' },
  { value: 'moto', label: 'Moto/Scooter' },
  { value: 'car', label: 'Auto' },
];

export function DriversEditor() {
  const queryClient = useQueryClient();
  const [editingDriver, setEditingDriver] = useState<Driver | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    vehicle_type: '',
    vehicle_plate: '',
    vehicle_color: '',
    is_active: true,
    pin_code: '',
    emoji: '🚗',
  });

  const { data: drivers = [], isLoading } = useQuery({
    queryKey: ['drivers-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('takeaway_drivers')
        .select('*')
        .order('name');
      if (error) throw error;
      return data as Driver[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (driverData: any) => {
      const payload = {
        name: driverData.name,
        phone: driverData.phone,
        email: driverData.email || null,
        vehicle_type: driverData.vehicle_type || null,
        vehicle_plate: driverData.vehicle_plate || null,
        vehicle_color: driverData.vehicle_color || null,
        is_active: driverData.is_active,
        pin_code: driverData.pin_code || null,
        emoji: driverData.emoji || '🚗',
      };

      if (editingDriver) {
        const { error } = await supabase
          .from('takeaway_drivers')
          .update(payload)
          .eq('id', editingDriver.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('takeaway_drivers')
          .insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['drivers-admin'] });
      toast.success(editingDriver ? 'Driver aggiornato' : 'Driver creato');
      handleCloseDialog();
    },
    onError: (error: any) => {
      console.error('Driver save error:', error);
      toast.error(`Errore: ${error.message || 'Salvataggio fallito'}`);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('takeaway_drivers')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['drivers-admin'] });
      toast.success('Driver eliminato');
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from('takeaway_drivers')
        .update({ status })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['drivers-admin'] });
      toast.success('Stato aggiornato');
    },
  });

  const handleOpenDialog = (driver?: Driver) => {
    if (driver) {
      setEditingDriver(driver);
      setForm({
        name: driver.name,
        phone: driver.phone,
        email: driver.email || '',
        vehicle_type: driver.vehicle_type || '',
        vehicle_plate: driver.vehicle_plate || '',
        vehicle_color: driver.vehicle_color || '',
        is_active: driver.is_active,
        pin_code: driver.pin_code || '',
        emoji: driver.emoji || '🚗',
      });
    } else {
      setEditingDriver(null);
      setForm({
        name: '',
        phone: '',
        email: '',
        vehicle_type: '',
        vehicle_plate: '',
        vehicle_color: '',
        is_active: true,
        pin_code: '',
        emoji: '🚗',
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingDriver(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMutation.mutate(form);
  };

  const copyDriverLink = (driver: Driver) => {
    if (!driver.access_token) {
      toast.error('Token non disponibile');
      return;
    }
    const link = `${window.location.origin}/driver?token=${driver.access_token}`;
    navigator.clipboard.writeText(link);
    toast.success('Link copiato negli appunti!');
  };

  const generateNewPin = () => {
    const pin = Math.floor(1000 + Math.random() * 9000).toString();
    setForm({ ...form, pin_code: pin });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Driver</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" onClick={() => handleOpenDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              Nuovo driver
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>{editingDriver ? 'Modifica driver' : 'Nuovo driver'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Nome *</Label>
                <Input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Mario Rossi"
                />
              </div>
              <div>
                <Label>Telefono *</Label>
                <Input
                  required
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="+39 333 1234567"
                />
              </div>
              <div>
                <Label>Email</Label>
                <Input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="mario@email.com"
                />
              </div>
              
              {/* PIN Code */}
              <div>
                <Label className="flex items-center gap-2">
                  <Key className="w-4 h-4" />
                  PIN di accesso
                </Label>
                <div className="flex gap-2">
                  <Input
                    type="text"
                    value={form.pin_code}
                    onChange={(e) => setForm({ ...form, pin_code: e.target.value })}
                    placeholder="1234"
                    maxLength={6}
                    className="font-mono"
                  />
                  <Button type="button" variant="outline" onClick={generateNewPin}>
                    Genera
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Il driver può usare questo PIN per accedere al pannello
                </p>
              </div>

              {/* Emoji */}
              <div>
                <Label>Emoji</Label>
                <div className="flex gap-2">
                  <Input
                    value={form.emoji}
                    onChange={(e) => setForm({ ...form, emoji: e.target.value })}
                    placeholder="🚗"
                    maxLength={4}
                    className="w-20 text-center text-xl"
                  />
                  <div className="flex gap-1 flex-wrap">
                    {['🚗', '🏍️', '🛵', '🚴', '🚕', '🛻'].map((e) => (
                      <Button
                        key={e}
                        type="button"
                        variant={form.emoji === e ? 'default' : 'outline'}
                        size="sm"
                        className="text-lg px-2"
                        onClick={() => setForm({ ...form, emoji: e })}
                      >
                        {e}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <Label>Veicolo</Label>
                  <Select
                    value={form.vehicle_type || ''}
                    onValueChange={(value) => setForm({ ...form, vehicle_type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Tipo" />
                    </SelectTrigger>
                    <SelectContent>
                      {vehicleTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Targa</Label>
                  <Input
                    value={form.vehicle_plate}
                    onChange={(e) => setForm({ ...form, vehicle_plate: e.target.value })}
                    placeholder="AB123CD"
                  />
                </div>
                <div>
                  <Label>Colore</Label>
                  <Input
                    value={form.vehicle_color}
                    onChange={(e) => setForm({ ...form, vehicle_color: e.target.value })}
                    placeholder="Nero"
                  />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={form.is_active}
                  onCheckedChange={(c) => setForm({ ...form, is_active: c })}
                />
                <Label>Attivo</Label>
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="button" variant="outline" onClick={handleCloseDialog} className="flex-1">
                  Annulla
                </Button>
                <Button type="submit" disabled={saveMutation.isPending} className="flex-1">
                  {saveMutation.isPending ? 'Salvataggio...' : 'Salva'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <p className="text-muted-foreground">Caricamento...</p>
      ) : drivers.length === 0 ? (
        <p className="text-muted-foreground text-center py-8">Nessun driver configurato</p>
      ) : (
        <div className="grid gap-3">
          {drivers.map((driver) => (
            <Card key={driver.id} className={!driver.is_active ? 'opacity-50' : ''}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xl">{driver.emoji || '🚗'}</span>
                      <span className="font-semibold">{driver.name}</span>
                      <Badge 
                        variant="outline" 
                        className={`${statusColors[driver.status]} text-white border-0 text-xs`}
                      >
                        {statusLabels[driver.status]}
                      </Badge>
                      {driver.pin_code && (
                        <Badge variant="secondary" className="text-xs gap-1">
                          <Key className="w-3 h-3" />
                          PIN: {driver.pin_code}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="w-3 h-3" />
                      {driver.phone}
                    </div>
                    {driver.vehicle_type && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Car className="w-3 h-3" />
                        {driver.vehicle_type} {driver.vehicle_plate && `(${driver.vehicle_plate})`}
                      </div>
                    )}
                    <div className="flex items-center gap-4 text-sm">
                      {driver.average_rating && (
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                          {driver.average_rating.toFixed(1)}
                        </span>
                      )}
                      <span className="text-muted-foreground">
                        {driver.total_deliveries || 0} consegne
                      </span>
                    </div>
                    
                    {/* Copy Link Button */}
                    {driver.access_token && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="mt-2 gap-2"
                        onClick={() => copyDriverLink(driver)}
                      >
                        <Link className="w-3 h-3" />
                        Copia link accesso
                      </Button>
                    )}
                  </div>
                  <div className="flex flex-col gap-1 ml-2">
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => handleOpenDialog(driver)}>
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="text-destructive"
                        onClick={() => deleteMutation.mutate(driver.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                    {driver.is_active && (
                      <select
                        value={driver.status}
                        onChange={(e) => updateStatusMutation.mutate({ id: driver.id, status: e.target.value })}
                        className="text-xs bg-secondary border border-border rounded px-2 py-1"
                      >
                        <option value="available">Disponibile</option>
                        <option value="busy">Occupato</option>
                        <option value="offline">Offline</option>
                      </select>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}