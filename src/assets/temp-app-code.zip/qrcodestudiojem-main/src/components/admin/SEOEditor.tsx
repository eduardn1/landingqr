import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Search, FileText, Globe, Share2, Code, AlertCircle, CheckCircle, Save, Loader2 } from 'lucide-react';
import { ImageUpload } from './ImageUpload';

interface SEOSettings {
  id: string;
  page_slug: string;
  page_name: string;
  title: Record<string, string>;
  description: Record<string, string>;
  keywords?: Record<string, string>;
  canonical_url?: string;
  robots?: string;
  og_title?: Record<string, string>;
  og_description?: Record<string, string>;
  og_image_url?: string;
  og_type?: string;
  twitter_card_type?: string;
  twitter_title?: Record<string, string>;
  twitter_description?: Record<string, string>;
  twitter_image_url?: string;
  schema_data?: Record<string, any>;
  hreflang_urls?: Record<string, string>;
  is_active: boolean;
  priority: number;
  change_frequency: string;
}

export function SEOEditor() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPage, setSelectedPage] = useState('home');
  
  // Fetch all SEO settings
  const { data: pages = [], isLoading } = useQuery({
    queryKey: ['seo-settings-all'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('seo_settings')
        .select('*')
        .order('page_slug', { ascending: true });
      
      if (error) throw error;
      return data as SEOSettings[];
    }
  });
  
  const currentPage = pages.find(p => p.page_slug === selectedPage);
  
  // Local state for editing
  const [formData, setFormData] = useState<Partial<SEOSettings>>({});
  
  // Update form when page changes
  useEffect(() => {
    if (currentPage) {
      setFormData({
        title: currentPage.title || {},
        description: currentPage.description || {},
        keywords: currentPage.keywords || {},
        og_title: currentPage.og_title || {},
        og_description: currentPage.og_description || {},
        og_image_url: currentPage.og_image_url || '',
        twitter_title: currentPage.twitter_title || {},
        twitter_description: currentPage.twitter_description || {},
        twitter_image_url: currentPage.twitter_image_url || '',
        canonical_url: currentPage.canonical_url || '',
        robots: currentPage.robots || 'index, follow',
        is_active: currentPage.is_active ?? true,
        priority: currentPage.priority || 0.5,
        change_frequency: currentPage.change_frequency || 'weekly'
      });
    }
  }, [currentPage]);
  
  // Save mutation
  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!currentPage?.id) throw new Error('No page selected');
      
      const { error } = await supabase
        .from('seo_settings')
        .update({
          title: formData.title,
          description: formData.description,
          keywords: formData.keywords,
          og_title: formData.og_title,
          og_description: formData.og_description,
          og_image_url: formData.og_image_url,
          twitter_title: formData.twitter_title,
          twitter_description: formData.twitter_description,
          twitter_image_url: formData.twitter_image_url,
          canonical_url: formData.canonical_url,
          robots: formData.robots,
          is_active: formData.is_active,
          priority: formData.priority,
          change_frequency: formData.change_frequency,
          updated_at: new Date().toISOString()
        })
        .eq('id', currentPage.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['seo-settings-all'] });
      queryClient.invalidateQueries({ queryKey: ['seo-settings', selectedPage] });
      toast({ title: 'SEO salvato!', description: `Pagina "${currentPage?.page_name}" aggiornata` });
    },
    onError: (error) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });
  
  // SEO Score Calculator
  const calculateSEOScore = () => {
    let score = 0;
    const issues: string[] = [];
    
    // Title check
    const titleLength = (formData.title?.it || '').length;
    if (titleLength >= 30 && titleLength <= 60) {
      score += 20;
    } else if (titleLength > 0) {
      score += 10;
      issues.push(titleLength < 30 ? 'Titolo troppo corto (min 30 caratteri)' : 'Titolo troppo lungo (max 60 caratteri)');
    } else {
      issues.push('Titolo mancante');
    }
    
    // Description check
    const descLength = (formData.description?.it || '').length;
    if (descLength >= 120 && descLength <= 160) {
      score += 20;
    } else if (descLength > 0) {
      score += 10;
      issues.push(descLength < 120 ? 'Descrizione troppo corta (min 120 caratteri)' : 'Descrizione troppo lunga (max 160 caratteri)');
    } else {
      issues.push('Descrizione mancante');
    }
    
    // Keywords
    if (formData.keywords?.it) {
      score += 10;
    } else {
      issues.push('Keywords mancanti');
    }
    
    // OG tags
    if (formData.og_image_url) {
      score += 20;
    } else {
      issues.push('Immagine OG mancante');
    }
    
    // Canonical
    if (formData.canonical_url) {
      score += 10;
    }
    
    // Active
    if (formData.is_active) {
      score += 10;
    }
    
    // Multi-language
    const langs = ['it', 'en'];
    const completedLangs = langs.filter(lang => formData.title?.[lang] && formData.description?.[lang]);
    score += Math.floor((completedLangs.length / langs.length) * 10);
    
    return { score: Math.min(score, 100), issues };
  };
  
  const { score, issues } = calculateSEOScore();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Search className="w-6 h-6" />
            SEO Manager
          </h2>
          <p className="text-muted-foreground mt-1">
            Ottimizza SEO per ogni pagina del sito
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          {/* SEO Score Badge */}
          <Badge 
            variant={score >= 80 ? 'default' : score >= 60 ? 'secondary' : 'destructive'}
            className="text-lg px-4 py-2"
          >
            {score >= 80 ? <CheckCircle className="w-4 h-4 mr-2" /> : <AlertCircle className="w-4 h-4 mr-2" />}
            SEO: {score}/100
          </Badge>
          
          <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
            {saveMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Salva
          </Button>
        </div>
      </div>
      
      {/* Page Selector */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Seleziona Pagina</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {pages.map(page => (
              <Button
                key={page.page_slug}
                variant={selectedPage === page.page_slug ? 'default' : 'outline'}
                onClick={() => setSelectedPage(page.page_slug)}
                size="sm"
              >
                <FileText className="w-4 h-4 mr-2" />
                {page.page_name}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* SEO Issues Alert */}
      {issues.length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>
            <strong>Problemi SEO:</strong> {issues.join(' • ')}
          </AlertDescription>
        </Alert>
      )}
      
      {/* Main Editor */}
      <Tabs defaultValue="basic" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="basic">
            <FileText className="w-4 h-4 mr-2" />
            Base
          </TabsTrigger>
          <TabsTrigger value="social">
            <Share2 className="w-4 h-4 mr-2" />
            Social
          </TabsTrigger>
          <TabsTrigger value="advanced">
            <Code className="w-4 h-4 mr-2" />
            Avanzato
          </TabsTrigger>
          <TabsTrigger value="preview">
            <Globe className="w-4 h-4 mr-2" />
            Preview
          </TabsTrigger>
        </TabsList>
        
        {/* BASIC TAB */}
        <TabsContent value="basic" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Informazioni Base</CardTitle>
              <CardDescription>Title, Description e Keywords per tutte le lingue</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="it">
                <TabsList className="mb-4">
                  <TabsTrigger value="it">🇮🇹 Italiano</TabsTrigger>
                  <TabsTrigger value="en">🇬🇧 English</TabsTrigger>
                </TabsList>
                
                {['it', 'en'].map(lang => (
                  <TabsContent key={lang} value={lang} className="space-y-4">
                    {/* Title */}
                    <div className="space-y-2">
                      <Label>
                        Title Tag
                        <span className="text-xs text-muted-foreground ml-2">
                          ({(formData.title?.[lang] || '').length}/60)
                        </span>
                      </Label>
                      <Input
                        placeholder="Menu Digitale - Ristorante"
                        value={formData.title?.[lang] || ''}
                        onChange={(e) => setFormData({
                          ...formData,
                          title: { ...formData.title, [lang]: e.target.value }
                        })}
                        className={(formData.title?.[lang] || '').length > 60 ? 'border-destructive' : ''}
                      />
                    </div>
                    
                    {/* Description */}
                    <div className="space-y-2">
                      <Label>
                        Meta Description
                        <span className="text-xs text-muted-foreground ml-2">
                          ({(formData.description?.[lang] || '').length}/160)
                        </span>
                      </Label>
                      <Textarea
                        placeholder="Scopri il nostro menu digitale..."
                        value={formData.description?.[lang] || ''}
                        onChange={(e) => setFormData({
                          ...formData,
                          description: { ...formData.description, [lang]: e.target.value }
                        })}
                        rows={3}
                        className={(formData.description?.[lang] || '').length > 160 ? 'border-destructive' : ''}
                      />
                    </div>
                    
                    {/* Keywords */}
                    <div className="space-y-2">
                      <Label>Keywords</Label>
                      <Input
                        placeholder="ristorante, menu digitale, cucina italiana"
                        value={formData.keywords?.[lang] || ''}
                        onChange={(e) => setFormData({
                          ...formData,
                          keywords: { ...formData.keywords, [lang]: e.target.value }
                        })}
                      />
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* SOCIAL TAB */}
        <TabsContent value="social" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Open Graph (Facebook, LinkedIn)</CardTitle>
              <CardDescription>Come apparirà quando condiviso sui social</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Immagine OG (1200x630px consigliato)</Label>
                <ImageUpload
                  value={formData.og_image_url || ''}
                  onChange={(url) => setFormData({ ...formData, og_image_url: url })}
                  bucket="seo-images"
                  folder="og"
                />
              </div>
              
              <Tabs defaultValue="it">
                <TabsList className="mb-4">
                  <TabsTrigger value="it">🇮🇹 Italiano</TabsTrigger>
                  <TabsTrigger value="en">🇬🇧 English</TabsTrigger>
                </TabsList>
                
                {['it', 'en'].map(lang => (
                  <TabsContent key={lang} value={lang} className="space-y-4">
                    <div className="space-y-2">
                      <Label>OG Title (lascia vuoto per usare Title)</Label>
                      <Input
                        placeholder={formData.title?.[lang] || ''}
                        value={formData.og_title?.[lang] || ''}
                        onChange={(e) => setFormData({
                          ...formData,
                          og_title: { ...formData.og_title, [lang]: e.target.value }
                        })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>OG Description</Label>
                      <Textarea
                        placeholder={formData.description?.[lang] || ''}
                        value={formData.og_description?.[lang] || ''}
                        onChange={(e) => setFormData({
                          ...formData,
                          og_description: { ...formData.og_description, [lang]: e.target.value }
                        })}
                        rows={2}
                      />
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Twitter Cards</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Tipo Card</Label>
                <Select 
                  value={formData.twitter_card_type || 'summary_large_image'} 
                  onValueChange={(v) => setFormData({ ...formData, twitter_card_type: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="summary">Summary</SelectItem>
                    <SelectItem value="summary_large_image">Summary Large Image</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* ADVANCED TAB */}
        <TabsContent value="advanced" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Impostazioni Avanzate</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Canonical URL */}
              <div className="space-y-2">
                <Label>URL Canonica</Label>
                <Input
                  type="url"
                  placeholder="https://example.com/page"
                  value={formData.canonical_url || ''}
                  onChange={(e) => setFormData({ ...formData, canonical_url: e.target.value })}
                />
                <p className="text-xs text-muted-foreground">
                  Lascia vuoto per usare URL attuale
                </p>
              </div>
              
              {/* Robots */}
              <div className="space-y-2">
                <Label>Meta Robots</Label>
                <Select 
                  value={formData.robots || 'index, follow'} 
                  onValueChange={(v) => setFormData({ ...formData, robots: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="index, follow">Index, Follow</SelectItem>
                    <SelectItem value="noindex, follow">No Index, Follow</SelectItem>
                    <SelectItem value="index, nofollow">Index, No Follow</SelectItem>
                    <SelectItem value="noindex, nofollow">No Index, No Follow</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Sitemap Priority */}
              <div className="space-y-2">
                <Label>Priorità Sitemap: {formData.priority}</Label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={formData.priority || 0.5}
                  onChange={(e) => setFormData({ ...formData, priority: parseFloat(e.target.value) })}
                  className="w-full"
                />
              </div>
              
              {/* Change Frequency */}
              <div className="space-y-2">
                <Label>Frequenza Aggiornamento</Label>
                <Select 
                  value={formData.change_frequency || 'weekly'} 
                  onValueChange={(v) => setFormData({ ...formData, change_frequency: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="always">Always</SelectItem>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="yearly">Yearly</SelectItem>
                    <SelectItem value="never">Never</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Active */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Pagina Attiva</Label>
                  <p className="text-xs text-muted-foreground">Includi nei risultati di ricerca</p>
                </div>
                <Switch
                  checked={formData.is_active ?? true}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* PREVIEW TAB */}
        <TabsContent value="preview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Preview Google Search</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg p-4 bg-background">
                <div className="text-xs text-muted-foreground mb-1">
                  {formData.canonical_url || 'https://tuosito.com/' + selectedPage}
                </div>
                <div className="text-primary text-lg font-medium hover:underline cursor-pointer">
                  {formData.title?.it || 'Titolo della pagina'}
                </div>
                <div className="text-sm text-muted-foreground line-clamp-2 mt-1">
                  {formData.description?.it || 'Descrizione della pagina che apparirà nei risultati di ricerca...'}
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Preview Social Share</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden max-w-md">
                {formData.og_image_url ? (
                  <img 
                    src={formData.og_image_url} 
                    alt="OG Preview" 
                    className="w-full aspect-video object-cover"
                  />
                ) : (
                  <div className="w-full aspect-video bg-muted flex items-center justify-center text-muted-foreground">
                    Nessuna immagine
                  </div>
                )}
                <div className="p-3 bg-muted/50">
                  <div className="text-xs text-muted-foreground uppercase">tuosito.com</div>
                  <div className="font-medium mt-1">
                    {formData.og_title?.it || formData.title?.it || 'Titolo'}
                  </div>
                  <div className="text-sm text-muted-foreground line-clamp-2">
                    {formData.og_description?.it || formData.description?.it || 'Descrizione...'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
