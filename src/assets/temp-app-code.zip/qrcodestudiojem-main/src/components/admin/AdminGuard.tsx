import { ReactNode } from 'react';
import { Navigate, useLocation, Link } from 'react-router-dom';
import { Loader2, ShieldAlert } from 'lucide-react';
import { useAdminAuth } from '@/hooks/useAdminAuth';
import { Button } from '@/components/ui/button';

interface AdminGuardProps {
  children: ReactNode;
}

export function AdminGuard({ children }: AdminGuardProps) {
  const { isAdmin, isAuthenticated, isLoading, user } = useAdminAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-8 h-8 animate-spin text-muted-foreground mx-auto" />
          <p className="text-sm text-muted-foreground">Verifica accesso...</p>
        </div>
      </div>
    );
  }

  // Not logged in - redirect to auth
  if (!isAuthenticated) {
    return <Navigate to="/auth" state={{ from: location, adminRequired: true }} replace />;
  }

  // Logged in but not admin
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <div className="text-center space-y-6 max-w-md">
          <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
            <ShieldAlert className="w-8 h-8 text-destructive" />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-semibold text-foreground">Accesso Negato</h1>
            <p className="text-muted-foreground">
              Non hai i permessi per accedere all'area amministrativa.
            </p>
            {user?.email && (
              <p className="text-xs text-muted-foreground/70 mt-2">
                Loggato come: {user.email}
              </p>
            )}
          </div>
          <div className="flex flex-col gap-2">
            <Button variant="outline" onClick={() => window.history.back()}>
              Torna Indietro
            </Button>
            <Button variant="ghost" asChild>
              <Link to="/">Vai al Menu</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}