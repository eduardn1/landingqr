import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Loader2, LayoutGrid, List, Grid2X2, Check, Image as ImageIcon, Smile, Palette, Grid3X3 } from 'lucide-react';
import { ImageUpload } from './ImageUpload';
import { DishPlaceholder, PlaceholderType } from '@/components/client/DishPlaceholder';
import { Separator } from '@/components/ui/separator';

type MenuViewMode = 'cards' | 'list' | 'grid';

const viewOptions: { value: MenuViewMode; label: string; description: string; icon: typeof LayoutGrid }[] = [
  { 
    value: 'cards', 
    label: 'Cards (Immagini grandi)', 
    description: 'Visualizzazione classica con immagini grandi e informazioni complete',
    icon: LayoutGrid 
  },
  { 
    value: 'list', 
    label: 'Lista compatta', 
    description: 'Immagine piccola a sinistra, testo a destra. Ideale per menu lunghi',
    icon: List 
  },
  { 
    value: 'grid', 
    label: 'Griglia 2x2', 
    description: 'Vista compatta a griglia con immagini quadrate. Mostra più piatti',
    icon: Grid2X2 
  },
];

const placeholderOptions: { value: PlaceholderType; label: string; description: string; icon: typeof Palette }[] = [
  { 
    value: 'gradient', 
    label: 'Gradiente sfumato', 
    description: 'Sfondo sfumato con icona categoria sovrapposta',
    icon: Palette 
  },
  { 
    value: 'emoji', 
    label: 'Emoji', 
    description: 'Emoji grande centrata come placeholder',
    icon: Smile 
  },
  { 
    value: 'pattern', 
    label: 'Pattern geometrico', 
    description: 'Motivo a puntini con icona categoria',
    icon: Grid3X3 
  },
  { 
    value: 'image', 
    label: 'Immagine personalizzata', 
    description: 'Carica un\'immagine di default per i piatti senza foto',
    icon: ImageIcon 
  },
];

const gradientPresets = [
  { value: 'from-secondary/60 via-secondary/40 to-secondary/20', label: 'Neutro' },
  { value: 'from-accent/30 via-accent/15 to-transparent', label: 'Accent' },
  { value: 'from-primary/20 via-secondary/30 to-accent/10', label: 'Mix' },
  { value: 'from-amber-500/20 via-orange-500/10 to-transparent', label: 'Caldo' },
  { value: 'from-emerald-500/20 via-teal-500/10 to-transparent', label: 'Verde' },
  { value: 'from-violet-500/20 via-purple-500/10 to-transparent', label: 'Viola' },
];

const emojiPresets = ['🍽️', '🍕', '🍝', '🥗', '🍔', '🍣', '🥘', '🍰', '🍷', '☕'];

export function MenuViewEditor() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedView, setSelectedView] = useState<MenuViewMode>('cards');
  const [placeholderType, setPlaceholderType] = useState<PlaceholderType>('gradient');
  const [placeholderEmoji, setPlaceholderEmoji] = useState('🍽️');
  const [placeholderGradient, setPlaceholderGradient] = useState('from-secondary/60 via-secondary/40 to-secondary/20');
  const [placeholderImage, setPlaceholderImage] = useState<string | null>(null);

  const { data: config, isLoading } = useQuery({
    queryKey: ['restaurant-config-menu-view'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('restaurant_config')
        .select('id, menu_view_mode, placeholder_type, placeholder_emoji, placeholder_gradient, placeholder_image')
        .limit(1)
        .single();
      
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (config) {
      if (config.menu_view_mode) setSelectedView(config.menu_view_mode as MenuViewMode);
      if (config.placeholder_type) setPlaceholderType(config.placeholder_type as PlaceholderType);
      if (config.placeholder_emoji) setPlaceholderEmoji(config.placeholder_emoji);
      if (config.placeholder_gradient) setPlaceholderGradient(config.placeholder_gradient);
      if (config.placeholder_image) setPlaceholderImage(config.placeholder_image);
    }
  }, [config]);

  const updateMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from('restaurant_config')
        .update({ 
          menu_view_mode: selectedView,
          placeholder_type: placeholderType,
          placeholder_emoji: placeholderEmoji,
          placeholder_gradient: placeholderGradient,
          placeholder_image: placeholderImage,
        })
        .eq('id', config?.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['restaurant-config'] });
      queryClient.invalidateQueries({ queryKey: ['restaurant-config-menu-view'] });
      toast({
        title: 'Salvato',
        description: 'Le impostazioni del menu sono state aggiornate',
      });
    },
    onError: () => {
      toast({
        title: 'Errore',
        description: 'Impossibile salvare le modifiche',
        variant: 'destructive',
      });
    },
  });

  const handleSave = () => {
    updateMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* View Mode Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <LayoutGrid className="w-5 h-5" />
            Visualizzazione Menu
          </CardTitle>
          <CardDescription>
            Scegli come visualizzare i piatti nel menu. I clienti potranno anche cambiare la vista dalla pagina menu.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <RadioGroup
            value={selectedView}
            onValueChange={(value) => setSelectedView(value as MenuViewMode)}
            className="space-y-3"
          >
            {viewOptions.map((option) => {
              const Icon = option.icon;
              return (
                <label
                  key={option.value}
                  className={`flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                    selectedView === option.value
                      ? 'border-accent bg-accent/5'
                      : 'border-border hover:border-accent/50 hover:bg-secondary/20'
                  }`}
                >
                  <RadioGroupItem value={option.value} className="mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Icon className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">{option.label}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {option.description}
                    </p>
                  </div>
                  {selectedView === option.value && (
                    <Check className="w-5 h-5 text-accent" />
                  )}
                </label>
              );
            })}
          </RadioGroup>

          {/* Preview */}
          <div className="border rounded-xl p-4 bg-secondary/10">
            <p className="text-sm font-medium mb-3">Anteprima vista</p>
            <div className="bg-background rounded-lg p-3">
              {selectedView === 'cards' && (
                <div className="grid grid-cols-2 gap-2">
                  {[1, 2].map((i) => (
                    <div key={i} className="space-y-2">
                      <div className="aspect-[4/3] bg-secondary/30 rounded-lg" />
                      <div className="h-3 bg-secondary/40 rounded w-3/4" />
                      <div className="h-2 bg-secondary/20 rounded w-1/2" />
                    </div>
                  ))}
                </div>
              )}
              {selectedView === 'list' && (
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex gap-2 p-2 bg-secondary/10 rounded-lg">
                      <div className="w-12 h-12 bg-secondary/30 rounded-lg flex-shrink-0" />
                      <div className="flex-1 space-y-1.5">
                        <div className="h-2.5 bg-secondary/40 rounded w-3/4" />
                        <div className="h-2 bg-secondary/20 rounded w-full" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {selectedView === 'grid' && (
                <div className="grid grid-cols-4 gap-1.5">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="space-y-1">
                      <div className="aspect-square bg-secondary/30 rounded-md" />
                      <div className="h-2 bg-secondary/40 rounded w-3/4" />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Placeholder Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ImageIcon className="w-5 h-5" />
            Placeholder Piatti
          </CardTitle>
          <CardDescription>
            Scegli cosa mostrare quando un piatto non ha un'immagine caricata.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <RadioGroup
            value={placeholderType}
            onValueChange={(value) => setPlaceholderType(value as PlaceholderType)}
            className="space-y-3"
          >
            {placeholderOptions.map((option) => {
              const Icon = option.icon;
              return (
                <label
                  key={option.value}
                  className={`flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all ${
                    placeholderType === option.value
                      ? 'border-accent bg-accent/5'
                      : 'border-border hover:border-accent/50 hover:bg-secondary/20'
                  }`}
                >
                  <RadioGroupItem value={option.value} className="mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Icon className="w-4 h-4 text-muted-foreground" />
                      <span className="font-medium">{option.label}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {option.description}
                    </p>
                  </div>
                  {placeholderType === option.value && (
                    <Check className="w-5 h-5 text-accent" />
                  )}
                </label>
              );
            })}
          </RadioGroup>

          <Separator />

          {/* Placeholder Options */}
          {placeholderType === 'gradient' && (
            <div className="space-y-3">
              <Label>Scegli gradiente</Label>
              <div className="grid grid-cols-3 gap-2">
                {gradientPresets.map((preset) => (
                  <button
                    key={preset.value}
                    onClick={() => setPlaceholderGradient(preset.value)}
                    className={`p-3 rounded-lg border transition-all ${
                      placeholderGradient === preset.value
                        ? 'border-accent ring-2 ring-accent/30'
                        : 'border-border hover:border-accent/50'
                    }`}
                  >
                    <div className={`h-10 rounded bg-gradient-to-br ${preset.value}`} />
                    <p className="text-xs mt-2 text-center">{preset.label}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {placeholderType === 'emoji' && (
            <div className="space-y-3">
              <Label>Scegli emoji</Label>
              <div className="flex flex-wrap gap-2">
                {emojiPresets.map((emoji) => (
                  <button
                    key={emoji}
                    onClick={() => setPlaceholderEmoji(emoji)}
                    className={`w-12 h-12 text-2xl rounded-lg border transition-all flex items-center justify-center ${
                      placeholderEmoji === emoji
                        ? 'border-accent bg-accent/10 ring-2 ring-accent/30'
                        : 'border-border hover:border-accent/50 bg-secondary/20'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
              <div className="flex gap-2 items-center mt-2">
                <Label className="text-sm">Oppure inserisci:</Label>
                <Input 
                  value={placeholderEmoji}
                  onChange={(e) => setPlaceholderEmoji(e.target.value)}
                  className="w-20 text-center text-xl"
                  maxLength={2}
                />
              </div>
            </div>
          )}

          {placeholderType === 'image' && (
            <div className="space-y-3">
              <Label>Immagine placeholder</Label>
              <ImageUpload
                value={placeholderImage || undefined}
                onChange={(url) => setPlaceholderImage(url || null)}
                bucket="restaurant-assets"
                folder="placeholders"
              />
            </div>
          )}

          {/* Placeholder Preview */}
          <div className="border rounded-xl p-4 bg-secondary/10">
            <p className="text-sm font-medium mb-3">Anteprima placeholder</p>
            <div className="flex gap-4 items-center">
              <div className="w-24 h-24 rounded-lg overflow-hidden border border-border">
                <DishPlaceholder 
                  categoryIcon="🍝"
                  size="medium"
                  placeholderType={placeholderType}
                  placeholderEmoji={placeholderEmoji}
                  placeholderGradient={placeholderGradient}
                  placeholderImage={placeholderImage || undefined}
                />
              </div>
              <div className="text-sm text-muted-foreground">
                <p>Esempio con icona categoria</p>
                <p className="text-xs mt-1">L'icona della categoria verrà sovrapposta al placeholder</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Button 
        onClick={handleSave} 
        disabled={updateMutation.isPending}
        className="w-full"
        size="lg"
      >
        {updateMutation.isPending ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Salvataggio...
          </>
        ) : (
          'Salva tutte le modifiche'
        )}
      </Button>
    </div>
  );
}
