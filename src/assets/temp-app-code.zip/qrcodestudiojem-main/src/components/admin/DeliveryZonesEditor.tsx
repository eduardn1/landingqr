import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, MapPin, Clock, Euro } from 'lucide-react';

interface DeliveryZone {
  id: string;
  name: string;
  description: string | null;
  zip_codes: string[];
  delivery_fee: number;
  minimum_order: number | null;
  estimated_minutes: number;
  is_active: boolean;
}

export function DeliveryZonesEditor() {
  const queryClient = useQueryClient();
  const [editingZone, setEditingZone] = useState<DeliveryZone | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [form, setForm] = useState({
    name: '',
    description: '',
    zip_codes: '',
    delivery_fee: 0,
    minimum_order: 0,
    estimated_minutes: 30,
    is_active: true,
  });

  const { data: zones = [], isLoading } = useQuery({
    queryKey: ['delivery-zones-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('delivery_zones')
        .select('*')
        .order('name');
      if (error) throw error;
      return data as DeliveryZone[];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (zoneData: any) => {
      const payload = {
        name: zoneData.name,
        description: zoneData.description || null,
        zip_codes: zoneData.zip_codes.split(',').map((z: string) => z.trim()).filter(Boolean),
        delivery_fee: zoneData.delivery_fee,
        minimum_order: zoneData.minimum_order || null,
        estimated_minutes: zoneData.estimated_minutes,
        is_active: zoneData.is_active,
      };

      if (editingZone) {
        const { error } = await supabase
          .from('delivery_zones')
          .update(payload)
          .eq('id', editingZone.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('delivery_zones')
          .insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['delivery-zones-admin'] });
      toast.success(editingZone ? 'Zona aggiornata' : 'Zona creata');
      handleCloseDialog();
    },
    onError: () => {
      toast.error('Errore nel salvataggio');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('delivery_zones')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['delivery-zones-admin'] });
      toast.success('Zona eliminata');
    },
  });

  const handleOpenDialog = (zone?: DeliveryZone) => {
    if (zone) {
      setEditingZone(zone);
      setForm({
        name: zone.name,
        description: zone.description || '',
        zip_codes: zone.zip_codes.join(', '),
        delivery_fee: zone.delivery_fee,
        minimum_order: zone.minimum_order || 0,
        estimated_minutes: zone.estimated_minutes,
        is_active: zone.is_active,
      });
    } else {
      setEditingZone(null);
      setForm({
        name: '',
        description: '',
        zip_codes: '',
        delivery_fee: 0,
        minimum_order: 0,
        estimated_minutes: 30,
        is_active: true,
      });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingZone(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMutation.mutate(form);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Zone di consegna</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" onClick={() => handleOpenDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              Nuova zona
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingZone ? 'Modifica zona' : 'Nuova zona'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Nome zona *</Label>
                <Input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Es: Centro città"
                />
              </div>
              <div>
                <Label>Descrizione</Label>
                <Input
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  placeholder="Es: Zona centrale"
                />
              </div>
              <div>
                <Label>CAP coperti (separati da virgola) *</Label>
                <Input
                  required
                  value={form.zip_codes}
                  onChange={(e) => setForm({ ...form, zip_codes: e.target.value })}
                  placeholder="20121, 20122, 20123"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Costo consegna (€)</Label>
                  <Input
                    type="number"
                    step="0.5"
                    value={form.delivery_fee}
                    onChange={(e) => setForm({ ...form, delivery_fee: parseFloat(e.target.value) })}
                  />
                </div>
                <div>
                  <Label>Ordine minimo (€)</Label>
                  <Input
                    type="number"
                    step="0.5"
                    value={form.minimum_order}
                    onChange={(e) => setForm({ ...form, minimum_order: parseFloat(e.target.value) })}
                  />
                </div>
              </div>
              <div>
                <Label>Tempo stimato (minuti)</Label>
                <Input
                  type="number"
                  value={form.estimated_minutes}
                  onChange={(e) => setForm({ ...form, estimated_minutes: parseInt(e.target.value) })}
                />
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={form.is_active}
                  onCheckedChange={(c) => setForm({ ...form, is_active: c })}
                />
                <Label>Attiva</Label>
              </div>
              <div className="flex gap-2 pt-4">
                <Button type="button" variant="outline" onClick={handleCloseDialog} className="flex-1">
                  Annulla
                </Button>
                <Button type="submit" disabled={saveMutation.isPending} className="flex-1">
                  {saveMutation.isPending ? 'Salvataggio...' : 'Salva'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <p className="text-muted-foreground">Caricamento...</p>
      ) : zones.length === 0 ? (
        <p className="text-muted-foreground text-center py-8">Nessuna zona configurata</p>
      ) : (
        <div className="grid gap-3">
          {zones.map((zone) => (
            <Card key={zone.id} className={!zone.is_active ? 'opacity-50' : ''}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-accent" />
                      <span className="font-semibold">{zone.name}</span>
                      {!zone.is_active && (
                        <span className="text-xs text-muted-foreground">(disattivata)</span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      CAP: {zone.zip_codes.join(', ')}
                    </p>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="flex items-center gap-1">
                        <Euro className="w-3 h-3" />
                        {zone.delivery_fee > 0 ? `€${zone.delivery_fee}` : 'Gratis'}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        ~{zone.estimated_minutes} min
                      </span>
                      {zone.minimum_order && zone.minimum_order > 0 && (
                        <span className="text-muted-foreground">
                          Min. €{zone.minimum_order}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" onClick={() => handleOpenDialog(zone)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="text-destructive"
                      onClick={() => deleteMutation.mutate(zone.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
