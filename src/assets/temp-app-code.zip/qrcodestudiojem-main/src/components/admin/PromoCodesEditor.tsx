import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Edit2, Tag, Eye, EyeOff, Calendar, Percent, Euro, Truck, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { MultiLangInput, type MultiLangValue } from './MultiLangInput';

interface PromoCode {
  id: string;
  promo_code: string | null;
  title: { it?: string; en?: string };
  description: { it?: string; en?: string } | null;
  discount_type: string;
  discount_value: number | null;
  minimum_order: number | null;
  max_uses: number | null;
  max_uses_per_user: number | null;
  current_uses: number | null;
  valid_from: string;
  valid_until: string;
  days_of_week: number[] | null;
  is_active: boolean | null;
  exclude_discounted_items: boolean | null;
  applies_to: string;
}

const DAYS = [
  { value: 0, label: 'Dom' },
  { value: 1, label: 'Lun' },
  { value: 2, label: 'Mar' },
  { value: 3, label: 'Mer' },
  { value: 4, label: 'Gio' },
  { value: 5, label: 'Ven' },
  { value: 6, label: 'Sab' },
];

export function PromoCodesEditor() {
  const queryClient = useQueryClient();
  const [editingPromo, setEditingPromo] = useState<PromoCode | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const [titleValue, setTitleValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });
  const [descValue, setDescValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });
  const [formData, setFormData] = useState({
    promo_code: '',
    discount_type: 'percentage' as string,
    discount_value: 10,
    minimum_order: 0,
    max_uses: 0,
    max_uses_per_user: 1,
    valid_from: new Date().toISOString().split('T')[0],
    valid_until: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    days_of_week: [] as number[],
    is_active: true,
    exclude_discounted_items: true,
    applies_to: 'all',
  });

  const { data: promoCodes = [], isLoading } = useQuery({
    queryKey: ['promo-codes'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('daily_promos')
        .select('*')
        .not('promo_code', 'is', null)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return (data || []) as PromoCode[];
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const { error } = await supabase.from('daily_promos').insert(data);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['promo-codes'] });
      toast.success('Codice promo creato!');
      resetForm();
      setIsCreateOpen(false);
    },
    onError: (error: any) => toast.error(error.message),
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, ...data }: any) => {
      const { error } = await supabase.from('daily_promos').update(data).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['promo-codes'] });
      toast.success('Codice promo aggiornato!');
      resetForm();
      setEditingPromo(null);
    },
    onError: (error: any) => toast.error(error.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('daily_promos').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['promo-codes'] });
      toast.success('Codice promo eliminato!');
    },
    onError: (error: any) => toast.error(error.message),
  });

  const resetForm = () => {
    setTitleValue({ it: '', en: '', de: '', es: '', fr: '' });
    setDescValue({ it: '', en: '', de: '', es: '', fr: '' });
    setFormData({
      promo_code: '',
      discount_type: 'percentage',
      discount_value: 10,
      minimum_order: 0,
      max_uses: 0,
      max_uses_per_user: 1,
      valid_from: new Date().toISOString().split('T')[0],
      valid_until: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      days_of_week: [],
      is_active: true,
      exclude_discounted_items: true,
      applies_to: 'all',
    });
  };

  const handleCreate = async () => {
    if (!formData.promo_code.trim()) {
      toast.error('Inserisci un codice promo');
      return;
    }

    await createMutation.mutateAsync({
      promo_code: formData.promo_code.toUpperCase(),
      title: { it: titleValue.it || formData.promo_code, en: titleValue.en || formData.promo_code },
      description: descValue.it ? { it: descValue.it, en: descValue.en } : null,
      discount_type: formData.discount_type,
      discount_value: formData.discount_value || null,
      minimum_order: formData.minimum_order || null,
      max_uses: formData.max_uses || null,
      max_uses_per_user: formData.max_uses_per_user || null,
      valid_from: formData.valid_from,
      valid_until: formData.valid_until,
      days_of_week: formData.days_of_week.length > 0 ? formData.days_of_week : null,
      is_active: formData.is_active,
      exclude_discounted_items: formData.exclude_discounted_items,
      applies_to: formData.applies_to,
      current_uses: 0,
    });
  };

  const handleUpdate = async () => {
    if (!editingPromo) return;

    await updateMutation.mutateAsync({
      id: editingPromo.id,
      promo_code: formData.promo_code.toUpperCase(),
      title: { it: titleValue.it || formData.promo_code, en: titleValue.en || formData.promo_code },
      description: descValue.it ? { it: descValue.it, en: descValue.en } : null,
      discount_type: formData.discount_type,
      discount_value: formData.discount_value || null,
      minimum_order: formData.minimum_order || null,
      max_uses: formData.max_uses || null,
      max_uses_per_user: formData.max_uses_per_user || null,
      valid_from: formData.valid_from,
      valid_until: formData.valid_until,
      days_of_week: formData.days_of_week.length > 0 ? formData.days_of_week : null,
      is_active: formData.is_active,
      exclude_discounted_items: formData.exclude_discounted_items,
      applies_to: formData.applies_to,
    });
  };

  const openEditDialog = (promo: PromoCode) => {
    setEditingPromo(promo);
    setTitleValue({
      it: promo.title?.it || '',
      en: promo.title?.en || '',
      de: '', es: '', fr: '',
    });
    setDescValue({
      it: promo.description?.it || '',
      en: promo.description?.en || '',
      de: '', es: '', fr: '',
    });
    setFormData({
      promo_code: promo.promo_code || '',
      discount_type: promo.discount_type,
      discount_value: promo.discount_value || 0,
      minimum_order: promo.minimum_order || 0,
      max_uses: promo.max_uses || 0,
      max_uses_per_user: promo.max_uses_per_user || 1,
      valid_from: promo.valid_from.split('T')[0],
      valid_until: promo.valid_until.split('T')[0],
      days_of_week: promo.days_of_week || [],
      is_active: promo.is_active ?? true,
      exclude_discounted_items: promo.exclude_discounted_items ?? true,
      applies_to: promo.applies_to || 'all',
    });
  };

  const copyCode = async (code: string) => {
    await navigator.clipboard.writeText(code);
    setCopiedCode(code);
    toast.success('Codice copiato!');
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const toggleDay = (day: number) => {
    setFormData(prev => ({
      ...prev,
      days_of_week: prev.days_of_week.includes(day)
        ? prev.days_of_week.filter(d => d !== day)
        : [...prev.days_of_week, day].sort(),
    }));
  };

  const getDiscountIcon = (type: string) => {
    switch (type) {
      case 'percentage': return <Percent className="w-4 h-4" />;
      case 'fixed': return <Euro className="w-4 h-4" />;
      case 'free_delivery': return <Truck className="w-4 h-4" />;
      default: return <Tag className="w-4 h-4" />;
    }
  };

  const formatDiscount = (promo: PromoCode) => {
    if (promo.discount_type === 'percentage') return `-${promo.discount_value}%`;
    if (promo.discount_type === 'fixed') return `-€${promo.discount_value?.toFixed(2)}`;
    if (promo.discount_type === 'free_delivery') return 'Consegna gratis';
    return '';
  };

  if (isLoading) {
    return <div className="animate-pulse space-y-4">
      {[1, 2].map(i => <div key={i} className="h-20 bg-secondary/30 rounded-xl" />)}
    </div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Codici Sconto</h2>
          <p className="text-sm text-muted-foreground">Crea e gestisci codici promozionali</p>
        </div>
        <Button onClick={() => setIsCreateOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Nuovo Codice
        </Button>
      </div>

      {promoCodes.length === 0 ? (
        <div className="text-center py-12 bg-secondary/20 rounded-xl border border-dashed border-border">
          <Tag className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
          <p className="text-muted-foreground">Nessun codice sconto. Creane uno!</p>
        </div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {promoCodes.map((promo) => (
              <motion.div
                key={promo.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border"
              >
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center text-accent">
                  {getDiscountIcon(promo.discount_type)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <code className="font-mono font-bold text-sm bg-secondary/50 px-2 py-0.5 rounded">
                      {promo.promo_code}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => copyCode(promo.promo_code!)}
                    >
                      {copiedCode === promo.promo_code ? (
                        <Check className="w-3 h-3 text-green-500" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </Button>
                    <span className="text-sm font-medium text-accent">{formatDiscount(promo)}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {new Date(promo.valid_until).toLocaleDateString('it-IT')}
                    </span>
                    {promo.minimum_order && promo.minimum_order > 0 && (
                      <span>Min: €{promo.minimum_order}</span>
                    )}
                    {promo.max_uses && (
                      <span>Usi: {promo.current_uses || 0}/{promo.max_uses}</span>
                    )}
                  </div>
                </div>

                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => updateMutation.mutate({ id: promo.id, is_active: !promo.is_active })}
                  className={promo.is_active ? 'text-green-600' : 'text-muted-foreground'}
                >
                  {promo.is_active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </Button>

                <Button variant="ghost" size="icon" onClick={() => openEditDialog(promo)}>
                  <Edit2 className="w-4 h-4" />
                </Button>

                <Button
                  variant="ghost"
                  size="icon"
                  className="text-red-600"
                  onClick={() => deleteMutation.mutate(promo.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={isCreateOpen || !!editingPromo} onOpenChange={(open) => {
        if (!open) {
          setIsCreateOpen(false);
          setEditingPromo(null);
          resetForm();
        }
      }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPromo ? 'Modifica Codice' : 'Nuovo Codice Sconto'}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Promo Code */}
            <div className="space-y-2">
              <Label>Codice *</Label>
              <Input
                value={formData.promo_code}
                onChange={(e) => setFormData({ ...formData, promo_code: e.target.value.toUpperCase() })}
                placeholder="ES: SCONTO10"
                className="font-mono uppercase"
              />
            </div>

            {/* Title */}
            <MultiLangInput
              label="Nome (opzionale)"
              value={titleValue}
              onChange={setTitleValue}
              placeholder="Nome promo"
            />

            {/* Description */}
            <MultiLangInput
              label="Descrizione (opzionale)"
              value={descValue}
              onChange={setDescValue}
              placeholder="Descrizione"
            />

            {/* Discount Type & Value */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Tipo Sconto</Label>
                <Select
                  value={formData.discount_type}
                  onValueChange={(value) => setFormData({ ...formData, discount_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentuale (%)</SelectItem>
                    <SelectItem value="fixed">Fisso (€)</SelectItem>
                    <SelectItem value="free_delivery">Consegna Gratis</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.discount_type !== 'free_delivery' && (
                <div className="space-y-2">
                  <Label>Valore</Label>
                  <Input
                    type="number"
                    value={formData.discount_value}
                    onChange={(e) => setFormData({ ...formData, discount_value: Number(e.target.value) })}
                    min={0}
                  />
                </div>
              )}
            </div>

            {/* Minimum Order */}
            <div className="space-y-2">
              <Label>Ordine Minimo (€)</Label>
              <Input
                type="number"
                value={formData.minimum_order}
                onChange={(e) => setFormData({ ...formData, minimum_order: Number(e.target.value) })}
                min={0}
                placeholder="0 = nessun minimo"
              />
            </div>

            {/* Max Uses */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Utilizzi Totali Max</Label>
                <Input
                  type="number"
                  value={formData.max_uses}
                  onChange={(e) => setFormData({ ...formData, max_uses: Number(e.target.value) })}
                  min={0}
                  placeholder="0 = illimitati"
                />
              </div>
              <div className="space-y-2">
                <Label>Max per Utente</Label>
                <Input
                  type="number"
                  value={formData.max_uses_per_user}
                  onChange={(e) => setFormData({ ...formData, max_uses_per_user: Number(e.target.value) })}
                  min={1}
                />
              </div>
            </div>

            {/* Validity Dates */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Valido dal</Label>
                <Input
                  type="date"
                  value={formData.valid_from}
                  onChange={(e) => setFormData({ ...formData, valid_from: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Valido fino al</Label>
                <Input
                  type="date"
                  value={formData.valid_until}
                  onChange={(e) => setFormData({ ...formData, valid_until: e.target.value })}
                />
              </div>
            </div>

            {/* Days of Week */}
            <div className="space-y-2">
              <Label>Giorni Validi (vuoto = tutti)</Label>
              <div className="flex flex-wrap gap-2">
                {DAYS.map(day => (
                  <button
                    key={day.value}
                    type="button"
                    onClick={() => toggleDay(day.value)}
                    className={`px-3 py-1.5 text-sm rounded-full border transition-colors ${
                      formData.days_of_week.includes(day.value)
                        ? 'bg-accent text-accent-foreground border-accent'
                        : 'bg-secondary/30 border-border hover:border-accent/50'
                    }`}
                  >
                    {day.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Options */}
            <div className="space-y-3 pt-2 border-t border-border">
              <div className="flex items-center justify-between">
                <Label>Attivo</Label>
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Escludi prodotti scontati</Label>
                  <p className="text-xs text-muted-foreground">Non applicabile a prodotti già in offerta</p>
                </div>
                <Switch
                  checked={formData.exclude_discounted_items}
                  onCheckedChange={(checked) => setFormData({ ...formData, exclude_discounted_items: checked })}
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsCreateOpen(false);
              setEditingPromo(null);
              resetForm();
            }}>
              Annulla
            </Button>
            <Button onClick={editingPromo ? handleUpdate : handleCreate}>
              {editingPromo ? 'Salva' : 'Crea'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
