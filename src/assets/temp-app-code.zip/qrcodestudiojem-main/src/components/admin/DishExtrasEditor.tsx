import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Plus, Trash2, GripVertical, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface DishExtra {
  id: string;
  name_it: string;
  name_en: string;
  price: number;
  type: 'add' | 'remove' | 'option';
  is_default?: boolean;
  max_quantity?: number;
}

interface DishExtrasEditorProps {
  extras: DishExtra[];
  onChange: (extras: DishExtra[]) => void;
}

export function DishExtrasEditor({ extras, onChange }: DishExtrasEditorProps) {
  const [isExpanded, setIsExpanded] = useState(extras.length > 0);

  const addExtra = (type: 'add' | 'remove' | 'option') => {
    const newExtra: DishExtra = {
      id: crypto.randomUUID(),
      name_it: '',
      name_en: '',
      price: type === 'remove' ? 0 : 0,
      type,
      is_default: false,
      max_quantity: 1,
    };
    onChange([...extras, newExtra]);
  };

  const updateExtra = (id: string, updates: Partial<DishExtra>) => {
    onChange(extras.map(e => e.id === id ? { ...e, ...updates } : e));
  };

  const removeExtra = (id: string) => {
    onChange(extras.filter(e => e.id !== id));
  };

  const moveExtra = (index: number, direction: 'up' | 'down') => {
    const newExtras = [...extras];
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= extras.length) return;
    [newExtras[index], newExtras[newIndex]] = [newExtras[newIndex], newExtras[index]];
    onChange(newExtras);
  };

  const addExtras = extras.filter(e => e.type === 'add');
  const removeExtras = extras.filter(e => e.type === 'remove');
  const optionExtras = extras.filter(e => e.type === 'option');

  return (
    <div className="p-4 rounded-lg bg-purple-500/10 border border-purple-500/20 space-y-4">
      <button
        type="button"
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between w-full text-left"
      >
        <div className="flex items-center gap-2 text-sm font-medium text-purple-600 dark:text-purple-400">
          <Plus className="w-4 h-4" />
          Personalizzazioni ({extras.length})
        </div>
        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </button>

      {isExpanded && (
        <div className="space-y-6">
          {/* Add Extras Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-muted-foreground">AGGIUNTE (es. +Mozzarella)</Label>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => addExtra('add')}
                className="h-7 text-xs"
              >
                <Plus className="w-3 h-3 mr-1" />
                Aggiungi
              </Button>
            </div>
            {addExtras.map((extra, idx) => (
              <ExtraRow
                key={extra.id}
                extra={extra}
                index={idx}
                total={addExtras.length}
                onUpdate={(updates) => updateExtra(extra.id, updates)}
                onRemove={() => removeExtra(extra.id)}
                onMove={(dir) => {
                  const realIndex = extras.findIndex(e => e.id === extra.id);
                  moveExtra(realIndex, dir);
                }}
                showPrice
              />
            ))}
            {addExtras.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-2">
                Nessuna aggiunta configurata
              </p>
            )}
          </div>

          {/* Remove Extras Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-muted-foreground">RIMOZIONI (es. Senza cipolla)</Label>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => addExtra('remove')}
                className="h-7 text-xs"
              >
                <Plus className="w-3 h-3 mr-1" />
                Aggiungi
              </Button>
            </div>
            {removeExtras.map((extra, idx) => (
              <ExtraRow
                key={extra.id}
                extra={extra}
                index={idx}
                total={removeExtras.length}
                onUpdate={(updates) => updateExtra(extra.id, updates)}
                onRemove={() => removeExtra(extra.id)}
                onMove={(dir) => {
                  const realIndex = extras.findIndex(e => e.id === extra.id);
                  moveExtra(realIndex, dir);
                }}
                showPrice={false}
              />
            ))}
            {removeExtras.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-2">
                Nessuna rimozione configurata
              </p>
            )}
          </div>

          {/* Options Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-xs text-muted-foreground">OPZIONI (es. Cottura media/al sangue)</Label>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => addExtra('option')}
                className="h-7 text-xs"
              >
                <Plus className="w-3 h-3 mr-1" />
                Aggiungi
              </Button>
            </div>
            {optionExtras.map((extra, idx) => (
              <ExtraRow
                key={extra.id}
                extra={extra}
                index={idx}
                total={optionExtras.length}
                onUpdate={(updates) => updateExtra(extra.id, updates)}
                onRemove={() => removeExtra(extra.id)}
                onMove={(dir) => {
                  const realIndex = extras.findIndex(e => e.id === extra.id);
                  moveExtra(realIndex, dir);
                }}
                showPrice
              />
            ))}
            {optionExtras.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-2">
                Nessuna opzione configurata
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

interface ExtraRowProps {
  extra: DishExtra;
  index: number;
  total: number;
  onUpdate: (updates: Partial<DishExtra>) => void;
  onRemove: () => void;
  onMove: (direction: 'up' | 'down') => void;
  showPrice: boolean;
}

function ExtraRow({ extra, index, total, onUpdate, onRemove, onMove, showPrice }: ExtraRowProps) {
  return (
    <div className="flex items-center gap-2 p-2 bg-background/50 rounded-lg border border-border/50">
      <div className="flex flex-col">
        <button
          type="button"
          onClick={() => onMove('up')}
          disabled={index === 0}
          className="p-0.5 hover:bg-secondary rounded disabled:opacity-30"
        >
          <ChevronUp className="w-3 h-3" />
        </button>
        <button
          type="button"
          onClick={() => onMove('down')}
          disabled={index === total - 1}
          className="p-0.5 hover:bg-secondary rounded disabled:opacity-30"
        >
          <ChevronDown className="w-3 h-3" />
        </button>
      </div>
      
      <Input
        placeholder="Nome IT"
        value={extra.name_it}
        onChange={(e) => onUpdate({ name_it: e.target.value })}
        className="flex-1 h-8 text-sm"
      />
      <Input
        placeholder="Name EN"
        value={extra.name_en}
        onChange={(e) => onUpdate({ name_en: e.target.value })}
        className="flex-1 h-8 text-sm"
      />
      
      {showPrice && (
        <div className="flex items-center gap-1">
          <span className="text-xs text-muted-foreground">€</span>
          <Input
            type="number"
            step="0.50"
            min="0"
            placeholder="0.00"
            value={extra.price || ''}
            onChange={(e) => onUpdate({ price: parseFloat(e.target.value) || 0 })}
            className="w-16 h-8 text-sm"
          />
        </div>
      )}

      <div className="flex items-center gap-1" title="Predefinito">
        <Switch
          checked={extra.is_default}
          onCheckedChange={(v) => onUpdate({ is_default: v })}
          className="scale-75"
        />
      </div>
      
      <Button
        type="button"
        size="icon"
        variant="ghost"
        onClick={onRemove}
        className="h-7 w-7 text-destructive hover:text-destructive"
      >
        <Trash2 className="w-3 h-3" />
      </Button>
    </div>
  );
}
