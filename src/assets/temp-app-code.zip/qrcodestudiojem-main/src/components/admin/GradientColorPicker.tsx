import { useState } from 'react';
import { Check, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';

// HSL Color presets - Regular + Pastel colors
export const colorPresets = [
  // Regular colors
  { name: 'Arancione', value: '12 76% 61%' },
  { name: 'Rosso', value: '0 72% 51%' },
  { name: 'Rosso Scuro', value: '0 65% 40%' },
  { name: 'Rosa', value: '330 81% 60%' },
  { name: 'Rosa Chiaro', value: '350 89% 70%' },
  { name: 'Fucsia', value: '322 81% 55%' },
  { name: 'Viola', value: '271 76% 53%' },
  { name: 'Viola Scuro', value: '270 50% 40%' },
  { name: 'Indaco', value: '245 58% 51%' },
  { name: 'Blu', value: '217 91% 60%' },
  { name: 'Blu Scuro', value: '221 83% 45%' },
  { name: 'Navy', value: '230 60% 30%' },
  { name: 'Ciano', value: '188 78% 50%' },
  { name: 'Teal', value: '174 72% 40%' },
  { name: 'Verde Acqua', value: '168 76% 48%' },
  { name: 'Verde', value: '142 71% 45%' },
  { name: 'Verde Scuro', value: '142 60% 32%' },
  { name: 'Lime', value: '84 78% 45%' },
  { name: 'Giallo', value: '48 96% 53%' },
  { name: 'Oro', value: '45 93% 47%' },
  { name: 'Ambra', value: '38 92% 50%' },
  { name: 'Marrone', value: '30 55% 35%' },
  { name: 'Grigio', value: '0 0% 50%' },
  { name: 'Nero', value: '0 0% 10%' },
  // Pastel colors
  { name: 'Pastel Rosa', value: '350 70% 85%' },
  { name: 'Pastel Pesca', value: '20 80% 85%' },
  { name: 'Pastel Lavanda', value: '270 60% 85%' },
  { name: 'Pastel Lilla', value: '290 50% 85%' },
  { name: 'Pastel Blu', value: '210 60% 85%' },
  { name: 'Pastel Azzurro', value: '195 70% 85%' },
  { name: 'Pastel Menta', value: '160 50% 85%' },
  { name: 'Pastel Verde', value: '140 50% 85%' },
  { name: 'Pastel Giallo', value: '55 80% 85%' },
  { name: 'Pastel Corallo', value: '10 75% 80%' },
  { name: 'Pastel Salmone', value: '15 70% 80%' },
  { name: 'Pastel Acquamarina', value: '175 55% 80%' },
  { name: 'Pastel Glicine', value: '280 45% 82%' },
  { name: 'Pastel Celeste', value: '200 60% 88%' },
  { name: 'Pastel Albicocca', value: '30 75% 82%' },
];

// Gradient presets from uiGradients and custom
export const gradientPresets = [
  // Blues & Purples
  { name: 'Blurry Beach', value: 'from-[#d53369] to-[#daae51]' },
  { name: 'Namn', value: 'from-[#a73737] to-[#7a2828]' },
  { name: 'Day Tripper', value: 'from-[#f857a6] to-[#ff5858]' },
  { name: 'Pinot Noir', value: 'from-[#4b6cb7] to-[#182848]' },
  { name: 'Miaka', value: 'from-[#fc354c] to-[#0abfbc]' },
  { name: 'Army', value: 'from-[#414d0b] to-[#727a17]' },
  { name: 'Shrimpy', value: 'from-[#e43a15] to-[#e65245]' },
  { name: 'Influenza', value: 'from-[#c04848] to-[#480048]' },
  { name: 'Calm Darya', value: 'from-[#5f2c82] to-[#49a09d]' },
  { name: 'YouTube', value: 'from-[#e52d27] to-[#b31217]' },
  { name: 'Royal Blue', value: 'from-[#536976] to-[#292e49]' },
  { name: 'Deep Blue', value: 'from-[#1a2980] to-[#26d0ce]' },
  { name: 'Purple Love', value: 'from-[#cc2b5e] to-[#753a88]' },
  { name: 'Sublime Light', value: 'from-[#fc5c7d] to-[#6a82fb]' },
  { name: 'Intuitive Purple', value: 'from-[#da22ff] to-[#9733ee]' },
  { name: 'Emerald Water', value: 'from-[#348f50] to-[#56b4d3]' },
  { name: 'Lemon Twist', value: 'from-[#3ca55c] to-[#b5ac49]' },
  { name: 'Monte Carlo', value: 'from-[#cc95c0] to-[#7aa1d2]' },
  { name: 'Horizon', value: 'from-[#003973] to-[#e5e5be]' },
  { name: 'Rose Water', value: 'from-[#e55d87] to-[#5fc3e4]' },
  { name: 'Frozen', value: 'from-[#403b4a] to-[#e7e9bb]' },
  { name: 'Mango Pulp', value: 'from-[#f09819] to-[#edde5d]' },
  { name: 'Bloody Mary', value: 'from-[#ff512f] to-[#dd2476]' },
  { name: 'Aubergine', value: 'from-[#aa076b] to-[#61045f]' },
  { name: 'Aqua Marine', value: 'from-[#1a2980] to-[#26d0ce]' },
  { name: 'Sunrise', value: 'from-[#ff512f] to-[#f09819]' },
  { name: 'Purple Paradise', value: 'from-[#1d2b64] to-[#f8cdda]' },
  { name: 'Stripe', value: 'from-[#1fa2ff] via-[#12d8fa] to-[#a6ffcb]' },
  { name: 'Sea Blue', value: 'from-[#2b5876] to-[#4e4376]' },
  { name: 'Nimvelo', value: 'from-[#314755] to-[#26a0da]' },
  { name: 'Hazel', value: 'from-[#77a1d3] via-[#79cbca] to-[#e684ae]' },
  { name: 'Noon to Dusk', value: 'from-[#ff6e7f] to-[#bfe9ff]' },
  { name: 'Lush', value: 'from-[#56ab2f] to-[#a8e063]' },
  { name: 'Firewatch', value: 'from-[#cb2d3e] to-[#ef473a]' },
  { name: 'Sherbert', value: 'from-[#f79d00] to-[#64f38c]' },
  { name: 'Blood Red', value: 'from-[#f85032] to-[#e73827]' },
  { name: 'Sun on Horizon', value: 'from-[#fceabb] to-[#f8b500]' },
  { name: 'IIIT Delhi', value: 'from-[#808080] to-[#3fada8]' },
  { name: 'Jupiter', value: 'from-[#ffd89b] to-[#19547b]' },
  { name: 'Politics', value: 'from-[#2196f3] to-[#f44336]' },
  { name: 'Sweet Morning', value: 'from-[#ff5f6d] to-[#ffc371]' },
  { name: 'Sylvia', value: 'from-[#ff4b1f] to-[#1fddff]' },
  { name: 'Transfile', value: 'from-[#16bffd] to-[#cb3066]' },
  { name: 'Mauve', value: 'from-[#42275a] to-[#734b6d]' },
  { name: 'Mild', value: 'from-[#67b26f] to-[#4ca2cd]' },
  { name: 'Argon', value: 'from-[#03001e] via-[#7303c0] to-[#ec38bc]' },
  { name: 'Witching Hour', value: 'from-[#c31432] to-[#240b36]' },
  { name: 'Flare', value: 'from-[#f12711] to-[#f5af19]' },
  { name: 'Metapolis', value: 'from-[#659999] to-[#f4791f]' },
  { name: 'Kyoo Pal', value: 'from-[#dd3e54] to-[#6be585]' },
  { name: 'Kye Meh', value: 'from-[#8360c3] to-[#2ebf91]' },
  { name: 'Titanium', value: 'from-[#283048] to-[#859398]' },
  { name: 'Celestial', value: 'from-[#c33764] to-[#1d2671]' },
  { name: 'Digital Water', value: 'from-[#74ebd5] to-[#acb6e5]' },
  { name: 'Velvet Sun', value: 'from-[#e1eec3] to-[#f05053]' },
  { name: 'Quepal', value: 'from-[#11998e] to-[#38ef7d]' },
  { name: 'Cool Sky', value: 'from-[#2980b9] to-[#6dd5fa]' },
  { name: 'Passion', value: 'from-[#e53935] to-[#e35d5b]' },
  { name: 'Timber', value: 'from-[#fc00ff] to-[#00dbde]' },
  { name: 'Between Clouds', value: 'from-[#73c8a9] to-[#373b44]' },
  { name: 'Crazy Orange', value: 'from-[#d38312] to-[#a83279]' },
  { name: 'Hersheys', value: 'from-[#1e130c] to-[#9a8478]' },
  { name: 'Talking Murse', value: 'from-[#7b4397] to-[#dc2430]' },
  { name: 'Purple White', value: 'from-[#ba5370] to-[#f4e2d8]' },
  { name: 'Mirage', value: 'from-[#16222a] to-[#3a6073]' },
  { name: 'Steel Gray', value: 'from-[#1f1c2c] to-[#928dab]' },
  { name: 'Kashmir', value: 'from-[#614385] to-[#516395]' },
  { name: 'Electric Violet', value: 'from-[#4776e6] to-[#8e54e9]' },
  { name: 'Venice Blue', value: 'from-[#085078] to-[#85d8ce]' },
  { name: 'Bora Bora', value: 'from-[#2bc0e4] to-[#eaecc6]' },
  { name: 'Moss', value: 'from-[#134e5e] to-[#71b280]' },
  { name: 'Shroom Haze', value: 'from-[#5c258d] to-[#4389a2]' },
  { name: 'Mystic', value: 'from-[#757f9a] to-[#d7dde8]' },
  { name: 'Midnight City', value: 'from-[#232526] to-[#414345]' },
  { name: 'Sea Blizz', value: 'from-[#1cd8d2] to-[#93edc7]' },
  { name: 'Opa', value: 'from-[#3d7eaa] to-[#ffe47a]' },
  { name: 'Disco', value: 'from-[#4ecdc4] to-[#556270]' },
  { name: 'Love Couple', value: 'from-[#3a6186] to-[#89253e]' },
  { name: 'Azure Pop', value: 'from-[#ef32d9] to-[#89fffd]' },
  { name: 'Nepal', value: 'from-[#de6161] to-[#2657eb]' },
  { name: 'Cosmic Fusion', value: 'from-[#ff00cc] to-[#333399]' },
  { name: 'Cherry', value: 'from-[#eb3349] to-[#f45c43]' },
];

interface GradientColorPickerProps {
  value: string;
  onChange: (value: string) => void;
  type?: 'color' | 'gradient' | 'both';
  label?: string;
  placeholder?: string;
}

export function GradientColorPicker({
  value,
  onChange,
  type = 'both',
  label,
  placeholder = 'Seleziona...',
}: GradientColorPickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const defaultTab = type === 'gradient' ? 'gradient' : 'color';

  const isGradient = value?.includes('from-') || value?.includes('to-');

  const getDisplayValue = () => {
    if (!value) return placeholder;
    
    // Check if it's a known color preset
    const colorPreset = colorPresets.find(c => c.value === value);
    if (colorPreset) return colorPreset.name;
    
    // Check if it's a known gradient preset
    const gradientPreset = gradientPresets.find(g => g.value === value);
    if (gradientPreset) return gradientPreset.name;
    
    // Otherwise show the raw value (truncated)
    return value.length > 25 ? value.substring(0, 25) + '...' : value;
  };

  const renderPreview = () => {
    if (!value) return null;
    
    if (isGradient) {
      return (
        <div 
          className={cn('w-8 h-8 rounded-lg border border-border shrink-0 bg-gradient-to-r', value)}
        />
      );
    }
    
    return (
      <div 
        className="w-8 h-8 rounded-lg border border-border shrink-0"
        style={{ backgroundColor: `hsl(${value})` }}
      />
    );
  };

  const handleClear = () => {
    onChange('');
    setIsOpen(false);
  };

  return (
    <div className="space-y-2">
      {label && <label className="text-sm text-muted-foreground">{label}</label>}
      
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className="w-full justify-start gap-2 h-10"
          >
            {renderPreview()}
            <span className="truncate flex-1 text-left text-sm">
              {getDisplayValue()}
            </span>
            <Palette className="w-4 h-4 text-muted-foreground shrink-0" />
          </Button>
        </PopoverTrigger>
        <PopoverContent 
          className="w-80 p-0 z-[100]" 
          align="start"
          side="bottom"
          sideOffset={4}
          avoidCollisions={true}
        >
          <Tabs defaultValue={defaultTab} className="w-full">
            {type === 'both' && (
              <TabsList className="w-full grid grid-cols-2 rounded-none border-b bg-muted">
                <TabsTrigger value="color" className="rounded-none data-[state=active]:bg-background">Colori</TabsTrigger>
                <TabsTrigger value="gradient" className="rounded-none data-[state=active]:bg-background">Gradienti</TabsTrigger>
              </TabsList>
            )}
            
            {(type === 'color' || type === 'both') && (
              <TabsContent value="color" className="m-0">
                <ScrollArea className="h-[280px]">
                  <div className="p-2">
                    {/* Clear option */}
                    <button
                      type="button"
                      onClick={handleClear}
                      className={cn(
                        'w-full mb-2 py-2 px-3 rounded-lg border-2 text-sm text-left transition-all hover:bg-secondary',
                        !value ? 'border-foreground bg-secondary' : 'border-border'
                      )}
                    >
                      Nessuno (default)
                    </button>
                    
                    <div className="grid grid-cols-5 gap-1.5">
                      {colorPresets.map((color) => (
                        <button
                          key={color.value}
                          type="button"
                          onClick={() => {
                            onChange(color.value);
                            setIsOpen(false);
                          }}
                          className={cn(
                            'w-full aspect-square rounded-lg border-2 transition-all hover:scale-105',
                            value === color.value ? 'border-foreground ring-2 ring-foreground/20' : 'border-transparent'
                          )}
                          style={{ backgroundColor: `hsl(${color.value})` }}
                          title={color.name}
                        >
                          {value === color.value && (
                            <Check className="w-4 h-4 mx-auto text-white drop-shadow-md" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                </ScrollArea>
                <div className="p-2 border-t bg-muted/30">
                  <Input
                    value={isGradient ? '' : value}
                    onChange={(e) => onChange(e.target.value)}
                    placeholder="HSL: 12 76% 61%"
                    className="text-xs bg-background"
                  />
                </div>
              </TabsContent>
            )}
            
            {(type === 'gradient' || type === 'both') && (
              <TabsContent value="gradient" className="m-0">
                <ScrollArea className="h-[280px]">
                  <div className="p-2">
                    {/* Clear option */}
                    <button
                      type="button"
                      onClick={handleClear}
                      className={cn(
                        'w-full mb-2 py-2 px-3 rounded-lg border-2 text-sm text-left transition-all hover:bg-secondary',
                        !value ? 'border-foreground bg-secondary' : 'border-border'
                      )}
                    >
                      Nessuno (default)
                    </button>
                    
                    <div className="grid grid-cols-2 gap-1.5">
                      {gradientPresets.map((gradient) => (
                        <button
                          key={gradient.value}
                          type="button"
                          onClick={() => {
                            onChange(gradient.value);
                            setIsOpen(false);
                          }}
                          className={cn(
                            'w-full h-10 rounded-lg border-2 transition-all hover:scale-[1.02] bg-gradient-to-r flex items-center justify-center',
                            gradient.value,
                            value === gradient.value ? 'border-foreground ring-2 ring-foreground/20' : 'border-transparent'
                          )}
                          title={gradient.name}
                        >
                          {value === gradient.value && (
                            <Check className="w-4 h-4 text-white drop-shadow-md" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                </ScrollArea>
                <div className="p-2 border-t bg-muted/30">
                  <Input
                    value={isGradient ? value : ''}
                    onChange={(e) => onChange(e.target.value)}
                    placeholder="from-[#hex] to-[#hex]"
                    className="text-xs bg-background"
                  />
                </div>
              </TabsContent>
            )}
          </Tabs>
        </PopoverContent>
      </Popover>
    </div>
  );
}
