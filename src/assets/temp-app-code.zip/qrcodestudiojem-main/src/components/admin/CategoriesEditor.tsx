import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash2, Loader2, GripVertical } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { MultiLangInput, type MultiLangValue } from './MultiLangInput';
import { ImageUpload } from './ImageUpload';

interface Category {
  id: string;
  name_it: string;
  name_en: string;
  name_de?: string | null;
  name_es?: string | null;
  name_fr?: string | null;
  description_it: string | null;
  description_en: string | null;
  description_de?: string | null;
  description_es?: string | null;
  description_fr?: string | null;
  icon: string;
  image_url: string | null;
  is_active: boolean;
  is_featured: boolean;
  display_order: number;
}

export function CategoriesEditor() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  const { data: categories = [], isLoading } = useQuery({
    queryKey: ['admin-categories-full'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('display_order');
      if (error) throw error;
      return data as Category[];
    }
  });

  const saveMutation = useMutation({
    mutationFn: async (category: Partial<Category> & { id?: string }) => {
      if (category.id) {
        const { error } = await supabase
          .from('categories')
          .update(category)
          .eq('id', category.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('categories')
          .insert([category as any]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-categories-full'] });
      queryClient.invalidateQueries({ queryKey: ['admin-categories'] });
      setIsDialogOpen(false);
      setEditingCategory(null);
      toast({ title: 'Categoria salvata!' });
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('categories').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-categories-full'] });
      queryClient.invalidateQueries({ queryKey: ['admin-categories'] });
      toast({ title: 'Categoria eliminata!' });
    },
    onError: (error: any) => {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    }
  });

  const CategoryForm = ({ category, onSave }: { category: Category | null; onSave: (data: Partial<Category>) => void }) => {
    const [nameValue, setNameValue] = useState<MultiLangValue>({
      it: category?.name_it || '',
      en: category?.name_en || '',
      de: category?.name_de || '',
      es: category?.name_es || '',
      fr: category?.name_fr || '',
    });
    const [descValue, setDescValue] = useState<MultiLangValue>({
      it: category?.description_it || '',
      en: category?.description_en || '',
      de: category?.description_de || '',
      es: category?.description_es || '',
      fr: category?.description_fr || '',
    });
    const [formData, setFormData] = useState({
      icon: category?.icon || '🍽️',
      image_url: category?.image_url || '',
      is_active: category?.is_active ?? true,
      is_featured: category?.is_featured ?? false,
      display_order: category?.display_order ?? categories.length
    });

    const handleSave = () => {
      onSave({
        name_it: nameValue.it || '',
        name_en: nameValue.en || '',
        name_de: nameValue.de || null,
        name_es: nameValue.es || null,
        name_fr: nameValue.fr || null,
        description_it: descValue.it || null,
        description_en: descValue.en || null,
        description_de: descValue.de || null,
        description_es: descValue.es || null,
        description_fr: descValue.fr || null,
        ...formData
      });
    };

    return (
      <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
        <MultiLangInput
          label="Nome categoria"
          value={nameValue}
          onChange={setNameValue}
          placeholder="Nome"
          required
        />

        <MultiLangInput
          label="Descrizione"
          value={descValue}
          onChange={setDescValue}
          placeholder="Descrizione"
          multiline
          rows={2}
        />

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Icona (emoji)</Label>
            <Input
              value={formData.icon}
              onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
              placeholder="🍕"
            />
          </div>
          <div className="space-y-2">
            <Label>Ordine</Label>
            <Input
              type="number"
              value={formData.display_order}
              onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label>Immagine categoria</Label>
          <ImageUpload
            value={formData.image_url}
            onChange={(url) => setFormData({ ...formData, image_url: url || '' })}
            folder="categories"
          />
          <p className="text-xs text-muted-foreground">
            L'immagine verrà mostrata nei tab del takeaway (template "Tabs con Immagini")
          </p>
        </div>

        <div className="flex gap-6 pt-2">
          <div className="flex items-center gap-2">
            <Switch
              checked={formData.is_active}
              onCheckedChange={(v) => setFormData({ ...formData, is_active: v })}
            />
            <Label>Attiva</Label>
          </div>
          <div className="flex items-center gap-2">
            <Switch
              checked={formData.is_featured}
              onCheckedChange={(v) => setFormData({ ...formData, is_featured: v })}
            />
            <Label>In evidenza</Label>
          </div>
        </div>

        <Button
          onClick={handleSave}
          disabled={!nameValue.it || !nameValue.en}
          className="w-full"
        >
          {category ? 'Aggiorna' : 'Crea'} Categoria
        </Button>
      </div>
    );
  };

  if (isLoading) {
    return <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin" /></div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => setEditingCategory(null)}>
              <Plus className="w-4 h-4 mr-2" />
              Nuova Categoria
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{editingCategory ? 'Modifica' : 'Nuova'} Categoria</DialogTitle>
            </DialogHeader>
            <CategoryForm
              category={editingCategory}
              onSave={(data) => saveMutation.mutate(editingCategory ? { ...data, id: editingCategory.id } : data)}
            />
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2">
        {categories.map((category) => (
          <div
            key={category.id}
            className="flex items-center gap-3 p-3 bg-card border border-border rounded-lg"
          >
            <GripVertical className="w-4 h-4 text-muted-foreground cursor-grab" />
            
            <span className="text-2xl">{category.icon}</span>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-medium">{category.name_it}</span>
                {!category.is_active && (
                  <span className="text-xs px-2 py-0.5 bg-muted text-muted-foreground rounded-full">Nascosta</span>
                )}
                {category.is_featured && (
                  <span className="text-xs px-2 py-0.5 bg-accent/10 text-accent rounded-full">In evidenza</span>
                )}
              </div>
              <p className="text-sm text-muted-foreground">{category.name_en}</p>
            </div>

            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setEditingCategory(category);
                  setIsDialogOpen(true);
                }}
              >
                <Pencil className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  if (confirm('Eliminare questa categoria? I piatti associati potrebbero diventare orfani.')) {
                    deleteMutation.mutate(category.id);
                  }
                }}
              >
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          </div>
        ))}

        {categories.length === 0 && (
          <p className="text-center text-muted-foreground py-8">Nessuna categoria</p>
        )}
      </div>
    </div>
  );
}
