import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Save, Loader2, GripVertical, Edit2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { OnboardingStep } from '@/hooks/useOnboardingSteps';
import { QuizOptionsEditor } from './QuizOptionsEditor';

interface OnboardingEditorProps {
  steps: OnboardingStep[];
  currentLanguage: string;
  onRefresh: () => void;
}

export function OnboardingEditor({ steps, currentLanguage, onRefresh }: OnboardingEditorProps) {
  const [editingStep, setEditingStep] = useState<OnboardingStep | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [newStep, setNewStep] = useState({
    step_key: '',
    question_it: '',
    question_en: '',
    subtext_it: '',
    subtext_en: '',
  });

  const handleToggleActive = async (step: OnboardingStep) => {
    try {
      const { error } = await supabase
        .from('onboarding_steps')
        .update({ is_active: !step.is_active })
        .eq('id', step.id);

      if (error) throw error;
      toast.success(step.is_active ? 'Step disattivato' : 'Step attivato');
      onRefresh();
    } catch (error) {
      console.error('Error toggling step:', error);
      toast.error('Errore nell\'aggiornamento');
    }
  };

  const handleDelete = async (stepId: string) => {
    if (!confirm('Sei sicuro di voler eliminare questo step?')) return;
    
    try {
      const { error } = await supabase
        .from('onboarding_steps')
        .delete()
        .eq('id', stepId);

      if (error) throw error;
      toast.success('Step eliminato');
      onRefresh();
    } catch (error) {
      console.error('Error deleting step:', error);
      toast.error('Errore nell\'eliminazione');
    }
  };

  const handleSaveEdit = async () => {
    if (!editingStep) return;
    setIsSaving(true);

    try {
      const { error } = await supabase
        .from('onboarding_steps')
        .update({
          question: editingStep.question,
          subtext: editingStep.subtext,
          is_optional: editingStep.is_optional,
        })
        .eq('id', editingStep.id);

      if (error) throw error;
      toast.success('Step aggiornato');
      setEditingStep(null);
      onRefresh();
    } catch (error) {
      console.error('Error saving step:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateStep = async () => {
    if (!newStep.step_key || !newStep.question_it) {
      toast.error('Compila almeno chiave e domanda IT');
      return;
    }
    setIsSaving(true);

    try {
      const maxOrder = Math.max(...steps.map(s => s.display_order), 0);
      const { error } = await supabase
        .from('onboarding_steps')
        .insert({
          step_key: newStep.step_key,
          question: { it: newStep.question_it, en: newStep.question_en || newStep.question_it },
          subtext: newStep.subtext_it ? { it: newStep.subtext_it, en: newStep.subtext_en || newStep.subtext_it } : null,
          options: [],
          display_order: maxOrder + 1,
          is_active: true,
          is_optional: false,
        });

      if (error) throw error;
      toast.success('Step creato');
      setIsCreating(false);
      setNewStep({ step_key: '', question_it: '', question_en: '', subtext_it: '', subtext_en: '' });
      onRefresh();
    } catch (error) {
      console.error('Error creating step:', error);
      toast.error('Errore nella creazione');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Steps Onboarding ({steps.length})</h2>
        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Nuovo Step
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Crea Nuovo Step</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Chiave (univoca)</label>
                <Input
                  value={newStep.step_key}
                  onChange={(e) => setNewStep({ ...newStep, step_key: e.target.value })}
                  placeholder="es: dietary_preferences"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">Domanda IT</label>
                  <Input
                    value={newStep.question_it}
                    onChange={(e) => setNewStep({ ...newStep, question_it: e.target.value })}
                    placeholder="Domanda in italiano"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">Domanda EN</label>
                  <Input
                    value={newStep.question_en}
                    onChange={(e) => setNewStep({ ...newStep, question_en: e.target.value })}
                    placeholder="Question in English"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">Sottotesto IT</label>
                  <Input
                    value={newStep.subtext_it}
                    onChange={(e) => setNewStep({ ...newStep, subtext_it: e.target.value })}
                    placeholder="Opzionale"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">Sottotesto EN</label>
                  <Input
                    value={newStep.subtext_en}
                    onChange={(e) => setNewStep({ ...newStep, subtext_en: e.target.value })}
                    placeholder="Optional"
                  />
                </div>
              </div>
              <Button onClick={handleCreateStep} disabled={isSaving} className="w-full">
                {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                Crea Step
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {steps.map((step, index) => (
        <div key={step.id} className="p-4 rounded-2xl bg-secondary/30 border border-border/30">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3 flex-1">
              <GripVertical className="w-5 h-5 text-muted-foreground mt-1 cursor-grab" />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs text-muted-foreground uppercase tracking-wider">
                    Step {index + 1}
                  </span>
                  <span className="text-xs px-2 py-0.5 bg-background rounded-full">
                    {step.step_key}
                  </span>
                </div>
                <h3 className="font-medium">
                  {step.question[currentLanguage as 'it' | 'en'] || step.question.it}
                </h3>
                {step.subtext && (
                  <p className="text-sm text-muted-foreground mt-1">
                    {step.subtext[currentLanguage as 'it' | 'en'] || step.subtext.it}
                  </p>
                )}
                <div className="flex flex-wrap gap-2 mt-3">
                  {step.options.slice(0, 3).map((opt) => (
                    <span key={opt.id} className="px-3 py-1.5 bg-background rounded-lg text-sm">
                      {opt.emoji} {opt.label[currentLanguage as 'it' | 'en'] || opt.label.it}
                    </span>
                  ))}
                  {step.options.length > 3 && (
                    <span className="px-3 py-1.5 bg-background/50 rounded-lg text-sm text-muted-foreground">
                      +{step.options.length - 3} altre
                    </span>
                  )}
                </div>
                
                {/* Options Editor */}
                <QuizOptionsEditor step={step} currentLanguage={currentLanguage} onRefresh={onRefresh} />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Switch
                checked={step.is_active}
                onCheckedChange={() => handleToggleActive(step)}
              />
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" onClick={() => setEditingStep(step)}>
                    <Edit2 className="w-4 h-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Modifica Step</DialogTitle>
                  </DialogHeader>
                  {editingStep && (
                    <div className="space-y-4 pt-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-sm text-muted-foreground">🇮🇹 Domanda IT</label>
                          <Input
                            value={editingStep.question.it}
                            onChange={(e) => setEditingStep({
                              ...editingStep,
                              question: { ...editingStep.question, it: e.target.value }
                            })}
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm text-muted-foreground">🇬🇧 Domanda EN</label>
                          <Input
                            value={editingStep.question.en || ''}
                            onChange={(e) => setEditingStep({
                              ...editingStep,
                              question: { ...editingStep.question, en: e.target.value }
                            })}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-sm text-muted-foreground">🇮🇹 Sottotesto IT</label>
                          <Input
                            value={editingStep.subtext?.it || ''}
                            onChange={(e) => setEditingStep({
                              ...editingStep,
                              subtext: { ...editingStep.subtext, it: e.target.value }
                            })}
                            placeholder="Sottotesto opzionale"
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm text-muted-foreground">🇬🇧 Sottotesto EN</label>
                          <Input
                            value={editingStep.subtext?.en || ''}
                            onChange={(e) => setEditingStep({
                              ...editingStep,
                              subtext: { ...editingStep.subtext, en: e.target.value }
                            })}
                            placeholder="Optional subtext"
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={editingStep.is_optional}
                          onCheckedChange={(checked) => setEditingStep({
                            ...editingStep,
                            is_optional: checked
                          })}
                        />
                        <span className="text-sm">Opzionale (può essere saltato)</span>
                      </div>
                      <Button onClick={handleSaveEdit} disabled={isSaving} className="w-full">
                        {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                        Salva
                      </Button>
                    </div>
                  )}
                </DialogContent>
              </Dialog>
              <Button variant="ghost" size="icon" onClick={() => handleDelete(step.id)}>
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          </div>
        </div>
      ))}
    </motion.div>
  );
}