import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Save, Loader2, Edit2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { DynamicMood } from '@/hooks/useDynamicMoods';
import { GradientColorPicker } from './GradientColorPicker';

const LANGUAGES = [
  { code: 'it', flag: '🇮🇹' },
  { code: 'en', flag: '🇬🇧' },
  { code: 'de', flag: '🇩🇪' },
  { code: 'es', flag: '🇪🇸' },
  { code: 'fr', flag: '🇫🇷' },
];

interface MoodsEditorProps {
  moods: DynamicMood[];
  currentLanguage: string;
  onRefresh: () => void;
}

export function MoodsEditor({ moods, currentLanguage, onRefresh }: MoodsEditorProps) {
  const [editingMood, setEditingMood] = useState<DynamicMood | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [langTab, setLangTab] = useState('it');
  const [newMood, setNewMood] = useState({
    mood_key: '',
    emoji: '😋',
    label: { it: '', en: '', de: '', es: '', fr: '' },
    gradient: 'from-orange-500/20 to-red-500/20',
  });

  const handleToggleActive = async (mood: DynamicMood) => {
    try {
      const { error } = await supabase
        .from('moods')
        .update({ is_active: !mood.is_active })
        .eq('id', mood.id);

      if (error) throw error;
      toast.success(mood.is_active ? 'Mood disattivato' : 'Mood attivato');
      onRefresh();
    } catch (error) {
      console.error('Error toggling mood:', error);
      toast.error('Errore nell\'aggiornamento');
    }
  };

  const handleDelete = async (moodId: string) => {
    if (!confirm('Sei sicuro di voler eliminare questo mood?')) return;
    
    try {
      const { error } = await supabase
        .from('moods')
        .delete()
        .eq('id', moodId);

      if (error) throw error;
      toast.success('Mood eliminato');
      onRefresh();
    } catch (error) {
      console.error('Error deleting mood:', error);
      toast.error('Errore nell\'eliminazione');
    }
  };

  const handleSaveEdit = async () => {
    if (!editingMood) return;
    setIsSaving(true);

    try {
      const { error } = await supabase
        .from('moods')
        .update({
          emoji: editingMood.emoji,
          label: editingMood.label,
          gradient: editingMood.gradient,
        })
        .eq('id', editingMood.id);

      if (error) throw error;
      toast.success('Mood aggiornato');
      setEditingMood(null);
      onRefresh();
    } catch (error) {
      console.error('Error saving mood:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateMood = async () => {
    if (!newMood.mood_key || !newMood.label.it) {
      toast.error('Compila almeno chiave e label IT');
      return;
    }
    setIsSaving(true);

    try {
      const maxOrder = Math.max(...moods.map(m => m.display_order), 0);
      const { error } = await supabase
        .from('moods')
        .insert({
          mood_key: newMood.mood_key,
          emoji: newMood.emoji,
          label: {
            it: newMood.label.it,
            en: newMood.label.en || newMood.label.it,
            de: newMood.label.de || '',
            es: newMood.label.es || '',
            fr: newMood.label.fr || '',
          },
          gradient: newMood.gradient,
          display_order: maxOrder + 1,
          is_active: true,
          filters: { tags: [] },
        });

      if (error) throw error;
      toast.success('Mood creato');
      setIsCreating(false);
      setNewMood({ mood_key: '', emoji: '😋', label: { it: '', en: '', de: '', es: '', fr: '' }, gradient: 'from-orange-500/20 to-red-500/20' });
      onRefresh();
    } catch (error) {
      console.error('Error creating mood:', error);
      toast.error('Errore nella creazione');
    } finally {
      setIsSaving(false);
    }
  };

  const emojiOptions = ['😋', '🔥', '🥗', '🍝', '🍷', '🎉', '💝', '🌿', '⚡', '🍰'];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Mood Selector ({moods.length})</h2>
        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Nuovo Mood
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Crea Nuovo Mood</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Chiave (univoca)</label>
                <Input
                  value={newMood.mood_key}
                  onChange={(e) => setNewMood({ ...newMood, mood_key: e.target.value })}
                  placeholder="es: comfort_food"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Emoji</label>
                <div className="flex flex-wrap gap-2">
                  {emojiOptions.map((emoji) => (
                    <button
                      key={emoji}
                      onClick={() => setNewMood({ ...newMood, emoji })}
                      className={`w-10 h-10 rounded-lg text-xl flex items-center justify-center transition-all ${
                        newMood.emoji === emoji ? 'bg-accent ring-2 ring-foreground' : 'bg-secondary/50 hover:bg-secondary'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">Label (5 lingue)</label>
                <Tabs value={langTab} onValueChange={setLangTab}>
                  <TabsList className="h-8 w-full grid grid-cols-5">
                    {LANGUAGES.map((lang) => (
                      <TabsTrigger key={lang.code} value={lang.code} className="text-xs gap-1 px-1">
                        <span>{lang.flag}</span>
                        <span className="hidden sm:inline">{lang.code.toUpperCase()}</span>
                      </TabsTrigger>
                    ))}
                  </TabsList>
                  {LANGUAGES.map((lang) => (
                    <TabsContent key={lang.code} value={lang.code} className="mt-2">
                      <Input
                        value={newMood.label[lang.code as keyof typeof newMood.label] || ''}
                        onChange={(e) => setNewMood({ ...newMood, label: { ...newMood.label, [lang.code]: e.target.value } })}
                        placeholder={`Label in ${lang.code.toUpperCase()}`}
                      />
                    </TabsContent>
                  ))}
                </Tabs>
              </div>
              <GradientColorPicker
                value={newMood.gradient}
                onChange={(value) => setNewMood({ ...newMood, gradient: value })}
                type="gradient"
                label="Gradient sfondo"
              />
              <Button onClick={handleCreateMood} disabled={isSaving} className="w-full">
                {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                Crea Mood
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {moods.map((mood) => (
          <div key={mood.id} className="p-4 rounded-2xl bg-secondary/30 border border-border/30">
            <div className="flex items-center justify-between mb-3">
              <span className="text-3xl">{mood.emoji}</span>
              <div className="flex items-center gap-2">
                <Switch
                  checked={mood.is_active}
                  onCheckedChange={() => handleToggleActive(mood)}
                />
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="icon" onClick={() => setEditingMood(mood)}>
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Modifica Mood</DialogTitle>
                    </DialogHeader>
                    {editingMood && (
                      <div className="space-y-4 pt-4">
                        <div className="space-y-2">
                          <label className="text-sm text-muted-foreground">Emoji</label>
                          <div className="flex flex-wrap gap-2">
                            {emojiOptions.map((emoji) => (
                              <button
                                key={emoji}
                                onClick={() => setEditingMood({ ...editingMood, emoji })}
                                className={`w-10 h-10 rounded-lg text-xl flex items-center justify-center transition-all ${
                                  editingMood.emoji === emoji ? 'bg-accent ring-2 ring-foreground' : 'bg-secondary/50 hover:bg-secondary'
                                }`}
                              >
                                {emoji}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm text-muted-foreground">Label (5 lingue)</label>
                          <Tabs defaultValue="it">
                            <TabsList className="h-8 w-full grid grid-cols-5">
                              {LANGUAGES.map((lang) => (
                                <TabsTrigger key={lang.code} value={lang.code} className="text-xs gap-1 px-1">
                                  <span>{lang.flag}</span>
                                  <span className="hidden sm:inline">{lang.code.toUpperCase()}</span>
                                </TabsTrigger>
                              ))}
                            </TabsList>
                            {LANGUAGES.map((lang) => (
                              <TabsContent key={lang.code} value={lang.code} className="mt-2">
                                <Input
                                  value={(editingMood.label as any)[lang.code] || ''}
                                  onChange={(e) => setEditingMood({
                                    ...editingMood,
                                    label: { ...editingMood.label, [lang.code]: e.target.value }
                                  })}
                                  placeholder={`Label in ${lang.code.toUpperCase()}`}
                                />
                              </TabsContent>
                            ))}
                          </Tabs>
                        </div>
                        <Button onClick={handleSaveEdit} disabled={isSaving} className="w-full">
                          {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                          Salva
                        </Button>
                      </div>
                    )}
                  </DialogContent>
                </Dialog>
                <Button variant="ghost" size="icon" onClick={() => handleDelete(mood.id)}>
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              </div>
            </div>
            <h3 className="font-medium">
              {mood.label[currentLanguage as 'it' | 'en'] || mood.label.it}
            </h3>
            <p className="text-xs text-muted-foreground mt-1">{mood.mood_key}</p>
          </div>
        ))}
      </div>
    </motion.div>
  );
}