import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Trophy, Target, Plus, Trash2, Save, Flame, Gift, Settings
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface Badge {
  id: string;
  badge_key: string;
  name_it: string;
  name_en: string | null;
  description_it: string | null;
  description_en: string | null;
  icon: string;
  color: string;
  category: string;
  requirement_type: string;
  requirement_value: number;
  points_reward: number;
  is_active: boolean;
  is_secret: boolean;
  display_order: number;
}

interface Challenge {
  id: string;
  challenge_key: string;
  name_it: string;
  name_en: string | null;
  description_it: string | null;
  description_en: string | null;
  icon: string;
  color: string;
  challenge_type: string;
  requirement_type: string;
  requirement_value: number;
  points_reward: number;
  is_active: boolean;
  display_order: number;
}

const ICONS = ['🏆', '⭐', '🎉', '👑', '💎', '🔥', '🦋', '😋', '🎯', '📅', '👥', '💪', '🚀', '🌟', '✨', '🥇', '🥈', '🥉'];
const COLORS = [
  { value: 'from-yellow-500 to-amber-500', label: 'Gold' },
  { value: 'from-green-500 to-emerald-500', label: 'Green' },
  { value: 'from-blue-500 to-cyan-500', label: 'Blue' },
  { value: 'from-purple-500 to-pink-500', label: 'Purple' },
  { value: 'from-red-500 to-orange-500', label: 'Red' },
  { value: 'from-gray-400 to-gray-300', label: 'Silver' },
  { value: 'from-amber-700 to-amber-500', label: 'Bronze' },
];

const REQUIREMENT_TYPES = [
  { value: 'reservations_count', label: 'Numero prenotazioni' },
  { value: 'orders_count', label: 'Numero ordini asporto' },
  { value: 'total_orders', label: 'Totale ordini (prenotazioni + asporto)' },
  { value: 'total_spent', label: 'Totale speso (€)' },
  { value: 'consecutive_weeks', label: 'Settimane consecutive' },
  { value: 'favorites_count', label: 'Preferiti salvati' },
  { value: 'profile_complete', label: 'Profilo completato' },
];

const CHALLENGE_TYPES = [
  { value: 'one_time', label: 'Una tantum' },
  { value: 'daily', label: 'Giornaliera' },
  { value: 'weekly', label: 'Settimanale' },
  { value: 'monthly', label: 'Mensile' },
];

export function GamificationAdmin() {
  const [badges, setBadges] = useState<Badge[]>([]);
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({ earnedBadges: 0, activeChallenges: 0, totalStreaks: 0 });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const { data: badgesData } = await supabase
        .from('loyalty_badges')
        .select('*')
        .order('display_order', { ascending: true });
      if (badgesData) setBadges(badgesData);

      const { data: challengesData } = await supabase
        .from('loyalty_challenges')
        .select('*')
        .order('display_order', { ascending: true });
      if (challengesData) setChallenges(challengesData);

      // Stats
      const { count: earnedCount } = await supabase
        .from('user_badges')
        .select('*', { count: 'exact', head: true });

      const { count: streaksCount } = await supabase
        .from('loyalty_streaks')
        .select('*', { count: 'exact', head: true });

      setStats({
        earnedBadges: earnedCount || 0,
        activeChallenges: challengesData?.filter(c => c.is_active).length || 0,
        totalStreaks: streaksCount || 0,
      });
    } catch (error) {
      console.error('Error fetching gamification data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addBadge = async () => {
    const newKey = `badge_${Date.now()}`;
    const { data, error } = await supabase
      .from('loyalty_badges')
      .insert({
        badge_key: newKey,
        name_it: 'Nuovo Badge',
        name_en: 'New Badge',
        icon: '🏆',
        color: 'from-yellow-500 to-amber-500',
        category: 'achievement',
        requirement_type: 'reservations_count',
        requirement_value: 1,
        points_reward: 10,
        display_order: badges.length,
      })
      .select()
      .single();

    if (error) {
      toast.error('Errore nella creazione del badge');
      return;
    }
    if (data) {
      setBadges([...badges, data]);
      toast.success('Badge creato!');
    }
  };

  const updateBadge = async (badge: Badge) => {
    const { error } = await supabase
      .from('loyalty_badges')
      .update({
        name_it: badge.name_it,
        name_en: badge.name_en,
        description_it: badge.description_it,
        description_en: badge.description_en,
        icon: badge.icon,
        color: badge.color,
        category: badge.category,
        requirement_type: badge.requirement_type,
        requirement_value: badge.requirement_value,
        points_reward: badge.points_reward,
        is_active: badge.is_active,
        is_secret: badge.is_secret,
      })
      .eq('id', badge.id);

    if (error) {
      toast.error('Errore nell\'aggiornamento');
    } else {
      toast.success('Badge aggiornato!');
    }
  };

  const deleteBadge = async (id: string) => {
    const { error } = await supabase
      .from('loyalty_badges')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error('Errore nell\'eliminazione');
    } else {
      setBadges(badges.filter(b => b.id !== id));
      toast.success('Badge eliminato!');
    }
  };

  const addChallenge = async () => {
    const newKey = `challenge_${Date.now()}`;
    const { data, error } = await supabase
      .from('loyalty_challenges')
      .insert({
        challenge_key: newKey,
        name_it: 'Nuova Sfida',
        name_en: 'New Challenge',
        icon: '🎯',
        color: 'from-purple-500 to-pink-500',
        challenge_type: 'weekly',
        requirement_type: 'reservations_count',
        requirement_value: 1,
        points_reward: 20,
        display_order: challenges.length,
      })
      .select()
      .single();

    if (error) {
      toast.error('Errore nella creazione della sfida');
      return;
    }
    if (data) {
      setChallenges([...challenges, data]);
      toast.success('Sfida creata!');
    }
  };

  const updateChallenge = async (challenge: Challenge) => {
    const { error } = await supabase
      .from('loyalty_challenges')
      .update({
        name_it: challenge.name_it,
        name_en: challenge.name_en,
        description_it: challenge.description_it,
        description_en: challenge.description_en,
        icon: challenge.icon,
        color: challenge.color,
        challenge_type: challenge.challenge_type,
        requirement_type: challenge.requirement_type,
        requirement_value: challenge.requirement_value,
        points_reward: challenge.points_reward,
        is_active: challenge.is_active,
      })
      .eq('id', challenge.id);

    if (error) {
      toast.error('Errore nell\'aggiornamento');
    } else {
      toast.success('Sfida aggiornata!');
    }
  };

  const deleteChallenge = async (id: string) => {
    const { error } = await supabase
      .from('loyalty_challenges')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error('Errore nell\'eliminazione');
    } else {
      setChallenges(challenges.filter(c => c.id !== id));
      toast.success('Sfida eliminata!');
    }
  };

  if (isLoading) {
    return <div className="text-center py-8">Caricamento...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-yellow-500/20">
                <Trophy className="w-5 h-5 text-yellow-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{badges.filter(b => b.is_active).length}</p>
                <p className="text-xs text-muted-foreground">Badge attivi</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/20">
                <Target className="w-5 h-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.activeChallenges}</p>
                <p className="text-xs text-muted-foreground">Sfide attive</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/20">
                <Flame className="w-5 h-5 text-orange-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalStreaks}</p>
                <p className="text-xs text-muted-foreground">Utenti con serie</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="badges">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="badges" className="gap-2">
            <Trophy className="w-4 h-4" />
            Badge
          </TabsTrigger>
          <TabsTrigger value="challenges" className="gap-2">
            <Target className="w-4 h-4" />
            Sfide
          </TabsTrigger>
        </TabsList>

        {/* Badges Tab */}
        <TabsContent value="badges" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              Gestisci i badge che gli utenti possono sbloccare
            </p>
            <Button onClick={addBadge} size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Aggiungi Badge
            </Button>
          </div>

          {badges.map((badge) => (
            <Card key={badge.id}>
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  {/* Badge Preview */}
                  <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${badge.color} flex items-center justify-center text-3xl flex-shrink-0 shadow-md`}>
                    {badge.icon}
                  </div>

                  <div className="flex-1 grid gap-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs">Nome (IT)</Label>
                        <Input
                          value={badge.name_it}
                          onChange={(e) => setBadges(badges.map(b => b.id === badge.id ? { ...b, name_it: e.target.value } : b))}
                          onBlur={() => updateBadge(badge)}
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Nome (EN)</Label>
                        <Input
                          value={badge.name_en || ''}
                          onChange={(e) => setBadges(badges.map(b => b.id === badge.id ? { ...b, name_en: e.target.value } : b))}
                          onBlur={() => updateBadge(badge)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-3">
                      <div>
                        <Label className="text-xs">Icona</Label>
                        <Select
                          value={badge.icon}
                          onValueChange={(value) => {
                            const updated = { ...badge, icon: value };
                            setBadges(badges.map(b => b.id === badge.id ? updated : b));
                            updateBadge(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {ICONS.map(icon => (
                              <SelectItem key={icon} value={icon}>{icon}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs">Colore</Label>
                        <Select
                          value={badge.color}
                          onValueChange={(value) => {
                            const updated = { ...badge, color: value };
                            setBadges(badges.map(b => b.id === badge.id ? updated : b));
                            updateBadge(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {COLORS.map(c => (
                              <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs">Requisito</Label>
                        <Select
                          value={badge.requirement_type}
                          onValueChange={(value) => {
                            const updated = { ...badge, requirement_type: value };
                            setBadges(badges.map(b => b.id === badge.id ? updated : b));
                            updateBadge(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {REQUIREMENT_TYPES.map(t => (
                              <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs">Valore</Label>
                        <Input
                          type="number"
                          value={badge.requirement_value}
                          onChange={(e) => setBadges(badges.map(b => b.id === badge.id ? { ...b, requirement_value: parseInt(e.target.value) || 0 } : b))}
                          onBlur={() => updateBadge(badge)}
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={badge.is_active}
                            onCheckedChange={(checked) => {
                              const updated = { ...badge, is_active: checked };
                              setBadges(badges.map(b => b.id === badge.id ? updated : b));
                              updateBadge(updated);
                            }}
                          />
                          <Label className="text-xs">Attivo</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={badge.is_secret}
                            onCheckedChange={(checked) => {
                              const updated = { ...badge, is_secret: checked };
                              setBadges(badges.map(b => b.id === badge.id ? updated : b));
                              updateBadge(updated);
                            }}
                          />
                          <Label className="text-xs">Segreto</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Gift className="w-4 h-4 text-accent" />
                          <Input
                            type="number"
                            className="w-20 h-8"
                            value={badge.points_reward}
                            onChange={(e) => setBadges(badges.map(b => b.id === badge.id ? { ...b, points_reward: parseInt(e.target.value) || 0 } : b))}
                            onBlur={() => updateBadge(badge)}
                          />
                          <span className="text-xs text-muted-foreground">punti</span>
                        </div>
                      </div>
                      <Button variant="destructive" size="sm" onClick={() => deleteBadge(badge.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Challenges Tab */}
        <TabsContent value="challenges" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              Gestisci le sfide periodiche per gli utenti
            </p>
            <Button onClick={addChallenge} size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Aggiungi Sfida
            </Button>
          </div>

          {challenges.map((challenge) => (
            <Card key={challenge.id}>
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${challenge.color} flex items-center justify-center text-3xl flex-shrink-0 shadow-md`}>
                    {challenge.icon}
                  </div>

                  <div className="flex-1 grid gap-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs">Nome (IT)</Label>
                        <Input
                          value={challenge.name_it}
                          onChange={(e) => setChallenges(challenges.map(c => c.id === challenge.id ? { ...c, name_it: e.target.value } : c))}
                          onBlur={() => updateChallenge(challenge)}
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Nome (EN)</Label>
                        <Input
                          value={challenge.name_en || ''}
                          onChange={(e) => setChallenges(challenges.map(c => c.id === challenge.id ? { ...c, name_en: e.target.value } : c))}
                          onBlur={() => updateChallenge(challenge)}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-3">
                      <div>
                        <Label className="text-xs">Tipo</Label>
                        <Select
                          value={challenge.challenge_type}
                          onValueChange={(value) => {
                            const updated = { ...challenge, challenge_type: value };
                            setChallenges(challenges.map(c => c.id === challenge.id ? updated : c));
                            updateChallenge(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {CHALLENGE_TYPES.map(t => (
                              <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs">Requisito</Label>
                        <Select
                          value={challenge.requirement_type}
                          onValueChange={(value) => {
                            const updated = { ...challenge, requirement_type: value };
                            setChallenges(challenges.map(c => c.id === challenge.id ? updated : c));
                            updateChallenge(updated);
                          }}
                        >
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {REQUIREMENT_TYPES.map(t => (
                              <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-xs">Valore</Label>
                        <Input
                          type="number"
                          value={challenge.requirement_value}
                          onChange={(e) => setChallenges(challenges.map(c => c.id === challenge.id ? { ...c, requirement_value: parseInt(e.target.value) || 0 } : c))}
                          onBlur={() => updateChallenge(challenge)}
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Ricompensa</Label>
                        <Input
                          type="number"
                          value={challenge.points_reward}
                          onChange={(e) => setChallenges(challenges.map(c => c.id === challenge.id ? { ...c, points_reward: parseInt(e.target.value) || 0 } : c))}
                          onBlur={() => updateChallenge(challenge)}
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={challenge.is_active}
                          onCheckedChange={(checked) => {
                            const updated = { ...challenge, is_active: checked };
                            setChallenges(challenges.map(c => c.id === challenge.id ? updated : c));
                            updateChallenge(updated);
                          }}
                        />
                        <Label className="text-xs">Attiva</Label>
                      </div>
                      <Button variant="destructive" size="sm" onClick={() => deleteChallenge(challenge.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
