import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Star, Instagram, Info, Save, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface SocialIntegrationsEditorProps {
  configId: string;
  initialGooglePlaceId?: string;
  initialInstagramUsername?: string;
  onSave?: () => void;
}

export function SocialIntegrationsEditor({ 
  configId, 
  initialGooglePlaceId,
  initialInstagramUsername,
  onSave 
}: SocialIntegrationsEditorProps) {
  const { toast } = useToast();
  const [googlePlaceId, setGooglePlaceId] = useState(initialGooglePlaceId || '');
  const [instagramUsername, setInstagramUsername] = useState(initialInstagramUsername || '');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (initialGooglePlaceId) setGooglePlaceId(initialGooglePlaceId);
    if (initialInstagramUsername) setInstagramUsername(initialInstagramUsername);
  }, [initialGooglePlaceId, initialInstagramUsername]);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('restaurant_config')
        .update({ 
          google_place_id: googlePlaceId || null,
          instagram_username: instagramUsername || null
        })
        .eq('id', configId);

      if (error) throw error;
      
      toast({ title: 'Integrazioni salvate!' });
      onSave?.();
    } catch (error: any) {
      toast({ title: 'Errore', description: error.message, variant: 'destructive' });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Google Reviews Section */}
      <div className="p-6 rounded-xl bg-secondary/30 border border-border/30 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-yellow-500/10 flex items-center justify-center">
            <Star className="w-6 h-6 text-yellow-500" />
          </div>
          <div>
            <h3 className="font-semibold">Google Reviews</h3>
            <p className="text-sm text-muted-foreground">Mostra le recensioni Google nel menu</p>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start gap-3 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20"
        >
          <Info className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
          <div className="text-xs text-muted-foreground">
            <p className="mb-1">Per trovare il tuo Google Place ID:</p>
            <ol className="list-decimal list-inside space-y-1">
              <li>Vai su <a href="https://developers.google.com/maps/documentation/places/web-service/place-id" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">Google Place ID Finder</a></li>
              <li>Cerca il nome del tuo locale</li>
              <li>Copia il Place ID (es: ChIJ...)</li>
            </ol>
          </div>
        </motion.div>

        <div className="space-y-2">
          <Label className="text-sm">Google Place ID</Label>
          <Input
            value={googlePlaceId}
            onChange={(e) => setGooglePlaceId(e.target.value)}
            placeholder="ChIJN1t_tDeuEmsRUsoyG83frY4"
          />
        </div>

        {googlePlaceId && (
          <Button variant="outline" size="sm" asChild>
            <a 
              href={`https://search.google.com/local/reviews?placeid=${googlePlaceId}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Verifica su Google Maps
            </a>
          </Button>
        )}
      </div>

      {/* Instagram Feed Section */}
      <div className="p-6 rounded-xl bg-secondary/30 border border-border/30 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 via-pink-500/20 to-orange-500/20 flex items-center justify-center">
            <Instagram className="w-6 h-6 text-pink-500" />
          </div>
          <div>
            <h3 className="font-semibold">Instagram Feed</h3>
            <p className="text-sm text-muted-foreground">Mostra i tuoi post Instagram nel menu</p>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-start gap-3 p-3 rounded-lg bg-purple-500/10 border border-purple-500/20"
        >
          <Info className="w-4 h-4 text-purple-500 mt-0.5 shrink-0" />
          <div className="text-xs text-muted-foreground">
            <p>
              Inserisci il tuo username Instagram (senza @). I post verranno caricati 
              automaticamente e mostrati nella sezione dedicata del menu.
            </p>
          </div>
        </motion.div>

        <div className="space-y-2">
          <Label className="text-sm">Username Instagram</Label>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground">@</span>
            <Input
              value={instagramUsername}
              onChange={(e) => setInstagramUsername(e.target.value.replace('@', ''))}
              placeholder="iltuolocale"
            />
          </div>
        </div>

        {instagramUsername && (
          <Button variant="outline" size="sm" asChild>
            <a 
              href={`https://instagram.com/${instagramUsername}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Vedi profilo Instagram
            </a>
          </Button>
        )}
      </div>

      {/* Save Button */}
      <Button onClick={handleSave} disabled={isSaving} className="w-full">
        <Save className="w-4 h-4 mr-2" />
        {isSaving ? 'Salvataggio...' : 'Salva Integrazioni'}
      </Button>
    </div>
  );
}
