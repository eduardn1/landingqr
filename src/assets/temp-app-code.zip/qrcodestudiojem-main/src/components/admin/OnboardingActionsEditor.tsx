import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, ChevronUp, ChevronDown, Save, Eye, EyeOff, Pencil, X } from 'lucide-react';
import * as Icons from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { 
  useOnboardingActions, 
  useUpdateOnboardingAction, 
  useCreateOnboardingAction,
  useDeleteOnboardingAction 
} from '@/hooks/useOnboardingActions';
import { MultiLangInput } from './MultiLangInput';

const ICON_OPTIONS = [
  'UtensilsCrossed', 'ShoppingBag', 'Calendar', 'PartyPopper', 'Home',
  'Menu', 'Coffee', 'Wine', 'Pizza', 'Salad', 'Soup', 'Cake',
  'Phone', 'MapPin', 'Clock', 'Gift', 'Star', 'Heart', 'Music',
  'Sparkles', 'Zap', 'Flame', 'Leaf', 'Sun', 'Moon', 'Utensils',
  'ChefHat', 'Truck', 'Store', 'Users', 'MessageCircle', 'Info',
  'HelpCircle', 'BookOpen', 'Camera', 'Image', 'Video', 'Share2'
];

const GRADIENT_OPTIONS = [
  { value: 'from-orange-500 to-red-500', label: 'Arancio → Rosso' },
  { value: 'from-green-500 to-emerald-500', label: 'Verde → Smeraldo' },
  { value: 'from-blue-500 to-indigo-500', label: 'Blu → Indigo' },
  { value: 'from-purple-500 to-pink-500', label: 'Viola → Rosa' },
  { value: 'from-gray-500 to-gray-700', label: 'Grigio' },
  { value: 'from-amber-500 to-orange-500', label: 'Ambra → Arancio' },
  { value: 'from-teal-500 to-cyan-500', label: 'Teal → Cyan' },
  { value: 'from-rose-500 to-red-500', label: 'Rosa → Rosso' },
  { value: 'from-accent to-accent/80', label: 'Accent (default)' },
  { value: 'from-yellow-400 to-orange-500', label: 'Giallo → Arancio' },
  { value: 'from-indigo-500 to-purple-600', label: 'Indigo → Viola' },
  { value: 'from-emerald-400 to-teal-500', label: 'Smeraldo → Teal' },
];

const BORDER_STYLE_OPTIONS = [
  { value: 'none', label: 'Nessun bordo' },
  { value: 'border border-foreground/10', label: 'Bordo sottile (10%)' },
  { value: 'border border-foreground/20', label: 'Bordo leggero (20%)' },
  { value: 'border border-foreground/30', label: 'Bordo medio (30%)' },
  { value: 'border-2 border-foreground/20', label: 'Bordo spesso (2px)' },
  { value: 'border border-accent/30', label: 'Bordo accent' },
  { value: 'border border-accent/50', label: 'Bordo accent forte' },
];

const ACTION_TYPES = [
  { value: 'navigate', label: 'Naviga a pagina' },
  { value: 'action', label: 'Azione speciale' },
];

interface ActionFormData {
  action_key: string;
  icon: string;
  label: { it: string; en: string };
  subtitle: { it: string; en: string };
  action_type: string;
  action_value: string;
  gradient: string;
}

export function OnboardingActionsEditor() {
  const { data: actions = [], isLoading } = useOnboardingActions();
  const updateAction = useUpdateOnboardingAction();
  const createAction = useCreateOnboardingAction();
  const deleteAction = useDeleteOnboardingAction();
  
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingData, setEditingData] = useState<ActionFormData | null>(null);
  const [newAction, setNewAction] = useState<ActionFormData | null>(null);

  const handleMoveUp = async (index: number) => {
    if (index === 0) return;
    const current = actions[index];
    const prev = actions[index - 1];
    
    await updateAction.mutateAsync({ id: current.id, display_order: prev.display_order });
    await updateAction.mutateAsync({ id: prev.id, display_order: current.display_order });
  };

  const handleMoveDown = async (index: number) => {
    if (index === actions.length - 1) return;
    const current = actions[index];
    const next = actions[index + 1];
    
    await updateAction.mutateAsync({ id: current.id, display_order: next.display_order });
    await updateAction.mutateAsync({ id: next.id, display_order: current.display_order });
  };

  const handleToggleActive = async (id: string, isActive: boolean) => {
    await updateAction.mutateAsync({ id, is_active: !isActive });
    toast.success(isActive ? 'Disattivato' : 'Attivato');
  };

  const handleSaveNew = async () => {
    if (!newAction) return;
    
    try {
      await createAction.mutateAsync({
        ...newAction,
        display_order: actions.length + 1,
        is_active: true,
      });
      setNewAction(null);
      toast.success('Azione creata');
    } catch (error) {
      toast.error('Errore nella creazione');
    }
  };

  const handleStartEdit = (action: any) => {
    const label = action.label as { it: string; en: string };
    const subtitle = action.subtitle as { it: string; en: string };
    
    setEditingId(action.id);
    setEditingData({
      action_key: action.action_key,
      icon: action.icon,
      label: { it: label.it || '', en: label.en || '' },
      subtitle: { it: subtitle?.it || '', en: subtitle?.en || '' },
      action_type: action.action_type,
      action_value: action.action_value,
      gradient: action.gradient || 'from-accent to-accent/80',
    });
  };

  const handleSaveEdit = async () => {
    if (!editingId || !editingData) return;
    
    try {
      await updateAction.mutateAsync({
        id: editingId,
        action_key: editingData.action_key,
        icon: editingData.icon,
        label: editingData.label,
        subtitle: editingData.subtitle,
        action_type: editingData.action_type,
        action_value: editingData.action_value,
        gradient: editingData.gradient,
      });
      setEditingId(null);
      setEditingData(null);
      toast.success('Modifiche salvate');
    } catch (error) {
      toast.error('Errore nel salvataggio');
    }
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditingData(null);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Eliminare questa azione?')) return;
    
    try {
      await deleteAction.mutateAsync(id);
      toast.success('Eliminato');
    } catch (error) {
      toast.error('Errore nell\'eliminazione');
    }
  };

  const getIconComponent = (iconName: string) => {
    return (Icons as any)[iconName] || Icons.Circle;
  };

  const renderActionForm = (
    data: ActionFormData, 
    onChange: (data: ActionFormData) => void,
    onSave: () => void,
    onCancel: () => void,
    saveLabel: string = 'Salva'
  ) => (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      className="bg-accent/10 border border-accent/30 rounded-xl p-4 space-y-4"
    >
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Chiave unica</Label>
          <Input
            value={data.action_key}
            onChange={(e) => onChange({ ...data, action_key: e.target.value })}
            placeholder="es: view_menu"
          />
        </div>
        <div>
          <Label>Icona</Label>
          <Select
            value={data.icon}
            onValueChange={(v) => onChange({ ...data, icon: v })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="max-h-60">
              {ICON_OPTIONS.map(icon => {
                const Icon = getIconComponent(icon);
                return (
                  <SelectItem key={icon} value={icon}>
                    <div className="flex items-center gap-2">
                      <Icon className="w-4 h-4" />
                      {icon}
                    </div>
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>
      </div>

      <MultiLangInput
        label="Etichetta"
        value={data.label}
        onChange={(v) => onChange({ ...data, label: { it: v.it || '', en: v.en || '' } })}
      />

      <MultiLangInput
        label="Sottotitolo"
        value={data.subtitle}
        onChange={(v) => onChange({ ...data, subtitle: { it: v.it || '', en: v.en || '' } })}
      />

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label>Tipo azione</Label>
          <Select
            value={data.action_type}
            onValueChange={(v) => onChange({ ...data, action_type: v })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ACTION_TYPES.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  {type.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Destinazione</Label>
          <Input
            value={data.action_value}
            onChange={(e) => onChange({ ...data, action_value: e.target.value })}
            placeholder="es: /takeaway o reservation"
          />
        </div>
      </div>

      <div>
        <Label>Gradiente sfondo</Label>
        <Select
          value={data.gradient}
          onValueChange={(v) => onChange({ ...data, gradient: v })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {GRADIENT_OPTIONS.map(opt => (
              <SelectItem key={opt.value} value={opt.value}>
                <div className="flex items-center gap-2">
                  <div className={`w-6 h-4 rounded bg-gradient-to-r ${opt.value}`} />
                  {opt.label}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Preview */}
      <div className="pt-2 border-t border-border/30">
        <Label className="text-xs text-muted-foreground mb-2 block">Anteprima</Label>
        <div className="flex items-center gap-4 p-3 rounded-xl bg-background/50 border border-foreground/10">
          <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${data.gradient} flex items-center justify-center flex-shrink-0`}>
            {(() => {
              const Icon = getIconComponent(data.icon);
              return <Icon className="w-6 h-6 text-white" />;
            })()}
          </div>
          <div className="flex-1">
            <p className="font-semibold">{data.label.it || 'Etichetta'}</p>
            <p className="text-xs text-muted-foreground">{data.subtitle.it || 'Sottotitolo'}</p>
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={onCancel}>
          Annulla
        </Button>
        <Button onClick={onSave} disabled={!data.action_key}>
          <Save className="w-4 h-4 mr-2" />
          {saveLabel}
        </Button>
      </div>
    </motion.div>
  );

  if (isLoading) {
    return <div className="animate-pulse h-48 bg-muted rounded-xl" />;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold">Azioni Onboarding</h3>
          <p className="text-sm text-muted-foreground">
            Configura le opzioni "Cosa vorresti fare?" - clicca su una card per modificarla
          </p>
        </div>
        <Button
          size="sm"
          onClick={() => setNewAction({
            action_key: '',
            icon: 'Star',
            label: { it: '', en: '' },
            subtitle: { it: '', en: '' },
            action_type: 'navigate',
            action_value: '/',
            gradient: 'from-accent to-accent/80',
          })}
          disabled={!!newAction || !!editingId}
        >
          <Plus className="w-4 h-4 mr-2" />
          Aggiungi
        </Button>
      </div>

      {/* New Action Form */}
      <AnimatePresence>
        {newAction && renderActionForm(
          newAction,
          setNewAction,
          handleSaveNew,
          () => setNewAction(null),
          'Crea'
        )}
      </AnimatePresence>

      {/* Actions List */}
      <div className="space-y-2">
        {actions.map((action, index) => {
          const Icon = getIconComponent(action.icon);
          const label = action.label as { it: string; en: string };
          const subtitle = action.subtitle as { it: string; en: string };
          const isEditing = editingId === action.id;
          
          return (
            <div key={action.id}>
              {isEditing && editingData ? (
                <AnimatePresence>
                  {renderActionForm(
                    editingData,
                    setEditingData,
                    handleSaveEdit,
                    handleCancelEdit,
                    'Salva modifiche'
                  )}
                </AnimatePresence>
              ) : (
                <motion.div
                  layout
                  className={`bg-card border rounded-xl p-4 ${action.is_active ? 'border-border' : 'border-border/50 opacity-60'} ${!editingId && !newAction ? 'cursor-pointer hover:border-accent/50 transition-colors' : ''}`}
                  onClick={() => !editingId && !newAction && handleStartEdit(action)}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex flex-col gap-1">
                      <button
                        onClick={(e) => { e.stopPropagation(); handleMoveUp(index); }}
                        disabled={index === 0}
                        className="p-1 hover:bg-muted rounded disabled:opacity-30"
                      >
                        <ChevronUp className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleMoveDown(index); }}
                        disabled={index === actions.length - 1}
                        className="p-1 hover:bg-muted rounded disabled:opacity-30"
                      >
                        <ChevronDown className="w-3 h-3" />
                      </button>
                    </div>

                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${action.gradient || 'from-accent to-accent/80'} flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{label.it || label.en}</p>
                      <p className="text-xs text-muted-foreground truncate">
                        {subtitle?.it || subtitle?.en || `${action.action_type}: ${action.action_value}`}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => { e.stopPropagation(); handleStartEdit(action); }}
                        className="p-2 rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground"
                        title="Modifica"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleToggleActive(action.id, action.is_active); }}
                        className={`p-2 rounded-lg ${action.is_active ? 'text-green-500 bg-green-500/10' : 'text-muted-foreground bg-muted'}`}
                        title={action.is_active ? 'Disattiva' : 'Attiva'}
                      >
                        {action.is_active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDelete(action.id); }}
                        className="p-2 rounded-lg text-red-500 hover:bg-red-500/10"
                        title="Elimina"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          );
        })}
      </div>

      {actions.length === 0 && !newAction && (
        <div className="text-center py-8 text-muted-foreground">
          Nessuna azione configurata. Clicca "Aggiungi" per crearne una.
        </div>
      )}
    </div>
  );
}
