import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAllActionButtons, type ActionButton } from '@/hooks/useActionButtons';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Smartphone, Monitor, ArrowUp, ArrowDown, Palette, Type, Square, Circle } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { GradientColorPicker } from './GradientColorPicker';

// Available icons for selection
const availableIcons = [
  'UtensilsCrossed', 'CalendarDays', 'Sparkles', 'ShoppingBag', 'Info',
  'Phone', 'MapPin', 'Clock', 'Gift', 'Star', 'Heart', 'MessageCircle',
  'Wine', 'Coffee', 'Beer', 'Pizza', 'Utensils', 'ChefHat', 'Music',
  'PartyPopper', 'Ticket', 'Store', 'Truck', 'Users', 'Calendar'
];

// Preset colors
const presetColors = [
  { label: 'Accent', value: '' },
  { label: 'Bianco', value: '0 0% 100%' },
  { label: 'Nero', value: '0 0% 0%' },
  { label: 'Grigio chiaro', value: '0 0% 90%' },
  { label: 'Grigio scuro', value: '0 0% 20%' },
  { label: 'Arancione', value: '24 95% 53%' },
  { label: 'Rosso', value: '0 84% 60%' },
  { label: 'Blu', value: '217 91% 60%' },
  { label: 'Verde', value: '142 71% 45%' },
  { label: 'Viola', value: '262 83% 58%' },
  { label: 'Rosa', value: '330 81% 60%' },
  { label: 'Teal', value: '174 72% 56%' },
  { label: 'Oro', value: '45 93% 47%' },
];

// Preset gradients
const presetGradients = [
  { label: 'Accent Soft', value: 'from-accent/20 to-accent/5' },
  { label: 'Accent Strong', value: 'from-accent/40 to-accent/10' },
  { label: 'Orange', value: 'from-orange-500/30 to-orange-500/5' },
  { label: 'Blue', value: 'from-blue-500/30 to-blue-500/5' },
  { label: 'Green', value: 'from-green-500/30 to-green-500/5' },
  { label: 'Purple', value: 'from-purple-500/30 to-purple-500/5' },
  { label: 'Pink', value: 'from-pink-500/30 to-pink-500/5' },
  { label: 'Transparent', value: 'from-transparent to-transparent' },
];

// Dynamic icon component
const DynamicIcon = ({ name, className, style }: { name: string; className?: string; style?: React.CSSProperties }) => {
  const IconComponent = (LucideIcons as any)[name];
  if (!IconComponent) return <LucideIcons.HelpCircle className={className} style={style} />;
  return <IconComponent className={className} style={style} />;
};

interface ButtonFormData {
  button_key: string;
  label_it: string;
  label_en: string;
  label_de: string;
  label_es: string;
  label_fr: string;
  subtitle_it: string;
  subtitle_en: string;
  subtitle_de: string;
  subtitle_es: string;
  subtitle_fr: string;
  icon: string;
  action_type: 'internal' | 'modal' | 'external';
  action_value: string;
  gradient: string;
  button_color: string;
  display_style: 'card' | 'button' | 'pill' | 'minimal';
  bg_color: string;
  bg_opacity: number;
  label_color: string;
  icon_color: string;
  border_color: string;
  is_active: boolean;
  is_visible_mobile: boolean;
  is_visible_desktop: boolean;
  size: 'small' | 'medium' | 'large';
  col_span: number;
}

const defaultFormData: ButtonFormData = {
  button_key: '',
  label_it: '',
  label_en: '',
  label_de: '',
  label_es: '',
  label_fr: '',
  subtitle_it: '',
  subtitle_en: '',
  subtitle_de: '',
  subtitle_es: '',
  subtitle_fr: '',
  icon: 'Star',
  action_type: 'modal',
  action_value: '',
  gradient: 'from-accent/20 to-accent/5',
  button_color: '',
  display_style: 'card',
  bg_color: '',
  bg_opacity: 1,
  label_color: '',
  icon_color: '',
  border_color: '',
  is_active: true,
  is_visible_mobile: true,
  is_visible_desktop: true,
  size: 'medium',
  col_span: 1,
};

export function ActionButtonsEditor() {
  const { buttons, isLoading, refetch } = useAllActionButtons();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingButton, setEditingButton] = useState<ActionButton | null>(null);
  const [formData, setFormData] = useState<ButtonFormData>(defaultFormData);
  const [isSaving, setIsSaving] = useState(false);

  const handleEdit = (button: ActionButton) => {
    setEditingButton(button);
    const label = button.label as Record<string, string>;
    const subtitle = button.subtitle as Record<string, string> | null;
    setFormData({
      button_key: button.button_key,
      label_it: label.it || '',
      label_en: label.en || '',
      label_de: label.de || '',
      label_es: label.es || '',
      label_fr: label.fr || '',
      subtitle_it: subtitle?.it || '',
      subtitle_en: subtitle?.en || '',
      subtitle_de: subtitle?.de || '',
      subtitle_es: subtitle?.es || '',
      subtitle_fr: subtitle?.fr || '',
      icon: button.icon,
      action_type: button.action_type,
      action_value: button.action_value || '',
      gradient: button.gradient || 'from-accent/20 to-accent/5',
      button_color: button.button_color || '',
      display_style: (button as any).display_style || 'card',
      bg_color: (button as any).bg_color || '',
      bg_opacity: (button as any).bg_opacity ?? 1,
      label_color: (button as any).label_color || '',
      icon_color: (button as any).icon_color || '',
      border_color: (button as any).border_color || '',
      is_active: button.is_active,
      is_visible_mobile: button.is_visible_mobile,
      is_visible_desktop: button.is_visible_desktop,
      size: button.size || 'medium',
      col_span: button.col_span || 1,
    });
    setIsDialogOpen(true);
  };

  const handleNew = () => {
    setEditingButton(null);
    setFormData(defaultFormData);
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.button_key || !formData.label_it) {
      toast.error('Compila i campi obbligatori');
      return;
    }

    setIsSaving(true);
    try {
      const payload = {
        button_key: formData.button_key,
        label: { 
          it: formData.label_it, 
          en: formData.label_en || formData.label_it,
          de: formData.label_de || formData.label_en || formData.label_it,
          es: formData.label_es || formData.label_en || formData.label_it,
          fr: formData.label_fr || formData.label_en || formData.label_it,
        },
        subtitle: { 
          it: formData.subtitle_it, 
          en: formData.subtitle_en || formData.subtitle_it,
          de: formData.subtitle_de || formData.subtitle_en || formData.subtitle_it,
          es: formData.subtitle_es || formData.subtitle_en || formData.subtitle_it,
          fr: formData.subtitle_fr || formData.subtitle_en || formData.subtitle_it,
        },
        icon: formData.icon,
        action_type: formData.action_type,
        action_value: formData.action_value || null,
        gradient: formData.gradient,
        button_color: formData.button_color || null,
        display_style: formData.display_style,
        bg_color: formData.bg_color || null,
        bg_opacity: formData.bg_opacity,
        label_color: formData.label_color || null,
        icon_color: formData.icon_color || null,
        border_color: formData.border_color || null,
        is_active: formData.is_active,
        is_visible_mobile: formData.is_visible_mobile,
        is_visible_desktop: formData.is_visible_desktop,
        size: formData.size,
        col_span: formData.col_span,
        display_order: editingButton?.display_order ?? buttons.length,
      };

      if (editingButton) {
        const { error } = await supabase
          .from('action_buttons')
          .update(payload)
          .eq('id', editingButton.id);
        if (error) throw error;
        toast.success('Pulsante aggiornato');
      } else {
        const { error } = await supabase
          .from('action_buttons')
          .insert(payload);
        if (error) throw error;
        toast.success('Pulsante creato');
      }

      refetch();
      setIsDialogOpen(false);
    } catch (error: any) {
      toast.error(error.message || 'Errore nel salvare');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Sei sicuro di voler eliminare questo pulsante?')) return;

    try {
      const { error } = await supabase
        .from('action_buttons')
        .delete()
        .eq('id', id);
      if (error) throw error;
      toast.success('Pulsante eliminato');
      refetch();
    } catch (error: any) {
      toast.error(error.message || 'Errore nell\'eliminare');
    }
  };

  const handleToggleActive = async (button: ActionButton) => {
    try {
      const { error } = await supabase
        .from('action_buttons')
        .update({ is_active: !button.is_active })
        .eq('id', button.id);
      if (error) throw error;
      refetch();
    } catch (error: any) {
      toast.error('Errore nell\'aggiornamento');
    }
  };

  const handleMoveUp = async (button: ActionButton, index: number) => {
    if (index === 0) return;
    const sortedButtons = [...buttons].sort((a, b) => a.display_order - b.display_order);
    const prevButton = sortedButtons[index - 1];
    
    try {
      await Promise.all([
        supabase.from('action_buttons').update({ display_order: prevButton.display_order }).eq('id', button.id),
        supabase.from('action_buttons').update({ display_order: button.display_order }).eq('id', prevButton.id)
      ]);
      refetch();
    } catch (error: any) {
      toast.error('Errore nel riordinare');
    }
  };

  const handleMoveDown = async (button: ActionButton, index: number) => {
    const sortedButtons = [...buttons].sort((a, b) => a.display_order - b.display_order);
    if (index === sortedButtons.length - 1) return;
    const nextButton = sortedButtons[index + 1];
    
    try {
      await Promise.all([
        supabase.from('action_buttons').update({ display_order: nextButton.display_order }).eq('id', button.id),
        supabase.from('action_buttons').update({ display_order: button.display_order }).eq('id', nextButton.id)
      ]);
      refetch();
    } catch (error: any) {
      toast.error('Errore nel riordinare');
    }
  };

  // Generate preview style
  const getPreviewStyle = () => {
    const style: React.CSSProperties = {};
    if (formData.bg_color) {
      style.backgroundColor = `hsla(${formData.bg_color}, ${formData.bg_opacity})`;
    }
    if (formData.border_color) {
      style.borderColor = `hsl(${formData.border_color})`;
    }
    return style;
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="h-20 rounded-xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3">
        <p className="text-sm text-muted-foreground">
          Gestisci i pulsanti azione della homepage
        </p>
        <Button onClick={handleNew} size="sm" className="gap-2 touch-manipulation w-full sm:w-auto">
          <Plus className="w-4 h-4" />
          Nuovo pulsante
        </Button>
      </div>

      <div className="space-y-3">
        {[...buttons].sort((a, b) => a.display_order - b.display_order).map((button, index, sortedArray) => (
          <Card key={button.id} className={!button.is_active ? 'opacity-50' : ''}>
            <CardContent className="p-3 sm:p-4">
              <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                {/* Mobile: First row - Icon, Label, Toggle */}
                <div className="flex items-center gap-3 w-full sm:w-auto">
                  {/* Reorder buttons - hidden on mobile */}
                  <div className="hidden sm:flex flex-col gap-0.5">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-5 w-5 touch-manipulation" 
                      onClick={() => handleMoveUp(button, index)}
                      disabled={index === 0}
                    >
                      <ArrowUp className="w-3 h-3" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-5 w-5 touch-manipulation" 
                      onClick={() => handleMoveDown(button, index)}
                      disabled={index === sortedArray.length - 1}
                    >
                      <ArrowDown className="w-3 h-3" />
                    </Button>
                  </div>
                  
                  <div 
                    className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{
                      backgroundColor: (button as any).bg_color 
                        ? `hsla(${(button as any).bg_color}, ${(button as any).bg_opacity ?? 1})`
                        : button.button_color 
                          ? `hsl(${button.button_color})` 
                          : undefined,
                    }}
                  >
                    <DynamicIcon 
                      name={button.icon} 
                      className="w-5 h-5"
                      style={{
                        color: (button as any).icon_color 
                          ? `hsl(${(button as any).icon_color})` 
                          : button.button_color 
                            ? 'white'
                            : undefined
                      }}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{button.label.it}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {(button as any).display_style || 'card'} · {button.action_type}
                    </p>
                  </div>

                  {/* Toggle & Edit on mobile - right aligned */}
                  <div className="flex items-center gap-2 sm:hidden">
                    <Switch
                      checked={button.is_active}
                      onCheckedChange={() => handleToggleActive(button)}
                    />
                    <Button variant="ghost" size="icon" className="h-8 w-8 touch-manipulation" onClick={() => handleEdit(button)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Desktop: Additional info and controls */}
                <div className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="px-1.5 py-0.5 bg-accent/10 rounded">
                    {button.size === 'small' ? 'S' : button.size === 'large' ? 'L' : 'M'}
                  </span>
                  <span className="px-1.5 py-0.5 bg-accent/10 rounded">
                    {button.col_span}col
                  </span>
                </div>

                <div className="hidden sm:flex items-center gap-2">
                  {button.is_visible_mobile && <Smartphone className="w-4 h-4 text-muted-foreground" />}
                  {button.is_visible_desktop && <Monitor className="w-4 h-4 text-muted-foreground" />}
                </div>

                <div className="hidden sm:block">
                  <Switch
                    checked={button.is_active}
                    onCheckedChange={() => handleToggleActive(button)}
                  />
                </div>

                <Button variant="ghost" size="icon" onClick={() => handleEdit(button)} title="Modifica" className="hidden sm:inline-flex">
                  <Pencil className="w-4 h-4" />
                </Button>

                <Button variant="ghost" size="icon" onClick={() => handleDelete(button.id)} className="hidden sm:inline-flex">
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>

                {/* Mobile: Second row - Reorder, visibility, delete */}
                <div className="flex items-center justify-between gap-2 pt-2 border-t border-border/50 sm:hidden">
                  <div className="flex items-center gap-1">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="h-8 px-2 touch-manipulation" 
                      onClick={() => handleMoveUp(button, index)}
                      disabled={index === 0}
                    >
                      <ArrowUp className="w-3 h-3" />
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="h-8 px-2 touch-manipulation" 
                      onClick={() => handleMoveDown(button, index)}
                      disabled={index === sortedArray.length - 1}
                    >
                      <ArrowDown className="w-3 h-3" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    {button.is_visible_mobile && <Smartphone className="w-4 h-4" />}
                    {button.is_visible_desktop && <Monitor className="w-4 h-4" />}
                    <span className="px-1.5 py-0.5 bg-accent/10 rounded">{button.size?.[0]?.toUpperCase()}</span>
                  </div>

                  <Button variant="ghost" size="sm" onClick={() => handleDelete(button.id)} className="h-8 px-2 text-destructive">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingButton ? 'Modifica pulsante' : 'Nuovo pulsante'}
            </DialogTitle>
          </DialogHeader>

          <Tabs defaultValue="content" className="mt-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="content" className="gap-2">
                <Type className="w-4 h-4" />
                Contenuto
              </TabsTrigger>
              <TabsTrigger value="style" className="gap-2">
                <Palette className="w-4 h-4" />
                Stile
              </TabsTrigger>
              <TabsTrigger value="layout" className="gap-2">
                <Square className="w-4 h-4" />
                Layout
              </TabsTrigger>
            </TabsList>

            {/* Content Tab */}
            <TabsContent value="content" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Chiave univoca *</Label>
                  <Input
                    value={formData.button_key}
                    onChange={(e) => setFormData({ ...formData, button_key: e.target.value.toLowerCase().replace(/\s/g, '-') })}
                    placeholder="es: menu, delivery"
                    disabled={!!editingButton}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Icona</Label>
                  <Select value={formData.icon} onValueChange={(v) => setFormData({ ...formData, icon: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {availableIcons.map((icon) => (
                        <SelectItem key={icon} value={icon}>
                          <div className="flex items-center gap-2">
                            <DynamicIcon name={icon} className="w-4 h-4" />
                            {icon}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Labels */}
              <div className="space-y-3 border rounded-lg p-3 bg-muted/30">
                <p className="text-xs font-medium text-muted-foreground uppercase">Labels</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs">🇮🇹 IT *</Label>
                    <Input value={formData.label_it} onChange={(e) => setFormData({ ...formData, label_it: e.target.value })} placeholder="Menu" className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">🇬🇧 EN</Label>
                    <Input value={formData.label_en} onChange={(e) => setFormData({ ...formData, label_en: e.target.value })} placeholder="Menu" className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">🇩🇪 DE</Label>
                    <Input value={formData.label_de} onChange={(e) => setFormData({ ...formData, label_de: e.target.value })} className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">🇪🇸 ES</Label>
                    <Input value={formData.label_es} onChange={(e) => setFormData({ ...formData, label_es: e.target.value })} className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <Label className="text-xs">🇫🇷 FR</Label>
                    <Input value={formData.label_fr} onChange={(e) => setFormData({ ...formData, label_fr: e.target.value })} className="h-8 text-sm" />
                  </div>
                </div>
              </div>

              {/* Subtitles */}
              <div className="space-y-3 border rounded-lg p-3 bg-muted/30">
                <p className="text-xs font-medium text-muted-foreground uppercase">Sottotitoli</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs">🇮🇹 IT</Label>
                    <Input value={formData.subtitle_it} onChange={(e) => setFormData({ ...formData, subtitle_it: e.target.value })} placeholder="Sfoglia" className="h-8 text-sm" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">🇬🇧 EN</Label>
                    <Input value={formData.subtitle_en} onChange={(e) => setFormData({ ...formData, subtitle_en: e.target.value })} placeholder="Browse" className="h-8 text-sm" />
                  </div>
                </div>
              </div>

              {/* Action */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Tipo azione</Label>
                  <Select value={formData.action_type} onValueChange={(v: any) => setFormData({ ...formData, action_type: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="internal">Navigazione interna</SelectItem>
                      <SelectItem value="modal">Apri modale</SelectItem>
                      <SelectItem value="external">Link esterno</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Valore azione</Label>
                  <Input
                    value={formData.action_value}
                    onChange={(e) => setFormData({ ...formData, action_value: e.target.value })}
                    placeholder={formData.action_type === 'external' ? 'https://...' : 'menu, reservation, takeaway'}
                  />
                </div>
              </div>
            </TabsContent>

            {/* Style Tab */}
            <TabsContent value="style" className="space-y-4 mt-4">
              {/* Live Preview */}
              <div className="p-4 rounded-lg bg-background border border-border">
                <p className="text-xs text-muted-foreground mb-3">Anteprima</p>
                <div 
                  className={`p-4 rounded-xl border transition-all ${
                    formData.display_style === 'pill' ? 'rounded-full px-6' :
                    formData.display_style === 'button' ? 'rounded-lg' :
                    formData.display_style === 'minimal' ? 'border-transparent' : ''
                  }`}
                  style={{
                    ...getPreviewStyle(),
                    background: formData.bg_color 
                      ? `hsla(${formData.bg_color}, ${formData.bg_opacity})`
                      : formData.gradient 
                        ? undefined 
                        : 'hsl(var(--card))',
                  }}
                >
                  <div className={`bg-gradient-to-br ${formData.gradient} rounded-xl p-4 flex items-center gap-3`}>
                    <div 
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{
                        backgroundColor: formData.button_color 
                          ? `hsl(${formData.button_color})` 
                          : 'hsl(var(--accent) / 0.2)',
                      }}
                    >
                      <DynamicIcon 
                        name={formData.icon} 
                        className="w-5 h-5"
                        style={{
                          color: formData.icon_color 
                            ? `hsl(${formData.icon_color})` 
                            : formData.button_color 
                              ? 'white'
                              : 'hsl(var(--accent))'
                        }}
                      />
                    </div>
                    <div>
                      <p 
                        className="font-semibold"
                        style={{
                          color: formData.label_color 
                            ? `hsl(${formData.label_color})` 
                            : undefined
                        }}
                      >
                        {formData.label_it || 'Label'}
                      </p>
                      {formData.subtitle_it && (
                        <p className="text-xs text-muted-foreground">{formData.subtitle_it}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Display Style */}
              <div className="space-y-2">
                <Label>Tipo di visualizzazione</Label>
                <Select value={formData.display_style} onValueChange={(v: any) => setFormData({ ...formData, display_style: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="card">
                      <div className="flex items-center gap-2">
                        <Square className="w-4 h-4" />
                        Card (con sfondo)
                      </div>
                    </SelectItem>
                    <SelectItem value="button">
                      <div className="flex items-center gap-2">
                        <Square className="w-4 h-4" />
                        Button (compatto)
                      </div>
                    </SelectItem>
                    <SelectItem value="pill">
                      <div className="flex items-center gap-2">
                        <Circle className="w-4 h-4" />
                        Pill (arrotondato)
                      </div>
                    </SelectItem>
                    <SelectItem value="minimal">
                      <div className="flex items-center gap-2">
                        <Type className="w-4 h-4" />
                        Minimal (solo testo)
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Colors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <GradientColorPicker
                  value={formData.button_color}
                  onChange={(value) => setFormData({ ...formData, button_color: value })}
                  type="both"
                  label="Colore icona/sfondo"
                  placeholder="Accent (default)"
                />
                <GradientColorPicker
                  value={formData.gradient}
                  onChange={(value) => setFormData({ ...formData, gradient: value })}
                  type="both"
                  label="Gradiente sfondo"
                  placeholder="Soft accent"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <GradientColorPicker
                  value={formData.bg_color}
                  onChange={(value) => setFormData({ ...formData, bg_color: value === 'none' ? '' : value })}
                  type="both"
                  label="Colore sfondo"
                  placeholder="Trasparente"
                />

                <div className="space-y-2">
                  <Label>Opacità sfondo: {Math.round(formData.bg_opacity * 100)}%</Label>
                  <Slider
                    value={[formData.bg_opacity]}
                    onValueChange={([v]) => setFormData({ ...formData, bg_opacity: v })}
                    min={0}
                    max={1}
                    step={0.05}
                    className="touch-manipulation"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <GradientColorPicker
                  value={formData.label_color}
                  onChange={(value) => setFormData({ ...formData, label_color: value === 'none' ? '' : value })}
                  type="both"
                  label="Colore label"
                  placeholder="Default"
                />

                <GradientColorPicker
                  value={formData.icon_color}
                  onChange={(value) => setFormData({ ...formData, icon_color: value === 'none' ? '' : value })}
                  type="both"
                  label="Colore icona"
                  placeholder="Default"
                />
              </div>
            </TabsContent>

            {/* Layout Tab */}
            <TabsContent value="layout" className="space-y-4 mt-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Dimensione</Label>
                  <Select value={formData.size} onValueChange={(v: any) => setFormData({ ...formData, size: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Piccolo</SelectItem>
                      <SelectItem value="medium">Medio</SelectItem>
                      <SelectItem value="large">Grande</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Larghezza Desktop (colonne)</Label>
                  <Select value={String(formData.col_span)} onValueChange={(v) => setFormData({ ...formData, col_span: Number(v) })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 colonna</SelectItem>
                      <SelectItem value="2">2 colonne</SelectItem>
                      <SelectItem value="3">3 colonne</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-4 rounded-lg bg-muted/30">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={formData.is_active}
                    onCheckedChange={(v) => setFormData({ ...formData, is_active: v })}
                  />
                  <Label>Attivo</Label>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={formData.is_visible_mobile}
                      onCheckedChange={(v) => setFormData({ ...formData, is_visible_mobile: v })}
                    />
                    <Label className="flex items-center gap-1">
                      <Smartphone className="w-4 h-4" /> Mobile
                    </Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={formData.is_visible_desktop}
                      onCheckedChange={(v) => setFormData({ ...formData, is_visible_desktop: v })}
                    />
                    <Label className="flex items-center gap-1">
                      <Monitor className="w-4 h-4" /> Desktop
                    </Label>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="touch-manipulation">
              Annulla
            </Button>
            <Button onClick={handleSave} disabled={isSaving} className="touch-manipulation">
              {isSaving ? 'Salvataggio...' : 'Salva'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
