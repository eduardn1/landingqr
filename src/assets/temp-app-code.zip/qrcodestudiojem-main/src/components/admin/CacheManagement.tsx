import { useState } from 'react';
import { motion } from 'framer-motion';
import { Trash2, RefreshCw, Database, Image, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';

export function CacheManagement() {
  const queryClient = useQueryClient();
  const [isClearing, setIsClearing] = useState<string | null>(null);

  const clearAllQueryCache = async () => {
    setIsClearing('all');
    try {
      // Clear React Query cache
      queryClient.clear();
      
      // Clear service worker caches
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(
          cacheNames.map(cacheName => caches.delete(cacheName))
        );
      }

      // Update service workers
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map(reg => reg.update()));
      }

      toast.success('Cache svuotata! Gli utenti riceveranno dati aggiornati.');
    } catch (error) {
      console.error('Error clearing cache:', error);
      toast.error('Errore durante la pulizia della cache');
    } finally {
      setIsClearing(null);
    }
  };

  const clearMenuCache = async () => {
    setIsClearing('menu');
    try {
      // Invalidate menu-related queries
      await queryClient.invalidateQueries({ queryKey: ['dishes'] });
      await queryClient.invalidateQueries({ queryKey: ['categories'] });
      await queryClient.invalidateQueries({ queryKey: ['featured-dishes'] });
      await queryClient.invalidateQueries({ queryKey: ['moods'] });
      await queryClient.invalidateQueries({ queryKey: ['allergens'] });

      // Clear supabase cache from service worker
      if ('caches' in window) {
        await caches.delete('supabase-cache');
      }

      toast.success('Cache menu aggiornata!');
    } catch (error) {
      console.error('Error clearing menu cache:', error);
      toast.error('Errore durante la pulizia della cache menu');
    } finally {
      setIsClearing(null);
    }
  };

  const clearImageCache = async () => {
    setIsClearing('images');
    try {
      if ('caches' in window) {
        await caches.delete('storage-cache');
        await caches.delete('image-cache');
      }

      toast.success('Cache immagini svuotata!');
    } catch (error) {
      console.error('Error clearing image cache:', error);
      toast.error('Errore durante la pulizia della cache immagini');
    } finally {
      setIsClearing(null);
    }
  };

  const refreshAllData = async () => {
    setIsClearing('refresh');
    try {
      // Invalidate all queries to force refetch
      await queryClient.invalidateQueries();
      toast.success('Dati aggiornati!');
    } catch (error) {
      console.error('Error refreshing data:', error);
      toast.error('Errore durante l\'aggiornamento');
    } finally {
      setIsClearing(null);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div>
        <h2 className="text-lg font-semibold mb-2">Gestione Cache</h2>
        <p className="text-sm text-muted-foreground">
          Svuota la cache per forzare il refresh dei dati su tutti i dispositivi degli utenti.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {/* Clear All Cache */}
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
              <Trash2 className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <h3 className="font-medium text-foreground">Svuota Tutta la Cache</h3>
              <p className="text-xs text-muted-foreground">Rimuove tutti i dati in cache</p>
            </div>
          </div>
          <Button
            variant="destructive"
            size="sm"
            className="w-full"
            onClick={clearAllQueryCache}
            disabled={isClearing !== null}
          >
            {isClearing === 'all' ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Trash2 className="w-4 h-4 mr-2" />
            )}
            Svuota Tutto
          </Button>
        </div>

        {/* Refresh All Data */}
        <div className="p-4 rounded-xl bg-secondary/50 border border-border/30 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
              <RefreshCw className="w-5 h-5 text-accent" />
            </div>
            <div>
              <h3 className="font-medium text-foreground">Aggiorna Dati</h3>
              <p className="text-xs text-muted-foreground">Ricarica tutti i dati dal database</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={refreshAllData}
            disabled={isClearing !== null}
          >
            {isClearing === 'refresh' ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <RefreshCw className="w-4 h-4 mr-2" />
            )}
            Aggiorna
          </Button>
        </div>

        {/* Clear Menu Cache */}
        <div className="p-4 rounded-xl bg-secondary/50 border border-border/30 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-foreground/10 flex items-center justify-center">
              <Database className="w-5 h-5 text-muted-foreground" />
            </div>
            <div>
              <h3 className="font-medium text-foreground">Cache Menu</h3>
              <p className="text-xs text-muted-foreground">Piatti, categorie, allergeni</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={clearMenuCache}
            disabled={isClearing !== null}
          >
            {isClearing === 'menu' ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Database className="w-4 h-4 mr-2" />
            )}
            Aggiorna Menu
          </Button>
        </div>

        {/* Clear Image Cache */}
        <div className="p-4 rounded-xl bg-secondary/50 border border-border/30 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-foreground/10 flex items-center justify-center">
              <Image className="w-5 h-5 text-muted-foreground" />
            </div>
            <div>
              <h3 className="font-medium text-foreground">Cache Immagini</h3>
              <p className="text-xs text-muted-foreground">Foto piatti, eventi, promo</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={clearImageCache}
            disabled={isClearing !== null}
          >
            {isClearing === 'images' ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Image className="w-4 h-4 mr-2" />
            )}
            Svuota Immagini
          </Button>
        </div>
      </div>
    </motion.div>
  );
}