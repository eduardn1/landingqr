import { useState } from 'react';
import { useAllEvents, useEventMutations, type DbEvent } from '@/hooks/useEvents';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { ImageUpload } from './ImageUpload';
import { MultiLangInput, type MultiLangValue } from './MultiLangInput';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Calendar, Clock, Music, Mic, Wine, PartyPopper, Sparkles } from 'lucide-react';
import { format, parseISO } from 'date-fns';

const eventTypes = [
  { value: 'dj_set', label: 'DJ Set', icon: Music },
  { value: 'live_music', label: 'Live Music', icon: Music },
  { value: 'karaoke', label: 'Karaoke', icon: Mic },
  { value: 'aperitivo', label: 'Aperitivo', icon: Wine },
  { value: 'degustazione', label: 'Degustazione', icon: Wine },
  { value: 'altro', label: 'Altro', icon: PartyPopper },
];

type EventType = 'dj_set' | 'live_music' | 'karaoke' | 'aperitivo' | 'degustazione' | 'altro';

export function EventsEditor() {
  const { events, isLoading, refetch } = useAllEvents();
  const { createEvent, updateEvent, deleteEvent } = useEventMutations();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<DbEvent | null>(null);
  
  const [titleValue, setTitleValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });
  const [descValue, setDescValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });
  const [priceNoteValue, setPriceNoteValue] = useState<MultiLangValue>({ it: '', en: '', de: '', es: '', fr: '' });
  const [formData, setFormData] = useState({
    event_type: 'live_music' as EventType,
    event_date: '',
    start_time: '21:00',
    end_time: '',
    image_url: '',
    entry_price: '',
    is_active: true,
    is_featured: false,
  });

  const resetForm = () => {
    setTitleValue({ it: '', en: '', de: '', es: '', fr: '' });
    setDescValue({ it: '', en: '', de: '', es: '', fr: '' });
    setPriceNoteValue({ it: '', en: '', de: '', es: '', fr: '' });
    setFormData({
      event_type: 'live_music',
      event_date: '',
      start_time: '21:00',
      end_time: '',
      image_url: '',
      entry_price: '',
      is_active: true,
      is_featured: false,
    });
  };

  const handleEdit = (event: DbEvent) => {
    setEditingEvent(event);
    setTitleValue({
      it: event.title_it,
      en: event.title_en || '',
      de: (event as any).title_de || '',
      es: (event as any).title_es || '',
      fr: (event as any).title_fr || '',
    });
    setDescValue({
      it: event.description_it || '',
      en: event.description_en || '',
      de: (event as any).description_de || '',
      es: (event as any).description_es || '',
      fr: (event as any).description_fr || '',
    });
    setPriceNoteValue({
      it: event.entry_price_note_it || '',
      en: event.entry_price_note_en || '',
      de: (event as any).entry_price_note_de || '',
      es: (event as any).entry_price_note_es || '',
      fr: (event as any).entry_price_note_fr || '',
    });
    setFormData({
      event_type: event.event_type,
      event_date: event.event_date,
      start_time: event.start_time,
      end_time: event.end_time || '',
      image_url: event.image_url || '',
      entry_price: event.entry_price?.toString() || '',
      is_active: event.is_active,
      is_featured: event.is_featured,
    });
    setIsDialogOpen(true);
  };

  const handleNew = () => {
    setEditingEvent(null);
    resetForm();
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!titleValue.it || !formData.event_date || !formData.start_time) {
      toast.error('Compila i campi obbligatori');
      return;
    }

    const payload = {
      title_it: titleValue.it,
      title_en: titleValue.en || null,
      title_de: titleValue.de || null,
      title_es: titleValue.es || null,
      title_fr: titleValue.fr || null,
      description_it: descValue.it || null,
      description_en: descValue.en || null,
      description_de: descValue.de || null,
      description_es: descValue.es || null,
      description_fr: descValue.fr || null,
      event_type: formData.event_type,
      event_date: formData.event_date,
      start_time: formData.start_time,
      end_time: formData.end_time || null,
      image_url: formData.image_url || null,
      entry_price: formData.entry_price ? parseFloat(formData.entry_price) : null,
      entry_price_note_it: priceNoteValue.it || null,
      entry_price_note_en: priceNoteValue.en || null,
      entry_price_note_de: priceNoteValue.de || null,
      entry_price_note_es: priceNoteValue.es || null,
      entry_price_note_fr: priceNoteValue.fr || null,
      is_active: formData.is_active,
      is_featured: formData.is_featured,
    };

    try {
      if (editingEvent) {
        await updateEvent.mutateAsync({ id: editingEvent.id, ...payload });
        toast.success('Evento aggiornato');
      } else {
        await createEvent.mutateAsync(payload);
        toast.success('Evento creato');
      }
      setIsDialogOpen(false);
      resetForm();
    } catch (error: any) {
      toast.error(error.message || 'Errore nel salvare');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Sei sicuro di voler eliminare questo evento?')) return;
    try {
      await deleteEvent.mutateAsync(id);
      toast.success('Evento eliminato');
    } catch (error: any) {
      toast.error(error.message || "Errore nell'eliminare");
    }
  };

  const handleToggleActive = async (event: DbEvent) => {
    try {
      await updateEvent.mutateAsync({ id: event.id, is_active: !event.is_active });
    } catch (error: any) {
      toast.error("Errore nell'aggiornamento");
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[...Array(3)].map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <p className="text-sm text-muted-foreground">
          Gestisci eventi e serate
        </p>
        <Button onClick={handleNew} size="sm" className="gap-2">
          <Plus className="w-4 h-4" />
          Nuovo evento
        </Button>
      </div>

      <div className="space-y-3">
        {events.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              Nessun evento creato. Clicca "Nuovo evento" per iniziare.
            </CardContent>
          </Card>
        ) : (
          events.map((event) => {
            const typeConfig = eventTypes.find(t => t.value === event.event_type);
            const TypeIcon = typeConfig?.icon || PartyPopper;
            
            return (
              <Card key={event.id} className={!event.is_active ? 'opacity-50' : ''}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    {event.image_url ? (
                      <img src={event.image_url} alt="" className="w-16 h-16 rounded-xl object-cover" />
                    ) : (
                      <div className="w-16 h-16 rounded-xl bg-accent/20 flex items-center justify-center">
                        <TypeIcon className="w-6 h-6 text-accent" />
                      </div>
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{event.title_it}</p>
                        {event.is_featured && <Sparkles className="w-4 h-4 text-accent" />}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(parseISO(event.event_date), 'dd/MM/yyyy')}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {event.start_time}
                        </span>
                        <span className="px-1.5 py-0.5 bg-accent/10 rounded text-[10px]">
                          {typeConfig?.label}
                        </span>
                      </div>
                    </div>

                    <Switch
                      checked={event.is_active}
                      onCheckedChange={() => handleToggleActive(event)}
                    />

                    <Button variant="ghost" size="icon" onClick={() => handleEdit(event)} title="Modifica">
                      <Pencil className="w-4 h-4" />
                    </Button>

                    <Button variant="ghost" size="icon" onClick={() => handleDelete(event.id)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingEvent ? 'Modifica evento' : 'Nuovo evento'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <MultiLangInput
              label="Titolo"
              value={titleValue}
              onChange={setTitleValue}
              placeholder="Titolo evento"
              required
            />

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Tipo evento</Label>
                <Select value={formData.event_type} onValueChange={(v) => setFormData({ ...formData, event_type: v as EventType })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {eventTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div className="flex items-center gap-2">
                          <type.icon className="w-4 h-4" />
                          {type.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Data *</Label>
                <Input
                  type="date"
                  value={formData.event_date}
                  onChange={(e) => setFormData({ ...formData, event_date: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Ora inizio *</Label>
                <Input
                  type="time"
                  value={formData.start_time}
                  onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Ora fine</Label>
                <Input
                  type="time"
                  value={formData.end_time}
                  onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                />
              </div>
            </div>

            <MultiLangInput
              label="Descrizione"
              value={descValue}
              onChange={setDescValue}
              placeholder="Descrizione evento"
              multiline
              rows={2}
            />

            <div className="space-y-2">
              <Label>Immagine</Label>
              <ImageUpload
                value={formData.image_url}
                onChange={(url) => setFormData({ ...formData, image_url: url || '' })}
                folder="events"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Prezzo ingresso (€)</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.entry_price}
                  onChange={(e) => setFormData({ ...formData, entry_price: e.target.value })}
                  placeholder="0.00"
                />
              </div>
            </div>

            <MultiLangInput
              label="Nota prezzo"
              value={priceNoteValue}
              onChange={setPriceNoteValue}
              placeholder="es: con drink incluso"
            />

            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(v) => setFormData({ ...formData, is_active: v })}
                />
                <Label>Attivo</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={formData.is_featured}
                  onCheckedChange={(v) => setFormData({ ...formData, is_featured: v })}
                />
                <Label className="flex items-center gap-1">
                  <Sparkles className="w-4 h-4" /> In evidenza
                </Label>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Annulla
              </Button>
              <Button onClick={handleSave} disabled={createEvent.isPending || updateEvent.isPending}>
                {createEvent.isPending || updateEvent.isPending ? 'Salvataggio...' : 'Salva'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
