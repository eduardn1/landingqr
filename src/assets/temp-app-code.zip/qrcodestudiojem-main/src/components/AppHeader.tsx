import { motion } from 'framer-motion';
import { Heart, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { LanguageSwitcher } from './LanguageSwitcher';
import { ThemeToggle } from './ThemeToggle';
import { NotificationBell } from './client/NotificationBell';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { useFavorites } from '@/hooks/useFavorites';
import { useAuth } from '@/hooks/useAuth';
import { BackButton } from '@/components/ui/BackButton';
import { useHeaderVisibility } from '@/hooks/useHeaderVisibility';

interface AppHeaderProps {
  showBack?: boolean;
  onBack?: () => void;
  onOpenFavorites?: () => void;
}

export function AppHeader({ showBack, onBack, onOpenFavorites }: AppHeaderProps) {
  const { favoritesCount } = useFavorites();
  const { isAuthenticated } = useAuth();
  const { config: restaurantConfig } = useRestaurantConfig();
  const visibility = useHeaderVisibility();

  return (
    <motion.header 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="sticky top-0 z-50"
    >
      {/* Glassmorphism background */}
      <div className="absolute inset-0 bg-background/70 backdrop-blur-xl border-b border-border/10" />
      
      <div className="container relative flex items-center justify-between h-16 px-4">
        {/* Left Section */}
        <div className="flex items-center gap-3">
          {showBack && onBack ? (
            <BackButton onClick={onBack} label="Home" size="lg" />
          ) : visibility.logo && restaurantConfig?.logo_url && (
            <motion.div 
              className="flex items-center -my-4 relative z-10"
            >
              <motion.img 
                src={restaurantConfig.logo_url} 
                alt={restaurantConfig?.name || 'Logo'} 
                className="w-20 h-20 object-contain drop-shadow-lg"
                animate={{ 
                  rotate: [0, 3, -3, 3, 0],
                }}
                transition={{ 
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                whileHover={{ scale: 1.1 }}
              />
            </motion.div>
          )}
        </div>

        {/* Right Section - Actions */}
        <div className="flex items-center gap-2">
          {/* Notification Bell */}
          {visibility.notifications && isAuthenticated && <NotificationBell />}

          {/* Theme Toggle */}
          {visibility.theme && <ThemeToggle />}

          {/* Favorites Button */}
          {visibility.favorites && favoritesCount > 0 && onOpenFavorites && (
            <motion.button
              onClick={onOpenFavorites}
              className="relative flex w-10 h-10 rounded-full bg-accent/10 border border-accent/20 items-center justify-center"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <Heart className="w-4 h-4 text-accent" fill="currentColor" />
              <motion.span 
                className="absolute -top-1 -right-1 min-w-5 h-5 px-1 rounded-full bg-foreground text-background text-[10px] font-bold flex items-center justify-center shadow-lg"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
              >
                {favoritesCount > 9 ? '9+' : favoritesCount}
              </motion.span>
            </motion.button>
          )}

          {/* User Button */}
          {visibility.profile && (
            <Link to={isAuthenticated ? '/profile' : '/auth'}>
              <motion.div
                className={`flex w-10 h-10 rounded-full items-center justify-center overflow-hidden relative cursor-pointer ${
                  isAuthenticated 
                    ? 'bg-accent/20 border border-accent/30 text-accent' 
                    : 'bg-secondary/50 border border-border/20 text-muted-foreground hover:text-foreground'
                }`}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                {isAuthenticated && (
                  <motion.div
                    className="absolute inset-0 bg-accent/10"
                    animate={{ 
                      opacity: [0.3, 0.6, 0.3]
                    }}
                    transition={{ 
                      duration: 3,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                )}
                <User className="w-4 h-4 relative z-10" />
              </motion.div>
            </Link>
          )}

          {/* Language Switcher */}
          {visibility.language && <LanguageSwitcher />}
        </div>
      </div>
    </motion.header>
  );
}
