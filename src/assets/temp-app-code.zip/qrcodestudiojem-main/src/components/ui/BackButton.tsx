import { forwardRef } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface BackButtonProps {
  onClick: () => void;
  label?: string;
  variant?: 'back' | 'close';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showTooltip?: boolean;
}

export const BackButton = forwardRef<HTMLButtonElement, BackButtonProps>(({ 
  onClick, 
  label, 
  variant = 'back',
  size = 'md',
  className,
  showTooltip = true
}, ref) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12'
  };

  const iconSizes = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-6 h-6'
  };

  const Icon = variant === 'close' ? X : ChevronLeft;
  const tooltipText = variant === 'close' ? 'Chiudi' : 'Torna indietro';

  const button = (
    <motion.button
      ref={ref}
      onClick={onClick}
      aria-label={tooltipText}
      className={cn(
        "flex items-center gap-2 text-foreground hover:text-foreground transition-colors group",
        className
      )}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <motion.div 
        className={cn(
          "relative rounded-full bg-foreground/10 backdrop-blur-sm border border-foreground/20 flex items-center justify-center overflow-hidden",
          "group-hover:bg-foreground/20 group-hover:border-foreground/30 transition-all duration-300",
          "shadow-sm",
          sizeClasses[size]
        )}
      >
        {/* Hover glow effect */}
        <motion.div 
          className="absolute inset-0 bg-accent/0 group-hover:bg-accent/20 transition-colors duration-300 rounded-full"
        />
        <Icon className={cn("relative z-10 text-foreground", iconSizes[size])} />
      </motion.div>
      {label && (
        <span className="text-sm font-medium hidden sm:block">{label}</span>
      )}
    </motion.button>
  );

  if (showTooltip) {
    return (
      <TooltipProvider delayDuration={300}>
        <Tooltip>
          <TooltipTrigger asChild>
            {button}
          </TooltipTrigger>
          <TooltipContent side="bottom" className="text-xs">
            {tooltipText}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return button;
});

BackButton.displayName = 'BackButton';
