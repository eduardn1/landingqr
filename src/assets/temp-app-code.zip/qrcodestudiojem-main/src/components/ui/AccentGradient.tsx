import { forwardRef, HTMLAttributes, ReactNode, CSSProperties } from 'react';
import { cn } from '@/lib/utils';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { isGradient, tailwindGradientToCss } from '@/lib/gradientUtils';

interface AccentGradientProps {
  /** Additional class names */
  className?: string;
  /** Inline styles */
  style?: CSSProperties;
  /** Children */
  children?: ReactNode;
  /** Gradient direction */
  direction?: 'to right' | 'to left' | 'to bottom' | 'to top' | 'to bottom right' | 'to top right';
  /** Opacity of the gradient/color */
  opacity?: number;
  /** Whether to use gradient for text instead of background */
  textGradient?: boolean;
  /** Fallback to solid accent if no gradient configured */
  fallbackToSolid?: boolean;
  /** Click handler */
  onClick?: () => void;
}

/**
 * AccentGradient - A component that renders the configured accent color/gradient
 * 
 * Usage:
 * <AccentGradient className="p-4 rounded-xl">
 *   Content with gradient background
 * </AccentGradient>
 * 
 * <AccentGradient textGradient className="text-2xl font-bold">
 *   Gradient Text
 * </AccentGradient>
 */
export const AccentGradient = forwardRef<HTMLDivElement, AccentGradientProps>(
  ({ 
    direction = 'to right', 
    opacity = 1,
    textGradient = false,
    fallbackToSolid = true,
    className, 
    style,
    children,
    onClick,
  }, ref) => {
    const { config } = useRestaurantConfig();
    const colorAccent = config?.color_accent;
    
    const hasGradient = isGradient(colorAccent);
    const cssGradient = hasGradient ? tailwindGradientToCss(colorAccent!, direction) : null;
    
    // Build style object
    const gradientStyle: CSSProperties = { ...style };
    
    if (textGradient) {
      // Text gradient effect
      if (cssGradient) {
        gradientStyle.background = cssGradient;
        gradientStyle.WebkitBackgroundClip = 'text';
        gradientStyle.WebkitTextFillColor = 'transparent';
        gradientStyle.backgroundClip = 'text';
      } else if (fallbackToSolid) {
        gradientStyle.color = 'hsl(var(--accent))';
      }
    } else {
      // Background gradient
      if (cssGradient) {
        if (opacity < 1) {
          gradientStyle.background = cssGradient;
          gradientStyle.opacity = opacity;
        } else {
          gradientStyle.background = cssGradient;
        }
      } else if (fallbackToSolid) {
        gradientStyle.backgroundColor = `hsl(var(--accent) / ${opacity})`;
      }
    }
    
    return (
      <div
        ref={ref}
        className={cn(
          !textGradient && 'text-white',
          className
        )}
        style={gradientStyle}
        onClick={onClick}
      >
        {children}
      </div>
    );
  }
);

AccentGradient.displayName = 'AccentGradient';

/**
 * Hook to get accent gradient styles for custom use
 */
export function useAccentGradient(options: {
  direction?: string;
  opacity?: number;
} = {}) {
  const { config } = useRestaurantConfig();
  const { direction = 'to right', opacity = 1 } = options;
  
  const colorAccent = config?.color_accent;
  const hasGradient = isGradient(colorAccent);
  const cssGradient = hasGradient ? tailwindGradientToCss(colorAccent!, direction) : null;
  
  return {
    hasGradient,
    colorAccent,
    cssGradient,
    // Style for background gradient
    backgroundStyle: cssGradient 
      ? { background: cssGradient } 
      : { backgroundColor: `hsl(var(--accent) / ${opacity})` },
    // Style for text gradient
    textGradientStyle: cssGradient
      ? {
          background: cssGradient,
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          backgroundClip: 'text',
        }
      : { color: 'hsl(var(--accent))' },
    // Primary color (first color of gradient or solid color)
    primaryColor: hasGradient 
      ? extractPrimaryColor(colorAccent!)
      : (colorAccent ? `hsl(${colorAccent})` : 'hsl(var(--accent))'),
  };
}

function extractPrimaryColor(gradient: string): string {
  const match = gradient.match(/from-\[#([a-fA-F0-9]{6})\]/);
  if (match) return `#${match[1]}`;
  return 'hsl(var(--accent))';
}
