import { useState, useRef, useEffect, memo, forwardRef } from 'react';
import { cn } from '@/lib/utils';

interface ProgressiveImageProps {
  src: string;
  alt: string;
  className?: string;
  containerClassName?: string;
  placeholderColor?: string;
  aspectRatio?: 'square' | 'video' | '4/3' | '3/2' | '16/9';
  rootMargin?: string;
  onLoad?: () => void;
  onError?: () => void;
}

// Generate a tiny blurred placeholder color from image URL
const getPlaceholderGradient = (src: string) => {
  let hash = 0;
  for (let i = 0; i < src.length; i++) {
    hash = src.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  const h = Math.abs(hash % 360);
  const s = 20 + (Math.abs(hash >> 8) % 20);
  const l = 15 + (Math.abs(hash >> 16) % 15);
  
  return `hsl(${h}, ${s}%, ${l}%)`;
};

const aspectRatioClasses = {
  'square': 'aspect-square',
  'video': 'aspect-video',
  '4/3': 'aspect-[4/3]',
  '3/2': 'aspect-[3/2]',
  '16/9': 'aspect-[16/9]',
};

export const ProgressiveImage = memo(forwardRef<HTMLDivElement, ProgressiveImageProps>(
  function ProgressiveImage({
    src,
    alt,
    className,
    containerClassName,
    placeholderColor,
    aspectRatio = '4/3',
    rootMargin = '100px',
    onLoad,
    onError,
  }, ref) {
    const [isInView, setIsInView] = useState(false);
    const [isLoaded, setIsLoaded] = useState(false);
    const [hasError, setHasError] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    // Use forwarded ref or internal ref
    const elementRef = (ref as React.RefObject<HTMLDivElement>) || containerRef;

    const bgColor = placeholderColor || getPlaceholderGradient(src);

    useEffect(() => {
      const element = containerRef.current;
      if (!element) return;

      if (!('IntersectionObserver' in window)) {
        setIsInView(true);
        return;
      }

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setIsInView(true);
              observer.unobserve(entry.target);
            }
          });
        },
        {
          rootMargin,
          threshold: 0.01,
        }
      );

      observer.observe(element);

      return () => {
        observer.disconnect();
      };
    }, [rootMargin]);

    const handleLoad = () => {
      setIsLoaded(true);
      onLoad?.();
    };

    const handleError = () => {
      setHasError(true);
      onError?.();
    };

    if (hasError) {
      return (
        <div
          ref={containerRef}
          className={cn(
            'relative overflow-hidden bg-secondary/30 flex items-center justify-center',
            aspectRatioClasses[aspectRatio],
            containerClassName
          )}
        >
          <span className="text-3xl text-muted-foreground/30">🍽️</span>
        </div>
      );
    }

    return (
      <div
        ref={containerRef}
        className={cn(
          'relative overflow-hidden',
          aspectRatioClasses[aspectRatio],
          containerClassName
        )}
        style={{ backgroundColor: bgColor }}
      >
        {/* Shimmer skeleton placeholder */}
        {!isLoaded && (
          <div className="absolute inset-0 z-10">
            <div 
              className="absolute inset-0"
              style={{
                background: `linear-gradient(135deg, ${bgColor} 0%, hsl(var(--secondary) / 0.3) 100%)`,
              }}
            />
            <div
              className="absolute inset-0 animate-shimmer"
              style={{
                background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.08) 50%, transparent 100%)',
              }}
            />
          </div>
        )}

        {/* Actual image - only load when in view */}
        {isInView && (
          <img
            src={src}
            alt={alt}
            loading="lazy"
            decoding="async"
            onLoad={handleLoad}
            onError={handleError}
            className={cn(
              'w-full h-full object-cover transition-all duration-500',
              isLoaded ? 'opacity-100 scale-100 blur-0' : 'opacity-0 scale-110 blur-lg',
              className
            )}
          />
        )}
      </div>
    );
  }
));

ProgressiveImage.displayName = 'ProgressiveImage';

// Preload an image programmatically
export function preloadImage(src: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve();
    img.onerror = reject;
    img.src = src;
  });
}

// Preload multiple images
export function preloadImages(srcs: string[]): Promise<void[]> {
  return Promise.all(srcs.map(preloadImage));
}
