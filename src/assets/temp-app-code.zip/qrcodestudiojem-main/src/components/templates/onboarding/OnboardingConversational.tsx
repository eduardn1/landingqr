import { motion, AnimatePresence } from 'framer-motion';
import { ReactNode } from 'react';

interface OnboardingConversationalProps {
  config: Record<string, any>;
  currentStep: number;
  totalSteps: number;
  children: ReactNode;
}

export function OnboardingConversational({ config, currentStep, totalSteps, children }: OnboardingConversationalProps) {
  const style = config.style || 'chat_bubbles';
  const progress = config.progress || 'dots';
  
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Progress indicator */}
      <div className="p-4">
        {progress === 'dots' && (
          <div className="flex justify-center gap-2">
            {Array.from({ length: totalSteps }).map((_, i) => (
              <motion.div
                key={i}
                className={`w-2 h-2 rounded-full ${
                  i <= currentStep ? 'bg-accent' : 'bg-muted'
                }`}
                initial={{ scale: 0.8 }}
                animate={{ scale: i === currentStep ? 1.2 : 1 }}
                transition={{ duration: 0.3 }}
              />
            ))}
          </div>
        )}
        {progress === 'bar' && (
          <div className="w-full bg-muted rounded-full h-1 overflow-hidden">
            <motion.div
              className="h-full bg-accent rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${((currentStep + 1) / totalSteps) * 100}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
            />
          </div>
        )}
      </div>
      
      {/* Content area */}
      <div className="flex-1 flex flex-col justify-end p-4 pb-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
            className={style === 'chat_bubbles' ? 'space-y-4' : ''}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}