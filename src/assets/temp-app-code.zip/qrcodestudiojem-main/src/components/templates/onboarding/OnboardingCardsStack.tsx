import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { ReactNode, useState } from 'react';

interface OnboardingCardsStackProps {
  config: Record<string, any>;
  steps: ReactNode[];
  currentStep: number;
  onSwipe: (direction: 'left' | 'right') => void;
}

export function OnboardingCardsStack({ config, steps, currentStep, onSwipe }: OnboardingCardsStackProps) {
  const [exitX, setExitX] = useState(0);
  
  const handleDragEnd = (_: any, info: PanInfo) => {
    if (info.offset.x > 100) {
      setExitX(200);
      onSwipe('right');
    } else if (info.offset.x < -100) {
      setExitX(-200);
      onSwipe('left');
    }
  };
  
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-3 sm:p-4">
      {/* Card stack */}
      <div className="relative w-full max-w-md h-[420px] sm:h-[480px] md:h-[500px]">
        <AnimatePresence>
          {steps.map((step, i) => {
            if (i < currentStep) return null;
            
            const isTop = i === currentStep;
            const stackOffset = Math.min(i - currentStep, 2);
            
            return (
              <motion.div
                key={i}
                className="absolute inset-0 bg-card rounded-2xl sm:rounded-3xl shadow-xl border border-border/50 p-4 sm:p-6 cursor-grab active:cursor-grabbing"
                style={{
                  zIndex: steps.length - i,
                  transformOrigin: 'center bottom',
                }}
                initial={{ 
                  scale: 1 - stackOffset * 0.05,
                  y: stackOffset * 15,
                  opacity: 1 - stackOffset * 0.2,
                }}
                animate={{ 
                  scale: 1 - stackOffset * 0.05,
                  y: stackOffset * 15,
                  opacity: 1 - stackOffset * 0.2,
                  rotateZ: 0,
                }}
                exit={{ 
                  x: exitX,
                  opacity: 0,
                  rotateZ: exitX > 0 ? 15 : -15,
                  transition: { duration: 0.3 }
                }}
                drag={isTop ? "x" : false}
                dragConstraints={{ left: 0, right: 0 }}
                onDragEnd={isTop ? handleDragEnd : undefined}
                whileDrag={{ scale: 1.02, cursor: 'grabbing' }}
              >
                {step}
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
      
      {/* Swipe hints */}
      <div className="flex justify-center gap-8 mt-8">
        <div className="text-sm text-muted-foreground">← Salta</div>
        <div className="text-sm text-muted-foreground">Conferma →</div>
      </div>
      
      {/* Progress */}
      <div className="flex gap-2 mt-6">
        {steps.map((_, i) => (
          <div
            key={i}
            className={`w-2 h-2 rounded-full transition-colors ${
              i <= currentStep ? 'bg-accent' : 'bg-muted'
            }`}
          />
        ))}
      </div>
    </div>
  );
}