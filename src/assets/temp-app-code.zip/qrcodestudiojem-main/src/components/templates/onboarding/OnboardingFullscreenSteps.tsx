import { motion, AnimatePresence } from 'framer-motion';
import { ReactNode } from 'react';

interface OnboardingFullscreenStepsProps {
  config: Record<string, any>;
  currentStep: number;
  totalSteps: number;
  children: ReactNode;
  backgroundGradient?: string;
}

export function OnboardingFullscreenSteps({ 
  config, 
  currentStep, 
  totalSteps, 
  children,
  backgroundGradient 
}: OnboardingFullscreenStepsProps) {
  const progress = config.progress || 'vertical_line';
  
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Animated background */}
      {backgroundGradient && (
        <motion.div
          className="absolute inset-0 opacity-30"
          animate={{
            background: backgroundGradient,
          }}
          transition={{ duration: 1 }}
        />
      )}
      
      {/* Vertical progress line */}
      {progress === 'vertical_line' && (
        <div className="absolute left-8 top-20 bottom-20 w-0.5 bg-muted">
          <motion.div
            className="w-full bg-accent origin-top"
            animate={{ 
              height: `${((currentStep + 1) / totalSteps) * 100}%` 
            }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          />
          
          {/* Step markers */}
          {Array.from({ length: totalSteps }).map((_, i) => (
            <motion.div
              key={i}
              className={`absolute left-1/2 -translate-x-1/2 w-3 h-3 rounded-full border-2 ${
                i <= currentStep 
                  ? 'bg-accent border-accent' 
                  : 'bg-background border-muted'
              }`}
              style={{ top: `${(i / (totalSteps - 1)) * 100}%` }}
              animate={{ scale: i === currentStep ? 1.3 : 1 }}
            />
          ))}
        </div>
      )}
      
      {/* Fullscreen content */}
      <div className="min-h-screen flex items-center justify-center p-4 sm:p-6 pl-12 sm:pl-16">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-sm sm:max-w-md lg:max-w-lg"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}