import { motion } from 'framer-motion';
import type { HomepageTemplateProps } from './types';
import { 
  HeroSection, 
  ActionButtonsSection, 
  FeaturedDishesSection, 
  MoodSection,
  EventsSectionWrapper,
  PromosSectionWrapper,
  RestaurantInfoSection,
  GoogleReviewsSection
} from './sections';
import { useHomeSections } from '@/hooks/useHomeSections';

export function HomepageMasonry({ config, sectionProps }: HomepageTemplateProps) {
  const { 
    restaurantConfig, 
    currentLanguage, 
    onButtonAction, 
    goToMenu, 
    onDishClick,
    recommendedDishes,
    featuredLoading,
    selectedMood,
    onSelectMood,
    onboardingAnswers,
    isDishRecommended,
    t
  } = sectionProps;

  const { isSectionEnabled } = useHomeSections();
  const tagline = restaurantConfig?.tagline?.[currentLanguage as 'it' | 'en'] || restaurantConfig?.tagline?.it || '';

  return (
    <div className="min-h-screen bg-background">
      {/* Minimal Hero */}
      <HeroSection
        name={restaurantConfig?.name}
        tagline={tagline}
        logoUrl={restaurantConfig?.logo_url}
        variant="minimal"
        className="pt-4"
      />

      {/* Masonry Grid Layout */}
      <main className="container px-4 py-6">
        <div className="grid grid-cols-12 gap-4 auto-rows-auto">
          {/* Action Buttons - Full width on mobile, 8 cols on desktop */}
          {isSectionEnabled('action_grid') && (
            <motion.div 
              className="col-span-12 md:col-span-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <ActionButtonsSection onAction={onButtonAction} variant="glass" />
            </motion.div>
          )}

          {/* Mood Selector - 4 cols on desktop */}
          {isSectionEnabled('mood_selector') && (
            <motion.div 
              className="col-span-12 md:col-span-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="h-full p-4 rounded-2xl bg-foreground/5 border border-border/20">
                <MoodSection
                  selectedMood={selectedMood}
                  onSelectMood={onSelectMood}
                  variant="compact"
                />
              </div>
            </motion.div>
          )}

          {/* Featured Dishes - Bento style */}
          {isSectionEnabled('featured') && (
            <motion.div 
              className="col-span-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <FeaturedDishesSection
                dishes={recommendedDishes}
                isLoading={featuredLoading}
                onDishClick={onDishClick}
                goToMenu={goToMenu}
                onboardingAnswers={onboardingAnswers}
                selectedMood={selectedMood}
                isDishRecommended={isDishRecommended}
                t={t}
                variant="bento"
              />
            </motion.div>
          )}

          {/* Promos - 6 cols */}
          {isSectionEnabled('promos') && (
            <motion.div 
              className="col-span-12 md:col-span-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <PromosSectionWrapper variant="glass" />
            </motion.div>
          )}

          {/* Events - 6 cols */}
          {isSectionEnabled('events') && (
            <motion.div 
              className="col-span-12 md:col-span-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <EventsSectionWrapper variant="glass" />
            </motion.div>
          )}

          {/* Reviews - 8 cols */}
          {isSectionEnabled('google_reviews') && (
            <motion.div 
              className="col-span-12 md:col-span-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <GoogleReviewsSection variant="glass" />
            </motion.div>
          )}

          {/* Restaurant Info - 4 cols */}
          {isSectionEnabled('restaurant_info') && (
            <motion.div 
              className="col-span-12 md:col-span-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
            >
              <RestaurantInfoSection variant="glass" />
            </motion.div>
          )}
        </div>

        {/* Decorative Liquid Shapes */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
          <motion.div
            className="absolute -top-20 -right-20 w-96 h-96 rounded-full bg-accent/10 blur-3xl"
            animate={{
              scale: [1, 1.2, 1],
              x: [0, 30, 0],
              y: [0, -20, 0],
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full bg-primary/10 blur-3xl"
            animate={{
              scale: [1, 0.9, 1],
              x: [0, -20, 0],
              y: [0, 30, 0],
            }}
            transition={{
              duration: 12,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 3,
            }}
          />
        </div>
      </main>
    </div>
  );
}
