import { motion } from 'framer-motion';
import { ActionButtonsGrid } from '@/components/client/ActionButtonsGrid';

interface ActionButtonsSectionProps {
  onAction: (actionType: string, actionValue: string | null) => void;
  variant?: 'default' | 'glass' | 'minimal' | 'floating';
  className?: string;
}

export function ActionButtonsSection({ 
  onAction, 
  variant = 'default',
  className = ''
}: ActionButtonsSectionProps) {
  if (variant === 'glass') {
    return (
      <motion.section
        className={`p-4 rounded-2xl bg-foreground/5 backdrop-blur-sm border border-border/20 ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <ActionButtonsGrid onAction={onAction} />
      </motion.section>
    );
  }

  if (variant === 'floating') {
    return (
      <motion.div
        className={`fixed bottom-20 left-4 right-4 z-40 ${className}`}
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <div className="p-3 rounded-2xl bg-background/90 backdrop-blur-xl border border-border/30 shadow-2xl">
          <ActionButtonsGrid onAction={onAction} />
        </div>
      </motion.div>
    );
  }

  if (variant === 'minimal') {
    return (
      <motion.section
        className={className}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4 }}
      >
        <ActionButtonsGrid onAction={onAction} />
      </motion.section>
    );
  }

  // Default variant
  return (
    <motion.section
      className={className}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <ActionButtonsGrid onAction={onAction} />
    </motion.section>
  );
}
