import { motion } from 'framer-motion';
import { MoodSelector } from '@/components/client/MoodSelector';

interface MoodSectionProps {
  selectedMood: string | null;
  onSelectMood: (mood: string | null) => void;
  title?: string;
  variant?: 'default' | 'compact' | 'glass' | 'inline';
  className?: string;
}

export function MoodSection({
  selectedMood,
  onSelectMood,
  title = 'Come ti senti?',
  variant = 'default',
  className = ''
}: MoodSectionProps) {
  if (variant === 'glass') {
    return (
      <motion.section
        className={`p-4 rounded-2xl bg-foreground/5 backdrop-blur-sm border border-border/20 space-y-3 ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          {title}
        </h2>
        <MoodSelector selectedMood={selectedMood} onSelectMood={onSelectMood} />
      </motion.section>
    );
  }

  if (variant === 'compact') {
    return (
      <motion.div
        className={className}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <MoodSelector selectedMood={selectedMood} onSelectMood={onSelectMood} />
      </motion.div>
    );
  }

  if (variant === 'inline') {
    return (
      <motion.div
        className={`flex items-center gap-4 ${className}`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <span className="text-sm text-muted-foreground whitespace-nowrap">{title}</span>
        <MoodSelector selectedMood={selectedMood} onSelectMood={onSelectMood} />
      </motion.div>
    );
  }

  // Default variant
  return (
    <motion.section
      className={`space-y-3 ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
        {title}
      </h2>
      <MoodSelector selectedMood={selectedMood} onSelectMood={onSelectMood} />
    </motion.section>
  );
}
