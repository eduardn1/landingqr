import { motion } from 'framer-motion';
import type { HomepageTemplateProps } from './types';
import { 
  ActionButtonsSection, 
  FeaturedDishesSection, 
  MoodSection,
  EventsSectionWrapper,
  PromosSectionWrapper,
  RestaurantInfoSection,
  GoogleReviewsSection
} from './sections';
import { useHomeSections } from '@/hooks/useHomeSections';

interface HomepageBentoMinimalProps {
  config: Record<string, any>;
  sectionProps?: HomepageTemplateProps['sectionProps'];
  children?: React.ReactNode;
}

export function HomepageBentoMinimal({ config, sectionProps, children }: HomepageBentoMinimalProps) {
  const typography = config.typography || {};
  const { isSectionEnabled } = useHomeSections();

  // If sectionProps provided, use new bento grid system
  if (sectionProps) {
    const { 
      restaurantConfig, 
      currentLanguage, 
      onButtonAction, 
      goToMenu, 
      onDishClick,
      recommendedDishes,
      featuredLoading,
      selectedMood,
      onSelectMood,
      onboardingAnswers,
      isDishRecommended,
      t
    } = sectionProps;
    
    const tagline = restaurantConfig?.tagline?.[currentLanguage as 'it' | 'en'] || restaurantConfig?.tagline?.it || '';

    return (
      <div className="min-h-screen bg-background">
        <div className="container px-4 py-8 md:py-12">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-12 gap-3 md:gap-4"
          >
            {/* Header/Hero - Full Width */}
            <motion.div
              className="col-span-12 p-4 sm:p-5 md:p-6 rounded-xl sm:rounded-2xl bg-gradient-to-br from-accent/10 to-transparent border border-border/30"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ y: -2 }}
            >
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-3 sm:gap-4 text-center sm:text-left">
                {restaurantConfig?.logo_url && (
                  <img 
                    src={restaurantConfig.logo_url} 
                    alt={restaurantConfig?.name} 
                    className="h-12 w-12 sm:h-14 sm:w-14 object-contain"
                  />
                )}
                <div>
                  <h1 className="text-xl sm:text-2xl md:text-3xl font-bold text-foreground">
                    {restaurantConfig?.name || 'Il Locale'}
                  </h1>
                  {tagline && (
                    <p className="text-xs sm:text-sm text-muted-foreground mt-1">{tagline}</p>
                  )}
                </div>
              </div>
            </motion.div>

            {/* Action Buttons - 8 cols on desktop */}
            {isSectionEnabled('action_grid') && (
              <BentoItem colSpan="col-span-12 md:col-span-8">
                <div className="p-4">
                  <ActionButtonsSection onAction={onButtonAction} variant="minimal" />
                </div>
              </BentoItem>
            )}

            {/* Mood Selector - 4 cols on desktop */}
            {isSectionEnabled('mood_selector') && (
              <BentoItem colSpan="col-span-12 md:col-span-4">
                <div className="p-4 h-full flex flex-col justify-center">
                  <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
                    Come ti senti?
                  </h3>
                  <MoodSection
                    selectedMood={selectedMood}
                    onSelectMood={onSelectMood}
                    variant="compact"
                  />
                </div>
              </BentoItem>
            )}

            {/* Featured Dishes - Full width, Bento layout */}
            {isSectionEnabled('featured') && (
              <div className="col-span-12">
                <FeaturedDishesSection
                  dishes={recommendedDishes}
                  isLoading={featuredLoading}
                  onDishClick={onDishClick}
                  goToMenu={goToMenu}
                  onboardingAnswers={onboardingAnswers}
                  selectedMood={selectedMood}
                  isDishRecommended={isDishRecommended}
                  t={t}
                  variant="bento"
                />
              </div>
            )}

            {/* Promos - 6 cols */}
            {isSectionEnabled('promos') && (
              <BentoItem colSpan="col-span-12 md:col-span-6">
                <div className="p-4">
                  <PromosSectionWrapper />
                </div>
              </BentoItem>
            )}

            {/* Events - 6 cols */}
            {isSectionEnabled('events') && (
              <BentoItem colSpan="col-span-12 md:col-span-6">
                <div className="p-4">
                  <EventsSectionWrapper />
                </div>
              </BentoItem>
            )}

            {/* Reviews - 8 cols */}
            {isSectionEnabled('google_reviews') && (
              <BentoItem colSpan="col-span-12 md:col-span-8">
                <div className="p-4">
                  <GoogleReviewsSection />
                </div>
              </BentoItem>
            )}

            {/* Restaurant Info - 4 cols */}
            {isSectionEnabled('restaurant_info') && (
              <BentoItem colSpan="col-span-12 md:col-span-4">
                <div className="p-4">
                  <RestaurantInfoSection variant="minimal" />
                </div>
              </BentoItem>
            )}
          </motion.div>
        </div>
      </div>
    );
  }

  // Legacy mode
  return (
    <div className="min-h-screen bg-background">
      <div className="container px-4 py-8 md:py-16">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-12 gap-3 md:gap-4"
        >
          {children}
        </motion.div>
      </div>
    </div>
  );
}

// Bento grid item wrapper
interface BentoItemProps {
  children: React.ReactNode;
  colSpan?: string;
  rowSpan?: string;
  className?: string;
}

export function BentoItem({ children, colSpan = "col-span-12", rowSpan = "", className = "" }: BentoItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className={`${colSpan} ${rowSpan} ${className} rounded-2xl bg-secondary/30 border border-border/30 overflow-hidden`}
    >
      {children}
    </motion.div>
  );
}
