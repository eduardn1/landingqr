import { motion } from 'framer-motion';

interface HeroSectionProps {
  name?: string;
  tagline?: string;
  coverImage?: string;
  logoUrl?: string;
  variant?: 'minimal' | 'full' | 'split' | 'overlay';
  className?: string;
}

export function HeroSection({ 
  name, 
  tagline, 
  coverImage, 
  logoUrl,
  variant = 'minimal',
  className = ''
}: HeroSectionProps) {
  if (variant === 'full') {
    return (
      <div className={`relative min-h-[60vh] flex items-center justify-center ${className}`}>
        {coverImage && (
          <>
            <img 
              src={coverImage} 
              alt={name || 'Restaurant'} 
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          </>
        )}
        <motion.div 
          className="relative z-10 text-center space-y-4 px-4"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {logoUrl && (
            <img src={logoUrl} alt={name} className="h-20 mx-auto" />
          )}
          <h1 className="text-4xl md:text-5xl font-bold text-foreground drop-shadow-lg">
            {name}
          </h1>
          {tagline && (
            <p className="text-lg text-foreground/80 max-w-md mx-auto">
              {tagline}
            </p>
          )}
        </motion.div>
      </div>
    );
  }

  if (variant === 'split') {
    return (
      <div className={`grid md:grid-cols-2 gap-6 md:gap-0 min-h-[50vh] ${className}`}>
        <motion.div 
          className="flex flex-col justify-center px-6 md:px-12 py-8"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          {logoUrl && (
            <img src={logoUrl} alt={name} className="h-16 mb-6 object-contain self-start" />
          )}
          <h1 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            {name}
          </h1>
          {tagline && (
            <p className="text-lg text-muted-foreground max-w-md">
              {tagline}
            </p>
          )}
        </motion.div>
        {coverImage && (
          <motion.div 
            className="relative h-64 md:h-auto"
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
          >
            <img 
              src={coverImage} 
              alt={name || 'Restaurant'} 
              className="absolute inset-0 w-full h-full object-cover md:rounded-l-3xl"
            />
          </motion.div>
        )}
      </div>
    );
  }

  if (variant === 'overlay') {
    return (
      <div className={`relative min-h-[70vh] ${className}`}>
        {coverImage && (
          <img 
            src={coverImage} 
            alt={name || 'Restaurant'} 
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/40 to-background" />
        <div className="relative z-10 h-full min-h-[70vh] flex flex-col">
          <motion.div 
            className="flex-1 flex items-center justify-center p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="text-center space-y-6 max-w-2xl">
              {logoUrl && (
                <motion.img 
                  src={logoUrl} 
                  alt={name} 
                  className="h-24 mx-auto"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.5 }}
                />
              )}
              <h1 className="text-4xl md:text-6xl font-bold text-foreground">
                {name}
              </h1>
              {tagline && (
                <p className="text-xl text-muted-foreground">
                  {tagline}
                </p>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  // Default minimal variant
  return (
    <motion.section 
      className={`text-center space-y-2 py-8 ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      {logoUrl && (
        <img src={logoUrl} alt={name} className="h-12 mx-auto mb-4" />
      )}
      <h1 className="text-2xl font-medium text-foreground">
        {name || 'Il Locale'}
      </h1>
      {tagline && (
        <p className="text-sm text-muted-foreground">
          {tagline}
        </p>
      )}
    </motion.section>
  );
}
