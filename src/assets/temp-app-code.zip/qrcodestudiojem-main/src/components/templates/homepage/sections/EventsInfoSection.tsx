import { motion } from 'framer-motion';
import { EventsSection } from '@/components/client/EventsSection';
import { PromosSection } from '@/components/client/PromosSection';
import { RestaurantInfoCard } from '@/components/RestaurantInfoCard';
import { GoogleReviews } from '@/components/client/GoogleReviews';

interface EventsSectionWrapperProps {
  variant?: 'default' | 'glass' | 'card';
  className?: string;
}

export function EventsSectionWrapper({ variant = 'default', className = '' }: EventsSectionWrapperProps) {
  if (variant === 'glass') {
    return (
      <motion.div
        className={`p-4 rounded-2xl bg-foreground/5 backdrop-blur-sm border border-border/20 ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <EventsSection />
      </motion.div>
    );
  }

  if (variant === 'card') {
    return (
      <motion.div
        className={`p-4 rounded-2xl bg-card border border-border ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <EventsSection />
      </motion.div>
    );
  }

  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <EventsSection />
    </motion.div>
  );
}

interface PromosSectionWrapperProps {
  variant?: 'default' | 'glass' | 'card';
  className?: string;
}

export function PromosSectionWrapper({ variant = 'default', className = '' }: PromosSectionWrapperProps) {
  if (variant === 'glass') {
    return (
      <motion.div
        className={`p-4 rounded-2xl bg-foreground/5 backdrop-blur-sm border border-border/20 ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <PromosSection />
      </motion.div>
    );
  }

  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <PromosSection />
    </motion.div>
  );
}

interface RestaurantInfoSectionProps {
  title?: string;
  variant?: 'default' | 'glass' | 'minimal';
  className?: string;
}

export function RestaurantInfoSection({ 
  title = 'Info & Contatti',
  variant = 'default', 
  className = '' 
}: RestaurantInfoSectionProps) {
  if (variant === 'glass') {
    return (
      <motion.section
        className={`p-4 rounded-2xl bg-foreground/5 backdrop-blur-sm border border-border/20 ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">
          {title}
        </h2>
        <RestaurantInfoCard />
      </motion.section>
    );
  }

  if (variant === 'minimal') {
    return (
      <motion.div
        className={className}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <RestaurantInfoCard />
      </motion.div>
    );
  }

  return (
    <motion.section
      className={className}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">
        {title}
      </h2>
      <RestaurantInfoCard />
    </motion.section>
  );
}

interface GoogleReviewsSectionProps {
  variant?: 'default' | 'glass';
  className?: string;
}

export function GoogleReviewsSection({ variant = 'default', className = '' }: GoogleReviewsSectionProps) {
  if (variant === 'glass') {
    return (
      <motion.div
        className={`p-4 rounded-2xl bg-foreground/5 backdrop-blur-sm border border-border/20 ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <GoogleReviews />
      </motion.div>
    );
  }

  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <GoogleReviews />
    </motion.div>
  );
}
