import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import type { HomepageTemplateProps } from './types';
import { 
  ActionButtonsSection, 
  FeaturedDishesSection, 
  MoodSection,
  EventsSectionWrapper,
  PromosSectionWrapper,
  RestaurantInfoSection,
  GoogleReviewsSection
} from './sections';
import { useHomeSections } from '@/hooks/useHomeSections';

interface HomepageParallaxProps {
  config: Record<string, any>;
  sectionProps?: HomepageTemplateProps['sectionProps'];
  heroImage?: string;
  heroContent?: React.ReactNode;
  children?: React.ReactNode;
}

export function HomepageParallax({ config, sectionProps, heroImage, heroContent, children }: HomepageParallaxProps) {
  const heroConfig = config.hero_config || {};
  const containerRef = useRef<HTMLDivElement>(null);
  const { isSectionEnabled } = useHomeSections();
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [0, heroConfig.parallax_speed ? 300 * heroConfig.parallax_speed : 150]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 1.1]);

  // If sectionProps provided, use new system
  if (sectionProps) {
    const { 
      restaurantConfig, 
      currentLanguage, 
      onButtonAction, 
      goToMenu, 
      onDishClick,
      recommendedDishes,
      featuredLoading,
      selectedMood,
      onSelectMood,
      onboardingAnswers,
      isDishRecommended,
      t
    } = sectionProps;
    
    const tagline = restaurantConfig?.tagline?.[currentLanguage as 'it' | 'en'] || restaurantConfig?.tagline?.it || '';
    const coverImage = restaurantConfig?.cover_image_url;

    return (
      <div className="min-h-screen bg-background" ref={containerRef}>
        {/* Parallax Hero */}
        <div 
          className="relative overflow-hidden"
          style={{ height: heroConfig.height || '100vh' }}
        >
          {/* Parallax background image */}
          <motion.div
            className="absolute inset-0"
            style={{ y, scale }}
          >
            {coverImage ? (
              <img 
                src={coverImage} 
                alt={restaurantConfig?.name || 'Restaurant'} 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-b from-accent/20 to-background" />
            )}
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-transparent to-background" />
          </motion.div>
          
          {/* Hero content */}
          <motion.div
            className="relative z-10 h-full flex flex-col items-center justify-center"
            style={{ opacity }}
          >
            <div className="container px-4 text-center">
              {restaurantConfig?.logo_url && (
                <motion.img 
                  src={restaurantConfig.logo_url} 
                  alt={restaurantConfig?.name} 
                  className="h-14 sm:h-16 md:h-20 mx-auto mb-4 sm:mb-6"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5 }}
                />
              )}
              <motion.h1 
                className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-3 sm:mb-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                {restaurantConfig?.name || 'Il Locale'}
              </motion.h1>
              {tagline && (
                <motion.p 
                  className="text-base sm:text-lg md:text-xl text-muted-foreground max-w-xl mx-auto px-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  {tagline}
                </motion.p>
              )}
            </div>
          </motion.div>
          
          {/* Scroll indicator */}
          <motion.div
            className="absolute bottom-8 left-1/2 -translate-x-1/2"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            style={{ opacity }}
          >
            <div className="w-6 h-10 rounded-full border-2 border-foreground/50 flex items-start justify-center p-2">
              <motion.div
                className="w-1.5 h-3 rounded-full bg-foreground/50"
                animate={{ y: [0, 12, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              />
            </div>
          </motion.div>
        </div>
        
        {/* Content sections */}
        <main className="relative z-20 bg-background container px-4 py-8 space-y-8">
          {/* Action Buttons */}
          {isSectionEnabled('action_grid') && (
            <ActionButtonsSection onAction={onButtonAction} variant="default" />
          )}

          {/* Mood Selector */}
          {isSectionEnabled('mood_selector') && (
            <MoodSection
              selectedMood={selectedMood}
              onSelectMood={onSelectMood}
              variant="default"
            />
          )}

          {/* Featured Dishes */}
          {isSectionEnabled('featured') && (
            <FeaturedDishesSection
              dishes={recommendedDishes}
              isLoading={featuredLoading}
              onDishClick={onDishClick}
              goToMenu={goToMenu}
              onboardingAnswers={onboardingAnswers}
              selectedMood={selectedMood}
              isDishRecommended={isDishRecommended}
              t={t}
              variant="carousel"
            />
          )}

          {/* Promos */}
          {isSectionEnabled('promos') && (
            <PromosSectionWrapper />
          )}

          {/* Events */}
          {isSectionEnabled('events') && (
            <EventsSectionWrapper />
          )}

          {/* Reviews */}
          {isSectionEnabled('google_reviews') && (
            <GoogleReviewsSection />
          )}

          {/* Restaurant Info */}
          {isSectionEnabled('restaurant_info') && (
            <RestaurantInfoSection />
          )}
        </main>
      </div>
    );
  }

  // Legacy mode
  return (
    <div className="min-h-screen bg-background" ref={containerRef}>
      <div 
        className="relative overflow-hidden"
        style={{ height: heroConfig.height || '100vh' }}
      >
        <motion.div className="absolute inset-0" style={{ y, scale }}>
          {heroImage ? (
            <img src={heroImage} alt="Hero" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-b from-accent/20 to-background" />
          )}
          <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-transparent to-background" />
        </motion.div>
        <motion.div className="relative z-10 h-full flex items-center justify-center" style={{ opacity }}>
          <div className="container px-4 text-center">{heroContent}</div>
        </motion.div>
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          style={{ opacity }}
        >
          <div className="w-6 h-10 rounded-full border-2 border-foreground/50 flex items-start justify-center p-2">
            <motion.div
              className="w-1.5 h-3 rounded-full bg-foreground/50"
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </div>
        </motion.div>
      </div>
      <div className="relative z-20 bg-background">{children}</div>
    </div>
  );
}
