import { motion } from 'framer-motion';
import type { HomepageTemplateProps } from './types';
import { 
  HeroSection, 
  ActionButtonsSection, 
  FeaturedDishesSection, 
  MoodSection,
  EventsSectionWrapper,
  PromosSectionWrapper,
  RestaurantInfoSection,
  GoogleReviewsSection
} from './sections';
import { useHomeSections } from '@/hooks/useHomeSections';

export function HomepageVideoBackground({ config, sectionProps }: HomepageTemplateProps) {
  const { 
    restaurantConfig, 
    currentLanguage, 
    onButtonAction, 
    goToMenu, 
    onDishClick,
    recommendedDishes,
    featuredLoading,
    selectedMood,
    onSelectMood,
    onboardingAnswers,
    isDishRecommended,
    t
  } = sectionProps;

  const { isSectionEnabled } = useHomeSections();
  const tagline = restaurantConfig?.tagline?.[currentLanguage as 'it' | 'en'] || restaurantConfig?.tagline?.it || '';
  const heroConfig = config.hero_config || {};

  return (
    <div className="min-h-screen bg-background">
      {/* Video Background Hero */}
      <div className="relative min-h-[80vh] overflow-hidden">
        {/* Video or Image Background */}
        {heroConfig.video_url ? (
          <video
            autoPlay
            loop
            muted
            playsInline
            className="absolute inset-0 w-full h-full object-cover"
          >
            <source src={heroConfig.video_url} type="video/mp4" />
          </video>
        ) : restaurantConfig?.cover_image_url ? (
          <img 
            src={restaurantConfig.cover_image_url} 
            alt={restaurantConfig?.name} 
            className="absolute inset-0 w-full h-full object-cover"
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-background" />
        )}
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        
        {/* Content */}
        <div className="relative z-10 min-h-[80vh] flex flex-col justify-end pb-8 sm:pb-12">
          <div className="container px-4">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-xl"
            >
              {restaurantConfig?.logo_url && (
                <img 
                  src={restaurantConfig.logo_url} 
                  alt={restaurantConfig?.name} 
                  className="h-12 sm:h-14 md:h-16 mb-4 sm:mb-6"
                />
              )}
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-foreground mb-3 sm:mb-4">
                {restaurantConfig?.name || 'Il Locale'}
              </h1>
              {tagline && (
                <p className="text-base sm:text-lg text-muted-foreground mb-4 sm:mb-6">
                  {tagline}
                </p>
              )}
              
              {/* Floating Action Buttons */}
              {isSectionEnabled('action_grid') && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <ActionButtonsSection onAction={onButtonAction} variant="glass" />
                </motion.div>
              )}
            </motion.div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container px-4 py-8 space-y-8">
        {/* Mood Selector */}
        {isSectionEnabled('mood_selector') && (
          <MoodSection
            selectedMood={selectedMood}
            onSelectMood={onSelectMood}
            variant="default"
          />
        )}

        {/* Featured Dishes */}
        {isSectionEnabled('featured') && (
          <FeaturedDishesSection
            dishes={recommendedDishes}
            isLoading={featuredLoading}
            onDishClick={onDishClick}
            goToMenu={goToMenu}
            onboardingAnswers={onboardingAnswers}
            selectedMood={selectedMood}
            isDishRecommended={isDishRecommended}
            t={t}
            variant="grid"
          />
        )}

        {/* Promos */}
        {isSectionEnabled('promos') && (
          <PromosSectionWrapper />
        )}

        {/* Events */}
        {isSectionEnabled('events') && (
          <EventsSectionWrapper />
        )}

        {/* Reviews */}
        {isSectionEnabled('google_reviews') && (
          <GoogleReviewsSection />
        )}

        {/* Restaurant Info */}
        {isSectionEnabled('restaurant_info') && (
          <RestaurantInfoSection />
        )}
      </main>
    </div>
  );
}
