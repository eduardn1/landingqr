import { motion } from 'framer-motion';
import type { HomepageTemplateProps } from './types';
import { DynamicHomeSections } from '@/components/client/DynamicHomeSections';

interface HomepageClassicProps {
  config: Record<string, any>;
  sectionProps?: HomepageTemplateProps['sectionProps'];
  children?: React.ReactNode;
}

export function HomepageClassic({ config, sectionProps, children }: HomepageClassicProps) {
  const animations = config.animations || {};
  
  // If sectionProps provided, render with new system
  if (sectionProps) {
    const { restaurantConfig, currentLanguage } = sectionProps;
    const tagline = restaurantConfig?.tagline?.[currentLanguage as 'it' | 'en'] || restaurantConfig?.tagline?.it || '';

    return (
      <div className="min-h-screen bg-background">
        <motion.div
          initial={animations.scroll_reveal ? { opacity: 0 } : undefined}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <main className="container px-4 py-6 space-y-8">
            {/* Welcome Section */}
            <motion.section 
              className="text-center space-y-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-2xl font-medium text-foreground">
                {restaurantConfig?.name || 'Il Locale'}
              </h1>
              <p className="text-sm text-muted-foreground">
                {tagline}
              </p>
            </motion.section>

            {/* Dynamic Sections */}
            <DynamicHomeSections
              onOpenAbout={sectionProps.onOpenAbout}
              onButtonAction={sectionProps.onButtonAction}
              goToMenu={sectionProps.goToMenu}
              onDishClick={sectionProps.onDishClick}
              onOpenFavorites={sectionProps.onOpenFavorites}
              handleResetPreferences={sectionProps.handleResetPreferences}
              selectedMood={sectionProps.selectedMood}
              onSelectMood={sectionProps.onSelectMood}
              recommendedDishes={sectionProps.recommendedDishes}
              shareableDishes={sectionProps.shareableDishes}
              featuredLoading={sectionProps.featuredLoading}
              categoriesLoading={sectionProps.categoriesLoading}
              onboardingAnswers={sectionProps.onboardingAnswers}
              favoritesCount={sectionProps.favoritesCount}
              isAuthenticated={sectionProps.isAuthenticated}
              isAuthLoading={sectionProps.isAuthLoading}
              isDishRecommended={sectionProps.isDishRecommended}
              t={sectionProps.t}
            />
          </main>
        </motion.div>
      </div>
    );
  }

  // Legacy mode - just wrap children
  return (
    <div className="min-h-screen bg-background">
      <motion.div
        initial={animations.scroll_reveal ? { opacity: 0 } : undefined}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {children}
      </motion.div>
    </div>
  );
}
