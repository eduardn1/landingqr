import type { Dish } from '@/lib/mockData';
import { ReactNode } from 'react';

// All props needed to render homepage sections
export interface HomepageSectionProps {
  // Handlers
  onOpenAbout: () => void;
  onButtonAction: (actionType: string, actionValue: string | null) => void;
  goToMenu: () => void;
  onDishClick: (dish: Dish) => void;
  onOpenFavorites: () => void;
  handleResetPreferences: () => void;
  
  // Data
  selectedMood: string | null;
  onSelectMood: (mood: string | null) => void;
  recommendedDishes: Dish[];
  shareableDishes: Dish[];
  featuredLoading: boolean;
  categoriesLoading: boolean;
  onboardingAnswers: any;
  favoritesCount: number;
  isAuthenticated: boolean;
  isAuthLoading: boolean;
  isDishRecommended: (dish: Dish) => boolean;
  t: (key: string) => string;
  
  // Restaurant config
  restaurantConfig?: {
    name?: string;
    tagline?: { it?: string; en?: string };
    cover_image_url?: string;
    logo_url?: string;
  };
  currentLanguage: string;
}

export interface HomepageTemplateProps {
  config: Record<string, any>;
  sectionProps: HomepageSectionProps;
  children?: ReactNode;
}

// Header variant types
export type HeaderVariant = 'default' | 'minimal' | 'centered' | 'floating';

// Footer variant types  
export type FooterVariant = 'default' | 'minimal' | 'expanded' | 'split';
