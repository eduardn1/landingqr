import { motion } from 'framer-motion';
import type { HomepageTemplateProps } from './types';
import { 
  ActionButtonsSection, 
  FeaturedDishesSection, 
  MoodSection,
  EventsSectionWrapper,
  PromosSectionWrapper,
  RestaurantInfoSection,
  GoogleReviewsSection
} from './sections';
import { useHomeSections } from '@/hooks/useHomeSections';

interface HomepageAuroraProps {
  config: Record<string, any>;
  sectionProps?: HomepageTemplateProps['sectionProps'];
  heroContent?: React.ReactNode;
  children?: React.ReactNode;
}

export function HomepageAurora({ config, sectionProps, heroContent, children }: HomepageAuroraProps) {
  const heroConfig = config.hero_config || {};
  // Use gradient colors from config (from backend) or fallback to nice defaults
  const rawGradientColors = heroConfig.gradient_colors;
  const gradientColors = Array.isArray(rawGradientColors) && rawGradientColors.length >= 2
    ? rawGradientColors 
    : ['#757f9a', '#d7dde8', '#A855F7', '#4ECDC4'];
  const { isSectionEnabled } = useHomeSections();

  // If sectionProps provided, use new system
  if (sectionProps) {
    const { 
      restaurantConfig, 
      currentLanguage, 
      onButtonAction, 
      goToMenu, 
      onDishClick,
      recommendedDishes,
      featuredLoading,
      selectedMood,
      onSelectMood,
      onboardingAnswers,
      isDishRecommended,
      t
    } = sectionProps;
    
    const tagline = restaurantConfig?.tagline?.[currentLanguage as 'it' | 'en'] || restaurantConfig?.tagline?.it || '';

    return (
      <div className="min-h-screen bg-background overflow-hidden">
        {/* Aurora gradient animated background */}
        <div className="relative min-h-[80vh]">
          {/* Aurora layers */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute inset-0 bg-[#0a0a0a]" />
            
            <motion.div
              className="absolute inset-0 opacity-50"
              style={{
                background: `radial-gradient(ellipse 80% 50% at 50% 0%, ${gradientColors[0]}40 0%, transparent 50%)`,
              }}
              animate={{
                x: [0, 50, 0, -50, 0],
                y: [0, -20, 0, 20, 0],
              }}
              transition={{
                duration: 20,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
            <motion.div
              className="absolute inset-0 opacity-40"
              style={{
                background: `radial-gradient(ellipse 60% 40% at 30% 20%, ${gradientColors[1]}50 0%, transparent 50%)`,
              }}
              animate={{
                x: [0, -30, 0, 30, 0],
                y: [0, 30, 0, -30, 0],
              }}
              transition={{
                duration: 15,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 2,
              }}
            />
            <motion.div
              className="absolute inset-0 opacity-30"
              style={{
                background: `radial-gradient(ellipse 70% 35% at 70% 30%, ${gradientColors[2]}40 0%, transparent 50%)`,
              }}
              animate={{
                x: [0, 40, 0, -40, 0],
                y: [0, -15, 0, 15, 0],
              }}
              transition={{
                duration: 18,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 4,
              }}
            />
            
            {/* Noise texture overlay */}
            <div 
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 256 256\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noise\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noise)\'/%3E%3C/svg%3E")',
              }}
            />
          </div>
          
          {/* Hero content */}
          <div className="relative z-10 container px-4 min-h-[80vh] flex flex-col items-center justify-center py-8 sm:py-12 md:py-16">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="max-w-2xl w-full text-center px-2"
            >
              {restaurantConfig?.logo_url && (
                <motion.img 
                  src={restaurantConfig.logo_url} 
                  alt={restaurantConfig?.name} 
                  className="h-14 sm:h-16 md:h-20 mx-auto mb-4 sm:mb-6"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                />
              )}
              <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-3 sm:mb-4">
                {restaurantConfig?.name || 'Il Locale'}
              </h1>
              {tagline && (
                <p className="text-base sm:text-lg text-white/70 mb-6 sm:mb-8 px-2">{tagline}</p>
              )}
              
              {/* Action buttons with neon glow effect */}
              {isSectionEnabled('action_grid') && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  <ActionButtonsSection onAction={onButtonAction} variant="glass" />
                </motion.div>
              )}
            </motion.div>
          </div>
          
          {/* Neon glow line at bottom */}
          <div 
            className="absolute bottom-0 left-0 right-0 h-px"
            style={{
              background: `linear-gradient(90deg, transparent, ${gradientColors[0]}, ${gradientColors[1]}, ${gradientColors[2]}, transparent)`,
              boxShadow: `0 0 20px ${gradientColors[0]}50, 0 0 40px ${gradientColors[1]}30`,
            }}
          />
        </div>
        
        {/* Content sections */}
        <main className="relative z-20 container px-4 py-8 space-y-8 bg-background">
          {/* Mood Selector */}
          {isSectionEnabled('mood_selector') && (
            <MoodSection
              selectedMood={selectedMood}
              onSelectMood={onSelectMood}
              variant="default"
            />
          )}

          {/* Featured Dishes */}
          {isSectionEnabled('featured') && (
            <FeaturedDishesSection
              dishes={recommendedDishes}
              isLoading={featuredLoading}
              onDishClick={onDishClick}
              goToMenu={goToMenu}
              onboardingAnswers={onboardingAnswers}
              selectedMood={selectedMood}
              isDishRecommended={isDishRecommended}
              t={t}
              variant="carousel"
            />
          )}

          {/* Promos */}
          {isSectionEnabled('promos') && (
            <PromosSectionWrapper />
          )}

          {/* Events */}
          {isSectionEnabled('events') && (
            <EventsSectionWrapper />
          )}

          {/* Reviews */}
          {isSectionEnabled('google_reviews') && (
            <GoogleReviewsSection />
          )}

          {/* Restaurant Info */}
          {isSectionEnabled('restaurant_info') && (
            <RestaurantInfoSection />
          )}
        </main>
      </div>
    );
  }

  // Legacy mode
  return (
    <div className="min-h-screen bg-background overflow-hidden">
      <div className="relative min-h-screen">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-[#0a0a0a]" />
          <motion.div
            className="absolute inset-0 opacity-50"
            style={{ background: `radial-gradient(ellipse 80% 50% at 50% 0%, ${gradientColors[0]}40 0%, transparent 50%)` }}
            animate={{ x: [0, 50, 0, -50, 0], y: [0, -20, 0, 20, 0] }}
            transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>
        <div className="relative z-10 container px-4 min-h-screen flex items-center justify-center py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="max-w-4xl w-full text-center"
          >
            {heroContent}
          </motion.div>
        </div>
        <div 
          className="absolute bottom-0 left-0 right-0 h-px"
          style={{
            background: `linear-gradient(90deg, transparent, ${gradientColors[0]}, ${gradientColors[1]}, ${gradientColors[2]}, transparent)`,
            boxShadow: `0 0 20px ${gradientColors[0]}50, 0 0 40px ${gradientColors[1]}30`,
          }}
        />
      </div>
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="relative z-20"
      >
        {children}
      </motion.div>
    </div>
  );
}
