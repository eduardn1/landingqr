import { motion } from 'framer-motion';
import { ChevronRight, Sparkles, HelpCircle } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { DishCard } from '@/components/DishCard';
import { DishCarouselSkeleton, DishGridSkeleton } from '@/components/client/DishCardSkeleton';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import type { Dish } from '@/lib/mockData';

interface FeaturedDishesSectionProps {
  dishes: Dish[];
  isLoading: boolean;
  onDishClick: (dish: Dish) => void;
  goToMenu: () => void;
  onboardingAnswers?: any;
  selectedMood?: string | null;
  isDishRecommended: (dish: Dish) => boolean;
  t: (key: string) => string;
  title?: string;
  variant?: 'carousel' | 'grid' | 'bento' | 'masonry';
  className?: string;
}

export function FeaturedDishesSection({
  dishes,
  isLoading,
  onDishClick,
  goToMenu,
  onboardingAnswers,
  selectedMood,
  isDishRecommended,
  t,
  title,
  variant = 'carousel',
  className = ''
}: FeaturedDishesSectionProps) {
  const isMobile = useIsMobile();
  const hasQuizAnswers = onboardingAnswers && Object.keys(onboardingAnswers).length > 0;
  const quizStepCount = hasQuizAnswers 
    ? Object.keys(onboardingAnswers).filter(key => key !== 'welcome').length 
    : 0;
  
  const hasPersonalization = hasQuizAnswers || selectedMood;
  const tipMessage = hasQuizAnswers 
    ? "Grazie al quiz, abbiamo trovato questi piatti perfetti per te!"
    : "In base al mood selezionato, ecco i piatti che ti consigliamo!";

  const renderHeader = () => (
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-2">
        {hasPersonalization ? (
          isMobile ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-accent/20 to-accent/10 border border-accent/30">
              <Sparkles className="w-3.5 h-3.5 text-accent" />
              <span className="text-xs font-semibold text-accent">Per Te</span>
            </div>
          ) : (
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-accent/20 to-accent/10 border border-accent/30 cursor-help">
                  <Sparkles className="w-3.5 h-3.5 text-accent" />
                  <span className="text-xs font-semibold text-accent">Per Te</span>
                  {quizStepCount > 0 && (
                    <span className="text-[10px] text-accent/80 bg-accent/15 px-1.5 py-0.5 rounded-full">
                      {quizStepCount} {quizStepCount === 1 ? 'risposta' : 'risposte'}
                    </span>
                  )}
                  <HelpCircle className="w-3 h-3 text-accent/50" />
                </div>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="max-w-[220px] text-center">
                <p className="text-xs">{tipMessage}</p>
              </TooltipContent>
            </Tooltip>
          )
        ) : (
          <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            {title || t('featured')}
          </h2>
        )}
      </div>
      <button
        onClick={goToMenu}
        className="text-xs text-foreground bg-accent/20 hover:bg-accent/30 flex items-center gap-1 transition-colors font-semibold px-3 py-1.5 rounded-full border border-accent/40 hover:border-accent/60"
      >
        {t('viewMenu')}
        <ChevronRight className="w-3 h-3" />
      </button>
    </div>
  );

  if (isLoading) {
    return (
      <motion.section
        className={`space-y-4 ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {renderHeader()}
        {isMobile ? <DishCarouselSkeleton count={4} /> : <DishGridSkeleton count={4} compact />}
      </motion.section>
    );
  }

  // Bento variant - asymmetric grid
  if (variant === 'bento') {
    return (
      <motion.section
        className={`space-y-4 ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {renderHeader()}
        <div className="grid grid-cols-12 gap-3">
          {dishes.slice(0, 4).map((dish, index) => (
            <motion.div
              key={dish.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className={
                index === 0 ? 'col-span-12 md:col-span-8 row-span-2' :
                index === 1 ? 'col-span-6 md:col-span-4' :
                'col-span-6 md:col-span-4'
              }
            >
              <DishCard
                dish={dish}
                compact={index !== 0}
                onClick={() => onDishClick(dish)}
                isRecommended={isDishRecommended(dish)}
              />
            </motion.div>
          ))}
        </div>
      </motion.section>
    );
  }

  // Grid variant
  if (variant === 'grid') {
    return (
      <motion.section
        className={`space-y-4 ${className}`}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {renderHeader()}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {dishes.map((dish, index) => (
            <motion.div
              key={dish.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <DishCard
                dish={dish}
                compact
                onClick={() => onDishClick(dish)}
                isRecommended={isDishRecommended(dish)}
              />
            </motion.div>
          ))}
        </div>
      </motion.section>
    );
  }

  // Default carousel variant
  return (
    <motion.section
      className={`space-y-4 ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {/* Mobile tip banner */}
      {hasPersonalization && isMobile && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 rounded-xl bg-gradient-to-r from-accent/15 to-accent/5 border border-accent/20"
        >
          <div className="flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-semibold text-accent">Per Te</span>
                {quizStepCount > 0 && (
                  <span className="text-[10px] text-accent/80 bg-accent/20 px-2 py-0.5 rounded-full">
                    {quizStepCount} {quizStepCount === 1 ? 'risposta' : 'risposte'}
                  </span>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-1">{tipMessage}</p>
            </div>
          </div>
        </motion.div>
      )}

      {renderHeader()}
      
      {/* Mobile: Horizontal Carousel */}
      <div className="md:hidden -mx-4 px-4 overflow-x-auto scrollbar-hide">
        <div className="flex gap-3" style={{ width: 'max-content' }}>
          {dishes.map((dish, index) => (
            <motion.div
              key={dish.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="w-40 flex-shrink-0"
            >
              <DishCard
                dish={dish}
                compact
                onClick={() => onDishClick(dish)}
                isRecommended={isDishRecommended(dish)}
              />
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Desktop: 4 Column Grid */}
      <div className="hidden md:grid md:grid-cols-4 gap-3">
        {dishes.map((dish, index) => (
          <motion.div
            key={dish.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
          >
            <DishCard
              dish={dish}
              compact
              onClick={() => onDishClick(dish)}
              isRecommended={isDishRecommended(dish)}
            />
          </motion.div>
        ))}
      </div>
    </motion.section>
  );
}
