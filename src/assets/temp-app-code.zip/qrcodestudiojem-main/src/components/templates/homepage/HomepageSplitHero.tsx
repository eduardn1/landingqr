import { motion } from 'framer-motion';
import type { HomepageTemplateProps } from './types';
import { 
  HeroSection, 
  ActionButtonsSection, 
  FeaturedDishesSection, 
  MoodSection,
  EventsSectionWrapper,
  PromosSectionWrapper,
  RestaurantInfoSection,
  GoogleReviewsSection
} from './sections';
import { useHomeSections } from '@/hooks/useHomeSections';

export function HomepageSplitHero({ config, sectionProps }: HomepageTemplateProps) {
  const { 
    restaurantConfig, 
    currentLanguage, 
    onButtonAction, 
    goToMenu, 
    onDishClick,
    recommendedDishes,
    featuredLoading,
    selectedMood,
    onSelectMood,
    onboardingAnswers,
    isDishRecommended,
    t
  } = sectionProps;

  const { isSectionEnabled } = useHomeSections();

  const tagline = restaurantConfig?.tagline?.[currentLanguage as 'it' | 'en'] || restaurantConfig?.tagline?.it || '';

  return (
    <div className="min-h-screen bg-background">
      {/* Split Hero Section */}
      <HeroSection
        name={restaurantConfig?.name}
        tagline={tagline}
        coverImage={restaurantConfig?.cover_image_url}
        logoUrl={restaurantConfig?.logo_url}
        variant="split"
      />

      {/* Main Content */}
      <main className="container px-4 py-8 space-y-8">
        {/* Action Buttons */}
        {isSectionEnabled('action_grid') && (
          <ActionButtonsSection onAction={onButtonAction} variant="default" />
        )}

        {/* Mood Selector in glass card */}
        {isSectionEnabled('mood_selector') && (
          <MoodSection
            selectedMood={selectedMood}
            onSelectMood={onSelectMood}
            variant="glass"
          />
        )}

        {/* Featured Dishes as Carousel */}
        {isSectionEnabled('featured') && (
          <FeaturedDishesSection
            dishes={recommendedDishes}
            isLoading={featuredLoading}
            onDishClick={onDishClick}
            goToMenu={goToMenu}
            onboardingAnswers={onboardingAnswers}
            selectedMood={selectedMood}
            isDishRecommended={isDishRecommended}
            t={t}
            variant="carousel"
          />
        )}

        {/* Promos */}
        {isSectionEnabled('promos') && (
          <PromosSectionWrapper />
        )}

        {/* Events */}
        {isSectionEnabled('events') && (
          <EventsSectionWrapper variant="card" />
        )}

        {/* Reviews */}
        {isSectionEnabled('google_reviews') && (
          <GoogleReviewsSection />
        )}

        {/* Restaurant Info */}
        {isSectionEnabled('restaurant_info') && (
          <RestaurantInfoSection />
        )}
      </main>
    </div>
  );
}
