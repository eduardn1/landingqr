export { HomepageClassic } from './HomepageClassic';
export { HomepageModernGlass } from './HomepageModernGlass';
export { HomepageBentoMinimal, BentoItem } from './HomepageBentoMinimal';
export { HomepageParallax } from './HomepageParallax';
export { HomepageAurora } from './HomepageAurora';
export { HomepageSplitHero } from './HomepageSplitHero';
export { HomepageVideoBackground } from './HomepageVideoBackground';
export { HomepageMasonry } from './HomepageMasonry';
export type { HomepageTemplateProps, HomepageSectionProps } from './types';