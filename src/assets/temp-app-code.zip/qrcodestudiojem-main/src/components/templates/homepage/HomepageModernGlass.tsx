import { motion } from 'framer-motion';
import type { HomepageTemplateProps } from './types';
import { 
  HeroSection, 
  ActionButtonsSection, 
  FeaturedDishesSection, 
  MoodSection,
  EventsSectionWrapper,
  PromosSectionWrapper,
  RestaurantInfoSection,
  GoogleReviewsSection
} from './sections';
import { useHomeSections } from '@/hooks/useHomeSections';
import { DynamicHomeSections } from '@/components/client/DynamicHomeSections';

interface HomepageModernGlassProps {
  config: Record<string, any>;
  sectionProps?: HomepageTemplateProps['sectionProps'];
  heroContent?: React.ReactNode;
  children?: React.ReactNode;
}

export function HomepageModernGlass({ config, sectionProps, heroContent, children }: HomepageModernGlassProps) {
  const heroConfig = config.hero_config || {};
  const features = config.features || {};
  const { isSectionEnabled } = useHomeSections();

  // If sectionProps provided, use new system
  if (sectionProps) {
    const { 
      restaurantConfig, 
      currentLanguage, 
      onButtonAction, 
      goToMenu, 
      onDishClick,
      recommendedDishes,
      featuredLoading,
      selectedMood,
      onSelectMood,
      onboardingAnswers,
      isDishRecommended,
      t
    } = sectionProps;
    
    const tagline = restaurantConfig?.tagline?.[currentLanguage as 'it' | 'en'] || restaurantConfig?.tagline?.it || '';

    return (
      <div className="min-h-screen bg-background overflow-hidden">
        {/* Animated Mesh Gradient Background for Hero */}
        <div className="relative" style={{ minHeight: heroConfig.height || '70vh' }}>
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-accent/30 via-primary/20 to-secondary/30" />
          
          {/* Blur overlay */}
          <div 
            className="absolute inset-0 backdrop-blur-3xl"
            style={{ backdropFilter: `blur(${heroConfig.blur_intensity || '20px'})` }}
          />
          
          {/* Floating decorative elements */}
          {features.floating_elements !== false && (
            <>
              <motion.div
                className="absolute top-20 left-10 w-20 h-20 rounded-full bg-accent/20 blur-2xl"
                animate={{ 
                  y: [0, -20, 0],
                  scale: [1, 1.1, 1],
                }}
                transition={{ 
                  duration: 4, 
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
              <motion.div
                className="absolute bottom-40 right-10 w-32 h-32 rounded-full bg-primary/20 blur-3xl"
                animate={{ 
                  y: [0, 20, 0],
                  scale: [1, 0.9, 1],
                }}
                transition={{ 
                  duration: 5, 
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 1
                }}
              />
            </>
          )}
          
          {/* Hero content with glassmorphism card */}
          <div className="relative z-10 container px-4 min-h-[inherit] flex items-center justify-center py-8 sm:py-12 md:py-16">
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="max-w-2xl w-full p-5 sm:p-6 md:p-10 rounded-2xl sm:rounded-3xl text-center"
              style={{
                background: 'rgba(255, 255, 255, 0.08)',
                backdropFilter: 'blur(12px)',
                border: '1px solid rgba(255, 255, 255, 0.15)',
                boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.2)',
              }}
            >
              {restaurantConfig?.logo_url && (
                <img 
                  src={restaurantConfig.logo_url} 
                  alt={restaurantConfig?.name} 
                  className="h-12 sm:h-14 md:h-16 mx-auto mb-3 sm:mb-4"
                />
              )}
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-foreground mb-2">
                {restaurantConfig?.name || 'Il Locale'}
              </h1>
              {tagline && (
                <p className="text-sm sm:text-base text-muted-foreground mb-4 sm:mb-6">{tagline}</p>
              )}
              
              {/* Action buttons inside glass card */}
              {isSectionEnabled('action_grid') && (
                <ActionButtonsSection onAction={onButtonAction} variant="minimal" />
              )}
            </motion.div>
          </div>
        </div>
        
        {/* Rest of sections */}
        <main className="container px-4 py-8 space-y-8">
          {/* Mood Selector */}
          {isSectionEnabled('mood_selector') && (
            <MoodSection
              selectedMood={selectedMood}
              onSelectMood={onSelectMood}
              variant="glass"
            />
          )}

          {/* Featured Dishes */}
          {isSectionEnabled('featured') && (
            <FeaturedDishesSection
              dishes={recommendedDishes}
              isLoading={featuredLoading}
              onDishClick={onDishClick}
              goToMenu={goToMenu}
              onboardingAnswers={onboardingAnswers}
              selectedMood={selectedMood}
              isDishRecommended={isDishRecommended}
              t={t}
              variant="carousel"
            />
          )}

          {/* Promos */}
          {isSectionEnabled('promos') && (
            <PromosSectionWrapper variant="glass" />
          )}

          {/* Events */}
          {isSectionEnabled('events') && (
            <EventsSectionWrapper variant="glass" />
          )}

          {/* Reviews */}
          {isSectionEnabled('google_reviews') && (
            <GoogleReviewsSection variant="glass" />
          )}

          {/* Restaurant Info */}
          {isSectionEnabled('restaurant_info') && (
            <RestaurantInfoSection variant="glass" />
          )}
        </main>
      </div>
    );
  }

  // Legacy mode
  return (
    <div className="min-h-screen bg-background overflow-hidden">
      <div className="relative" style={{ minHeight: heroConfig.height || '90vh' }}>
        <div className="absolute inset-0 bg-gradient-to-br from-accent/30 via-primary/20 to-secondary/30 animate-pulse" />
        <div className="absolute inset-0 backdrop-blur-3xl" />
        <div className="relative z-10 container px-4 min-h-[inherit] flex items-center justify-center py-20">
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-4xl w-full p-8 md:p-12 rounded-3xl"
            style={{
              background: 'rgba(255, 255, 255, 0.08)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(255, 255, 255, 0.15)',
              boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.2)',
            }}
          >
            {heroContent}
          </motion.div>
        </div>
      </div>
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.6 }}
      >
        {children}
      </motion.div>
    </div>
  );
}
