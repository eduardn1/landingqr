import { motion, AnimatePresence } from 'framer-motion';
import { ReactNode, useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

interface Category {
  id: string;
  name: string;
  icon?: string;
  image_url?: string | null;
}

interface TakeawayTabsImageProps {
  config: Record<string, any>;
  categories: Category[];
  renderDishes: (categoryId: string) => ReactNode;
  cart?: ReactNode;
}

export function TakeawayTabsImage({ config, categories, renderDishes, cart }: TakeawayTabsImageProps) {
  const [activeTab, setActiveTab] = useState(categories[0]?.id || '');
  const tabsStyle = config.tabs_style || 'pills_image';
  const showImages = config.show_images !== false;
  
  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Category tabs with images */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border/50">
          <div className="container px-3 sm:px-4 py-2 sm:py-3">
            <div className="flex gap-2 sm:gap-3 overflow-x-auto scrollbar-hide pb-1">
              {categories.map((category) => {
                const isActive = activeTab === category.id;
                const hasImage = showImages && category.image_url;
                
                return (
                  <motion.button
                    key={category.id}
                    onClick={() => setActiveTab(category.id)}
                    className={cn(
                      "relative flex-shrink-0 rounded-lg sm:rounded-xl overflow-hidden transition-all",
                      hasImage ? "w-20 h-16 sm:w-24 sm:h-20" : "px-3 py-2 sm:px-4 sm:py-2.5",
                      hasImage
                        ? isActive 
                          ? "ring-2 ring-accent shadow-lg" 
                          : "ring-1 ring-border/50 hover:ring-accent/50"
                        : isActive
                          ? "bg-accent text-accent-foreground"
                          : "bg-muted hover:bg-muted/80 text-foreground/70"
                    )}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {hasImage ? (
                      <>
                        {/* Category image */}
                        <img 
                          src={category.image_url!} 
                          alt={category.name}
                          className="w-full h-full object-cover"
                        />
                        {/* Overlay with name */}
                        <div className={cn(
                          "absolute inset-0 flex items-end justify-center pb-1.5",
                          "bg-gradient-to-t from-black/70 via-black/20 to-transparent"
                        )}>
                          <span className="text-xs font-medium text-white text-center px-1 line-clamp-1">
                            {category.name}
                          </span>
                        </div>
                        {/* Active indicator */}
                        {isActive && (
                          <motion.div 
                            layoutId="activeCategoryIndicator"
                            className="absolute inset-0 border-2 border-accent rounded-xl pointer-events-none"
                          />
                        )}
                      </>
                    ) : (
                      // Fallback: icon + text pill
                      <div className="flex items-center gap-2 whitespace-nowrap">
                        {category.icon && (
                          <span className="text-lg">{category.icon}</span>
                        )}
                        <span className="text-sm font-medium">{category.name}</span>
                      </div>
                    )}
                  </motion.button>
                );
              })}
            </div>
          </div>
        </div>
        
        {/* Tab content with animation */}
        <div className="container px-3 sm:px-4 py-4 sm:py-6">
          <AnimatePresence mode="wait">
            {categories.map((category) => (
              <TabsContent key={category.id} value={category.id} className="mt-0">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {renderDishes(category.id)}
                </motion.div>
              </TabsContent>
            ))}
          </AnimatePresence>
        </div>
      </Tabs>
      
      {/* Floating cart */}
      {cart && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="fixed bottom-20 sm:bottom-24 right-3 sm:right-4 z-40"
        >
          {cart}
        </motion.div>
      )}
    </div>
  );
}