import { motion } from 'framer-motion';
import { ReactNode } from 'react';

interface TakeawayCardGridProps {
  config: Record<string, any>;
  filters?: ReactNode;
  dishes?: ReactNode;
  cart?: ReactNode;
}

export function TakeawayCardGrid({ config, filters, dishes, cart }: TakeawayCardGridProps) {
  const gridColumns = config.grid_columns || { mobile: 1, tablet: 2, desktop: 3 };
  const filterConfig = config.filters || {};
  
  return (
    <div className="min-h-screen bg-background pb-32">
      {/* Sticky filters */}
      {filters && (
        <div 
          className={`sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border/50 ${
            filterConfig.position === 'sticky_top' ? 'py-3' : ''
          }`}
        >
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="container px-4"
          >
            {filters}
          </motion.div>
        </div>
      )}
      
      {/* Dish grid */}
      <div className="container px-3 sm:px-4 py-4 sm:py-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="grid grid-cols-1 xs:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4"
        >
          {dishes}
        </motion.div>
      </div>
      
      {/* Floating cart */}
      {cart && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          className="fixed bottom-20 sm:bottom-24 right-3 sm:right-4 z-40"
        >
          {cart}
        </motion.div>
      )}
    </div>
  );
}