import { motion } from 'framer-motion';
import { ReactNode } from 'react';

interface TakeawayListQuickProps {
  config: Record<string, any>;
  filters?: ReactNode;
  dishes?: ReactNode;
  cart?: ReactNode;
}

export function TakeawayListQuick({ config, filters, dishes, cart }: TakeawayListQuickProps) {
  return (
    <div className="min-h-screen bg-background pb-28">
      {/* Filters */}
      {filters && (
        <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border/50 py-3">
          <div className="container px-4">
            {filters}
          </div>
        </div>
      )}
      
      {/* Compact list */}
      <div className="container px-3 sm:px-4 py-3 sm:py-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-2"
        >
          {dishes}
        </motion.div>
      </div>
      
      {/* Sticky bottom cart bar */}
      {cart && (
        <motion.div
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="fixed bottom-16 sm:bottom-20 left-0 right-0 z-40 bg-background/95 backdrop-blur-sm border-t border-border/50"
        >
          <div className="container px-3 sm:px-4 py-2 sm:py-3">
            {cart}
          </div>
        </motion.div>
      )}
    </div>
  );
}