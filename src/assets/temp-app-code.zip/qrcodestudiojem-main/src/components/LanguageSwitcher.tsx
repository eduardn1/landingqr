import { useState } from 'react';
import { Globe, ChevronDown, Check } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNavigationConfig } from '@/hooks/useNavigationConfig';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

export function LanguageSwitcher() {
  const { currentLanguage, setLanguage, languages } = useLanguage();
  const { config: navConfig } = useNavigationConfig();
  const [isOpen, setIsOpen] = useState(false);

  // Filter languages based on navigation config
  const visibleLanguages = navConfig.available_languages
    .filter(lang => lang.visible)
    .map(lang => {
      // Find matching language from context for full data
      const contextLang = languages.find(l => l.code === lang.code);
      return {
        code: lang.code,
        flag: lang.flag,
        label: lang.label,
        nativeName: contextLang?.nativeName || lang.label,
      };
    });

  const currentLang = visibleLanguages.find(l => l.code === currentLanguage) || visibleLanguages[0];

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-2 px-3 py-2 rounded-full bg-secondary/50 border border-border/20 text-foreground hover:bg-secondary transition-colors">
          <Globe className="h-4 w-4" />
          <span className="hidden sm:inline text-sm font-medium">{currentLang?.nativeName}</span>
          <ChevronDown className={cn(
            "h-4 w-4 transition-transform duration-200",
            isOpen && "rotate-180"
          )} />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        align="end" 
        className="min-w-[180px] p-2"
        sideOffset={8}
      >
        {visibleLanguages.map((lang) => (
          <DropdownMenuItem
            key={lang.code}
            onClick={() => setLanguage(lang.code)}
            className={cn(
              "flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-colors",
              currentLanguage === lang.code 
                ? "bg-primary text-primary-foreground" 
                : "hover:bg-secondary"
            )}
          >
            <span className="text-lg">{lang.flag}</span>
            <span className="flex-1 font-medium">{lang.nativeName}</span>
            {currentLanguage === lang.code && (
              <Check className="h-4 w-4" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
