import { motion } from 'framer-motion';
import { usePromos } from '@/hooks/usePromos';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedDbField } from '@/lib/i18n';
import { Skeleton } from '@/components/ui/skeleton';
import { ExternalLink, MessageCircle, Sparkles, ArrowRight } from 'lucide-react';

// Translation map for promo section
const promoTranslations: Record<string, Record<string, string>> = {
  specialOffers: { it: 'Offerte Speciali', en: 'Special Offers', de: 'Sonderangebote', es: 'Ofertas Especiales', fr: 'Offres Spéciales' },
  promo: { it: 'Promo', en: 'Deal', de: 'Angebot', es: 'Promo', fr: 'Promo' },
  contactUs: { it: 'Contattaci', en: 'Contact us', de: 'Kontaktieren Sie uns', es: 'Contáctanos', fr: 'Contactez-nous' },
  learnMore: { it: 'Scopri di più', en: 'Learn more', de: 'Mehr erfahren', es: 'Saber más', fr: 'En savoir plus' },
};

export function PromosSection() {
  const { activePromos, isLoading } = usePromos();
  const { currentLanguage } = useLanguage();

  const getPromoText = (key: string) => {
    return promoTranslations[key]?.[currentLanguage] || promoTranslations[key]?.en || key;
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-5 w-32" />
        <div className="flex gap-4 overflow-hidden">
          {[1, 2].map(i => (
            <Skeleton key={i} className="w-[320px] h-48 rounded-2xl flex-shrink-0" />
          ))}
        </div>
      </div>
    );
  }

  if (activePromos.length === 0) return null;

  const handlePromoClick = (promo: typeof activePromos[0]) => {
    if (promo.link_type === 'none' || !promo.link_url) return;
    
    if (promo.link_type === 'whatsapp') {
      const phone = promo.link_url.replace(/\D/g, '');
      window.open(`https://wa.me/${phone}`, '_blank');
    } else if (promo.link_type === 'external') {
      window.open(promo.link_url, '_blank');
    } else if (promo.link_type === 'internal') {
      window.location.href = promo.link_url;
    }
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Header with icon */}
      <div className="flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-accent" />
        <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          {getPromoText('specialOffers')}
        </h2>
      </div>

      {/* Horizontal scroll carousel */}
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4 snap-x snap-mandatory">
        {activePromos.map((promo, index) => {
          const title = getLocalizedDbField(promo, 'title', currentLanguage);
          const description = getLocalizedDbField(promo, 'description', currentLanguage);
          const hasLink = promo.link_type !== 'none' && promo.link_url;

          return (
            <motion.div
              key={promo.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1, type: 'spring', stiffness: 300 }}
              onClick={() => handlePromoClick(promo)}
              className={`min-w-[85vw] md:min-w-[320px] max-w-[320px] rounded-2xl overflow-hidden border border-border/20 flex-shrink-0 relative group snap-center ${hasLink ? 'cursor-pointer' : ''}`}
            >
              {/* Image with aspect ratio */}
              <div className="aspect-[16/10] overflow-hidden">
                <img
                  src={promo.image_url}
                  alt={title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>

              {/* Gradient overlay with text */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-5">
                {/* Promo badge */}
                <div className="absolute top-3 left-3">
                  <span className="px-2.5 py-1 rounded-full bg-accent text-accent-foreground text-[10px] font-bold uppercase tracking-wide shadow-lg">
                    {getPromoText('promo')}
                  </span>
                </div>
                
                <h3 className="text-white font-bold text-xl drop-shadow-lg leading-tight">{title}</h3>
                {description && (
                  <p className="text-white/80 text-sm line-clamp-2 mt-1 drop-shadow-md">{description}</p>
                )}
                
                {/* CTA indicator */}
                {hasLink && (
                  <div className="flex items-center gap-1.5 mt-3 text-accent text-sm font-medium group-hover:gap-2.5 transition-all">
                    {promo.link_type === 'whatsapp' ? (
                      <>
                        <MessageCircle className="w-4 h-4" />
                        <span>{getPromoText('contactUs')}</span>
                      </>
                    ) : (
                      <>
                        <span>{getPromoText('learnMore')}</span>
                        <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Hover glow effect */}
              {hasLink && (
                <div className="absolute inset-0 rounded-2xl ring-2 ring-accent/0 group-hover:ring-accent/50 transition-all duration-300 pointer-events-none" />
              )}
            </motion.div>
          );
        })}
      </div>
    </motion.section>
  );
}
