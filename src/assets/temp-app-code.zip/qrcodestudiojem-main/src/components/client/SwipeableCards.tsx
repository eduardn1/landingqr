import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform, PanInfo } from 'framer-motion';
import { X, Heart, Hand, ArrowLeftRight } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { type Dish } from '@/lib/mockData';
import { cn } from '@/lib/utils';
import { BackButton } from '@/components/ui/BackButton';

interface SwipeableCardsProps {
  dishes: Dish[];
  isOpen: boolean;
  onClose: () => void;
  onLike?: (dish: Dish) => void;
  onSkip?: (dish: Dish) => void;
}

export function SwipeableCards({ dishes, isOpen, onClose, onLike, onSkip }: SwipeableCardsProps) {
  const { currentLanguage } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [exitX, setExitX] = useState(0);
  const [showHelper, setShowHelper] = useState(true);

  const currentDish = dishes[currentIndex];
  const nextDish = dishes[currentIndex + 1];

  // Hide helper after first interaction or 4 seconds
  useEffect(() => {
    if (isOpen) {
      setShowHelper(true);
      setCurrentIndex(0);
      const timer = setTimeout(() => setShowHelper(false), 4000);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  const handleSwipe = (direction: 'left' | 'right') => {
    if (!currentDish) return;
    
    setShowHelper(false);
    setExitX(direction === 'left' ? -300 : 300);
    
    if (direction === 'right') {
      onLike?.(currentDish);
    } else {
      onSkip?.(currentDish);
    }

    setTimeout(() => {
      if (currentIndex < dishes.length - 1) {
        setCurrentIndex(currentIndex + 1);
        setExitX(0);
      } else {
        onClose();
      }
    }, 200);
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-background overflow-hidden"
      style={{ 
        top: 0, 
        left: 0, 
        right: 0, 
        bottom: 0, 
        position: 'fixed',
        touchAction: 'none'
      }}
    >
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between p-4 safe-area-top">
        <BackButton onClick={onClose} size="lg" />
        <span className="text-sm text-muted-foreground">
          {currentIndex + 1} / {dishes.length}
        </span>
        <div className="w-12" />
      </div>

      {/* Helper Message */}
      <AnimatePresence>
        {showHelper && currentDish && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-20 left-0 right-0 z-20 flex justify-center px-6"
          >
            <div className="bg-foreground/90 text-background rounded-2xl px-5 py-3 shadow-xl max-w-xs">
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ x: [-10, 10, -10] }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                >
                  <ArrowLeftRight className="w-5 h-5" />
                </motion.div>
                <div>
                  <p className="text-sm font-medium">Scorri per scegliere!</p>
                  <p className="text-xs opacity-70">Destra = Mi piace • Sinistra = Salta</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Cards Stack */}
      <div className="absolute inset-0 flex items-center justify-center px-6" style={{ paddingTop: 'calc(80px + env(safe-area-inset-top))', paddingBottom: 'calc(160px + env(safe-area-inset-bottom))' }}>
        <div className="relative w-full max-w-sm h-full max-h-[500px]">
          <AnimatePresence mode="popLayout">
            {/* Background card - positioned behind */}
            {nextDish && (
              <motion.div
                key={`bg-${nextDish.id}`}
                className="absolute inset-0"
                style={{ zIndex: 0 }}
                initial={{ scale: 0.92, y: 20, opacity: 0.5 }}
                animate={{ scale: 0.95, y: 10, opacity: 0.7 }}
              >
                <SwipeCard dish={nextDish} currentLanguage={currentLanguage} isBackground />
              </motion.div>
            )}

            {/* Active card - positioned on top */}
            {currentDish && (
              <motion.div
                key={currentDish.id}
                className="absolute inset-0"
                style={{ zIndex: 10 }}
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1, x: 0 }}
                exit={{ x: exitX, opacity: 0, scale: 0.9 }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              >
                <DraggableCard
                  dish={currentDish}
                  currentLanguage={currentLanguage}
                  onSwipe={handleSwipe}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="absolute left-0 right-0 flex items-center justify-center gap-6 safe-area-bottom" style={{ bottom: 'calc(24px + env(safe-area-inset-bottom))' }}>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => handleSwipe('left')}
          className="w-20 h-20 rounded-full bg-destructive/10 border-2 border-destructive/40 flex flex-col items-center justify-center shadow-xl hover:bg-destructive/20 hover:border-destructive/60 transition-all"
        >
          <X className="w-9 h-9 text-destructive" />
          <span className="text-[10px] font-medium text-destructive mt-0.5">NO</span>
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => handleSwipe('right')}
          className="w-20 h-20 rounded-full bg-green-500/10 border-2 border-green-500/40 text-green-500 flex flex-col items-center justify-center shadow-xl hover:bg-green-500/20 hover:border-green-500/60 transition-all"
        >
          <Heart className="w-9 h-9" />
          <span className="text-[10px] font-medium mt-0.5">MI PIACE</span>
        </motion.button>
      </div>

      {/* Swipe hint animation on first card */}
      {showHelper && currentDish && (
        <motion.div
          className="absolute bottom-32 left-0 right-0 flex justify-center pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            animate={{ x: [-20, 20, -20] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="flex items-center gap-2 text-muted-foreground"
          >
            <Hand className="w-5 h-5" />
            <span className="text-sm">Trascina la card</span>
          </motion.div>
        </motion.div>
      )}

      {/* No more cards */}
      {!currentDish && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute inset-0 flex flex-col items-center justify-center gap-4"
        >
          <span className="text-4xl">✨</span>
          <p className="text-muted-foreground">Hai visto tutti i piatti!</p>
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-full bg-foreground text-background text-sm font-medium"
          >
            Torna al menu
          </button>
        </motion.div>
      )}
    </motion.div>
  );
}

// Draggable Card Component
function DraggableCard({ 
  dish, 
  currentLanguage, 
  onSwipe 
}: { 
  dish: Dish; 
  currentLanguage: string; 
  onSwipe: (dir: 'left' | 'right') => void;
}) {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-15, 15]);
  const likeOpacity = useTransform(x, [0, 100], [0, 1]);
  const nopeOpacity = useTransform(x, [-100, 0], [1, 0]);

  const handleDragEnd = (_: any, info: PanInfo) => {
    if (info.offset.x > 100) {
      onSwipe('right');
    } else if (info.offset.x < -100) {
      onSwipe('left');
    }
  };

  return (
    <motion.div
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      dragElastic={0.7}
      onDragEnd={handleDragEnd}
      style={{ x, rotate }}
      className="cursor-grab active:cursor-grabbing"
    >
      {/* Swipe indicators */}
      <motion.div
        style={{ opacity: likeOpacity }}
        className="absolute top-8 right-8 z-10 px-4 py-2 rounded-lg border-2 border-green-500 text-green-500 font-bold text-xl rotate-12"
      >
        MI PIACE
      </motion.div>
      <motion.div
        style={{ opacity: nopeOpacity }}
        className="absolute top-8 left-8 z-10 px-4 py-2 rounded-lg border-2 border-red-500 text-red-500 font-bold text-xl -rotate-12"
      >
        NO
      </motion.div>

      <SwipeCard dish={dish} currentLanguage={currentLanguage} />
    </motion.div>
  );
}

// Card UI Component
function SwipeCard({ 
  dish, 
  currentLanguage, 
  isBackground = false 
}: { 
  dish: Dish; 
  currentLanguage: string; 
  isBackground?: boolean;
}) {
  return (
    <div className={cn(
      "h-full bg-card border border-border/50 rounded-3xl overflow-hidden shadow-2xl",
      isBackground && "pointer-events-none"
    )}>
      {/* Image */}
      <div className="h-64 bg-gradient-to-br from-secondary to-background flex items-center justify-center">
        {dish.images?.[0] ? (
          <img src={dish.images[0]} alt="" className="w-full h-full object-cover" />
        ) : (
          <span className="text-6xl opacity-50">🍽️</span>
        )}
      </div>

      {/* Content */}
      <div className="p-5 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <h3 className="text-xl font-semibold text-foreground">
            {getLocalizedContent(dish.name, currentLanguage)}
          </h3>
          <span className="text-lg font-bold text-accent">
            €{dish.price.toFixed(2)}
          </span>
        </div>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {getLocalizedContent(dish.description, currentLanguage)}
        </p>
        {dish.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 pt-1">
            {dish.tags.slice(0, 3).map(tag => (
              <span key={tag} className="px-2.5 py-1 text-xs rounded-full bg-accent/10 text-accent border border-accent/20">
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
