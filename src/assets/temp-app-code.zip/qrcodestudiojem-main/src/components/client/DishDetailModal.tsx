import { motion, AnimatePresence } from 'framer-motion';
import { X, Flame, Heart, AlertTriangle, Plus, Minus } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { allergens as allergensData, dietTypes, type Dish } from '@/lib/mockData';
import { cn } from '@/lib/utils';

interface DishDetailModalProps {
  dish: Dish | null;
  isOpen: boolean;
  onClose: () => void;
  isFavorite?: boolean;
  onToggleFavorite?: (dishId: string) => void;
}

export function DishDetailModal({ dish, isOpen, onClose, isFavorite, onToggleFavorite }: DishDetailModalProps) {
  const { currentLanguage, t } = useLanguage();

  if (!dish) return null;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat(currentLanguage, {
      style: 'currency',
      currency: dish.currency || 'EUR',
    }).format(price);
  };

  const getDietTags = () => {
    return dish.tags
      .map(tag => dietTypes.find(d => d.code === tag))
      .filter(Boolean);
  };

  const getAllergens = () => {
    return dish.allergens
      .map(code => allergensData.find(a => a.code === code))
      .filter(Boolean);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key="dish-detail-modal"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          {/* Backdrop with blur */}
          <motion.div 
            className="absolute inset-0 bg-background/60 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* Modal Content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-lg max-h-[85vh] overflow-hidden rounded-2xl bg-secondary/40 backdrop-blur-xl border border-border/30 shadow-2xl"
          >
            {/* Header Image */}
            <div className="relative h-56 overflow-hidden">
              {dish.images?.[0] ? (
                <img 
                  src={dish.images[0]} 
                  alt={getLocalizedContent(dish.name, currentLanguage)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-secondary/80 to-secondary/40 flex items-center justify-center">
                  <span className="text-8xl opacity-30">🍽️</span>
                </div>
              )}
              
              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-secondary/90 via-transparent to-transparent" />
              
              {/* Close button */}
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-10 h-10 rounded-full bg-background/30 backdrop-blur-sm border border-border/20 flex items-center justify-center hover:bg-background/50 transition-colors"
              >
                <X className="w-5 h-5 text-foreground" />
              </button>

              {/* Favorite button */}
              <button
                onClick={() => onToggleFavorite?.(dish.id)}
                className={cn(
                  "absolute top-4 left-4 w-10 h-10 rounded-full backdrop-blur-sm border flex items-center justify-center transition-all",
                  isFavorite 
                    ? "bg-accent/80 border-accent text-accent-foreground" 
                    : "bg-background/30 border-white/10 hover:bg-background/50"
                )}
              >
                <Heart className={cn("w-5 h-5", isFavorite && "fill-current")} />
              </button>

              {/* Badge */}
              {dish.badge && (
                <div className="absolute bottom-4 left-4 px-3 py-1 bg-accent text-accent-foreground text-sm font-semibold rounded-full">
                  {dish.badge}
                </div>
              )}
            </div>

            {/* Content */}
            <div className="p-6 space-y-4 overflow-y-auto max-h-[calc(85vh-14rem)]">
              {/* Title & Price */}
              <div className="flex items-start justify-between gap-4">
                <h2 className="text-2xl font-semibold text-foreground">
                  {getLocalizedContent(dish.name, currentLanguage)}
                </h2>
                <div className="text-right flex-shrink-0">
                  <span className="text-2xl font-bold text-foreground">{formatPrice(dish.price)}</span>
                  {dish.originalPrice && (
                    <span className="block text-sm text-muted-foreground line-through">
                      {formatPrice(dish.originalPrice)}
                    </span>
                  )}
                </div>
              </div>

              {/* Meta info */}
              <div className="flex flex-wrap items-center gap-3">
                {dish.spicyLevel && dish.spicyLevel > 0 && (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/30 border border-border/20 text-sm">
                    {[1, 2, 3].map((level) => (
                      <Flame
                        key={level}
                        className={cn(
                          "h-4 w-4",
                          level <= dish.spicyLevel! ? "text-accent" : "text-muted-foreground/30"
                        )}
                        fill={level <= dish.spicyLevel! ? "currentColor" : "none"}
                      />
                    ))}
                  </div>
                )}
                {!dish.isAvailable && (
                  <span className="px-3 py-1.5 rounded-full bg-destructive/20 text-destructive text-sm font-medium">
                    Non disponibile
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="text-muted-foreground leading-relaxed">
                {getLocalizedContent(dish.description, currentLanguage)}
              </p>

              {/* Diet tags */}
              {getDietTags().length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {getDietTags().map((diet) => (
                    <span
                      key={diet!.code}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-accent/10 border border-accent/20 text-sm"
                    >
                      <span>{diet!.icon}</span>
                      <span className="text-foreground/80">{getLocalizedContent(diet!.name, currentLanguage)}</span>
                    </span>
                  ))}
                </div>
              )}

              {/* Allergens */}
              {getAllergens().length > 0 && (
                <div className="p-4 rounded-2xl bg-destructive/5 border border-destructive/20 space-y-2">
                  <div className="flex items-center gap-2 text-destructive">
                    <AlertTriangle className="w-4 h-4" />
                    <h3 className="text-xs font-medium uppercase tracking-wider">Allergeni</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {getAllergens().map((allergen) => (
                      <span
                        key={allergen!.code}
                        className="inline-flex items-center gap-1.5 px-2 py-1 rounded-lg bg-background/50 text-xs"
                      >
                        <span>{allergen!.icon}</span>
                        <span>{getLocalizedContent(allergen!.name, currentLanguage)}</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
    </AnimatePresence>
  );
}
