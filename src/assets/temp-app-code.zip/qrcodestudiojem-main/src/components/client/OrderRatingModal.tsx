import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useLanguage } from '@/contexts/LanguageContext';
import { cn } from '@/lib/utils';

interface OrderRatingModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
  orderNumber: string;
  orderType: 'pickup' | 'delivery';
  userId: string;
  onRated?: () => void;
}

export function OrderRatingModal({
  isOpen,
  onClose,
  orderId,
  orderNumber,
  orderType,
  userId,
  onRated,
}: OrderRatingModalProps) {
  const { currentLanguage } = useLanguage();
  const [foodRating, setFoodRating] = useState(0);
  const [deliveryRating, setDeliveryRating] = useState(0);
  const [driverRating, setDriverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (foodRating === 0) {
      toast.error(currentLanguage === 'it' ? 'Valuta almeno il cibo' : 'Please rate the food');
      return;
    }

    setIsSubmitting(true);
    try {
      const ratings = [foodRating];
      if (orderType === 'delivery' && deliveryRating > 0) ratings.push(deliveryRating);
      if (orderType === 'delivery' && driverRating > 0) ratings.push(driverRating);
      const overallRating = Math.round(ratings.reduce((a, b) => a + b, 0) / ratings.length);

      const { error } = await supabase.from('order_ratings').insert({
        order_id: orderId,
        user_id: userId,
        food_rating: foodRating,
        delivery_rating: orderType === 'delivery' ? deliveryRating : null,
        driver_rating: orderType === 'delivery' ? driverRating : null,
        overall_rating: overallRating,
        comment: comment || null,
      });

      if (error) throw error;

      toast.success(currentLanguage === 'it' ? 'Grazie per la tua valutazione!' : 'Thanks for your rating!');
      onRated?.();
      onClose();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const StarRating = ({ 
    value, 
    onChange, 
    label 
  }: { 
    value: number; 
    onChange: (v: number) => void; 
    label: string;
  }) => (
    <div className="space-y-2">
      <p className="text-sm font-medium">{label}</p>
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className="p-1 transition-transform hover:scale-110"
          >
            <Star
              className={cn(
                'w-8 h-8 transition-colors',
                star <= value
                  ? 'fill-yellow-400 text-yellow-400'
                  : 'text-muted-foreground'
              )}
            />
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {currentLanguage === 'it' ? 'Valuta il tuo ordine' : 'Rate your order'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <p className="text-sm text-muted-foreground">
            {currentLanguage === 'it'
              ? `Come è andato l'ordine #${orderNumber}?`
              : `How was order #${orderNumber}?`}
          </p>

          <StarRating
            value={foodRating}
            onChange={setFoodRating}
            label={currentLanguage === 'it' ? '🍽️ Qualità del cibo' : '🍽️ Food quality'}
          />

          {orderType === 'delivery' && (
            <>
              <StarRating
                value={deliveryRating}
                onChange={setDeliveryRating}
                label={currentLanguage === 'it' ? '🚗 Servizio di consegna' : '🚗 Delivery service'}
              />
              <StarRating
                value={driverRating}
                onChange={setDriverRating}
                label={currentLanguage === 'it' ? '👤 Il tuo driver' : '👤 Your driver'}
              />
            </>
          )}

          <div className="space-y-2">
            <p className="text-sm font-medium">
              {currentLanguage === 'it' ? '💬 Commento (opzionale)' : '💬 Comment (optional)'}
            </p>
            <Textarea
              placeholder={
                currentLanguage === 'it'
                  ? 'Racconta la tua esperienza...'
                  : 'Tell us about your experience...'
              }
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
            />
          </div>

          <div className="flex gap-3">
            <Button variant="outline" className="flex-1" onClick={onClose}>
              {currentLanguage === 'it' ? 'Dopo' : 'Later'}
            </Button>
            <Button
              className="flex-1"
              onClick={handleSubmit}
              disabled={isSubmitting || foodRating === 0}
            >
              {isSubmitting
                ? currentLanguage === 'it' ? 'Invio...' : 'Sending...'
                : currentLanguage === 'it' ? 'Invia' : 'Submit'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
