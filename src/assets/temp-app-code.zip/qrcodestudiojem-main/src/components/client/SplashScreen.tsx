import { motion } from 'framer-motion';
import { forwardRef, useEffect, useState } from 'react';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { InteractiveOnboarding } from './InteractiveOnboarding';

interface SplashScreenProps {
  onComplete: (destination?: string) => void;
  skipInteractive?: boolean;
}

export const SplashScreen = forwardRef<HTMLDivElement, SplashScreenProps>(
  ({ onComplete, skipInteractive = false }, ref) => {
    const { config, isLoading } = useRestaurantConfig();
    const [showInteractive, setShowInteractive] = useState(false);

    // Check if interactive onboarding was already completed this session
    const interactiveCompleted = sessionStorage.getItem('interactive_onboarding_completed') === 'true';

    useEffect(() => {
      // Determine which flow to show
      const variant = (config as any)?.onboarding_variant || 'interactive';
      
      // If interactive completed, also mark general onboarding as completed to prevent quiz
      if (interactiveCompleted) {
        sessionStorage.setItem('onboarding_completed', 'true');
      }
      
      if (skipInteractive || interactiveCompleted || variant === 'quiz') {
        // Show simple splash and complete
        const timer = setTimeout(() => onComplete(), 2000);
        return () => clearTimeout(timer);
      } else {
        // Show interactive onboarding after brief logo animation
        const timer = setTimeout(() => setShowInteractive(true), 1500);
        return () => clearTimeout(timer);
      }
    }, [onComplete, skipInteractive, interactiveCompleted, config]);

    // Show interactive onboarding
    if (showInteractive) {
      return (
        <InteractiveOnboarding 
          ref={ref}
          onComplete={onComplete}
        />
      );
    }

    // Simple splash screen
    return (
      <motion.div
        ref={ref}
        className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center"
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {/* Animated Logo */}
          {config?.logo_url ? (
            <motion.div
              className="mb-6"
              animate={{ 
                rotate: [0, 5, -5, 5, 0],
              }}
              transition={{ 
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              <img 
                src={config.logo_url} 
                alt="Logo" 
                className="h-20 w-auto mx-auto object-contain"
              />
            </motion.div>
          ) : (
            <motion.div
              className="text-6xl mb-6"
              animate={{ 
                rotate: [0, 10, -10, 10, 0],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            >
              🍽️
            </motion.div>
          )}


          <motion.div
            className="flex items-center justify-center gap-1.5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-1.5 h-1.5 rounded-full bg-foreground/30"
                animate={{ opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
              />
            ))}
          </motion.div>
        </motion.div>
      </motion.div>
    );
  }
);

SplashScreen.displayName = 'SplashScreen';
