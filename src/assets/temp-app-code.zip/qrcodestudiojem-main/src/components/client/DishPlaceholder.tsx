import { cn } from '@/lib/utils';
import { UtensilsCrossed } from 'lucide-react';

export type PlaceholderType = 'gradient' | 'emoji' | 'image' | 'pattern';

interface DishPlaceholderProps {
  categoryIcon?: string;
  size?: 'small' | 'medium' | 'large';
  className?: string;
  placeholderType?: PlaceholderType;
  placeholderEmoji?: string;
  placeholderGradient?: string;
  placeholderImage?: string;
}

export function DishPlaceholder({ 
  categoryIcon, 
  size = 'medium', 
  className,
  placeholderType = 'gradient',
  placeholderEmoji,
  placeholderGradient = 'from-secondary/60 via-secondary/40 to-secondary/20',
  placeholderImage
}: DishPlaceholderProps) {
  const sizeClasses = {
    small: 'text-2xl',
    medium: 'text-4xl',
    large: 'text-5xl',
  };

  const iconSizeClasses = {
    small: 'w-5 h-5',
    medium: 'w-8 h-8',
    large: 'w-12 h-12',
  };

  // Custom image placeholder
  if (placeholderType === 'image' && placeholderImage) {
    return (
      <div className={cn("w-full h-full relative overflow-hidden", className)}>
        <img 
          src={placeholderImage} 
          alt="Placeholder" 
          className="w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
        {categoryIcon && (
          <div className="absolute inset-0 flex items-center justify-center">
            <span className={cn(sizeClasses[size], "opacity-50 drop-shadow-lg")}>{categoryIcon}</span>
          </div>
        )}
      </div>
    );
  }

  // Emoji placeholder (large centered emoji)
  if (placeholderType === 'emoji') {
    const displayEmoji = placeholderEmoji || categoryIcon || '🍽️';
    return (
      <div 
        className={cn(
          "w-full h-full flex items-center justify-center relative overflow-hidden",
          "bg-gradient-to-br from-secondary/40 to-secondary/20",
          className
        )}
      >
        <div className="absolute inset-0 backdrop-blur-[1px]" />
        <span className={cn(
          size === 'small' ? 'text-3xl' : size === 'medium' ? 'text-5xl' : 'text-6xl',
          "relative z-10 opacity-60 drop-shadow-md"
        )}>
          {displayEmoji}
        </span>
      </div>
    );
  }

  // Pattern placeholder (geometric pattern)
  if (placeholderType === 'pattern') {
    return (
      <div 
        className={cn(
          "w-full h-full flex items-center justify-center relative overflow-hidden",
          "bg-secondary/30",
          className
        )}
      >
        {/* Dot pattern */}
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `radial-gradient(circle, hsl(var(--muted-foreground)) 1px, transparent 1px)`,
            backgroundSize: '12px 12px'
          }}
        />
        {/* Icon */}
        <div className="relative z-10 flex items-center justify-center opacity-40">
          {categoryIcon ? (
            <span className={sizeClasses[size]}>{categoryIcon}</span>
          ) : (
            <UtensilsCrossed className={cn(iconSizeClasses[size], "text-muted-foreground")} />
          )}
        </div>
      </div>
    );
  }

  // Default: Gradient placeholder with blur effect
  return (
    <div 
      className={cn(
        "w-full h-full flex items-center justify-center relative overflow-hidden",
        `bg-gradient-to-br ${placeholderGradient}`,
        className
      )}
    >
      {/* Blur overlay pattern */}
      <div className="absolute inset-0 backdrop-blur-[2px]">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-accent/5" />
        <div className="absolute top-1/4 left-1/4 w-1/2 h-1/2 bg-accent/5 rounded-full blur-2xl" />
        <div className="absolute bottom-1/4 right-1/4 w-1/3 h-1/3 bg-primary/5 rounded-full blur-xl" />
      </div>
      
      {/* Icon */}
      <div className="relative z-10 flex items-center justify-center opacity-40">
        {categoryIcon ? (
          <span className={sizeClasses[size]}>{categoryIcon}</span>
        ) : (
          <UtensilsCrossed className={cn(iconSizeClasses[size], "text-muted-foreground")} />
        )}
      </div>
    </div>
  );
}
