import { motion, AnimatePresence } from 'framer-motion';
import { Quote, MapPin, Phone, Mail } from 'lucide-react';
import { BackButton } from '@/components/ui/BackButton';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { useLanguage } from '@/contexts/LanguageContext';

// Fallback images
import storyInterior from '@/assets/story-interior.jpg';

interface AboutUsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface GalleryImage {
  url: string;
  caption_it?: string;
  caption_en?: string;
}

interface LocalizedText {
  it?: string;
  en?: string;
}

export function AboutUsModal({ isOpen, onClose }: AboutUsModalProps) {
  const { config, isLoading } = useRestaurantConfig();
  const { currentLanguage } = useLanguage();

  if (!isOpen) return null;

  // Get localized content from config
  const description = config?.description as LocalizedText | null;
  const tagline = config?.tagline as LocalizedText | null;
  const keywords = (config as any)?.about_keywords as LocalizedText[] | null;
  const gallery = (config as any)?.about_gallery as GalleryImage[] | null;
  
  const localizedDescription = description?.[currentLanguage as 'it' | 'en'] || description?.it || '';
  const localizedTagline = tagline?.[currentLanguage as 'it' | 'en'] || tagline?.it || '';

  // Use cover image or fallback
  const heroImage = config?.cover_image_url || storyInterior;

  // Gallery images from database or fallback
  const galleryImages = gallery && gallery.length > 0 ? gallery : [];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
          onClick={onClose}
        >
          {/* Backdrop */}
          <motion.div 
            className="absolute inset-0 bg-background/60 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-lg max-h-[90vh] overflow-hidden rounded-t-3xl sm:rounded-3xl bg-secondary/30 backdrop-blur-xl border border-border/20 shadow-2xl"
          >
            {/* Hero Image */}
            <div className="relative h-48 overflow-hidden">
              <img 
                src={heroImage} 
                alt={config?.name || 'Il Locale'}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
              
              {/* Close Button */}
              <div className="absolute top-4 right-4">
                <BackButton onClick={onClose} variant="close" size="lg" />
              </div>
              
              {/* Title overlay */}
              <div className="absolute bottom-4 left-6 right-6">
                {localizedTagline && (
                  <p className="text-xs text-accent font-medium mb-1">{localizedTagline}</p>
                )}
                <h2 className="text-2xl font-bold text-foreground">
                  {currentLanguage === 'it' ? 'Chi Siamo' : 'About Us'}
                </h2>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-12rem)]">
              {/* Restaurant Name */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center"
              >
                <h3 className="text-xl font-bold text-foreground">{config?.name || 'Il Locale'}</h3>
              </motion.div>

              {/* Keywords/Badges */}
              {keywords && keywords.length > 0 && (
                <div className="flex items-center justify-center gap-2 flex-wrap">
                  {keywords.map((keyword, idx) => {
                    const text = keyword[currentLanguage as 'it' | 'en'] || keyword.it || '';
                    return text ? (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 + idx * 0.1 }}
                        className="px-4 py-2 rounded-full bg-accent/10 border border-accent/20"
                      >
                        <span className="text-sm font-semibold text-accent">{text}</span>
                      </motion.div>
                    ) : null;
                  })}
                </div>
              )}

              {/* Description */}
              {localizedDescription && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  className="relative p-6 rounded-2xl bg-foreground/5 border border-border/20"
                >
                  <Quote className="absolute top-4 left-4 w-6 h-6 text-accent/30" />
                  <p className="text-sm text-muted-foreground leading-relaxed pl-8 whitespace-pre-line">
                    {localizedDescription}
                  </p>
                </motion.div>
              )}

              {/* Contact Info */}
              {(config?.address || config?.phone || config?.email) && (
                <div className="space-y-3">
                  <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    {currentLanguage === 'it' ? 'Contatti' : 'Contact'}
                  </h4>
                  <div className="space-y-2">
                    {config?.address && (
                      <motion.a
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3 }}
                        href={config?.google_maps_url || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-start gap-3 p-3 rounded-xl bg-background/30 hover:bg-background/50 transition-colors"
                      >
                        <MapPin className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                        <div>
                          <span className="text-sm text-foreground">{config.address}</span>
                          {config?.city && (
                            <span className="text-sm text-muted-foreground block">{config.city}</span>
                          )}
                        </div>
                      </motion.a>
                    )}
                    
                    {config?.phone && (
                      <motion.a
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.35 }}
                        href={`tel:${config.phone}`}
                        className="flex items-center gap-3 p-3 rounded-xl bg-background/30 hover:bg-background/50 transition-colors"
                      >
                        <Phone className="w-5 h-5 text-accent" />
                        <span className="text-sm text-foreground">{config.phone}</span>
                      </motion.a>
                    )}
                    
                    {config?.email && (
                      <motion.a
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.4 }}
                        href={`mailto:${config.email}`}
                        className="flex items-center gap-3 p-3 rounded-xl bg-background/30 hover:bg-background/50 transition-colors"
                      >
                        <Mail className="w-5 h-5 text-accent" />
                        <span className="text-sm text-foreground">{config.email}</span>
                      </motion.a>
                    )}
                  </div>
                </div>
              )}

              {/* Masonry Gallery */}
              {galleryImages.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    {currentLanguage === 'it' ? 'Galleria' : 'Gallery'}
                  </h4>
                  <div className="columns-2 gap-2 space-y-2">
                    {galleryImages.map((image, idx) => {
                      const caption = currentLanguage === 'it' 
                        ? image.caption_it 
                        : (image.caption_en || image.caption_it);
                      return (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0.5 + idx * 0.1 }}
                          className="relative break-inside-avoid rounded-xl overflow-hidden group"
                        >
                          <img 
                            src={image.url} 
                            alt={caption || `Gallery ${idx + 1}`}
                            className="w-full h-auto object-cover transition-transform duration-500 group-hover:scale-105"
                          />
                          {caption && (
                            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                              <span className="text-xs text-white font-medium">{caption}</span>
                            </div>
                          )}
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}