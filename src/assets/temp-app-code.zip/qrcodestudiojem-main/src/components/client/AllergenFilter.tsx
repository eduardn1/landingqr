import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, X, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAllergens } from '@/hooks/useMenu';
import { useLanguage } from '@/contexts/LanguageContext';

interface AllergenFilterProps {
  selectedAllergens: string[];
  onAllergensChange: (allergens: string[]) => void;
}

export function AllergenFilter({ selectedAllergens, onAllergensChange }: AllergenFilterProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { allergens, isLoading } = useAllergens();
  const { currentLanguage } = useLanguage();
  const language = currentLanguage;

  const toggleAllergen = (code: string) => {
    if (selectedAllergens.includes(code)) {
      onAllergensChange(selectedAllergens.filter(a => a !== code));
    } else {
      onAllergensChange([...selectedAllergens, code]);
    }
  };

  const clearAll = () => {
    onAllergensChange([]);
  };

  const getName = (allergen: { name_it: string; name_en: string }) => {
    return language === 'it' ? allergen.name_it : allergen.name_en;
  };

  return (
    <div className="relative">
      <Button
        variant="outline"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className={`gap-2 ${selectedAllergens.length > 0 ? 'border-accent bg-accent/10' : ''}`}
      >
        <Filter className="w-4 h-4" />
        {language === 'it' ? 'Allergeni' : 'Allergens'}
        {selectedAllergens.length > 0 && (
          <span className="bg-accent text-accent-foreground rounded-full w-5 h-5 text-xs flex items-center justify-center">
            {selectedAllergens.length}
          </span>
        )}
      </Button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-40"
              onClick={() => setIsOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="absolute right-0 top-full mt-2 w-80 bg-card rounded-xl shadow-xl border border-border z-50 overflow-hidden"
            >
              <div className="p-4 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-accent" />
                  <h3 className="font-semibold">
                    {language === 'it' ? 'Filtra Allergeni' : 'Filter Allergens'}
                  </h3>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsOpen(false)}
                  className="h-8 w-8"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="p-4">
                <p className="text-sm text-muted-foreground mb-4">
                  {language === 'it' 
                    ? 'Seleziona gli allergeni da escludere:' 
                    : 'Select allergens to exclude:'}
                </p>

                {isLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-accent" />
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-72 overflow-y-auto">
                    {allergens.map((allergen) => (
                      <button
                        key={allergen.code}
                        onClick={() => toggleAllergen(allergen.code)}
                        className={`flex items-center gap-2 p-3 rounded-xl text-sm transition-all text-foreground min-h-[52px] ${
                          selectedAllergens.includes(allergen.code)
                            ? 'bg-destructive/10 border-destructive border-2'
                            : 'bg-secondary hover:bg-secondary/80 border border-transparent'
                        }`}
                      >
                        <span className="text-lg flex-shrink-0">{allergen.icon}</span>
                        <span className="truncate text-xs sm:text-sm">{getName(allergen)}</span>
                      </button>
                    ))}
                  </div>
                )}

                {selectedAllergens.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={clearAll}
                      className="w-full"
                    >
                      {language === 'it' ? 'Rimuovi tutti i filtri' : 'Clear all filters'}
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
