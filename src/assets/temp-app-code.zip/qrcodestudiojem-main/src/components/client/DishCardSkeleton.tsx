import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

// Animated skeleton with shimmer effect
const ShimmerSkeleton = ({ className }: { className?: string }) => (
  <div className={cn("relative overflow-hidden bg-foreground/[0.06] dark:bg-secondary/50 rounded-lg", className)}>
    <motion.div
      className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-foreground/[0.08] to-transparent"
      animate={{ translateX: ['100%', '-100%'] }}
      transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
    />
  </div>
);

interface DishCardSkeletonProps {
  compact?: boolean;
}

export function DishCardSkeleton({ compact = false }: DishCardSkeletonProps) {
  if (compact) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="rounded-2xl bg-card/50 border border-border/20 overflow-hidden"
      >
        <ShimmerSkeleton className="w-full aspect-[4/3] rounded-none" />
        <div className="p-3 space-y-2">
          <ShimmerSkeleton className="h-4 w-3/4" />
          <ShimmerSkeleton className="h-3 w-1/2" />
          <ShimmerSkeleton className="h-5 w-16" />
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="rounded-2xl bg-card/50 border border-border/20 overflow-hidden"
    >
      <ShimmerSkeleton className="w-full aspect-video rounded-none" />
      <div className="p-4 space-y-3">
        <ShimmerSkeleton className="h-5 w-3/4" />
        <ShimmerSkeleton className="h-3 w-full" />
        <ShimmerSkeleton className="h-3 w-2/3" />
        <div className="flex justify-between items-center pt-2">
          <ShimmerSkeleton className="h-6 w-20" />
          <ShimmerSkeleton className="h-8 w-24 rounded-xl" />
        </div>
      </div>
    </motion.div>
  );
}

export function DishGridSkeleton({ count = 4, compact = true }: { count?: number; compact?: boolean }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      {[...Array(count)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
        >
          <DishCardSkeleton compact={compact} />
        </motion.div>
      ))}
    </div>
  );
}

// Horizontal carousel skeleton for mobile
export function DishCarouselSkeleton({ count = 4 }: { count?: number }) {
  return (
    <div className="-mx-4 px-4 overflow-hidden">
      <div className="flex gap-3">
        {[...Array(count)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="w-40 flex-shrink-0"
          >
            <DishCardSkeleton compact />
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// Stories section skeleton
export function StoriesSkeleton() {
  return (
    <div className="flex gap-4 overflow-hidden py-2 -mx-4 px-4">
      {[...Array(6)].map((_, i) => (
        <motion.div 
          key={i} 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: i * 0.08 }}
          className="flex-shrink-0 flex flex-col items-center gap-2"
        >
          <ShimmerSkeleton className="w-[72px] h-[72px] rounded-full" />
          <ShimmerSkeleton className="w-12 h-3 rounded" />
        </motion.div>
      ))}
    </div>
  );
}

// Action buttons skeleton
export function ActionButtonsSkeleton() {
  return (
    <div className="flex gap-3 overflow-hidden pb-2">
      {[...Array(4)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.08 }}
          className="flex-shrink-0 w-28 h-24 rounded-2xl bg-foreground/[0.03] border border-foreground/[0.06] flex flex-col items-center justify-center gap-2"
        >
          <ShimmerSkeleton className="w-10 h-10 rounded-xl" />
          <ShimmerSkeleton className="w-16 h-3" />
        </motion.div>
      ))}
    </div>
  );
}

// Mood selector skeleton
export function MoodSelectorSkeleton() {
  return (
    <div className="space-y-3">
      <ShimmerSkeleton className="h-3 w-24" />
      <div className="flex gap-2 overflow-hidden">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.06 }}
          >
            <ShimmerSkeleton className="w-20 h-9 rounded-full" />
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// Events section skeleton
export function EventsSkeleton() {
  return (
    <div className="space-y-3">
      <ShimmerSkeleton className="h-3 w-32" />
      <div className="flex gap-3 overflow-hidden -mx-4 px-4">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="flex-shrink-0 w-64"
          >
            <div className="rounded-2xl bg-card/50 border border-border/20 overflow-hidden">
              <ShimmerSkeleton className="w-full h-32 rounded-none" />
              <div className="p-4 space-y-2">
                <ShimmerSkeleton className="h-4 w-3/4" />
                <ShimmerSkeleton className="h-3 w-1/2" />
                <ShimmerSkeleton className="h-3 w-2/3" />
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// Restaurant info skeleton
export function RestaurantInfoSkeleton() {
  return (
    <div className="space-y-4">
      <ShimmerSkeleton className="h-3 w-28" />
      <div className="rounded-2xl bg-card/50 border border-border/20 p-4 space-y-4">
        <div className="flex items-center gap-3">
          <ShimmerSkeleton className="w-12 h-12 rounded-full" />
          <div className="flex-1 space-y-2">
            <ShimmerSkeleton className="h-4 w-32" />
            <ShimmerSkeleton className="h-3 w-24" />
          </div>
        </div>
        <div className="space-y-2">
          <ShimmerSkeleton className="h-3 w-full" />
          <ShimmerSkeleton className="h-3 w-3/4" />
        </div>
        <div className="flex gap-2">
          {[...Array(4)].map((_, i) => (
            <ShimmerSkeleton key={i} className="w-10 h-10 rounded-full" />
          ))}
        </div>
      </div>
    </div>
  );
}

// Section header skeleton
export function SectionHeaderSkeleton({ hasButton = true }: { hasButton?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <ShimmerSkeleton className="h-3 w-28" />
      {hasButton && <ShimmerSkeleton className="h-8 w-24 rounded-full" />}
    </div>
  );
}

// Full homepage skeleton
export function HomepageSkeleton() {
  return (
    <div className="space-y-6">
      <StoriesSkeleton />
      <ActionButtonsSkeleton />
      <MoodSelectorSkeleton />
      <div className="space-y-4">
        <SectionHeaderSkeleton />
        <DishCarouselSkeleton />
      </div>
      <EventsSkeleton />
      <RestaurantInfoSkeleton />
    </div>
  );
}
