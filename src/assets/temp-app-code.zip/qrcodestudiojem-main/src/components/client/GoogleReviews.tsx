import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Star, ExternalLink, Quote } from 'lucide-react';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { useLanguage } from '@/contexts/LanguageContext';
import { Skeleton } from '@/components/ui/skeleton';

interface GoogleReview {
  author_name: string;
  rating: number;
  text: string;
  time: number;
  profile_photo_url?: string;
  relative_time_description: string;
}

// Mock reviews for demo - in production these would come from Google Places API
const mockReviews: GoogleReview[] = [
  {
    author_name: 'Marco R.',
    rating: 5,
    text: 'Fantastico! Cibo eccellente e servizio impeccabile. Consiglio vivamente la pasta fatta in casa.',
    time: Date.now() - 86400000 * 3,
    relative_time_description: '3 giorni fa'
  },
  {
    author_name: 'Laura B.',
    rating: 5,
    text: 'Ambiente accogliente e piatti deliziosi. La pizza è tra le migliori che ho mangiato!',
    time: Date.now() - 86400000 * 7,
    relative_time_description: 'Una settimana fa'
  },
  {
    author_name: 'Giovanni M.',
    rating: 4,
    text: 'Ottima esperienza. Il tiramisù è da provare assolutamente. Torneremo sicuramente.',
    time: Date.now() - 86400000 * 14,
    relative_time_description: '2 settimane fa'
  },
];

export function GoogleReviews() {
  const { config, features } = useRestaurantConfig();
  const { currentLanguage } = useLanguage();
  const [reviews, setReviews] = useState<GoogleReview[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [averageRating, setAverageRating] = useState(4.8);
  const [totalReviews, setTotalReviews] = useState(127);

  useEffect(() => {
    // In production, this would fetch from Google Places API via edge function
    // For now, use mock data
    const timer = setTimeout(() => {
      setReviews(mockReviews);
      setIsLoading(false);
    }, 500);
    return () => clearTimeout(timer);
  }, [config?.google_place_id]);

  if (!features.google_reviews_enabled) return null;

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }).map((_, i) => (
      <Star
        key={i}
        className={`w-3.5 h-3.5 ${
          i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-muted-foreground/30'
        }`}
      />
    ));
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-4 w-24" />
        </div>
        <div className="flex gap-3 overflow-hidden">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="w-64 h-32 rounded-xl flex-shrink-0" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Header with rating summary */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
            <span className="text-lg font-semibold">{averageRating.toFixed(1)}</span>
          </div>
          <span className="text-sm text-muted-foreground">
            {totalReviews} recensioni
          </span>
        </div>
        {config?.google_place_id && (
          <a
            href={`https://www.google.com/maps/search/?api=1&query_place_id=${config.google_place_id}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            <img 
              src="https://www.google.com/favicon.ico" 
              alt="Google" 
              className="w-4 h-4"
            />
            Vedi tutte
            <ExternalLink className="w-3 h-3" />
          </a>
        )}
      </div>

      {/* Reviews carousel */}
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
        {reviews.map((review, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="min-w-[280px] max-w-[280px] p-4 rounded-xl bg-secondary/30 border border-border/30 space-y-3 flex-shrink-0"
          >
            {/* Author & Rating */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                  <span className="text-xs font-medium text-accent">
                    {review.author_name.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="text-sm font-medium">{review.author_name}</p>
                  <p className="text-[10px] text-muted-foreground">
                    {review.relative_time_description}
                  </p>
                </div>
              </div>
              <div className="flex">{renderStars(review.rating)}</div>
            </div>

            {/* Review text */}
            <div className="relative">
              <Quote className="absolute -top-1 -left-1 w-4 h-4 text-accent/30" />
              <p className="text-xs text-muted-foreground leading-relaxed line-clamp-3 pl-3">
                {review.text}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.section>
  );
}