import { useState, forwardRef, useMemo } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useOnboardingSteps, type OnboardingStepOption } from '@/hooks/useOnboardingSteps';
import { useLanguage } from '@/contexts/LanguageContext';
import { useDesignTemplates } from '@/hooks/useDesignTemplates';

// Re-export types for backward compatibility
export interface OnboardingFilters {
  is_featured?: boolean;
  is_seasonal?: boolean;
  tags?: string[];
  random?: boolean;
  suggest_sharing?: boolean;
}

export interface OnboardingOption {
  emoji: string;
  text: string;
  value: string;
  tags?: string[];
  filters?: OnboardingFilters;
}

interface OnboardingProps {
  onComplete: (answers: Record<string, OnboardingOption>) => void;
  onSkipToMenu: () => void;
}

export const ConversationalOnboarding = forwardRef<HTMLDivElement, OnboardingProps>(
  ({ onComplete, onSkipToMenu }, ref) => {
    const { steps, isLoading } = useOnboardingSteps();
    const { currentLanguage } = useLanguage();
    const [currentStep, setCurrentStep] = useState(0);
    const [answers, setAnswers] = useState<Record<string, OnboardingOption>>({});
    const [isAnimating, setIsAnimating] = useState(false);
    const [exitX, setExitX] = useState(0);
    
    // Design templates
    const { getActiveTemplate, getMergedConfig } = useDesignTemplates('onboarding');
    const activeTemplate = getActiveTemplate('onboarding');
    const templateConfig = getMergedConfig('onboarding');
    
    const templateKey = activeTemplate?.template_key || 'onboarding_conversational';

    // Convert DB steps to component format
    const formattedSteps = useMemo(() => {
      return steps.map(step => ({
        id: step.step_key,
        question: step.question[currentLanguage as 'it' | 'en'] || step.question.it,
        subtext: step.subtext?.[currentLanguage as 'it' | 'en'] || step.subtext?.it,
        tip: step.tip?.[currentLanguage as 'it' | 'en'] || step.tip?.it,
        options: step.options.map((opt: OnboardingStepOption) => ({
          emoji: opt.emoji,
          text: opt.label[currentLanguage as 'it' | 'en'] || opt.label.it,
          value: opt.id,
          filters: opt.filters,
        })),
      }));
    }, [steps, currentLanguage]);

    const step = formattedSteps[currentStep];

    const handleChoice = (option: OnboardingOption) => {
      if (isAnimating || !step) return;
      setIsAnimating(true);

      const newAnswers = { ...answers, [step.id]: option };
      setAnswers(newAnswers);

      setTimeout(() => {
        if (currentStep < formattedSteps.length - 1) {
          setCurrentStep(currentStep + 1);
          setIsAnimating(false);
        } else {
          onComplete(newAnswers);
        }
      }, 250);
    };

    const handleSwipe = (direction: 'left' | 'right') => {
      if (!step || isAnimating) return;
      
      if (direction === 'right') {
        // Confirm with first option
        const firstOption = step.options[0];
        if (firstOption) handleChoice(firstOption);
      } else {
        // Skip to menu
        onSkipToMenu();
      }
    };

    const handleDragEnd = (_: any, info: PanInfo) => {
      if (info.offset.x > 100) {
        setExitX(200);
        handleSwipe('right');
      } else if (info.offset.x < -100) {
        setExitX(-200);
        handleSwipe('left');
      }
    };

    if (isLoading) {
      return (
        <div
          ref={ref as React.RefObject<HTMLDivElement>}
          className="fixed inset-0 z-50 bg-background flex items-center justify-center p-6"
        >
          <div className="w-full max-w-sm">
            <div className="flex items-center justify-center gap-2 mb-12">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-1.5 w-3 rounded-full bg-foreground/10" />
              ))}
            </div>
            <div className="space-y-3 mb-8">
              <div className="h-7 bg-foreground/10 rounded-lg w-3/4 mx-auto" />
              <div className="h-4 bg-foreground/5 rounded w-1/2 mx-auto" />
            </div>
            <div className="space-y-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-14 bg-foreground/5 rounded-2xl" />
              ))}
            </div>
          </div>
        </div>
      );
    }

    if (!step) {
      onComplete({});
      return null;
    }

    // Step content component (reused across templates)
    const StepContent = ({ inCard = false }: { inCard?: boolean }) => (
      <div className={cn(inCard ? "" : "")}>
        <motion.h2 
          className="text-2xl font-medium text-foreground text-center mb-2"
        >
          {step.question}
        </motion.h2>
        {step.subtext && (
          <motion.p className="text-center text-muted-foreground text-sm mb-6">
            {step.subtext}
          </motion.p>
        )}
        {step.tip && (
          <motion.p className="text-center text-xs text-muted-foreground/70 mb-6 px-4 py-2 rounded-xl bg-secondary/30">
            {step.tip}
          </motion.p>
        )}
        {!step.subtext && !step.tip && <div className="mb-8" />}

        <div className="space-y-3">
          {step.options.map((option, index) => (
            <button
              key={option.value}
              onClick={() => handleChoice(option)}
              disabled={isAnimating}
              className="option-btn flex items-center gap-4 group w-full animate-fade-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <span className="text-2xl group-hover:scale-110 transition-transform duration-200">
                {option.emoji}
              </span>
              <span className="text-foreground/80 group-hover:text-foreground transition-colors font-medium">
                {option.text}
              </span>
              <ChevronRight className="ml-auto w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          ))}
        </div>

        <button
          onClick={onSkipToMenu}
          className="mt-8 w-full flex items-center justify-center gap-3 py-3 rounded-xl bg-transparent border border-border/30 text-muted-foreground/70 hover:text-muted-foreground hover:border-border/50 transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
        >
          <span className="text-sm font-medium">Vai al menu</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    );

    // Progress indicator component
    const ProgressIndicator = ({ variant = 'dots' }: { variant?: 'dots' | 'bar' | 'line' }) => {
      if (variant === 'bar') {
        return (
          <div className="w-full max-w-xs mx-auto h-1 bg-muted rounded-full overflow-hidden mb-8">
            <motion.div 
              className="h-full bg-accent"
              initial={{ width: 0 }}
              animate={{ width: `${((currentStep + 1) / formattedSteps.length) * 100}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        );
      }
      
      if (variant === 'line') {
        return (
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-border hidden md:block">
            {formattedSteps.map((_, i) => (
              <div 
                key={i}
                className={cn(
                  "absolute w-3 h-3 -left-[5px] rounded-full transition-colors",
                  i <= currentStep ? 'bg-accent' : 'bg-muted'
                )}
                style={{ top: `${(i / (formattedSteps.length - 1)) * 100}%` }}
              />
            ))}
          </div>
        );
      }

      return (
        <motion.div 
          className="flex items-center justify-center gap-2 mb-12"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          {formattedSteps.map((_, index) => (
            <motion.div
              key={index}
              className={cn(
                'h-1.5 rounded-full transition-all duration-500',
                index === currentStep
                  ? 'w-10 bg-accent'
                  : index < currentStep
                  ? 'w-3 bg-accent/50'
                  : 'w-3 bg-foreground/20'
              )}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: index * 0.1 }}
            />
          ))}
        </motion.div>
      );
    };

    // TEMPLATE: Cards Stack
    if (templateKey === 'onboarding_cards_stack') {
      return (
        <motion.div
          ref={ref}
          className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Single card - no stacking animation to prevent flickering */}
          <div className="relative w-full max-w-md">
            <motion.div
              key={currentStep}
              className="bg-card rounded-3xl shadow-xl border border-border/50 p-6 overflow-y-auto max-h-[520px]"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
            >
              <StepContent inCard />
            </motion.div>
          </div>
          
          {/* Progress */}
          <div className="flex gap-2 mt-6">
            {formattedSteps.map((_, i) => (
              <div
                key={i}
                className={`w-2 h-2 rounded-full transition-colors duration-300 ${
                  i <= currentStep ? 'bg-accent' : 'bg-muted'
                }`}
              />
            ))}
          </div>
        </motion.div>
      );
    }

    // TEMPLATE: Fullscreen Steps
    if (templateKey === 'onboarding_fullscreen_steps') {
      return (
        <motion.div
          ref={ref}
          className="fixed inset-0 z-50 bg-gradient-to-br from-background via-background to-accent/10 flex items-center justify-center p-6 overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Animated background */}
          <motion.div 
            className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-accent/10"
            animate={{ 
              backgroundPosition: ['0% 0%', '100% 100%'],
            }}
            transition={{ duration: 20, repeat: Infinity, repeatType: 'reverse' }}
          />
          
          {/* Vertical progress line */}
          <ProgressIndicator variant="line" />
          
          <div className="w-full max-w-md relative z-10">
            <ProgressIndicator variant="bar" />
            
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, scale: 0.95, y: 30 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: -30 }}
                transition={{ duration: 0.4, ease: [0.4, 0, 0.2, 1] }}
                className="bg-card/80 backdrop-blur-xl rounded-3xl p-8 shadow-2xl border border-border/50"
              >
                <StepContent />
              </motion.div>
            </AnimatePresence>
          </div>
        </motion.div>
      );
    }

    // DEFAULT TEMPLATE: Conversational
    return (
      <motion.div
        ref={ref}
        className="fixed inset-0 z-50 bg-background flex items-center justify-center p-6 overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <div className="w-full max-w-sm relative z-10">
          <ProgressIndicator variant="dots" />

          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
            >
              <StepContent />
            </motion.div>
          </AnimatePresence>
        </div>
      </motion.div>
    );
  }
);

ConversationalOnboarding.displayName = 'ConversationalOnboarding';
