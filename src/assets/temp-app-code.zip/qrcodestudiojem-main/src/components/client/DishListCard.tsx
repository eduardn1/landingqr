import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { type Dish } from '@/lib/mockData';
import { cn } from '@/lib/utils';
import { Flame, Sparkles, Plus } from 'lucide-react';
import { useState } from 'react';
import { DishPlaceholder, PlaceholderType } from './DishPlaceholder';
import { Button } from '@/components/ui/button';
import { useIsMobile } from '@/hooks/use-mobile';

interface SizeVariant {
  id: string;
  name_it: string;
  name_en: string;
  price: number;
}

interface DishListCardProps {
  dish: Dish & { size_variants?: SizeVariant[] };
  onClick?: () => void;
  isRecommended?: boolean;
  isMoodMatch?: boolean;
  categoryIcon?: string;
  placeholderType?: PlaceholderType;
  placeholderEmoji?: string;
  placeholderGradient?: string;
  placeholderImage?: string;
}

export function DishListCard({ 
  dish, 
  onClick, 
  isRecommended, 
  isMoodMatch, 
  categoryIcon,
  placeholderType,
  placeholderEmoji,
  placeholderGradient,
  placeholderImage
}: DishListCardProps) {
  const { currentLanguage, t } = useLanguage();
  const [imageError, setImageError] = useState(false);
  const isMobile = useIsMobile();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat(currentLanguage, {
      style: 'currency',
      currency: dish.currency || 'EUR',
    }).format(price);
  };

  // Calculate price range for dishes with size variants
  const hasVariants = dish.size_variants && dish.size_variants.length > 0;
  const priceRange = hasVariants && dish.size_variants
    ? {
        min: Math.min(...dish.size_variants.map(v => v.price)),
        max: Math.max(...dish.size_variants.map(v => v.price))
      }
    : null;

  const renderSpicyLevel = () => {
    if (!dish.spicyLevel || dish.spicyLevel === 0) return null;
    return (
      <div className="flex items-center gap-0.5">
        {[1, 2, 3].map((level) => (
          <Flame
            key={level}
            className={cn(
              "h-2.5 w-2.5",
              level <= dish.spicyLevel! ? "text-accent" : "text-muted-foreground/20"
            )}
            fill={level <= dish.spicyLevel! ? "currentColor" : "none"}
          />
        ))}
      </div>
    );
  };

  const hasImage = dish.images && dish.images[0] && !imageError;

  // Calculate discount percentage
  const hasDiscount = dish.originalPrice && dish.originalPrice > dish.price;
  const discountPercent = hasDiscount 
    ? Math.round(((dish.originalPrice! - dish.price) / dish.originalPrice!) * 100)
    : 0;

  return (
    <div
      onClick={onClick}
      className={cn(
        "flex gap-3 p-3 cursor-pointer group rounded-xl bg-foreground/[0.02] dark:bg-foreground/[0.04] border border-foreground/[0.06] transition-all hover:border-foreground/[0.12]",
        !dish.isAvailable && "opacity-50",
        isMoodMatch && "ring-2 ring-accent ring-offset-2 ring-offset-background"
      )}
    >
      {/* Image - Left Side */}
      <div className="relative w-20 h-20 flex-shrink-0 overflow-hidden rounded-lg bg-secondary/30">
        {hasImage ? (
          <img
            src={dish.images[0]}
            alt={getLocalizedContent(dish.name, currentLanguage)}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            onError={() => setImageError(true)}
          />
        ) : (
          <DishPlaceholder 
            categoryIcon={categoryIcon} 
            size="small" 
            placeholderType={placeholderType}
            placeholderEmoji={placeholderEmoji}
            placeholderGradient={placeholderGradient}
            placeholderImage={placeholderImage}
          />
        )}
        {isRecommended && !dish.badge && (
          <div className="absolute top-1 left-1 p-1 bg-gradient-to-r from-primary to-accent rounded-full z-10">
            <Sparkles className="w-2.5 h-2.5 text-primary-foreground" />
          </div>
        )}
        {dish.badge && (
          <div className="absolute top-1 left-1 px-1.5 py-0.5 bg-accent text-accent-foreground text-[8px] font-semibold rounded-full z-10 shadow-md backdrop-blur-sm">
            {dish.badge}
          </div>
        )}
      </div>

      {/* Content - Right Side */}
      <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
        <div>
          <h3 className="font-medium text-sm leading-tight text-foreground line-clamp-1">
            {getLocalizedContent(dish.name, currentLanguage)}
          </h3>
          <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
            {getLocalizedContent(dish.description, currentLanguage)}
          </p>
        </div>

        {/* Bottom Info - Price and Button */}
        <div className="flex items-center justify-between gap-2 mt-1.5">
          <div className="flex items-center gap-1.5 flex-wrap">
            {/* Price display */}
            {priceRange ? (
              <span className="text-sm font-semibold text-accent">
                €{priceRange.min.toFixed(2)} - €{priceRange.max.toFixed(2)}
              </span>
            ) : (
              <>
                <span className="text-sm font-semibold text-accent">
                  {formatPrice(dish.price)}
                </span>
                {hasDiscount && (
                  <>
                    <span className="text-xs text-muted-foreground line-through">
                      {formatPrice(dish.originalPrice!)}
                    </span>
                    <span className="text-[10px] font-medium bg-accent text-accent-foreground px-1.5 py-0.5 rounded-full">
                      -{discountPercent}%
                    </span>
                  </>
                )}
              </>
            )}
            {renderSpicyLevel()}
          </div>

          {/* Add button - Icon only on mobile, full button on desktop */}
          {isMobile ? (
            <Button
              size="icon"
              className="h-8 w-8 rounded-full flex-shrink-0"
              onClick={(e) => {
                e.stopPropagation();
                onClick?.();
              }}
            >
              <Plus className="w-4 h-4" />
            </Button>
          ) : (
            <Button
              size="sm"
              className="h-8 px-3 flex-shrink-0"
              onClick={(e) => {
                e.stopPropagation();
                onClick?.();
              }}
            >
              <Plus className="w-4 h-4 mr-1" />
              Dettagli
            </Button>
          )}
        </div>
      </div>

      {!dish.isAvailable && (
        <div className="absolute inset-0 bg-background/80 flex items-center justify-center rounded-xl">
          <span className="bg-foreground text-background px-2 py-1 rounded-full text-[10px] font-medium">
            Non disponibile
          </span>
        </div>
      )}
    </div>
  );
}
