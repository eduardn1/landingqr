import { useState, forwardRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useEvents, type DbEvent } from '@/hooks/useEvents';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedDbField } from '@/lib/i18n';
import { Skeleton } from '@/components/ui/skeleton';
import { Calendar, Clock, Music, Mic, PartyPopper, Wine, Sparkles, Ticket, X, CalendarPlus } from 'lucide-react';
import { format, parseISO, isToday, isTomorrow } from 'date-fns';
import { it, enUS, de, es, fr } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { TableReservation } from './TableReservation';

// Unified color for all event cards
const eventCardColor = 'bg-accent/10 border-accent/30';
const eventIconColor = 'text-accent';

const eventTypeConfig = {
  dj_set: { icon: Music, label: { it: 'DJ Set', en: 'DJ Set', de: 'DJ Set', es: 'DJ Set', fr: 'DJ Set' } },
  live_music: { icon: Music, label: { it: 'Live Music', en: 'Live Music', de: 'Live Musik', es: 'Música en Vivo', fr: 'Musique Live' } },
  karaoke: { icon: Mic, label: { it: 'Karaoke', en: 'Karaoke', de: 'Karaoke', es: 'Karaoke', fr: 'Karaoké' } },
  aperitivo: { icon: Wine, label: { it: 'Aperitivo', en: 'Aperitivo', de: 'Aperitif', es: 'Aperitivo', fr: 'Apéritif' } },
  degustazione: { icon: Wine, label: { it: 'Degustazione', en: 'Tasting', de: 'Verkostung', es: 'Degustación', fr: 'Dégustation' } },
  altro: { icon: PartyPopper, label: { it: 'Evento', en: 'Event', de: 'Veranstaltung', es: 'Evento', fr: 'Événement' } },
};

// Get locale for date-fns based on language
const getDateLocale = (lang: string) => {
  switch (lang) {
    case 'it': return it;
    case 'de': return de;
    case 'es': return es;
    case 'fr': return fr;
    default: return enUS;
  }
};

interface EventDetailModalProps {
  event: DbEvent | null;
  isOpen: boolean;
  onClose: () => void;
  onBookEvent: (event: DbEvent) => void;
}

const EventDetailModal = forwardRef<HTMLDivElement, EventDetailModalProps>(function EventDetailModal({ event, isOpen, onClose, onBookEvent }, ref) {
  const { currentLanguage, t } = useLanguage();
  
  if (!event) return null;
  
  const locale = getDateLocale(currentLanguage);
  const title = getLocalizedDbField(event, 'title', currentLanguage);
  const description = getLocalizedDbField(event, 'description', currentLanguage);
  const entryPriceNote = getLocalizedDbField(event, 'entry_price_note', currentLanguage);
  const eventDate = parseISO(event.event_date);
  const typeConfig = eventTypeConfig[event.event_type as keyof typeof eventTypeConfig] || eventTypeConfig.altro;
  const TypeIcon = typeConfig.icon;

  const getDateLabel = () => {
    if (isToday(eventDate)) return t('today');
    if (isTomorrow(eventDate)) return t('tomorrow');
    return format(eventDate, 'EEEE d MMMM yyyy', { locale });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed inset-4 m-auto max-w-md max-h-[85vh] bg-card rounded-2xl shadow-2xl border border-border z-50 overflow-hidden flex flex-col"
          >
            {/* Close button */}
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="absolute top-3 right-3 z-10 bg-background/80 backdrop-blur-sm rounded-full h-8 w-8"
            >
              <X className="w-4 h-4" />
            </Button>

            {/* Scrollable content */}
            <div className="flex-1 overflow-y-auto">
              {/* Image */}
              {event.image_url && (
                <div className="h-48 overflow-hidden">
                  <img 
                    src={event.image_url} 
                    alt={title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              
              {/* Content */}
              <div className="p-5 space-y-4">
                {/* Type badge */}
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 ${eventCardColor}`}>
                    <TypeIcon className={`w-4 h-4 ${eventIconColor}`} />
                    <span className="text-foreground">{typeConfig.label[currentLanguage as keyof typeof typeConfig.label] || typeConfig.label.en}</span>
                  </span>
                  {event.is_featured && (
                    <span className="px-3 py-1.5 rounded-full bg-accent/20 text-accent text-xs font-semibold flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4" />
                      {t('featured')}
                    </span>
                  )}
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-foreground">{title}</h3>

                {/* Date & Time */}
                <div className="flex flex-wrap items-center gap-4 text-sm">
                  <div className="flex items-center gap-2 text-foreground">
                    <Calendar className="w-5 h-5 text-accent" />
                    <span className="font-medium">{getDateLabel()}</span>
                  </div>
                  <div className="flex items-center gap-2 text-foreground">
                    <Clock className="w-5 h-5 text-accent" />
                    <span className="font-medium">{event.start_time}{event.end_time && ` - ${event.end_time}`}</span>
                  </div>
                </div>

                {/* Description */}
                {description && (
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
                  </div>
                )}

                {/* Price or Note */}
                {(event.entry_price !== null && event.entry_price > 0) || entryPriceNote ? (
                  <div className="flex items-center gap-2 p-3 rounded-xl bg-secondary/50 border border-border">
                    <Ticket className="w-5 h-5 text-muted-foreground" />
                    {event.entry_price !== null && event.entry_price > 0 && (
                      <span className="font-bold text-foreground">€{event.entry_price}</span>
                    )}
                    {entryPriceNote && (
                      <span className="text-muted-foreground text-sm">
                        {event.entry_price !== null && event.entry_price > 0 ? '- ' : ''}
                        {entryPriceNote}
                      </span>
                    )}
                  </div>
                ) : null}
              </div>
            </div>

            {/* Fixed Book Button at bottom */}
            <div className="p-4 border-t border-border bg-card">
              <Button
                onClick={() => onBookEvent(event)}
                className="w-full h-14 rounded-xl bg-accent text-accent-foreground hover:bg-accent/90 font-semibold gap-2 shadow-lg shadow-accent/30"
              >
                <CalendarPlus className="w-5 h-5" />
                {t('bookEvent')}
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
});

function EventCard({ event, onClick }: { event: DbEvent; onClick: () => void }) {
  const { currentLanguage, t } = useLanguage();
  const locale = getDateLocale(currentLanguage);
  
  const title = getLocalizedDbField(event, 'title', currentLanguage);
  const description = getLocalizedDbField(event, 'description', currentLanguage);
  const entryPriceNote = getLocalizedDbField(event, 'entry_price_note', currentLanguage);
  
  const eventDate = parseISO(event.event_date);
  const typeConfig = eventTypeConfig[event.event_type as keyof typeof eventTypeConfig] || eventTypeConfig.altro;
  const TypeIcon = typeConfig.icon;

  const getDateLabel = () => {
    if (isToday(eventDate)) return t('today');
    if (isTomorrow(eventDate)) return t('tomorrow');
    return format(eventDate, 'EEE d MMM', { locale });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`min-w-[280px] max-w-[280px] rounded-2xl overflow-hidden border cursor-pointer transition-all hover:shadow-lg ${eventCardColor} flex-shrink-0`}
    >
      {/* Image */}
      {event.image_url && (
        <div className="h-32 overflow-hidden">
          <img 
            src={event.image_url} 
            alt={title}
            className="w-full h-full object-cover"
          />
        </div>
      )}
      
      {/* Content */}
      <div className="p-4 space-y-3">
        {/* Type badge */}
        <div className="flex items-center gap-2">
          <span className={`px-2.5 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 bg-background/60 backdrop-blur-sm`}>
            <TypeIcon className={`w-3.5 h-3.5 ${eventIconColor}`} />
            <span className="text-foreground">{typeConfig.label[currentLanguage as keyof typeof typeConfig.label] || typeConfig.label.en}</span>
          </span>
          {event.is_featured && (
            <span className="px-2 py-1 rounded-full bg-accent/30 text-accent text-xs font-semibold flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
            </span>
          )}
        </div>

        {/* Title */}
        <h3 className="font-bold text-foreground line-clamp-2">{title}</h3>

        {/* Date & Time */}
        <div className="flex items-center gap-3 text-sm">
          <div className="flex items-center gap-1.5 text-foreground">
            <Calendar className="w-4 h-4 text-accent" />
            <span className="font-medium">{getDateLabel()}</span>
          </div>
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>{event.start_time}</span>
          </div>
        </div>

        {/* Description preview */}
        {description && (
          <p className="text-xs text-muted-foreground line-clamp-2">{description}</p>
        )}

        {/* Price or Note */}
        {((event.entry_price !== null && event.entry_price > 0) || entryPriceNote) && (
          <div className="flex items-center gap-1.5 text-sm">
            <Ticket className="w-4 h-4 text-accent" />
            {event.entry_price !== null && event.entry_price > 0 && (
              <span className="font-bold text-foreground">€{event.entry_price}</span>
            )}
            {entryPriceNote && (
              <span className="text-muted-foreground text-xs truncate max-w-[120px]">
                {entryPriceNote}
              </span>
            )}
          </div>
        )}

        {/* Tap to see more hint */}
        <p className="text-xs text-accent font-medium">
          {t('viewDetails')} →
        </p>
      </div>
    </motion.div>
  );
}

export function EventsSection() {
  const { events, isLoading } = useEvents();
  const { currentLanguage, t } = useLanguage();
  const [selectedEvent, setSelectedEvent] = useState<DbEvent | null>(null);
  const [bookingEvent, setBookingEvent] = useState<DbEvent | null>(null);
  const [isReservationOpen, setIsReservationOpen] = useState(false);

  const handleBookEvent = (event: DbEvent) => {
    setBookingEvent(event);
    setSelectedEvent(null);
    setIsReservationOpen(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-6 w-32" />
        <div className="flex gap-3 overflow-hidden">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="w-[280px] h-48 rounded-2xl flex-shrink-0" />
          ))}
        </div>
      </div>
    );
  }

  if (events.length === 0) return null;

  return (
    <>
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-4"
      >
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            {t('upcomingEvents')}
          </h2>
        </div>

        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
          {events.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <EventCard event={event} onClick={() => setSelectedEvent(event)} />
            </motion.div>
          ))}
        </div>
      </motion.section>

      <EventDetailModal 
        event={selectedEvent} 
        isOpen={!!selectedEvent} 
        onClose={() => setSelectedEvent(null)}
        onBookEvent={handleBookEvent}
      />

      <TableReservation
        isOpen={isReservationOpen}
        onClose={() => {
          setIsReservationOpen(false);
          setBookingEvent(null);
        }}
        preselectedDate={bookingEvent ? new Date(bookingEvent.event_date) : undefined}
        eventNote={bookingEvent ? `Evento: ${bookingEvent.title_it || bookingEvent.title_en}` : undefined}
        eventId={bookingEvent?.id}
        eventName={bookingEvent ? (bookingEvent.title_it || bookingEvent.title_en || '') : undefined}
      />
    </>
  );
}