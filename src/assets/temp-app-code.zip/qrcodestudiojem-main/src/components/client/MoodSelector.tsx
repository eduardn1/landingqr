import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useDynamicMoods } from '@/hooks/useDynamicMoods';
import { useLanguage } from '@/contexts/LanguageContext';
import { Skeleton } from '@/components/ui/skeleton';

// Legacy export for backward compatibility
export interface Mood {
  id: string;
  emoji: string;
  label: string;
  filters: {
    tags?: string[];
    is_featured?: boolean;
    spicy_level?: { min?: number; max?: number };
  };
}

// Fallback static moods (used if DB is empty)
export const moods: Mood[] = [
  { id: 'celebrate', emoji: '🎉', label: 'Speciale', filters: { is_featured: true } },
  { id: 'hungry', emoji: '🍽️', label: 'Fame', filters: { tags: ['hearty', 'rich'] } },
  { id: 'light', emoji: '🥗', label: 'Leggero', filters: { tags: ['light', 'healthy'] } },
  { id: 'spicy', emoji: '🌶️', label: 'Piccante', filters: { spicy_level: { min: 2 } } },
];

interface MoodSelectorProps {
  selectedMood: string | null;
  onSelectMood: (moodId: string | null) => void;
}

export function MoodSelector({ selectedMood, onSelectMood }: MoodSelectorProps) {
  const { moods: dbMoods, isLoading } = useDynamicMoods();
  const { currentLanguage } = useLanguage();

  if (isLoading) {
    return (
      <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
        {[...Array(4)].map((_, i) => (
          <Skeleton key={i} className="flex-shrink-0 w-24 h-10 rounded-full" />
        ))}
      </div>
    );
  }

  // Use DB moods if available, otherwise fallback to static
  const displayMoods = dbMoods.length > 0 
    ? dbMoods.map(m => ({
        id: m.mood_key,
        emoji: m.emoji,
        label: m.label[currentLanguage as 'it' | 'en'] || m.label.it,
        filters: m.filters,
      }))
    : moods;

  return (
    <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
      {displayMoods.map((mood, index) => (
        <motion.button
          key={mood.id}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
          onClick={() => onSelectMood(selectedMood === mood.id ? null : mood.id)}
          className={cn(
            'flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-full border transition-all duration-200',
            selectedMood === mood.id 
              ? 'bg-foreground text-background border-foreground' 
              : 'bg-transparent border-border/50 text-foreground/70 hover:border-foreground/30'
          )}
        >
          <span className="text-base">{mood.emoji}</span>
          <span className="text-xs font-medium">{mood.label}</span>
        </motion.button>
      ))}
    </div>
  );
}
