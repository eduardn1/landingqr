import { useRef, useMemo } from 'react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { DishCard } from '@/components/DishCard';
import { type Dish } from '@/lib/mockData';
import { motion } from 'framer-motion';

interface VirtualizedDishGridProps {
  dishes: Dish[];
  onDishClick?: (dish: Dish) => void;
  columns?: number;
  gap?: number;
  compact?: boolean;
  isDishRecommended?: (dish: Dish) => boolean;
  isDishMoodMatch?: (dish: Dish) => boolean;
}

export function VirtualizedDishGrid({
  dishes,
  onDishClick,
  columns = 2,
  gap = 12,
  compact = false,
  isDishRecommended,
  isDishMoodMatch,
}: VirtualizedDishGridProps) {
  const parentRef = useRef<HTMLDivElement>(null);

  // Group dishes into rows
  const rows = useMemo(() => {
    const result: Dish[][] = [];
    for (let i = 0; i < dishes.length; i += columns) {
      result.push(dishes.slice(i, i + columns));
    }
    return result;
  }, [dishes, columns]);

  // Estimate row height based on compact mode
  const estimateSize = compact ? 220 : 320;

  const virtualizer = useVirtualizer({
    count: rows.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => estimateSize,
    overscan: 3, // Render 3 extra rows above/below viewport
  });

  const virtualItems = virtualizer.getVirtualItems();

  // If few items, don't virtualize
  if (dishes.length <= 12) {
    return (
      <div 
        className="grid gap-3"
        style={{ gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }}
      >
        {dishes.map((dish, index) => (
          <motion.div
            key={dish.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <DishCard
              dish={dish}
              onClick={() => onDishClick?.(dish)}
              compact={compact}
              isRecommended={isDishRecommended?.(dish)}
              isMoodMatch={isDishMoodMatch?.(dish)}
            />
          </motion.div>
        ))}
      </div>
    );
  }

  return (
    <div
      ref={parentRef}
      className="w-full overflow-auto"
      style={{
        height: '100%',
        maxHeight: 'calc(100vh - 200px)',
      }}
    >
      <div
        style={{
          height: `${virtualizer.getTotalSize()}px`,
          width: '100%',
          position: 'relative',
        }}
      >
        {virtualItems.map((virtualRow) => {
          const rowDishes = rows[virtualRow.index];
          
          return (
            <div
              key={virtualRow.key}
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: `${virtualRow.size}px`,
                transform: `translateY(${virtualRow.start}px)`,
              }}
            >
              <div 
                className="grid h-full"
                style={{ 
                  gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
                  gap: `${gap}px`,
                  paddingBottom: `${gap}px`,
                }}
              >
                {rowDishes.map((dish) => (
                  <DishCard
                    key={dish.id}
                    dish={dish}
                    onClick={() => onDishClick?.(dish)}
                    compact={compact}
                    isRecommended={isDishRecommended?.(dish)}
                    isMoodMatch={isDishMoodMatch?.(dish)}
                  />
                ))}
                {/* Fill empty cells if last row is incomplete */}
                {rowDishes.length < columns && 
                  Array(columns - rowDishes.length).fill(null).map((_, i) => (
                    <div key={`empty-${i}`} />
                  ))
                }
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// Virtualized list for single column (e.g., category view)
interface VirtualizedDishListProps {
  dishes: Dish[];
  onDishClick?: (dish: Dish) => void;
  isDishRecommended?: (dish: Dish) => boolean;
  isDishMoodMatch?: (dish: Dish) => boolean;
}

export function VirtualizedDishList({
  dishes,
  onDishClick,
  isDishRecommended,
  isDishMoodMatch,
}: VirtualizedDishListProps) {
  const parentRef = useRef<HTMLDivElement>(null);

  const virtualizer = useVirtualizer({
    count: dishes.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 280,
    overscan: 5,
  });

  // If few items, don't virtualize
  if (dishes.length <= 10) {
    return (
      <div className="space-y-3">
        {dishes.map((dish, index) => (
          <motion.div
            key={dish.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <DishCard
              dish={dish}
              onClick={() => onDishClick?.(dish)}
              isRecommended={isDishRecommended?.(dish)}
              isMoodMatch={isDishMoodMatch?.(dish)}
            />
          </motion.div>
        ))}
      </div>
    );
  }

  const virtualItems = virtualizer.getVirtualItems();

  return (
    <div
      ref={parentRef}
      className="w-full overflow-auto"
      style={{
        height: '100%',
        maxHeight: 'calc(100vh - 200px)',
      }}
    >
      <div
        style={{
          height: `${virtualizer.getTotalSize()}px`,
          width: '100%',
          position: 'relative',
        }}
      >
        {virtualItems.map((virtualItem) => {
          const dish = dishes[virtualItem.index];
          
          return (
            <div
              key={virtualItem.key}
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: `${virtualItem.size}px`,
                transform: `translateY(${virtualItem.start}px)`,
                paddingBottom: '12px',
              }}
            >
              <DishCard
                dish={dish}
                onClick={() => onDishClick?.(dish)}
                isRecommended={isDishRecommended?.(dish)}
                isMoodMatch={isDishMoodMatch?.(dish)}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}
