import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useStories } from '@/hooks/useStories';
import { cn } from '@/lib/utils';
import { StoriesSkeleton } from './DishCardSkeleton';

// Import fallback images
import storyInterior from '@/assets/story-interior.jpg';
import storyChef from '@/assets/story-chef.jpg';
import storyIngredients from '@/assets/story-ingredients.jpg';

// Fallback image mapping
const fallbackImages: Record<string, string> = {
  'chef': storyChef,
  'ingredients': storyIngredients,
  'interior': storyInterior,
};

interface StoriesSectionProps {
  onDishSelect?: (dishId: string) => void;
  onOpenAbout?: () => void;
  isLoading?: boolean;
}

export function StoriesSection({ onDishSelect, onOpenAbout, isLoading = false }: StoriesSectionProps) {
  const { currentLanguage } = useLanguage();
  const { stories: dbStories, isLoading: storiesLoading } = useStories();
  const [activeStory, setActiveStory] = useState<number | null>(null);
  const [currentSlide, setCurrentSlide] = useState(0);

  // Format stories for display
  const allStories = useMemo(() => {
    return dbStories.map(story => ({
      id: story.story_key,
      title: story.label[currentLanguage as 'it' | 'en'] || story.label.it,
      icon: story.icon,
      gradient: story.gradient,
      hasNew: story.has_new,
      thumbnail: story.thumbnail_url || story.slides[0]?.url || fallbackImages[story.story_key] || storyChef,
      slides: story.slides,
    }));
  }, [dbStories, currentLanguage]);

  const handleStoryClick = (index: number) => {
    const story = allStories[index];
    // Always show slides if available
    if (story.slides.length > 0) {
      setActiveStory(index);
      setCurrentSlide(0);
    } else if (onOpenAbout) {
      // Only fallback to about modal if no slides
      onOpenAbout();
    }
  };

  if (isLoading || storiesLoading) {
    return <StoriesSkeleton />;
  }

  if (allStories.length === 0) {
    return null;
  }

  return (
    <>
      {/* Story Circles - Hide scrollbar */}
      <div className="flex gap-4 overflow-x-auto py-2 -mx-4 px-4" style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}>
        <style>{`.stories-scroll::-webkit-scrollbar { display: none; }`}</style>
        {allStories.map((story, index) => (
          <motion.button
            key={story.id}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.08, type: 'spring', stiffness: 200 }}
            onClick={() => handleStoryClick(index)}
            className="flex-shrink-0 flex flex-col items-center gap-2"
          >
            <div className={cn(
              "w-[72px] h-[72px] rounded-full overflow-hidden relative",
              "ring-2 ring-offset-2 ring-offset-background",
              story.hasNew ? "ring-accent" : "ring-foreground/30",
              "transition-all duration-300 hover:scale-105 hover:ring-accent"
            )}>
              {/* Prioritize thumbnail image over icon */}
              {story.thumbnail && !story.thumbnail.includes('undefined') ? (
                <img 
                  src={story.thumbnail} 
                  alt={story.title}
                  className="w-full h-full object-cover"
                />
              ) : story.icon ? (
                <div className={cn(
                  "w-full h-full flex items-center justify-center text-2xl",
                  `bg-gradient-to-br ${story.gradient || 'from-accent to-accent/50'}`
                )}>
                  {story.icon}
                </div>
              ) : (
                <div className={cn(
                  "w-full h-full flex items-center justify-center text-2xl bg-secondary"
                )}>
                  📷
                </div>
              )}
              {story.hasNew && (
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-0.5 bg-accent text-[8px] font-bold text-accent-foreground rounded-full">
                  NEW
                </div>
              )}
            </div>
            <span className="text-[10px] text-muted-foreground font-medium max-w-[70px] truncate text-center">
              {story.title}
            </span>
          </motion.button>
        ))}
      </div>

      {/* Story Modal */}
      <AnimatePresence>
        {activeStory !== null && allStories[activeStory]?.slides.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-background"
          >
            {/* Header: Progress bars + Story title */}
            <div className="absolute top-4 left-4 right-4 z-10 space-y-3">
              {/* Progress bars */}
              <div className="flex gap-1">
                {allStories[activeStory].slides.map((_, idx) => (
                  <div key={idx} className="flex-1 h-0.5 bg-foreground/20 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-foreground"
                      initial={{ width: idx < currentSlide ? '100%' : '0%' }}
                      animate={{ width: idx <= currentSlide ? '100%' : '0%' }}
                      transition={{ duration: idx === currentSlide ? (allStories[activeStory].slides[idx]?.duration || 5) : 0 }}
                      onAnimationComplete={() => {
                        if (idx === currentSlide) {
                          const nextSlide = currentSlide + 1;
                          if (nextSlide < allStories[activeStory].slides.length) {
                            setCurrentSlide(nextSlide);
                          } else {
                            // Move to next story or close
                            const nextStory = activeStory + 1;
                            if (nextStory < allStories.length) {
                              setActiveStory(nextStory);
                              setCurrentSlide(0);
                            } else {
                              setActiveStory(null);
                            }
                          }
                        }
                      }}
                    />
                  </div>
                ))}
              </div>
              
              {/* Story title */}
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-foreground/10 backdrop-blur-sm flex items-center justify-center overflow-hidden">
                  {allStories[activeStory].thumbnail ? (
                    <img src={allStories[activeStory].thumbnail} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-sm">{allStories[activeStory].icon || '📷'}</span>
                  )}
                </div>
                <span className="text-sm font-semibold text-white [text-shadow:_0_1px_4px_rgb(0_0_0_/_60%)]">
                  {allStories[activeStory].title}
                </span>
              </div>
            </div>

            {/* Background image */}
            <div className="absolute inset-0">
              <img 
                src={allStories[activeStory].slides[currentSlide]?.url || allStories[activeStory].thumbnail} 
                alt=""
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-transparent to-background/80" />
            </div>

            {/* Close button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setActiveStory(null);
              }}
              className="absolute top-12 right-4 z-30 w-10 h-10 flex items-center justify-center rounded-full bg-foreground/10 backdrop-blur-sm hover:bg-foreground/20 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Caption */}
            {allStories[activeStory].slides[currentSlide]?.caption && (
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute bottom-24 left-6 right-6 text-center"
              >
                <p className="text-2xl md:text-3xl font-bold text-white [text-shadow:_0_2px_12px_rgb(0_0_0_/_60%),_0_1px_3px_rgb(0_0_0_/_80%)]">
                  {allStories[activeStory].slides[currentSlide].caption?.[currentLanguage as 'it' | 'en'] || 
                   allStories[activeStory].slides[currentSlide].caption?.it}
                </p>
              </motion.div>
            )}

            {/* Navigation touch areas */}
            <div 
              className="absolute top-24 bottom-0 left-0 w-1/3 z-20" 
              onClick={(e) => {
                e.stopPropagation();
                if (currentSlide > 0) {
                  setCurrentSlide(currentSlide - 1);
                } else if (activeStory > 0) {
                  setActiveStory(activeStory - 1);
                  setCurrentSlide(0);
                }
              }} 
            />
            <div 
              className="absolute top-24 bottom-0 right-0 w-1/3 z-20" 
              onClick={(e) => {
                e.stopPropagation();
                if (currentSlide < allStories[activeStory].slides.length - 1) {
                  setCurrentSlide(currentSlide + 1);
                } else if (activeStory < allStories.length - 1) {
                  setActiveStory(activeStory + 1);
                  setCurrentSlide(0);
                } else {
                  setActiveStory(null);
                }
              }} 
            />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
