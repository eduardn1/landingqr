import { useState } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { SlidersHorizontal, AlertTriangle, X } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAllergens } from '@/hooks/useAllergens';
import { useDietTypes } from '@/hooks/useDietTypes';
import { useDynamicMoods } from '@/hooks/useDynamicMoods';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Skeleton } from '@/components/ui/skeleton';
import { BackButton } from '@/components/ui/BackButton';
import { cn } from '@/lib/utils';

export interface FilterState {
  search: string;
  allergens: string[];
  dietTypes: string[];
  priceRange: [number, number];
}

interface MenuFilterBarProps {
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  selectedMood: string | null;
  onSelectMood: (mood: string | null) => void;
  maxPrice?: number;
}

export function MenuFilterBar({ 
  filters, 
  onFiltersChange, 
  selectedMood, 
  onSelectMood,
  maxPrice = 50 
}: MenuFilterBarProps) {
  const { currentLanguage, t } = useLanguage();
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  const { allergens: dbAllergens, isLoading: allergensLoading } = useAllergens();
  const { dietTypes: dbDietTypes, isLoading: dietTypesLoading } = useDietTypes();
  const { moods: dbMoods, isLoading: moodsLoading } = useDynamicMoods();

  const hasActiveFilters = 
    filters.dietTypes.length > 0 ||
    filters.priceRange[1] < maxPrice ||
    selectedMood !== null;

  const hasAllergenFilters = filters.allergens.length > 0;
  
  const totalActiveFilters = filters.dietTypes.length + filters.allergens.length + (selectedMood ? 1 : 0);

  const clearFilters = () => {
    onFiltersChange({
      ...filters,
      dietTypes: [],
      allergens: [],
      priceRange: [0, maxPrice],
    });
    onSelectMood(null);
  };

  const toggleAllergen = (code: string) => {
    const newAllergens = filters.allergens.includes(code)
      ? filters.allergens.filter(a => a !== code)
      : [...filters.allergens, code];
    onFiltersChange({ ...filters, allergens: newAllergens });
  };

  const toggleDiet = (code: string) => {
    const newDiets = filters.dietTypes.includes(code)
      ? filters.dietTypes.filter(d => d !== code)
      : [...filters.dietTypes, code];
    onFiltersChange({ ...filters, dietTypes: newDiets });
  };

  const getAllergenName = (code: string) => {
    const allergen = dbAllergens.find(a => a.code === code);
    if (!allergen) return code;
    return currentLanguage === 'it' ? allergen.name_it : allergen.name_en;
  };

  const getDietName = (code: string) => {
    const diet = dbDietTypes.find(d => d.code === code);
    if (!diet) return code;
    return currentLanguage === 'it' ? diet.name.it : diet.name.en;
  };

  return (
    <div className="space-y-3">
      {/* Filter Button */}
      <Button 
        variant="outline" 
        onClick={() => setIsFilterOpen(true)}
        className={cn(
          "w-full h-11 rounded-xl gap-2 justify-center font-medium",
          totalActiveFilters > 0 && "border-accent bg-accent/10 text-accent"
        )}
      >
        <SlidersHorizontal className="h-4 w-4" />
        {t('filters')}
        {totalActiveFilters > 0 && (
          <span className="bg-accent text-accent-foreground rounded-full min-w-5 h-5 px-1.5 text-xs flex items-center justify-center font-semibold">
            {totalActiveFilters}
          </span>
        )}
      </Button>

      {/* Filter Drawer - Rendered via Portal to escape stacking context */}
      {createPortal(
        <AnimatePresence>
          {isFilterOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[9999]"
              onClick={() => setIsFilterOpen(false)}
            >
              {/* Backdrop */}
              <div className="absolute inset-0 bg-background/80 backdrop-blur-md" />

              {/* Panel */}
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-secondary/60 backdrop-blur-xl border-l border-border/30"
              >
                {/* Header */}
                <div className="p-5 border-b border-border/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
                        <SlidersHorizontal className="w-5 h-5 text-accent" />
                      </div>
                      <div>
                        <h2 className="text-lg font-semibold">{t('filters')}</h2>
                        <p className="text-xs text-muted-foreground">
                          {totalActiveFilters > 0 
                            ? `${totalActiveFilters} ${currentLanguage === 'it' ? 'filtri attivi' : 'active filters'}`
                            : currentLanguage === 'it' ? 'Personalizza la ricerca' : 'Customize your search'}
                        </p>
                      </div>
                    </div>
                    <BackButton onClick={() => setIsFilterOpen(false)} variant="close" size="lg" />
                  </div>
                </div>

                {/* Content - More compact */}
                <div className="p-3 overflow-y-auto h-[calc(100%-4.5rem)] space-y-4">
                  {/* Mood Selector */}
                  <div className="space-y-2">
                    <h4 className="font-semibold text-[10px] uppercase tracking-wider text-muted-foreground">
                      {currentLanguage === 'it' ? 'Come ti senti?' : 'How do you feel?'}
                    </h4>
                    {moodsLoading ? (
                      <div className="grid grid-cols-2 gap-1.5">
                        {[1, 2, 3, 4].map(i => (
                          <Skeleton key={i} className="h-10 rounded-lg" />
                        ))}
                      </div>
                    ) : dbMoods.length > 0 ? (
                      <div className="grid grid-cols-2 gap-1.5">
                        {dbMoods.map((mood) => (
                          <button
                            key={mood.mood_key}
                            onClick={() => onSelectMood(selectedMood === mood.mood_key ? null : mood.mood_key)}
                            className={cn(
                              "flex items-center gap-2 p-2.5 rounded-lg border transition-all text-left",
                              selectedMood === mood.mood_key
                                ? "border-accent bg-accent/10"
                                : "border-border/30 bg-background/20 hover:border-accent/50"
                            )}
                          >
                            <span className="text-lg">{mood.emoji}</span>
                            <span className="text-xs font-medium truncate">
                              {mood.label[currentLanguage as 'it' | 'en'] || mood.label.it}
                            </span>
                          </button>
                        ))}
                      </div>
                    ) : null}
                  </div>

                  {/* Allergens - Compact */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-destructive" />
                      <h4 className="font-semibold text-[10px] uppercase tracking-wider text-muted-foreground">
                        {currentLanguage === 'it' ? 'Escludi Allergeni' : 'Exclude Allergens'}
                      </h4>
                    </div>
                    {allergensLoading ? (
                      <div className="grid grid-cols-4 gap-1">
                        {[1, 2, 3, 4, 5, 6, 7, 8].map(i => (
                          <Skeleton key={i} className="h-8 rounded-md" />
                        ))}
                      </div>
                    ) : (
                      <div className="grid grid-cols-4 gap-1">
                        {dbAllergens.map((allergen) => (
                          <button
                            key={allergen.code}
                            onClick={() => toggleAllergen(allergen.code)}
                            title={currentLanguage === 'it' ? allergen.name_it : allergen.name_en}
                            className={cn(
                              "flex items-center justify-center p-2 rounded-md text-lg transition-all",
                              filters.allergens.includes(allergen.code)
                                ? "bg-destructive/20 border border-destructive"
                                : "bg-background/20 border border-border/30 hover:border-destructive/50"
                            )}
                          >
                            {allergen.icon}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Diet Types - Compact */}
                  <div className="space-y-2">
                    <h4 className="font-semibold text-[10px] uppercase tracking-wider text-muted-foreground">
                      {t('dietaryInfo')}
                    </h4>
                    {dietTypesLoading ? (
                      <div className="grid grid-cols-2 gap-1.5">
                        {[1, 2, 3, 4].map(i => (
                          <Skeleton key={i} className="h-10 rounded-lg" />
                        ))}
                      </div>
                    ) : dbDietTypes.length > 0 ? (
                      <div className="grid grid-cols-2 gap-1.5">
                        {dbDietTypes.map((diet) => (
                          <button
                            key={diet.code}
                            onClick={() => toggleDiet(diet.code)}
                            className={cn(
                              "flex items-center gap-2 p-2.5 rounded-lg border transition-all text-left",
                              filters.dietTypes.includes(diet.code)
                                ? "border-primary bg-primary/10"
                                : "border-border/30 bg-background/20 hover:border-primary/50"
                            )}
                          >
                            <span className="text-base">{diet.icon}</span>
                            <span className="text-xs font-medium truncate">
                              {currentLanguage === 'it' ? diet.name.it : diet.name.en}
                            </span>
                          </button>
                        ))}
                      </div>
                    ) : null}
                  </div>

                  {/* Price Range - Compact */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-[10px] uppercase tracking-wider text-muted-foreground">
                        {t('price')}
                      </h4>
                      <span className="text-xs font-medium">
                        €{filters.priceRange[0]} - €{filters.priceRange[1]}
                      </span>
                    </div>
                    <Slider
                      value={filters.priceRange}
                      onValueChange={(value) => onFiltersChange({ ...filters, priceRange: value as [number, number] })}
                      min={0}
                      max={maxPrice}
                      step={1}
                      className="py-1"
                    />
                  </div>

                  {/* Clear Filters */}
                  {totalActiveFilters > 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={clearFilters}
                      className="w-full rounded-lg"
                    >
                      {t('clearFilters')}
                    </Button>
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>,
        document.body
      )}

      {/* Active Filters Display - Aligned row that wraps */}
      {totalActiveFilters > 0 && (
        <div className="flex items-center gap-2 flex-wrap animate-fade-in">
          {selectedMood && (
            <Badge
              variant="secondary"
              className="gap-1.5 cursor-pointer hover:bg-accent/20 rounded-full px-3 py-1 text-xs"
              onClick={() => onSelectMood(null)}
            >
              {dbMoods.find(m => m.mood_key === selectedMood)?.emoji} 
              {dbMoods.find(m => m.mood_key === selectedMood)?.label[currentLanguage as 'it' | 'en']}
              <X className="h-3 w-3" />
            </Badge>
          )}
          {filters.dietTypes.map((code) => {
            const diet = dbDietTypes.find(d => d.code === code);
            return diet ? (
              <Badge
                key={code}
                variant="secondary"
                className="gap-1.5 cursor-pointer hover:bg-primary/10 rounded-full px-3 py-1 text-xs"
                onClick={() => toggleDiet(code)}
              >
                {diet.icon} {getDietName(code)}
                <X className="h-3 w-3" />
              </Badge>
            ) : null;
          })}
          {filters.allergens.map((code) => {
            const allergen = dbAllergens.find(a => a.code === code);
            return allergen ? (
              <Badge
                key={code}
                variant="destructive"
                className="gap-1.5 cursor-pointer rounded-full px-3 py-1 text-xs"
                onClick={() => toggleAllergen(code)}
              >
                {allergen.icon} No {getAllergenName(code)}
                <X className="h-3 w-3" />
              </Badge>
            ) : null;
          })}
        </div>
      )}
    </div>
  );
}
