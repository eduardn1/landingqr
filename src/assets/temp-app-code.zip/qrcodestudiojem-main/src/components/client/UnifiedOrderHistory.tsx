import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Package, Truck, Clock, ChevronRight, CalendarDays, Users, Search, Filter, X } from 'lucide-react';
import { format, isAfter, isBefore, parseISO, startOfDay, endOfDay, subDays, subMonths } from 'date-fns';
import { it, enUS } from 'date-fns/locale';
import type { TakeAwayOrder } from '@/hooks/useTakeAwayOrders';

interface Reservation {
  id: string;
  name: string;
  phone: string;
  reservation_date: string;
  reservation_time: string;
  guests: number;
  status: string;
  notes: string | null;
  created_at: string;
  event_id?: string | null;
}

interface UnifiedOrderHistoryProps {
  reservations?: Reservation[];
  takeawayOrders?: TakeAwayOrder[];
  isLoading?: boolean;
}

const reservationStatusConfig: Record<string, { label: string; labelEn: string; color: string }> = {
  pending: { label: 'In attesa', labelEn: 'Pending', color: 'bg-yellow-500/20 text-yellow-600' },
  confirmed: { label: 'Confermata', labelEn: 'Confirmed', color: 'bg-green-500/20 text-green-600' },
  completed: { label: 'Completata', labelEn: 'Completed', color: 'bg-blue-500/20 text-blue-600' },
  cancelled: { label: 'Annullata', labelEn: 'Cancelled', color: 'bg-red-500/20 text-red-600' },
  rejected: { label: 'Rifiutata', labelEn: 'Rejected', color: 'bg-red-500/20 text-red-600' },
};

const takeawayStatusConfig: Record<string, { label: string; labelEn: string; color: string }> = {
  pending: { label: 'In attesa', labelEn: 'Pending', color: 'bg-yellow-500/20 text-yellow-600' },
  accepted: { label: 'Accettato', labelEn: 'Accepted', color: 'bg-blue-500/20 text-blue-600' },
  preparing: { label: 'In preparazione', labelEn: 'Preparing', color: 'bg-blue-500/20 text-blue-600' },
  ready: { label: 'Pronto', labelEn: 'Ready', color: 'bg-green-500/20 text-green-600' },
  delivering: { label: 'In consegna', labelEn: 'Delivering', color: 'bg-purple-500/20 text-purple-600' },
  completed: { label: 'Completato', labelEn: 'Completed', color: 'bg-green-500/20 text-green-600' },
  rejected: { label: 'Rifiutato', labelEn: 'Rejected', color: 'bg-red-500/20 text-red-600' },
  cancelled: { label: 'Annullato', labelEn: 'Cancelled', color: 'bg-red-500/20 text-red-600' },
};

type DateFilter = 'all' | 'today' | 'week' | 'month' | '3months';
type StatusFilter = 'all' | 'active' | 'completed' | 'cancelled';

export function UnifiedOrderHistory({ 
  reservations = [], 
  takeawayOrders = [], 
  isLoading = false 
}: UnifiedOrderHistoryProps) {
  const navigate = useNavigate();
  const { currentLanguage } = useLanguage();
  const locale = currentLanguage === 'it' ? it : enUS;
  
  const [activeTab, setActiveTab] = useState<'all' | 'reservations' | 'takeaway'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState<DateFilter>('all');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [showFilters, setShowFilters] = useState(false);

  // Filter helper
  const filterByDate = (date: string) => {
    const itemDate = parseISO(date);
    const today = startOfDay(new Date());
    
    switch (dateFilter) {
      case 'today':
        return isAfter(itemDate, startOfDay(today)) && isBefore(itemDate, endOfDay(today));
      case 'week':
        return isAfter(itemDate, subDays(today, 7));
      case 'month':
        return isAfter(itemDate, subMonths(today, 1));
      case '3months':
        return isAfter(itemDate, subMonths(today, 3));
      default:
        return true;
    }
  };

  const filterByStatus = (status: string, type: 'reservation' | 'takeaway') => {
    const activeStatuses = type === 'reservation' 
      ? ['pending', 'confirmed'] 
      : ['pending', 'accepted', 'preparing', 'ready', 'delivering'];
    const completedStatuses = ['completed'];
    const cancelledStatuses = ['cancelled', 'rejected'];
    
    switch (statusFilter) {
      case 'active':
        return activeStatuses.includes(status);
      case 'completed':
        return completedStatuses.includes(status);
      case 'cancelled':
        return cancelledStatuses.includes(status);
      default:
        return true;
    }
  };

  // Filtered data
  const filteredReservations = useMemo(() => {
    return reservations.filter(r => {
      const matchesSearch = searchTerm === '' || 
        r.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDate = filterByDate(r.reservation_date);
      const matchesStatus = filterByStatus(r.status, 'reservation');
      return matchesSearch && matchesDate && matchesStatus;
    });
  }, [reservations, searchTerm, dateFilter, statusFilter]);

  const filteredTakeaway = useMemo(() => {
    return takeawayOrders.filter(o => {
      const matchesSearch = searchTerm === '' || 
        o.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (o.order_number && o.order_number.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesDate = filterByDate(o.created_at);
      const matchesStatus = filterByStatus(o.status, 'takeaway');
      return matchesSearch && matchesDate && matchesStatus;
    });
  }, [takeawayOrders, searchTerm, dateFilter, statusFilter]);

  // Combined and sorted
  const allItems = useMemo(() => {
    const reservationItems = filteredReservations.map(r => ({
      type: 'reservation' as const,
      id: r.id,
      date: r.reservation_date,
      status: r.status,
      data: r,
    }));
    
    const takeawayItems = filteredTakeaway.map(o => ({
      type: 'takeaway' as const,
      id: o.id,
      date: o.created_at,
      status: o.status,
      data: o,
    }));
    
    return [...reservationItems, ...takeawayItems].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }, [filteredReservations, filteredTakeaway]);

  const hasActiveFilters = searchTerm !== '' || dateFilter !== 'all' || statusFilter !== 'all';

  const clearFilters = () => {
    setSearchTerm('');
    setDateFilter('all');
    setStatusFilter('all');
  };

  if (isLoading) {
    return (
      <div className="space-y-3 animate-pulse">
        {[1, 2, 3].map(i => (
          <div key={i} className="h-24 bg-secondary/50 rounded-xl" />
        ))}
      </div>
    );
  }

  const renderReservationCard = (reservation: Reservation) => {
    const status = reservationStatusConfig[reservation.status] || reservationStatusConfig.pending;
    const isActive = ['pending', 'confirmed'].includes(reservation.status);
    
    return (
      <Card
        key={reservation.id}
        className={`cursor-pointer hover:border-accent/50 transition-colors ${!isActive ? 'opacity-75' : ''}`}
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                isActive ? 'bg-accent/10' : 'bg-secondary/50'
              }`}>
                <CalendarDays className={`w-5 h-5 ${isActive ? 'text-accent' : 'text-muted-foreground'}`} />
              </div>
              <div>
                <p className="font-semibold text-sm">
                  {format(new Date(reservation.reservation_date), 'EEEE d MMM', { locale })}
                </p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>{reservation.reservation_time}</span>
                  <Users className="w-3 h-3 ml-1" />
                  <span>{reservation.guests}</span>
                </div>
              </div>
            </div>
            <Badge className={status.color}>
              {currentLanguage === 'it' ? status.label : status.labelEn}
            </Badge>
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderTakeawayCard = (order: TakeAwayOrder) => {
    const status = takeawayStatusConfig[order.status] || takeawayStatusConfig.pending;
    const isActive = ['pending', 'accepted', 'preparing', 'ready', 'delivering'].includes(order.status);
    
    return (
      <Card
        key={order.id}
        className={`cursor-pointer hover:border-accent/50 transition-colors ${!isActive ? 'opacity-75' : ''}`}
        onClick={() => navigate(`/takeaway/order/${order.id}`)}
      >
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                isActive ? 'bg-orange-500/10' : 'bg-secondary/50'
              }`}>
                {order.order_type === 'pickup' ? (
                  <Package className={`w-5 h-5 ${isActive ? 'text-orange-500' : 'text-muted-foreground'}`} />
                ) : (
                  <Truck className={`w-5 h-5 ${isActive ? 'text-orange-500' : 'text-muted-foreground'}`} />
                )}
              </div>
              <div>
                <p className="font-semibold text-sm">{order.order_number}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>{format(new Date(order.created_at), 'dd MMM HH:mm', { locale })}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-right">
                <Badge className={status.color}>
                  {currentLanguage === 'it' ? status.label : status.labelEn}
                </Badge>
                <p className="text-sm font-bold mt-1">€{order.total.toFixed(2)}</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const EmptyState = () => (
    <div className="text-center py-8 text-muted-foreground">
      <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
      <p className="text-sm">
        {currentLanguage === 'it' ? 'Nessun risultato trovato' : 'No results found'}
      </p>
      {hasActiveFilters && (
        <Button variant="ghost" size="sm" onClick={clearFilters} className="mt-2">
          <X className="w-4 h-4 mr-1" />
          {currentLanguage === 'it' ? 'Rimuovi filtri' : 'Clear filters'}
        </Button>
      )}
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Search & Filters */}
      <div className="space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder={currentLanguage === 'it' ? 'Cerca...' : 'Search...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 h-9"
            />
          </div>
          <Button 
            variant={showFilters ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className="h-9"
          >
            <Filter className="w-4 h-4" />
          </Button>
        </div>
        
        {showFilters && (
          <div className="grid grid-cols-2 gap-2">
            <Select value={dateFilter} onValueChange={(v) => setDateFilter(v as DateFilter)}>
              <SelectTrigger className="h-9 text-xs">
                <SelectValue placeholder={currentLanguage === 'it' ? 'Periodo' : 'Period'} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{currentLanguage === 'it' ? 'Tutti' : 'All time'}</SelectItem>
                <SelectItem value="today">{currentLanguage === 'it' ? 'Oggi' : 'Today'}</SelectItem>
                <SelectItem value="week">{currentLanguage === 'it' ? 'Ultima settimana' : 'Last week'}</SelectItem>
                <SelectItem value="month">{currentLanguage === 'it' ? 'Ultimo mese' : 'Last month'}</SelectItem>
                <SelectItem value="3months">{currentLanguage === 'it' ? 'Ultimi 3 mesi' : 'Last 3 months'}</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
              <SelectTrigger className="h-9 text-xs">
                <SelectValue placeholder={currentLanguage === 'it' ? 'Stato' : 'Status'} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{currentLanguage === 'it' ? 'Tutti' : 'All'}</SelectItem>
                <SelectItem value="active">{currentLanguage === 'it' ? 'Attivi' : 'Active'}</SelectItem>
                <SelectItem value="completed">{currentLanguage === 'it' ? 'Completati' : 'Completed'}</SelectItem>
                <SelectItem value="cancelled">{currentLanguage === 'it' ? 'Annullati' : 'Cancelled'}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
        
        {hasActiveFilters && (
          <Button variant="ghost" size="sm" onClick={clearFilters} className="text-xs">
            <X className="w-3 h-3 mr-1" />
            {currentLanguage === 'it' ? 'Rimuovi filtri' : 'Clear filters'}
          </Button>
        )}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
        <TabsList className="grid w-full grid-cols-3 h-9">
          <TabsTrigger value="all" className="text-xs">
            {currentLanguage === 'it' ? 'Tutti' : 'All'} ({allItems.length})
          </TabsTrigger>
          <TabsTrigger value="reservations" className="text-xs">
            {currentLanguage === 'it' ? 'Prenotazioni' : 'Reservations'} ({filteredReservations.length})
          </TabsTrigger>
          <TabsTrigger value="takeaway" className="text-xs">
            Asporto ({filteredTakeaway.length})
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="space-y-2 mt-3">
          {allItems.length === 0 ? (
            <EmptyState />
          ) : (
            allItems.map(item => 
              item.type === 'reservation' 
                ? renderReservationCard(item.data as Reservation)
                : renderTakeawayCard(item.data as TakeAwayOrder)
            )
          )}
        </TabsContent>
        
        <TabsContent value="reservations" className="space-y-2 mt-3">
          {filteredReservations.length === 0 ? (
            <EmptyState />
          ) : (
            filteredReservations.map(r => renderReservationCard(r))
          )}
        </TabsContent>
        
        <TabsContent value="takeaway" className="space-y-2 mt-3">
          {filteredTakeaway.length === 0 ? (
            <EmptyState />
          ) : (
            filteredTakeaway.map(o => renderTakeawayCard(o))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
