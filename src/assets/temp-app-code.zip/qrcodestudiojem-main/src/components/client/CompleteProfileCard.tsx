import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, MapPin, ChevronRight, CheckCircle2, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuthSession } from '@/hooks/useAuthSession';
import { supabase } from '@/integrations/supabase/client';

interface CompleteProfileCardProps {
  hasName: boolean;
  hasAddress: boolean;
  onComplete: () => void;
}

export function CompleteProfileCard({ hasName, hasAddress, onComplete }: CompleteProfileCardProps) {
  const navigate = useNavigate();
  const { currentLanguage } = useLanguage();
  const { user } = useAuthSession();
  
  const completionItems = [
    { key: 'name', label: currentLanguage === 'it' ? 'Nome' : 'Name', done: hasName },
    { key: 'address', label: currentLanguage === 'it' ? 'Indirizzo di consegna' : 'Delivery address', done: hasAddress },
  ];
  
  const completedCount = completionItems.filter(i => i.done).length;
  const isComplete = completedCount === completionItems.length;
  
  // Trigger gamification when profile is complete
  useEffect(() => {
    if (isComplete && user) {
      supabase.functions.invoke('process-gamification', {
        body: { user_id: user.id, action_type: 'profile_completed' }
      }).catch(console.error);
    }
  }, [isComplete, user]);
  
  if (isComplete) return null;
  
  const percentage = Math.round((completedCount / completionItems.length) * 100);
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-blue-500/10 via-accent/5 to-transparent border border-blue-500/20 rounded-2xl p-4 overflow-hidden"
    >
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center flex-shrink-0">
          <User className="w-6 h-6 text-blue-500" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold">
            {currentLanguage === 'it' ? 'Completa il tuo profilo' : 'Complete your profile'}
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {currentLanguage === 'it' 
              ? 'Risparmia tempo nei prossimi ordini' 
              : 'Save time on your next orders'}
          </p>
          
          {/* Progress bar */}
          <div className="mt-3 h-2 bg-secondary rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-blue-500 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${percentage}%` }}
              transition={{ delay: 0.3, duration: 0.5 }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {completedCount}/{completionItems.length} {currentLanguage === 'it' ? 'completati' : 'completed'}
          </p>
          
          {/* Items checklist */}
          <div className="mt-3 space-y-2">
            {completionItems.map((item) => (
              <div 
                key={item.key}
                className={`flex items-center gap-2 text-sm ${item.done ? 'text-muted-foreground' : 'text-foreground'}`}
              >
                {item.done ? (
                  <CheckCircle2 className="w-4 h-4 text-green-500" />
                ) : (
                  <div className="w-4 h-4 rounded-full border-2 border-muted-foreground/30" />
                )}
                <span className={item.done ? 'line-through' : ''}>{item.label}</span>
              </div>
            ))}
          </div>
          
          <Button 
            size="sm" 
            className="mt-4 gap-1"
            onClick={onComplete}
          >
            {currentLanguage === 'it' ? 'Completa ora' : 'Complete now'}
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
