import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Trophy, Flame, Target, Star, Lock, ChevronRight, 
  Sparkles, Medal, Zap, Gift
} from 'lucide-react';
import { useGamification, Badge, Challenge } from '@/hooks/useGamification';
import { useLoyalty } from '@/hooks/useLoyalty';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { cn } from '@/lib/utils';

export function GamificationCard() {
  const { currentLanguage } = useLanguage();
  const { 
    levelInfo, 
    streak, 
    getEarnedBadges, 
    getLockedBadges, 
    getActiveChallenges,
    getNewBadgesCount,
    markBadgeAsSeen,
    isLoading 
  } = useGamification();
  const { points, isActive } = useLoyalty();
  const [showBadgesModal, setShowBadgesModal] = useState(false);
  const [showChallengesModal, setShowChallengesModal] = useState(false);
  const [selectedBadge, setSelectedBadge] = useState<Badge | null>(null);

  if (!isActive || isLoading) return null;

  const earnedBadges = getEarnedBadges();
  const lockedBadges = getLockedBadges();
  const activeChallenges = getActiveChallenges();
  const newBadgesCount = getNewBadgesCount();

  const t = {
    it: {
      level: 'Livello',
      points: 'Punti',
      streak: 'Serie',
      weeks: 'settimane',
      badges: 'Badge',
      challenges: 'Sfide',
      earned: 'Guadagnati',
      locked: 'Da sbloccare',
      active: 'Attive',
      completed: 'Completata!',
      progress: 'Progresso',
      reward: 'Ricompensa',
      noStreak: 'Inizia la tua serie!',
      viewAll: 'Vedi tutti',
      xpToNext: 'XP al prossimo livello',
    },
    en: {
      level: 'Level',
      points: 'Points',
      streak: 'Streak',
      weeks: 'weeks',
      badges: 'Badges',
      challenges: 'Challenges',
      earned: 'Earned',
      locked: 'Locked',
      active: 'Active',
      completed: 'Completed!',
      progress: 'Progress',
      reward: 'Reward',
      noStreak: 'Start your streak!',
      viewAll: 'View all',
      xpToNext: 'XP to next level',
    },
  };

  const labels = t[currentLanguage as keyof typeof t] || t.it;

  return (
    <>
      <Card className="overflow-hidden border-accent/20">
        {/* Level Header */}
        <CardHeader className="bg-gradient-to-r from-accent/20 via-accent/10 to-transparent pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-accent to-accent/60 flex items-center justify-center shadow-lg shadow-accent/30">
                  <span className="text-2xl font-bold text-accent-foreground">
                    {levelInfo?.level || 1}
                  </span>
                </div>
                <motion.div 
                  className="absolute -top-1 -right-1"
                  animate={{ rotate: [0, 15, -15, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Sparkles className="w-5 h-5 text-yellow-400" />
                </motion.div>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide">{labels.level}</p>
                <p className="font-bold text-lg text-foreground">{levelInfo?.title || 'Novizio'}</p>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1 text-yellow-500">
                <Star className="w-5 h-5 fill-current" />
                <span className="text-xl font-bold">{points?.total_points || 0}</span>
              </div>
              <p className="text-xs text-muted-foreground">{labels.points}</p>
            </div>
          </div>

          {/* XP Progress */}
          {levelInfo && (
            <div className="mt-4">
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>{levelInfo.xp_current} / {levelInfo.xp_to_next_level} XP</span>
                <span>{labels.xpToNext}</span>
              </div>
              <Progress value={levelInfo.progress} className="h-2" />
            </div>
          )}
        </CardHeader>

        <CardContent className="space-y-4 pt-4">
          {/* Stats Row */}
          <div className="grid grid-cols-3 gap-2">
            {/* Streak */}
            <motion.div 
              className="p-3 rounded-xl bg-gradient-to-br from-orange-500/20 to-red-500/10 border border-orange-500/20 text-center"
              whileHover={{ scale: 1.02 }}
            >
              <Flame className={cn(
                "w-6 h-6 mx-auto mb-1",
                (streak?.current_streak || 0) > 0 ? "text-orange-500" : "text-muted-foreground"
              )} />
              <p className="text-lg font-bold text-foreground">
                {streak?.current_streak || 0}
              </p>
              <p className="text-[10px] text-muted-foreground uppercase">{labels.streak}</p>
            </motion.div>

            {/* Badges */}
            <motion.button
              onClick={() => setShowBadgesModal(true)}
              className="relative p-3 rounded-xl bg-gradient-to-br from-yellow-500/20 to-amber-500/10 border border-yellow-500/20 text-center"
              whileHover={{ scale: 1.02 }}
            >
              <Trophy className="w-6 h-6 mx-auto mb-1 text-yellow-500" />
              <p className="text-lg font-bold text-foreground">
                {earnedBadges.length}
              </p>
              <p className="text-[10px] text-muted-foreground uppercase">{labels.badges}</p>
              {newBadgesCount > 0 && (
                <motion.span 
                  className="absolute -top-1 -right-1 w-5 h-5 bg-accent text-accent-foreground text-xs font-bold rounded-full flex items-center justify-center"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                >
                  {newBadgesCount}
                </motion.span>
              )}
            </motion.button>

            {/* Challenges */}
            <motion.button
              onClick={() => setShowChallengesModal(true)}
              className="p-3 rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/10 border border-purple-500/20 text-center"
              whileHover={{ scale: 1.02 }}
            >
              <Target className="w-6 h-6 mx-auto mb-1 text-purple-500" />
              <p className="text-lg font-bold text-foreground">
                {activeChallenges.filter(c => !c.isCompleted).length}
              </p>
              <p className="text-[10px] text-muted-foreground uppercase">{labels.challenges}</p>
            </motion.button>
          </div>

          {/* Active Challenges Preview */}
          {activeChallenges.filter(c => !c.isCompleted).length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1">
                  <Zap className="w-3 h-3" />
                  {labels.challenges} {labels.active}
                </h4>
              </div>
              {activeChallenges.filter(c => !c.isCompleted).slice(0, 2).map((challenge) => (
                <motion.div
                  key={challenge.id}
                  className="p-3 rounded-lg bg-secondary/30 border border-border/30"
                  whileHover={{ scale: 1.01 }}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{challenge.icon}</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">
                        {getLocalizedContent({ it: challenge.name_it, en: challenge.name_en || '' }, currentLanguage)}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Progress 
                          value={(challenge.progress / challenge.requirement_value) * 100} 
                          className="h-1.5 flex-1" 
                        />
                        <span className="text-xs text-muted-foreground">
                          {challenge.progress}/{challenge.requirement_value}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-accent text-xs font-bold">
                      <Gift className="w-3 h-3" />
                      +{challenge.points_reward}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}

          {/* Recent Badges Preview */}
          {earnedBadges.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1">
                  <Medal className="w-3 h-3" />
                  {labels.badges} {labels.earned}
                </h4>
                <button 
                  onClick={() => setShowBadgesModal(true)}
                  className="text-xs text-accent flex items-center gap-1 hover:underline"
                >
                  {labels.viewAll}
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
              <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
                {earnedBadges.slice(0, 5).map((badge) => (
                  <motion.button
                    key={badge.id}
                    onClick={() => {
                      setSelectedBadge(badge);
                      markBadgeAsSeen(badge.id);
                    }}
                    className={cn(
                      "flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br flex items-center justify-center text-2xl shadow-md",
                      badge.color
                    )}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {badge.icon}
                  </motion.button>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Badges Modal */}
      <Dialog open={showBadgesModal} onOpenChange={setShowBadgesModal}>
        <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              {labels.badges}
            </DialogTitle>
          </DialogHeader>
          
          {/* Earned Badges */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-muted-foreground">{labels.earned} ({earnedBadges.length})</h4>
            <div className="grid grid-cols-4 gap-2">
              {earnedBadges.map((badge) => (
                <motion.button
                  key={badge.id}
                  onClick={() => setSelectedBadge(badge)}
                  className={cn(
                    "aspect-square rounded-xl bg-gradient-to-br flex items-center justify-center text-3xl shadow-md",
                    badge.color
                  )}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {badge.icon}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Locked Badges */}
          {lockedBadges.length > 0 && (
            <div className="space-y-3 mt-4">
              <h4 className="text-sm font-semibold text-muted-foreground">{labels.locked} ({lockedBadges.length})</h4>
              <div className="grid grid-cols-4 gap-2">
                {lockedBadges.map((badge) => (
                  <motion.button
                    key={badge.id}
                    onClick={() => setSelectedBadge(badge)}
                    className="aspect-square rounded-xl bg-secondary/50 border border-border/50 flex items-center justify-center relative"
                    whileHover={{ scale: 1.05 }}
                  >
                    <span className="text-3xl opacity-30">{badge.icon}</span>
                    <Lock className="absolute w-4 h-4 text-muted-foreground" />
                  </motion.button>
                ))}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Challenges Modal */}
      <Dialog open={showChallengesModal} onOpenChange={setShowChallengesModal}>
        <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-500" />
              {labels.challenges}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-3">
            {activeChallenges.map((challenge) => (
              <motion.div
                key={challenge.id}
                className={cn(
                  "p-4 rounded-xl border",
                  challenge.isCompleted 
                    ? "bg-green-500/10 border-green-500/30" 
                    : "bg-secondary/30 border-border/30"
                )}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <div className="flex items-start gap-3">
                  <div className={cn(
                    "w-12 h-12 rounded-xl bg-gradient-to-br flex items-center justify-center text-2xl flex-shrink-0",
                    challenge.color
                  )}>
                    {challenge.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold">
                      {getLocalizedContent({ it: challenge.name_it, en: challenge.name_en || '' }, currentLanguage)}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {getLocalizedContent({ it: challenge.description_it || '', en: challenge.description_en || '' }, currentLanguage)}
                    </p>
                    
                    {!challenge.isCompleted && (
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-muted-foreground">{labels.progress}</span>
                          <span className="font-medium">{challenge.progress}/{challenge.requirement_value}</span>
                        </div>
                        <Progress 
                          value={(challenge.progress / challenge.requirement_value) * 100} 
                          className="h-2" 
                        />
                      </div>
                    )}

                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-1 text-accent text-sm font-bold">
                        <Gift className="w-4 h-4" />
                        +{challenge.points_reward} {labels.points}
                      </div>
                      {challenge.isCompleted && (
                        <span className="text-green-500 text-sm font-medium flex items-center gap-1">
                          ✓ {labels.completed}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Badge Detail Modal */}
      <Dialog open={!!selectedBadge} onOpenChange={() => setSelectedBadge(null)}>
        <DialogContent className="max-w-xs">
          {selectedBadge && (
            <div className="text-center py-4">
              <motion.div
                className={cn(
                  "w-24 h-24 rounded-2xl bg-gradient-to-br mx-auto flex items-center justify-center text-5xl shadow-lg mb-4",
                  selectedBadge.color
                )}
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', damping: 15 }}
              >
                {selectedBadge.icon}
              </motion.div>
              <h3 className="text-xl font-bold mb-2">
                {getLocalizedContent({ it: selectedBadge.name_it, en: selectedBadge.name_en || '' }, currentLanguage)}
              </h3>
              <p className="text-muted-foreground text-sm mb-4">
                {getLocalizedContent({ it: selectedBadge.description_it || '', en: selectedBadge.description_en || '' }, currentLanguage)}
              </p>
              {selectedBadge.points_reward > 0 && (
                <div className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-accent/20 text-accent font-semibold text-sm">
                  <Gift className="w-4 h-4" />
                  +{selectedBadge.points_reward} {labels.points}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
