import { motion } from 'framer-motion';
import { Star, Trophy, Gift, TrendingUp, Sparkles } from 'lucide-react';
import { useLoyalty } from '@/hooks/useLoyalty';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const tierColors: Record<string, string> = {
  bronze: 'from-amber-700 to-amber-500',
  silver: 'from-gray-400 to-gray-300',
  gold: 'from-yellow-500 to-yellow-300',
  platinum: 'from-purple-500 to-purple-300',
};

const tierIcons: Record<string, typeof Star> = {
  bronze: Star,
  silver: Trophy,
  gold: Trophy,
  platinum: Sparkles,
};

export function LoyaltyCard() {
  const { points, rewards, isLoading, isActive, getTierProgress } = useLoyalty();
  const { currentLanguage } = useLanguage();

  if (!isActive || isLoading) return null;

  const tierProgress = getTierProgress();
  const TierIcon = tierIcons[tierProgress.current] || Star;

  const translations = {
    it: {
      yourPoints: 'I tuoi punti',
      tier: 'Livello',
      nextTier: 'Prossimo livello',
      pointsNeeded: 'punti necessari',
      rewards: 'Premi disponibili',
      points: 'punti',
      noRewards: 'Accumula punti per sbloccare premi!',
    },
    en: {
      yourPoints: 'Your Points',
      tier: 'Tier',
      nextTier: 'Next tier',
      pointsNeeded: 'points needed',
      rewards: 'Available Rewards',
      points: 'points',
      noRewards: 'Earn points to unlock rewards!',
    },
  };

  const t = translations[currentLanguage as keyof typeof translations] || translations.it;

  return (
    <Card className="overflow-hidden">
      <CardHeader className={`bg-gradient-to-r ${tierColors[tierProgress.current]} text-white pb-8`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm opacity-80">{t.yourPoints}</p>
            <motion.p
              className="text-4xl font-bold"
              initial={{ scale: 0.5 }}
              animate={{ scale: 1 }}
            >
              {points?.total_points || 0}
            </motion.p>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2">
              <TierIcon className="w-6 h-6" />
              <span className="text-lg font-semibold capitalize">{tierProgress.current}</span>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="-mt-4 space-y-4">
        {/* Progress to next tier */}
        {tierProgress.next && (
          <div className="bg-card rounded-xl p-4 shadow-lg border border-border">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-muted-foreground flex items-center gap-1">
                <TrendingUp className="w-4 h-4" />
                {t.nextTier}: <span className="capitalize font-medium text-foreground">{tierProgress.next}</span>
              </span>
              <span className="text-muted-foreground">
                {tierProgress.pointsNeeded} {t.pointsNeeded}
              </span>
            </div>
            <Progress value={tierProgress.progress} className="h-2" />
          </div>
        )}

        {/* Available Rewards */}
        {rewards.length > 0 && (
          <div>
            <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
              <Gift className="w-4 h-4 text-accent" />
              {t.rewards}
            </h4>
            <div className="space-y-2">
              {rewards.slice(0, 3).map((reward) => {
                const canRedeem = (points?.total_points || 0) >= reward.points_required;
                return (
                  <motion.div
                    key={reward.id}
                    className={`p-3 rounded-lg border ${
                      canRedeem
                        ? 'border-accent/30 bg-accent/5'
                        : 'border-border bg-secondary/30 opacity-60'
                    }`}
                    whileHover={canRedeem ? { scale: 1.02 } : {}}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-sm">
                          {getLocalizedContent({ it: reward.name_it, en: reward.name_en || '' }, currentLanguage)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {getLocalizedContent({ it: reward.description_it || '', en: reward.description_en || '' }, currentLanguage)}
                        </p>
                      </div>
                      <div className={`px-2 py-1 rounded text-xs font-bold ${
                        canRedeem ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'
                      }`}>
                        {reward.points_required} {t.points}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {rewards.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-4">
            {t.noRewards}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
