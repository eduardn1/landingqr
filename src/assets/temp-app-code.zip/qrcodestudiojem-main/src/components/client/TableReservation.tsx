import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Clock, Users, Phone, Check, ChevronRight, AlertCircle, UsersRound } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { BackButton } from '@/components/ui/BackButton';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { useReservations } from '@/hooks/useReservations';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';

interface TableReservationProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedDate?: Date;
  eventNote?: string;
  eventId?: string;
  eventName?: string;
}

interface TimeRange {
  open: string;
  close: string;
}

interface BusinessHour {
  day: string;
  ranges?: TimeRange[];
  open?: string;
  close?: string;
  closed: boolean;
}

interface ClosedDate {
  id: string;
  date: string;
  is_recurring: boolean;
}

const guestOptions = [1, 2, 3, 4, 5, 6, 7, 8];

const DAY_MAP: Record<number, string> = {
  0: 'sunday',
  1: 'monday',
  2: 'tuesday',
  3: 'wednesday',
  4: 'thursday',
  5: 'friday',
  6: 'saturday'
};

// Generate time slots between open and close
function generateTimeSlots(open: string, close: string): string[] {
  const slots: string[] = [];
  const [openHour, openMin] = open.split(':').map(Number);
  const [closeHour, closeMin] = close.split(':').map(Number);
  
  let currentHour = openHour;
  let currentMin = openMin;
  
  while (currentHour < closeHour || (currentHour === closeHour && currentMin < closeMin)) {
    slots.push(`${String(currentHour).padStart(2, '0')}:${String(currentMin).padStart(2, '0')}`);
    currentMin += 30;
    if (currentMin >= 60) {
      currentMin = 0;
      currentHour++;
    }
  }
  
  return slots;
}

// Generate time slots from multiple ranges with range labels
function generateTimeSlotsFromRanges(ranges: TimeRange[]): { slots: string[]; rangeLabels: Map<string, string> } {
  const allSlots: string[] = [];
  const rangeLabels = new Map<string, string>();
  
  ranges.forEach((range, index) => {
    const slots = generateTimeSlots(range.open, range.close);
    const label = getRangeLabel(range.open, index, ranges.length);
    slots.forEach(slot => {
      rangeLabels.set(slot, label);
      allSlots.push(slot);
    });
  });
  
  return { slots: [...new Set(allSlots)].sort(), rangeLabels };
}

// Get label for time range (Pranzo, Cena, etc.)
function getRangeLabel(openTime: string, index: number, totalRanges: number): string {
  const hour = parseInt(openTime.split(':')[0], 10);
  if (totalRanges === 1) return '';
  if (hour < 15) return 'Pranzo';
  if (hour < 18) return 'Aperitivo';
  return 'Cena';
}

// Group time slots by range
function groupSlotsByRange(slots: string[], rangeLabels: Map<string, string>): Map<string, string[]> {
  const groups = new Map<string, string[]>();
  
  slots.forEach(slot => {
    const label = rangeLabels.get(slot) || 'Orari';
    if (!groups.has(label)) {
      groups.set(label, []);
    }
    groups.get(label)!.push(slot);
  });
  
  return groups;
}

const RESERVATION_DRAFT_KEY = 'reservation_draft';

export function TableReservation({ isOpen, onClose, preselectedDate, eventNote, eventId, eventName }: TableReservationProps) {
  const { t } = useLanguage();
  const { config } = useRestaurantConfig();
  const { createReservation, isAuthenticated, isLoading: isAuthLoading } = useReservations();
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [guests, setGuests] = useState(2);
  const [isGroupBooking, setIsGroupBooking] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    notes: ''
  });
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [phoneValidated, setPhoneValidated] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  
  // Restore draft reservation data after login
  useEffect(() => {
    if (isOpen && isAuthenticated && !isAuthLoading) {
      const draft = sessionStorage.getItem(RESERVATION_DRAFT_KEY);
      const hasPendingReservation = sessionStorage.getItem('reservation_pending');
      if (draft) {
        try {
          const data = JSON.parse(draft);
          if (data.selectedDate) setSelectedDate(new Date(data.selectedDate));
          if (data.selectedTime) setSelectedTime(data.selectedTime);
          if (data.guests) setGuests(data.guests);
          if (data.isGroupBooking !== undefined) setIsGroupBooking(data.isGroupBooking);
          if (data.formData) {
            setFormData(data.formData);
            if (data.formData.phone) {
              setPhoneValidated(true);
            }
          }
          if (data.step) setStep(data.step);
          sessionStorage.removeItem(RESERVATION_DRAFT_KEY);
          sessionStorage.removeItem('reservation_pending');
          // Only show toast if we restored a pending reservation (avoids double toast)
          if (hasPendingReservation) {
            toast.success('Bentornato! Puoi completare la prenotazione.', { id: 'reservation-restored' });
          }
        } catch (e) {
          console.error('Error restoring reservation draft:', e);
        }
      }
    }
  }, [isOpen, isAuthenticated, isAuthLoading]);
  
  // Save draft and redirect to login
  const handleLoginRedirect = () => {
    const draft = {
      selectedDate: selectedDate?.toISOString(),
      selectedTime,
      guests,
      isGroupBooking,
      formData,
      step
    };
    sessionStorage.setItem(RESERVATION_DRAFT_KEY, JSON.stringify(draft));
    sessionStorage.setItem('reservation_pending', 'true');
    window.location.href = '/auth?returnTo=/';
  };
  
  // Fetch user profile for auto-fill
  const { data: userProfile } = useQuery({
    queryKey: ['user-profile-for-reservation'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      const { data } = await supabase
        .from('profiles')
        .select('display_name, phone')
        .eq('user_id', user.id)
        .maybeSingle();
      return data;
    },
    enabled: isOpen
  });
  
  // Auto-fill from profile when modal opens
  useEffect(() => {
    if (isOpen && userProfile && !formData.name && !formData.phone) {
      setFormData(prev => ({
        ...prev,
        name: userProfile.display_name || prev.name,
        phone: userProfile.phone ? formatPhoneDisplay(userProfile.phone) : prev.phone
      }));
      // Validate pre-filled phone
      if (userProfile.phone && validatePhone(userProfile.phone)) {
        setPhoneValidated(true);
      }
    }
  }, [isOpen, userProfile]);
  
  // Phone validation
  const validatePhone = (phone: string): boolean => {
    const cleaned = phone.replace(/[\s\-]/g, '');
    // Italian phone: +39 or 3xx with 9-10 digits
    const phoneRegex = /^(\+39)?[0-9]{9,10}$/;
    return phoneRegex.test(cleaned) && cleaned.length >= 9;
  };
  
  // Format phone for display: +39 333 123 4567
  const formatPhoneDisplay = (value: string): string => {
    const digits = value.replace(/\D/g, '');
    
    if (digits.startsWith('39') && digits.length > 2) {
      const rest = digits.slice(2);
      if (rest.length <= 3) return `+39 ${rest}`;
      if (rest.length <= 6) return `+39 ${rest.slice(0, 3)} ${rest.slice(3)}`;
      return `+39 ${rest.slice(0, 3)} ${rest.slice(3, 6)} ${rest.slice(6, 10)}`;
    }
    
    if (digits.length <= 3) return digits;
    if (digits.length <= 6) return `${digits.slice(0, 3)} ${digits.slice(3)}`;
    return `${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6, 10)}`;
  };
  
  const handlePhoneChange = (value: string) => {
    // Allow only digits, spaces, + and -
    const sanitized = value.replace(/[^\d\s\+\-]/g, '');
    const formatted = formatPhoneDisplay(sanitized);
    
    setFormData({ ...formData, phone: formatted });
    
    if (formatted.length > 0) {
      const isValid = validatePhone(formatted);
      if (!isValid) {
        setPhoneError('Formato non valido (es. +39 333 123 4567)');
        setPhoneValidated(false);
      } else {
        if (!phoneValidated) {
          toast.success('Numero valido!', { duration: 1500 });
          setPhoneValidated(true);
        }
        setPhoneError(null);
      }
    } else {
      setPhoneError(null);
      setPhoneValidated(false);
    }
  };

  // Set preselected date from event
  useEffect(() => {
    if (preselectedDate && isOpen) {
      setSelectedDate(preselectedDate);
      if (eventNote) {
        setFormData(prev => ({ ...prev, notes: eventNote }));
      }
    }
  }, [preselectedDate, eventNote, isOpen]);

  // Reset form when closed
  useEffect(() => {
    if (!isOpen) {
      setStep(1);
      setSelectedDate(null);
      setSelectedTime(null);
      setGuests(2);
      setIsGroupBooking(false);
      setSelectedPeriod(null);
      setFormData({ name: '', phone: '', notes: '' });
      setPhoneError(null);
      setPhoneValidated(false);
    }
  }, [isOpen]);

  const businessHours = (config?.business_hours as BusinessHour[] | null) || [];
  const maxGuestsPerSlot = (config as any)?.max_guests_per_slot || 20;

  // Fetch closed dates
  const { data: closedDates = [] } = useQuery({
    queryKey: ['closed-dates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('closed_dates')
        .select('*');
      if (error) throw error;
      return data as ClosedDate[];
    }
  });

  // Fetch existing reservations for capacity check
  const { data: existingReservations = [] } = useQuery({
    queryKey: ['reservations-for-date', selectedDate?.toISOString()],
    queryFn: async () => {
      if (!selectedDate) return [];
      const dateStr = format(selectedDate, 'yyyy-MM-dd');
      const { data, error } = await supabase
        .from('reservations')
        .select('reservation_time, guests')
        .eq('reservation_date', dateStr)
        .in('status', ['pending', 'confirmed']);
      if (error) throw error;
      return data || [];
    },
    enabled: !!selectedDate
  });

  // Check if a date is closed (special closures)
  const isDateClosed = (date: Date): boolean => {
    const dateStr = format(date, 'yyyy-MM-dd');
    const monthDay = format(date, 'MM-dd');
    
    return closedDates.some(cd => {
      if (cd.is_recurring) {
        return cd.date.slice(5) === monthDay;
      }
      return cd.date === dateStr;
    });
  };

  // Check if a day is open (business hours)
  const isDayOpen = (date: Date): boolean => {
    if (isDateClosed(date)) return false;
    const dayName = DAY_MAP[date.getDay()];
    const hours = businessHours.find(h => h.day === dayName);
    if (!hours) return true;
    if (hours.closed) return false;
    if (hours.ranges && hours.ranges.length === 0) return false;
    return true;
  };

  // Get time slots for a specific date based on business hours
  const getTimeSlotsForDate = (date: Date): { slots: string[]; rangeLabels: Map<string, string> } => {
    const dayName = DAY_MAP[date.getDay()];
    const hours = businessHours.find(h => h.day === dayName);
    if (!hours || hours.closed) return { slots: [], rangeLabels: new Map() };
    
    if (hours.ranges && hours.ranges.length > 0) {
      return generateTimeSlotsFromRanges(hours.ranges);
    }
    
    if (hours.open && hours.close) {
      const slots = generateTimeSlots(hours.open, hours.close);
      return { slots, rangeLabels: new Map() };
    }
    
    return { slots: [], rangeLabels: new Map() };
  };

  // Get available guests for a time slot
  const getAvailableGuests = (time: string): number => {
    const bookedGuests = existingReservations
      .filter(r => r.reservation_time === time)
      .reduce((sum, r) => sum + r.guests, 0);
    return Math.max(0, maxGuestsPerSlot - bookedGuests);
  };

  // Generate dates for the next 14 days, filtering out closed days
  const availableDates = useMemo(() => {
    const dates: Date[] = [];
    let daysChecked = 0;
    let daysAdded = 0;
    
    while (daysAdded < 14 && daysChecked < 30) {
      const date = new Date();
      date.setDate(date.getDate() + daysChecked);
      if (isDayOpen(date)) {
        dates.push(date);
        daysAdded++;
      }
      daysChecked++;
    }
    
    return dates;
  }, [businessHours, closedDates]);

  // Get available time slots and range labels for selected date
  const { slots: availableTimeSlots, rangeLabels } = selectedDate 
    ? getTimeSlotsForDate(selectedDate) 
    : { slots: [], rangeLabels: new Map() };

  // Group slots by range
  const groupedSlots = useMemo(() => {
    if (rangeLabels.size === 0 && availableTimeSlots.length > 0) {
      return new Map([['Orari disponibili', availableTimeSlots]]);
    }
    return groupSlotsByRange(availableTimeSlots, rangeLabels);
  }, [availableTimeSlots, rangeLabels]);

  // Get available period filters
  const availablePeriods = useMemo(() => {
    return Array.from(groupedSlots.keys()).filter(k => k !== 'Orari disponibili');
  }, [groupedSlots]);

  // Filtered slots based on selected period
  const filteredGroupedSlots = useMemo(() => {
    if (!selectedPeriod || availablePeriods.length <= 1) {
      return groupedSlots;
    }
    const filtered = new Map<string, string[]>();
    if (groupedSlots.has(selectedPeriod)) {
      filtered.set(selectedPeriod, groupedSlots.get(selectedPeriod)!);
    }
    return filtered;
  }, [groupedSlots, selectedPeriod, availablePeriods]);

  const formatDate = (date: Date) => {
    const days = ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'];
    const months = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];
    return {
      day: days[date.getDay()],
      date: date.getDate(),
      month: months[date.getMonth()]
    };
  };

  const handleSubmit = async () => {
    if (!selectedDate || !selectedTime) return;
    
    setIsSubmitting(true);
    
    // Add group info to notes if group booking
    let finalNotes = formData.notes;
    if (isGroupBooking && !finalNotes.toLowerCase().includes('gruppo')) {
      finalNotes = `[GRUPPO/+8 PERSONE] ${finalNotes}`.trim();
    }
    
    const result = await createReservation({
      name: formData.name,
      phone: formData.phone,
      reservation_date: selectedDate.toISOString().split('T')[0],
      reservation_time: selectedTime,
      guests: isGroupBooking ? 9 : guests, // 9+ indicates group
      notes: finalNotes || undefined,
      event_id: eventId,
      event_name: eventName
    });
    
    setIsSubmitting(false);
    
    if (!result.error) {
      onClose();
    }
  };

  // Check if step 1 is complete (date, period if needed, time selected)
  const isStep1Complete = () => {
    if (!selectedDate || !selectedTime) return false;
    // If multiple periods exist, one must be selected
    if (availablePeriods.length > 1 && !selectedPeriod) return false;
    return true;
  };

  const canProceed = () => {
    if (step === 1) return isStep1Complete();
    if (step === 2) return formData.name && formData.phone && phoneValidated && !phoneError && (!isGroupBooking || formData.notes);
    return true;
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-start justify-center pt-16 pb-4 px-4"
          onClick={onClose}
        >
          {/* Backdrop */}
          <motion.div 
            className="absolute inset-0 bg-background/60 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-lg max-h-[85vh] overflow-hidden rounded-2xl bg-secondary/40 backdrop-blur-xl border border-border/30 shadow-2xl"
          >
            {/* Header */}
            <div className="p-5 border-b border-border/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {step > 1 && (
                    <BackButton onClick={() => setStep(step - 1)} size="sm" />
                  )}
                  <h2 className="text-lg font-semibold">Prenota un Tavolo</h2>
                </div>
                <BackButton onClick={onClose} variant="close" size="lg" />
              </div>
              
              {/* Progress */}
              <div className="flex gap-2 mt-3">
                {[1, 2, 3].map((s) => (
                  <div
                    key={s}
                    className={cn(
                      "h-1 flex-1 rounded-full transition-colors",
                      s <= step ? "bg-accent" : "bg-border/30"
                    )}
                  />
                ))}
              </div>
            </div>

            {/* Content */}
            <div className="p-5 overflow-y-auto" style={{ maxHeight: 'calc(80vh - 12rem)' }}>
              <AnimatePresence mode="wait">
                {/* Step 1: Date & Time */}
                {step === 1 && (
                  <motion.div
                    key="step1"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-5"
                  >
                    {/* Date Selection */}
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                        <Calendar className="w-4 h-4" />
                        Seleziona data
                        {!selectedDate && <span className="text-xs text-accent">• richiesto</span>}
                      </label>
                      <div className="flex gap-2 overflow-x-auto pb-2 -mx-2 px-2 scrollbar-hide">
                        {availableDates.map((date) => {
                          const formatted = formatDate(date);
                          const isSelected = selectedDate?.toDateString() === date.toDateString();
                          return (
                            <button
                              key={date.toISOString()}
                              onClick={() => {
                                setSelectedDate(date);
                                setSelectedTime(null);
                                setSelectedPeriod(null);
                              }}
                              className={cn(
                                "flex-shrink-0 w-14 py-2.5 rounded-xl border text-center transition-all",
                                isSelected 
                                  ? "bg-accent text-accent-foreground border-accent shadow-lg shadow-accent/20" 
                                  : "bg-background/30 border-border/30 hover:bg-background/50"
                              )}
                            >
                              <span className="text-[10px] text-muted-foreground block">{formatted.day}</span>
                              <span className="text-base font-semibold">{formatted.date}</span>
                              <span className="text-[10px] text-muted-foreground block">{formatted.month}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Period Selection (Pranzo/Cena) - Only show when date is selected and multiple periods exist */}
                    {selectedDate && availablePeriods.length > 1 && (
                      <div className="space-y-2">
                      <label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          Pranzo o Cena?
                          {!selectedPeriod && <span className="text-xs text-accent">• seleziona</span>}
                        </label>
                        <div className="flex gap-2">
                          {availablePeriods.map((period) => (
                            <button
                              key={period}
                              onClick={() => {
                                setSelectedPeriod(period);
                                setSelectedTime(null);
                              }}
                              className={cn(
                                "flex-1 px-4 py-3 rounded-xl text-sm font-medium transition-all border",
                                selectedPeriod === period
                                  ? "bg-accent text-accent-foreground border-accent shadow-md shadow-accent/20"
                                  : "bg-background/30 border-border/30 hover:bg-background/50"
                              )}
                            >
                              {period}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Time Selection - Show only after period is selected (or if only one period exists) */}
                    {selectedDate && (availablePeriods.length <= 1 || selectedPeriod) && (
                      <div className="space-y-2">
                        <label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          Seleziona orario
                          {!selectedTime && <span className="text-xs text-accent">• richiesto</span>}
                        </label>
                        
                        {availableTimeSlots.length > 0 ? (
                          <div className="space-y-4">
                            {Array.from(filteredGroupedSlots.entries()).map(([rangeLabel, slots]) => (
                              <div key={rangeLabel} className="space-y-2">
                                {rangeLabel !== 'Orari disponibili' && availablePeriods.length <= 1 && (
                                  <span className="text-xs font-medium text-accent uppercase tracking-wider">
                                    {rangeLabel}
                                  </span>
                                )}
                                <div className="grid grid-cols-4 gap-1.5">
                                  {slots.map((time) => {
                                    const available = getAvailableGuests(time);
                                    const isAvailable = available >= guests;
                                    return (
                                      <button
                                        key={time}
                                        onClick={() => isAvailable && setSelectedTime(time)}
                                        disabled={!isAvailable}
                                        className={cn(
                                          "py-2 rounded-lg border text-xs font-medium transition-all",
                                          !isAvailable && "opacity-40 cursor-not-allowed",
                                          selectedTime === time 
                                            ? "bg-accent text-accent-foreground border-accent shadow-md shadow-accent/20" 
                                            : isAvailable 
                                              ? "bg-background/30 border-border/30 hover:bg-background/50"
                                              : "bg-muted/30 border-border/20"
                                        )}
                                      >
                                        {time}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20 text-yellow-600 text-sm">
                            <AlertCircle className="w-4 h-4 flex-shrink-0" />
                            <span>Nessun orario disponibile</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Message when no date selected */}
                    {!selectedDate && (
                      <div className="flex items-center gap-2 p-3 rounded-xl bg-foreground/5 border border-border/20 text-muted-foreground text-sm">
                        <Clock className="w-4 h-4 flex-shrink-0" />
                        <span>Seleziona prima una data</span>
                      </div>
                    )}

                    {/* Guests */}
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                        <Users className="w-4 h-4" />
                        Numero ospiti
                      </label>
                      <div className="flex gap-1.5 flex-wrap">
                        {guestOptions.map((num) => (
                          <button
                            key={num}
                            onClick={() => {
                              setGuests(num);
                              setIsGroupBooking(false);
                            }}
                            className={cn(
                              "w-10 h-10 rounded-lg border text-sm font-medium transition-all",
                              guests === num && !isGroupBooking
                                ? "bg-accent text-accent-foreground border-accent shadow-md shadow-accent/20" 
                                : "bg-background/30 border-border/30 hover:bg-background/50"
                            )}
                          >
                            {num}
                          </button>
                        ))}
                        {/* Group/Other option */}
                        <button
                          onClick={() => setIsGroupBooking(true)}
                          className={cn(
                            "px-3 h-10 rounded-lg border text-sm font-medium transition-all flex items-center gap-1.5",
                            isGroupBooking
                              ? "bg-accent text-accent-foreground border-accent shadow-md shadow-accent/20" 
                              : "bg-background/30 border-border/30 hover:bg-background/50"
                          )}
                        >
                          <UsersRound className="w-4 h-4" />
                          9+
                        </button>
                      </div>
                      {isGroupBooking && (
                        <p className="text-xs text-muted-foreground">
                          Per gruppi numerosi, specifica il numero esatto nelle note al prossimo step
                        </p>
                      )}
                    </div>
                  </motion.div>
                )}

                {/* Step 2: Contact Info */}
                {step === 2 && (
                  <motion.div
                    key="step2"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">Nome *</label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Il tuo nome"
                        className="w-full px-4 py-3 rounded-xl bg-background/30 border border-border/30 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                        <Phone className="w-4 h-4" />
                        WhatsApp / Telefono *
                      </label>
                      <div className="relative">
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => handlePhoneChange(e.target.value)}
                          placeholder="+39 333 1234567"
                          className={cn(
                            "w-full px-4 py-3 pr-10 rounded-xl bg-background/30 border focus:outline-none focus:ring-2 transition-all",
                            phoneError 
                              ? "border-red-500 focus:border-red-500 focus:ring-red-500/20" 
                              : phoneValidated
                                ? "border-green-500 focus:border-green-500 focus:ring-green-500/20"
                                : "border-border/30 focus:border-accent focus:ring-accent/20"
                          )}
                        />
                        {phoneValidated && !phoneError && (
                          <Check className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-500" />
                        )}
                      </div>
                      {phoneError ? (
                        <p className="text-xs text-red-500">{phoneError}</p>
                      ) : (
                        <p className="text-xs text-muted-foreground">Riceverai conferma via WhatsApp</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-muted-foreground">
                        Note speciali {isGroupBooking && <span className="text-accent">*</span>}
                      </label>
                      <textarea
                        value={formData.notes}
                        onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                        placeholder={isGroupBooking 
                          ? "Specifica il numero esatto di persone e altre richieste..." 
                          : "Allergie, occasioni speciali, richieste..."}
                        rows={3}
                        className="w-full px-4 py-3 rounded-xl bg-background/30 border border-border/30 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20 transition-all resize-none"
                      />
                      {isGroupBooking && (
                        <p className="text-xs text-accent">
                          Per prenotazioni di gruppo è obbligatorio specificare il numero esatto di ospiti
                        </p>
                      )}
                    </div>
                  </motion.div>
                )}

                {/* Step 3: Confirmation */}
                {step === 3 && (
                  <motion.div
                    key="step3"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-5"
                  >
                    {/* Login prompt if not authenticated */}
                    {!isAuthenticated && !isAuthLoading && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-4 rounded-xl bg-accent/10 border border-accent/30 space-y-3"
                      >
                        <div className="flex items-start gap-3">
                          <AlertCircle className="w-5 h-5 text-accent mt-0.5" />
                          <div className="flex-1">
                            <p className="font-medium text-accent">Accedi per confermare</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              Per completare la prenotazione devi effettuare l'accesso. I tuoi dati verranno salvati e potrai riprendere da qui dopo il login.
                            </p>
                          </div>
                        </div>
                        <button
                          onClick={handleLoginRedirect}
                          className="w-full py-3 rounded-xl bg-accent text-accent-foreground font-medium hover:bg-accent/90 transition-all flex items-center justify-center gap-2"
                        >
                          <Phone className="w-4 h-4" />
                          Accedi con il tuo telefono
                        </button>
                      </motion.div>
                    )}

                    <div className="text-center space-y-2">
                      <div className="w-14 h-14 mx-auto rounded-full bg-accent/20 flex items-center justify-center">
                        <Calendar className="w-7 h-7 text-accent" />
                      </div>
                      <h3 className="text-lg font-semibold">
                        {isAuthenticated ? 'Conferma prenotazione' : 'Riepilogo prenotazione'}
                      </h3>
                    </div>

                    <div className="p-4 rounded-xl bg-background/30 border border-border/20 space-y-2.5 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Data</span>
                        <span className="font-medium">{selectedDate?.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' })}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Orario</span>
                        <span className="font-medium">{selectedTime}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Ospiti</span>
                        <span className="font-medium">
                          {isGroupBooking ? 'Gruppo (9+)' : `${guests} ${guests === 1 ? 'persona' : 'persone'}`}
                        </span>
                      </div>
                      <div className="border-t border-border/20 pt-2.5 flex justify-between">
                        <span className="text-muted-foreground">Nome</span>
                        <span className="font-medium">{formData.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Telefono</span>
                        <span className="font-medium">{formData.phone}</span>
                      </div>
                      {formData.notes && (
                        <div className="border-t border-border/20 pt-2.5">
                          <span className="text-muted-foreground block mb-1">Note</span>
                          <span className="text-sm">{formData.notes}</span>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Footer - Fixed at bottom with safe area */}
            <div className="p-5 border-t border-border/20 bg-secondary/40 backdrop-blur-xl">
              {step === 3 && !isAuthenticated && !isAuthLoading ? (
                <p className="text-center text-sm text-muted-foreground">
                  Effettua l'accesso sopra per confermare la prenotazione
                </p>
              ) : (
                <button
                  onClick={() => {
                    if (step < 3) setStep(step + 1);
                    else handleSubmit();
                  }}
                  disabled={!canProceed() || isSubmitting}
                  className={cn(
                    "w-full py-3.5 rounded-xl font-medium transition-all flex items-center justify-center gap-2",
                    canProceed() && !isSubmitting
                      ? "bg-accent text-accent-foreground hover:bg-accent/90 shadow-lg shadow-accent/20"
                      : "bg-muted text-muted-foreground cursor-not-allowed"
                  )}
                >
                  {isSubmitting ? (
                    <>
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                        className="w-5 h-5 border-2 border-accent-foreground/30 border-t-accent-foreground rounded-full"
                      />
                      Invio in corso...
                    </>
                  ) : step < 3 ? (
                    <>
                      Continua
                      <ChevronRight className="w-4 h-4" />
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      Conferma Prenotazione
                    </>
                  )}
                </button>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}