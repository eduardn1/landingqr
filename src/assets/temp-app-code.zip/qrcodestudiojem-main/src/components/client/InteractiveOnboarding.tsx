import { useState, useEffect, forwardRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sun, Moon, ChevronRight, ChevronLeft } from 'lucide-react';
import * as Icons from 'lucide-react';
import { useTheme } from 'next-themes';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useLanguage } from '@/contexts/LanguageContext';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';
import { useAuthSession } from '@/hooks/useAuthSession';
import { Button } from '@/components/ui/button';

interface OnboardingAction {
  id: string;
  action_key: string;
  icon: string;
  label: { it: string; en: string };
  subtitle: { it: string; en: string };
  action_type: string;
  action_value: string;
  display_order: number;
  gradient: string | null;
}

interface InteractiveOnboardingProps {
  onComplete: (destination?: string) => void;
}

export const InteractiveOnboarding = forwardRef<HTMLDivElement, InteractiveOnboardingProps>(
  ({ onComplete }, ref) => {
    const [step, setStep] = useState<'theme' | 'action'>('theme');
    const { setTheme, resolvedTheme } = useTheme();
    const { currentLanguage } = useLanguage();
    const { config, isLoading: configLoading } = useRestaurantConfig();
    const { user } = useAuthSession();
    const navigate = useNavigate();

    // Fetch onboarding actions
    const { data: actions = [] } = useQuery({
      queryKey: ['onboarding-actions'],
      queryFn: async () => {
        const { data, error } = await supabase
          .from('onboarding_actions')
          .select('*')
          .eq('is_active', true)
          .order('display_order');
        
        if (error) throw error;
        return (data || []).map(item => ({
          ...item,
          label: item.label as unknown as { it: string; en: string },
          subtitle: item.subtitle as unknown as { it: string; en: string },
        })) as OnboardingAction[];
      },
    });

    // Save theme preference to profile if user is logged in
    const saveThemeToProfile = async (theme: string) => {
      if (!user?.id) return;
      
      try {
        await supabase
          .from('profiles')
          .update({ preferred_theme: theme })
          .eq('user_id', user.id);
      } catch (error) {
        console.error('Error saving theme preference:', error);
      }
    };

    const handleThemeSelect = (theme: 'light' | 'dark') => {
      setTheme(theme);
      localStorage.setItem('app-theme', theme);
      saveThemeToProfile(theme);
      
      // Apply theme immediately
      if (theme === 'light') {
        document.documentElement.classList.remove('dark');
        document.documentElement.style.colorScheme = 'light';
      } else {
        document.documentElement.classList.add('dark');
        document.documentElement.style.colorScheme = 'dark';
      }
      
      setStep('action');
    };

    const handleActionSelect = (action: OnboardingAction) => {
      // Mark BOTH interactive and general onboarding as completed to prevent quiz from showing
      sessionStorage.setItem('interactive_onboarding_completed', 'true');
      sessionStorage.setItem('onboarding_completed', 'true');
      
      if (action.action_type === 'navigate') {
        onComplete(action.action_value);
      } else if (action.action_type === 'action') {
        // Special actions like opening reservation modal
        onComplete(`/?action=${action.action_value}`);
      } else {
        onComplete('/');
      }
    };

    const handleBack = () => {
      if (step === 'action') {
        setStep('theme');
      }
    };

    const handleSkip = () => {
      // Mark BOTH as completed
      sessionStorage.setItem('interactive_onboarding_completed', 'true');
      sessionStorage.setItem('onboarding_completed', 'true');
      onComplete('/');
    };

    // Get icon component dynamically
    const getIcon = (iconName: string) => {
      const IconComponent = (Icons as any)[iconName];
      return IconComponent || Icons.Circle;
    };

    const language = currentLanguage;

    return (
      <motion.div
        ref={ref}
        className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center p-6"
        initial={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <AnimatePresence mode="wait">
          {step === 'theme' && (
            <motion.div
              key="theme"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full max-w-md text-center"
            >

              <h1 className="text-2xl font-bold mb-8">
                {language === 'it' ? 'Scegli il tuo stile' : 'Choose your style'}
              </h1>

              {/* Theme Cards - Minimal Sun/Moon Style */}
              <div className="flex justify-center gap-6 mb-8">
                {/* Light Theme */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleThemeSelect('light')}
                  className="flex flex-col items-center gap-3"
                >
                  <div className="w-20 h-20 rounded-2xl bg-white flex items-center justify-center border-2 border-foreground/10 transition-all">
                    <Sun className="w-8 h-8 text-black" strokeWidth={1.5} />
                  </div>
                  <span className="text-sm font-medium text-muted-foreground">Light</span>
                </motion.button>

                {/* Dark Theme */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleThemeSelect('dark')}
                  className="flex flex-col items-center gap-3"
                >
                  <div className="w-20 h-20 rounded-2xl bg-black flex items-center justify-center border-2 border-foreground/30 transition-all">
                    <Moon className="w-8 h-8 text-white" strokeWidth={1.5} />
                  </div>
                  <span className="text-sm font-medium text-foreground">Dark</span>
                </motion.button>
              </div>

              {/* Skip button */}
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleSkip}
                className="text-muted-foreground hover:text-foreground"
              >
                {language === 'it' ? 'Salta' : 'Skip'}
              </Button>
            </motion.div>
          )}

          {step === 'action' && (
            <motion.div
              key="action"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full max-w-md"
            >
              {/* Back button */}
              <motion.button
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                onClick={handleBack}
                className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
                {language === 'it' ? 'Indietro' : 'Back'}
              </motion.button>

              <div className="text-center mb-8">
                <h1 className="text-2xl font-bold mb-2">
                  {language === 'it' ? 'Cosa vorresti fare?' : 'What would you like to do?'}
                </h1>
                <p className="text-muted-foreground">
                  {language === 'it' ? 'Seleziona per iniziare' : 'Select to get started'}
                </p>
              </div>

              {/* Action Cards - Grid like Homepage */}
              <div className="grid grid-cols-2 gap-3 mb-6">
                {actions.map((action, index) => {
                  const IconComponent = getIcon(action.icon);
                  const label = action.label as { it: string; en: string };
                  const subtitle = action.subtitle as { it: string; en: string };
                  
                  return (
                    <motion.button
                      key={action.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.05 }}
                      whileHover={{ scale: 1.02, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleActionSelect(action)}
                      className={`relative p-4 rounded-xl overflow-hidden text-left group bg-gradient-to-br ${action.gradient || 'from-accent/20 to-accent/5'}`}
                    >
                      <div className="relative z-10">
                        <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${action.gradient || 'from-accent to-accent/80'} flex items-center justify-center mb-3 shadow-md`}>
                          <IconComponent className="w-5 h-5 text-white" />
                        </div>
                        <p className="font-semibold text-sm truncate">
                          {label[language as 'it' | 'en'] || label.it}
                        </p>
                        <p className="text-xs text-muted-foreground truncate mt-0.5">
                          {subtitle[language as 'it' | 'en'] || subtitle.it}
                        </p>
                      </div>
                    </motion.button>
                  );
                })}
              </div>

              {/* Skip button */}
              <div className="text-center">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={handleSkip}
                  className="text-muted-foreground hover:text-foreground"
                >
                  {language === 'it' ? 'Vai alla Home' : 'Go to Home'}
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  }
);

InteractiveOnboarding.displayName = 'InteractiveOnboarding';
