import { motion } from 'framer-motion';
import { Home, UtensilsCrossed, Heart, User, Sparkles, CalendarDays } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigationConfig, type NavbarItem } from '@/hooks/useNavigationConfig';
import { useLanguage } from '@/contexts/LanguageContext';
import { usePrefetch } from '@/hooks/usePrefetch';

interface BottomNavigationProps {
  activeTab: 'home' | 'menu' | 'discover' | 'favorites' | 'reservations' | 'profile';
  onTabChange: (tab: 'home' | 'menu' | 'discover' | 'favorites' | 'reservations' | 'profile') => void;
  favoritesCount?: number;
}

// Icon mapping
const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Home,
  UtensilsCrossed,
  Sparkles,
  Heart,
  User,
  CalendarDays,
};

export function BottomNavigation({ activeTab, onTabChange, favoritesCount = 0 }: BottomNavigationProps) {
  const { config } = useNavigationConfig();
  const { currentLanguage } = useLanguage();
  const { prefetchHome, prefetchMenu, prefetchProfile, prefetchReservations, prefetchFavorites } = usePrefetch();

  // Map tab keys to prefetch functions
  const prefetchMap: Record<string, () => void> = {
    home: prefetchHome,
    menu: prefetchMenu,
    profile: prefetchProfile,
    reservations: prefetchReservations,
    favorites: prefetchFavorites,
    discover: prefetchMenu,
  };

  const handleHover = (key: string) => {
    const prefetchFn = prefetchMap[key];
    if (prefetchFn) prefetchFn();
  };

  // Get visible and sorted navbar items
  const visibleItems = (config.navbar_items as NavbarItem[])
    .filter(item => item.visible)
    .sort((a, b) => a.order - b.order);

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-50 md:hidden"
    >
      {/* Glassmorphism background */}
      <div className="absolute inset-0 bg-background/80 backdrop-blur-xl border-t border-border/20" />
      
      {/* Safe area padding for iPhone notch - increased height and centered icons */}
      <div className="relative flex items-center justify-around px-2 pt-3 pb-[calc(env(safe-area-inset-bottom,12px)+8px)]">
        {visibleItems.map((item) => {
          const isActive = activeTab === item.key;
          const Icon = iconMap[item.icon] || Home;
          const label = item.label[currentLanguage as 'it' | 'en'] || item.label.it;
          
          return (
            <motion.button
              key={item.key}
              onClick={() => onTabChange(item.key as any)}
              onMouseEnter={() => handleHover(item.key)}
              onTouchStart={() => handleHover(item.key)}
              className={cn(
                "relative flex flex-col items-center justify-center gap-0.5 px-2 py-2 rounded-xl transition-all duration-300 min-w-0",
                isActive 
                  ? "text-accent flex-[1.3]" 
                  : "text-muted-foreground hover:text-foreground flex-1"
              )}
              whileTap={{ scale: 0.9 }}
            >
              {/* Active indicator background */}
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-accent/10 rounded-xl"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
              
              {/* Icon with animation */}
              <motion.div
                className="relative z-10"
                animate={isActive ? { scale: 1.1, y: -1 } : { scale: 1, y: 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              >
                <Icon 
                  className={cn(
                    "w-6 h-6 transition-all duration-300",
                    isActive && "drop-shadow-[0_0_8px_hsl(var(--accent))]"
                  )} 
                />
                
                {/* Favorites badge */}
                {item.key === 'favorites' && favoritesCount > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1 -right-1.5 w-4 h-4 rounded-full bg-accent text-accent-foreground text-[9px] font-bold flex items-center justify-center"
                  >
                    {favoritesCount > 9 ? '9+' : favoritesCount}
                  </motion.span>
                )}
              </motion.div>
              
              {/* Label - only show for active item */}
              {isActive && (
                <motion.span 
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="relative z-10 text-[11px] font-semibold whitespace-nowrap"
                >
                  {label}
                </motion.span>
              )}
            </motion.button>
          );
        })}
      </div>
    </motion.nav>
  );
}
