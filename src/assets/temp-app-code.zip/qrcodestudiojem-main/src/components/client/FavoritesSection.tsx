import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Trash2, Sparkles, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { type Dish } from '@/lib/mockData';
import { useDishes, type DbDish } from '@/hooks/useMenu';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import { BackButton } from '@/components/ui/BackButton';

// Helper to convert database dish to Dish format
const dbDishToDish = (dbDish: DbDish): Dish => ({
  id: dbDish.id,
  categoryId: dbDish.category_id,
  name: { it: dbDish.name_it, en: dbDish.name_en },
  description: { it: dbDish.description_it || '', en: dbDish.description_en || '' },
  ingredients: { it: dbDish.ingredients_it || '', en: dbDish.ingredients_en || '' },
  images: dbDish.image_url && dbDish.image_url.trim() !== '' ? [dbDish.image_url] : [],
  price: Number(dbDish.price),
  originalPrice: dbDish.original_price ? Number(dbDish.original_price) : undefined,
  currency: dbDish.currency,
  tags: dbDish.tags || [],
  allergens: dbDish.allergens || [],
  spicyLevel: dbDish.spicy_level || undefined,
  portionSize: dbDish.portion_size || undefined,
  isAvailable: dbDish.is_available,
  isFeatured: dbDish.is_featured,
  isSeasonal: dbDish.is_seasonal,
  badge: dbDish.badge || undefined,
  displayOrder: dbDish.display_order,
});

interface FavoritesSectionProps {
  isOpen: boolean;
  onClose: () => void;
  localFavorites: string[];
  onRemoveFavorite: (dishId: string) => void;
  onDishClick: (dish: Dish) => void;
}

export function FavoritesSection({ 
  isOpen, 
  onClose, 
  localFavorites, 
  onRemoveFavorite,
  onDishClick 
}: FavoritesSectionProps) {
  const { currentLanguage } = useLanguage();
  const { dishes: dbDishes } = useDishes();
  const [activeTab, setActiveTab] = useState<'all' | 'swipe'>('all');
  const [swipeLikes, setSwipeLikes] = useState<string[]>([]);
  const [user, setUser] = useState<any>(null);

  // Convert db dishes
  const allDishes = useMemo(() => dbDishes.map(d => dbDishToDish(d)), [dbDishes]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchSwipeLikes(session.user.id);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchSwipeLikes(session.user.id);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchSwipeLikes = async (userId: string) => {
    const { data } = await supabase
      .from('swipe_interactions')
      .select('dish_id')
      .eq('user_id', userId)
      .eq('action', 'like');
    
    if (data) {
      setSwipeLikes(data.map(d => d.dish_id));
    }
  };

  const favoriteDishes = allDishes.filter(d => localFavorites.includes(d.id));
  const swipeDishes = allDishes.filter(d => swipeLikes.includes(d.id));
  const displayDishes = activeTab === 'all' ? favoriteDishes : swipeDishes;

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat(currentLanguage, {
      style: 'currency',
      currency: 'EUR',
    }).format(price);
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-background/60 backdrop-blur-md" />

      {/* Panel */}
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-secondary/40 backdrop-blur-xl border-l border-border/30"
      >
        {/* Header */}
        <div className="p-6 border-b border-border/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
                <Heart className="w-5 h-5 text-accent" fill="currentColor" />
              </div>
              <div>
                <h2 className="text-lg font-semibold">I tuoi preferiti</h2>
                <p className="text-xs text-muted-foreground">
                  {favoriteDishes.length + swipeLikes.length} piatti salvati
                </p>
              </div>
            </div>
            <BackButton onClick={onClose} variant="close" size="lg" />
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => setActiveTab('all')}
              className={cn(
                "flex-1 py-2 rounded-xl text-sm font-medium transition-all",
                activeTab === 'all'
                  ? "bg-accent text-accent-foreground"
                  : "bg-background/30 text-muted-foreground hover:bg-background/50"
              )}
            >
              Preferiti ({favoriteDishes.length})
            </button>
            <button
              onClick={() => setActiveTab('swipe')}
              className={cn(
                "flex-1 py-2 rounded-xl text-sm font-medium transition-all flex items-center justify-center gap-1.5",
                activeTab === 'swipe'
                  ? "bg-accent text-accent-foreground"
                  : "bg-background/30 text-muted-foreground hover:bg-background/50"
              )}
            >
              <Sparkles className="w-4 h-4" />
              Mi piace ({swipeLikes.length})
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto h-[calc(100%-10rem)]">
          {displayDishes.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <div className="w-16 h-16 mx-auto rounded-full bg-secondary/50 flex items-center justify-center">
                {activeTab === 'all' ? (
                  <Heart className="w-8 h-8 text-muted-foreground/50" />
                ) : (
                  <Sparkles className="w-8 h-8 text-muted-foreground/50" />
                )}
              </div>
              <p className="text-muted-foreground">
                {activeTab === 'all' 
                  ? 'Nessun preferito salvato' 
                  : 'Nessun piatto piaciuto dallo swipe'}
              </p>
              <p className="text-xs text-muted-foreground/70">
                {activeTab === 'all'
                  ? 'Tocca il cuore sui piatti per salvarli qui'
                  : 'Usa la funzione Swipe per scoprire nuovi piatti!'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <AnimatePresence>
                {displayDishes.map((dish, index) => (
                  <motion.div
                    key={dish.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex gap-3 p-3 rounded-2xl bg-background/30 border border-border/20 group"
                  >
                    {/* Image */}
                    <div 
                      className="w-20 h-20 rounded-xl overflow-hidden bg-secondary/50 flex-shrink-0 cursor-pointer"
                      onClick={() => onDishClick(dish)}
                    >
                      {dish.images?.[0] ? (
                        <img src={dish.images[0]} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <span className="text-2xl">🍽️</span>
                        </div>
                      )}
                    </div>

                    {/* Info */}
                    <div 
                      className="flex-1 min-w-0 cursor-pointer"
                      onClick={() => onDishClick(dish)}
                    >
                      <h3 className="font-medium text-foreground truncate">
                        {getLocalizedContent(dish.name, currentLanguage)}
                      </h3>
                      <p className="text-sm text-muted-foreground line-clamp-1">
                        {getLocalizedContent(dish.description, currentLanguage)}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm font-semibold text-accent">
                          {formatPrice(dish.price)}
                        </span>
                        {activeTab === 'swipe' && (
                          <span className="px-2 py-0.5 rounded-full bg-accent/10 text-accent text-[10px] font-medium">
                            Da Swipe
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onDishClick(dish)}
                        className="w-8 h-8 rounded-full bg-secondary/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                      {activeTab === 'all' && (
                        <button
                          onClick={() => onRemoveFavorite(dish.id)}
                          className="w-8 h-8 rounded-full bg-destructive/10 flex items-center justify-center text-destructive hover:bg-destructive/20 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>

        {/* Login prompt if not logged in */}
        {!user && (
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-secondary/80 to-transparent">
            <div className="p-4 rounded-2xl bg-background/50 backdrop-blur-sm border border-border/30 text-center space-y-2">
              <p className="text-sm text-muted-foreground">
                Accedi per sincronizzare i preferiti su tutti i dispositivi
              </p>
              <Link
                to="/auth"
                className="inline-block px-6 py-2 rounded-xl bg-accent text-accent-foreground text-sm font-medium hover:bg-accent/90 transition-colors"
              >
                Accedi o Registrati
              </Link>
            </div>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}
