import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Cookie, X, Shield, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CONSENT_KEY = 'cookie_consent';
const CONSENT_VERSION = '1.0';

interface ConsentState {
  version: string;
  accepted: boolean;
  timestamp: string;
  preferences: {
    necessary: boolean;
    analytics: boolean;
    marketing: boolean;
  };
}

interface CookieConsentProps {
  /** Only show after onboarding is complete */
  onlyAfterOnboarding?: boolean;
}

// Global function to open cookie settings
export const openCookieSettings = () => {
  window.dispatchEvent(new CustomEvent('open-cookie-settings'));
};

export function CookieConsent({ onlyAfterOnboarding = true }: CookieConsentProps) {
  const [showBanner, setShowBanner] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [preferences, setPreferences] = useState({
    necessary: true, // Always required
    analytics: true,
    marketing: false,
  });

  // Listen for open-cookie-settings event
  useEffect(() => {
    const handleOpenSettings = () => {
      // Load current preferences from localStorage
      const stored = localStorage.getItem(CONSENT_KEY);
      if (stored) {
        try {
          const consent: ConsentState = JSON.parse(stored);
          setPreferences(consent.preferences);
        } catch {
          // Keep defaults
        }
      }
      setShowDetails(true);
      setShowBanner(true);
    };

    window.addEventListener('open-cookie-settings', handleOpenSettings);
    return () => window.removeEventListener('open-cookie-settings', handleOpenSettings);
  }, []);

  useEffect(() => {
    // Check if consent was already given
    const stored = localStorage.getItem(CONSENT_KEY);
    if (stored) {
      try {
        const consent: ConsentState = JSON.parse(stored);
        // Check if version matches
        if (consent.version === CONSENT_VERSION && consent.accepted) {
          return; // Don't show banner
        }
      } catch {
        // Invalid stored data, show banner
      }
    }
    
    // If onlyAfterOnboarding is true, check if onboarding is complete
    if (onlyAfterOnboarding) {
      const onboardingCompleted = sessionStorage.getItem('onboarding_completed') === 'true';
      if (!onboardingCompleted) {
        return; // Don't show banner until onboarding is complete
      }
    }
    
    // Delay showing banner for better UX
    const timer = setTimeout(() => setShowBanner(true), 1500);
    return () => clearTimeout(timer);
  }, [onlyAfterOnboarding]);

  const saveConsent = (accepted: boolean, prefs = preferences) => {
    const consent: ConsentState = {
      version: CONSENT_VERSION,
      accepted,
      timestamp: new Date().toISOString(),
      preferences: prefs,
    };
    localStorage.setItem(CONSENT_KEY, JSON.stringify(consent));
    setShowBanner(false);
  };

  const handleAcceptAll = () => {
    const allAccepted = { necessary: true, analytics: true, marketing: true };
    setPreferences(allAccepted);
    saveConsent(true, allAccepted);
  };

  const handleAcceptSelected = () => {
    saveConsent(true, preferences);
  };

  const handleRejectNonEssential = () => {
    const essentialOnly = { necessary: true, analytics: false, marketing: false };
    setPreferences(essentialOnly);
    saveConsent(true, essentialOnly);
  };

  if (!showBanner) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 100 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="fixed bottom-0 left-0 right-0 z-[60] p-4 pb-safe"
      >
        <div className="max-w-2xl mx-auto bg-card/95 backdrop-blur-xl border border-border/30 rounded-2xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="p-4 pb-3 flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-accent/15 flex items-center justify-center flex-shrink-0">
              <Cookie className="w-5 h-5 text-accent" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-foreground text-sm">Cookie e Privacy</h3>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                Utilizziamo cookie per migliorare la tua esperienza, analizzare il traffico e personalizzare i contenuti.
              </p>
            </div>
            <button
              onClick={() => setShowBanner(false)}
              className="p-1.5 rounded-lg hover:bg-secondary/50 transition-colors"
              aria-label="Chiudi"
            >
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>

          {/* Details (expandable) */}
          <AnimatePresence>
            {showDetails && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="border-t border-border/20 overflow-hidden"
              >
                <div className="p-4 space-y-3">
                  {/* Necessary */}
                  <label className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30 cursor-not-allowed">
                    <input
                      type="checkbox"
                      checked={preferences.necessary}
                      disabled
                      className="w-4 h-4 rounded accent-accent"
                    />
                    <div className="flex-1">
                      <span className="text-sm font-medium text-foreground">Necessari</span>
                      <p className="text-xs text-muted-foreground">Essenziali per il funzionamento del sito</p>
                    </div>
                    <Shield className="w-4 h-4 text-muted-foreground" />
                  </label>

                  {/* Analytics */}
                  <label className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors">
                    <input
                      type="checkbox"
                      checked={preferences.analytics}
                      onChange={(e) => setPreferences(p => ({ ...p, analytics: e.target.checked }))}
                      className="w-4 h-4 rounded accent-accent"
                    />
                    <div className="flex-1">
                      <span className="text-sm font-medium text-foreground">Analitici</span>
                      <p className="text-xs text-muted-foreground">Ci aiutano a capire come usi il sito</p>
                    </div>
                  </label>

                  {/* Marketing */}
                  <label className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors">
                    <input
                      type="checkbox"
                      checked={preferences.marketing}
                      onChange={(e) => setPreferences(p => ({ ...p, marketing: e.target.checked }))}
                      className="w-4 h-4 rounded accent-accent"
                    />
                    <div className="flex-1">
                      <span className="text-sm font-medium text-foreground">Marketing</span>
                      <p className="text-xs text-muted-foreground">Per contenuti e offerte personalizzate</p>
                    </div>
                  </label>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Actions */}
          <div className="p-4 pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 border-t border-border/20">
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
            >
              <ExternalLink className="w-3 h-3" />
              {showDetails ? 'Nascondi dettagli' : 'Personalizza'}
            </button>
            
            <div className="flex-1" />
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleRejectNonEssential}
                className="text-xs border-border"
              >
                Solo necessari
              </Button>
              {showDetails ? (
                <Button
                  size="sm"
                  onClick={handleAcceptSelected}
                  className="text-xs bg-accent text-accent-foreground hover:bg-accent/90 font-semibold shadow-md"
                >
                  Salva preferenze
                </Button>
              ) : (
                <Button
                  size="sm"
                  onClick={handleAcceptAll}
                  className="text-xs bg-accent text-accent-foreground hover:bg-accent/90 font-semibold shadow-md"
                >
                  Accetta tutti
                </Button>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
