import { cn } from '@/lib/utils';
import { LayoutGrid, List, Grid2X2, FileText } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { useLanguage } from '@/contexts/LanguageContext';

export type MenuViewMode = 'cards' | 'list' | 'grid' | 'compact';

interface MenuViewToggleProps {
  currentView: MenuViewMode;
  onViewChange: (view: MenuViewMode) => void;
  className?: string;
}

const viewConfig: { mode: MenuViewMode; icon: typeof LayoutGrid; labelIt: string; labelEn: string }[] = [
  { mode: 'cards', icon: LayoutGrid, labelIt: 'Card grandi', labelEn: 'Large cards' },
  { mode: 'list', icon: List, labelIt: 'Lista', labelEn: 'List' },
  { mode: 'grid', icon: Grid2X2, labelIt: 'Griglia 2x2', labelEn: 'Grid 2x2' },
  { mode: 'compact', icon: FileText, labelIt: 'Compatta', labelEn: 'Compact' },
];

export function MenuViewToggle({ 
  currentView, 
  onViewChange, 
  className 
}: MenuViewToggleProps) {
  const isMobile = useIsMobile();
  const { currentLanguage } = useLanguage();

  return (
    <div className={cn(
      "flex items-center bg-foreground/[0.04] dark:bg-foreground/[0.06] rounded-xl p-1 overflow-x-auto",
      className
    )}>
      {viewConfig.map(({ mode, icon: Icon, labelIt, labelEn }) => {
        const isActive = currentView === mode;
        const label = currentLanguage === 'it' ? labelIt : labelEn;
        
        return (
          <button
            key={mode}
            onClick={() => onViewChange(mode)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all duration-200 whitespace-nowrap flex-shrink-0",
              isActive
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <Icon className="w-4 h-4" />
            {!isMobile && <span className="text-xs font-medium">{label}</span>}
          </button>
        );
      })}
    </div>
  );
}

// Helper hook to get optimal view mode based on device
export function useOptimalMenuView(defaultView: MenuViewMode = 'cards'): MenuViewMode {
  const isMobile = useIsMobile();
  
  if (isMobile) {
    return defaultView === 'compact' ? 'list' : defaultView;
  }
  
  return defaultView;
}
