import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/contexts/LanguageContext';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Package, Truck, Clock, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';
import { it, enUS } from 'date-fns/locale';
import type { TakeAwayOrder } from '@/hooks/useTakeAwayOrders';

const statusConfig: Record<string, { label: string; labelEn: string; color: string }> = {
  pending: { label: 'In attesa', labelEn: 'Pending', color: 'bg-yellow-500/20 text-yellow-600' },
  accepted: { label: 'Accettato', labelEn: 'Accepted', color: 'bg-blue-500/20 text-blue-600' },
  preparing: { label: 'In preparazione', labelEn: 'Preparing', color: 'bg-blue-500/20 text-blue-600' },
  ready: { label: 'Pronto', labelEn: 'Ready', color: 'bg-green-500/20 text-green-600' },
  delivering: { label: 'In consegna', labelEn: 'Delivering', color: 'bg-purple-500/20 text-purple-600' },
  completed: { label: 'Completato', labelEn: 'Completed', color: 'bg-green-500/20 text-green-600' },
  rejected: { label: 'Rifiutato', labelEn: 'Rejected', color: 'bg-red-500/20 text-red-600' },
  cancelled: { label: 'Annullato', labelEn: 'Cancelled', color: 'bg-red-500/20 text-red-600' },
};

interface TakeAwayOrderHistoryProps {
  orders?: TakeAwayOrder[];
  isLoading?: boolean;
}

export const TakeAwayOrderHistory = React.forwardRef<HTMLDivElement, TakeAwayOrderHistoryProps>(
  ({ orders = [], isLoading = false }, ref) => {
  const navigate = useNavigate();
  const { currentLanguage } = useLanguage();
  const locale = currentLanguage === 'it' ? it : enUS;

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map(i => (
          <Skeleton key={i} className="h-24 rounded-xl" />
        ))}
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
        <p>{currentLanguage === 'it' ? 'Nessun ordine ancora' : 'No orders yet'}</p>
      </div>
    );
  }

  // Split into active and past orders
  const activeStatuses = ['pending', 'accepted', 'preparing', 'ready', 'delivering'];
  const activeOrders = orders.filter(o => activeStatuses.includes(o.status));
  const pastOrders = orders.filter(o => !activeStatuses.includes(o.status));

  return (
    <div className="space-y-6">
      {activeOrders.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-sm text-muted-foreground">
            {currentLanguage === 'it' ? 'Ordini attivi' : 'Active orders'}
          </h3>
          {activeOrders.map(order => {
            const status = statusConfig[order.status];
            return (
              <Card
                key={order.id}
                className="cursor-pointer hover:border-accent/50 transition-colors"
                onClick={() => navigate(`/takeaway/order/${order.id}`)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center">
                        {order.order_type === 'pickup' ? (
                          <Package className="w-5 h-5 text-accent" />
                        ) : (
                          <Truck className="w-5 h-5 text-accent" />
                        )}
                      </div>
                      <div>
                        <p className="font-semibold">{order.order_number}</p>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          <span>
                            {format(new Date(order.created_at), 'dd MMM HH:mm', { locale })}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <Badge className={status.color}>
                          {currentLanguage === 'it' ? status.label : status.labelEn}
                        </Badge>
                        <p className="text-sm font-bold mt-1">€{order.total.toFixed(2)}</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-muted-foreground" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {pastOrders.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-sm text-muted-foreground">
            {currentLanguage === 'it' ? 'Ordini passati' : 'Past orders'}
          </h3>
          {pastOrders.slice(0, 10).map(order => {
            const status = statusConfig[order.status];
            return (
              <Card
                key={order.id}
                className="cursor-pointer hover:border-accent/50 transition-colors opacity-75"
                onClick={() => navigate(`/takeaway/order/${order.id}`)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-secondary/50 flex items-center justify-center">
                        {order.order_type === 'pickup' ? (
                          <Package className="w-5 h-5 text-muted-foreground" />
                        ) : (
                          <Truck className="w-5 h-5 text-muted-foreground" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{order.order_number}</p>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(order.created_at), 'dd MMM yyyy', { locale })}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <Badge variant="secondary" className={status.color}>
                          {currentLanguage === 'it' ? status.label : status.labelEn}
                        </Badge>
                        <p className="text-sm font-medium mt-1">€{order.total.toFixed(2)}</p>
                      </div>
                      <ChevronRight className="w-5 h-5 text-muted-foreground" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
});
TakeAwayOrderHistory.displayName = 'TakeAwayOrderHistory';
