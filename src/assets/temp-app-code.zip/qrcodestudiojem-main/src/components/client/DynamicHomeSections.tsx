import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronRight, Heart, RefreshCw, Users, User, Sparkles, HelpCircle } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useHomeSections, type HomeSection } from '@/hooks/useHomeSections';
import { useIsMobile } from '@/hooks/use-mobile';
import { StoriesSection } from './StoriesSection';
import { ActionButtonsGrid } from './ActionButtonsGrid';
import { EventsSection } from './EventsSection';
import { PromosSection } from './PromosSection';
import { MoodSelector } from './MoodSelector';
import { RestaurantInfoCard } from '@/components/RestaurantInfoCard';
import { GoogleReviews } from './GoogleReviews';
import { InstagramFeed } from './InstagramFeed';
import { DishCard } from '@/components/DishCard';
import { DishGridSkeleton, DishCarouselSkeleton, MoodSelectorSkeleton, EventsSkeleton, RestaurantInfoSkeleton } from './DishCardSkeleton';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import type { Dish } from '@/lib/mockData';

interface DynamicHomeSectionsProps {
  // Action handlers
  onOpenAbout: () => void;
  onButtonAction: (actionType: string, actionValue: string | null) => void;
  goToMenu: () => void;
  onDishClick: (dish: Dish) => void;
  onOpenFavorites: () => void;
  handleResetPreferences: () => void;
  // Data
  selectedMood: string | null;
  onSelectMood: (mood: string | null) => void;
  recommendedDishes: Dish[];
  shareableDishes: Dish[];
  featuredLoading: boolean;
  categoriesLoading: boolean;
  onboardingAnswers: any;
  favoritesCount: number;
  isAuthenticated: boolean;
  isAuthLoading?: boolean;
  isDishRecommended: (dish: Dish) => boolean;
  t: (key: string) => string;
}

export function DynamicHomeSections({
  onOpenAbout,
  onButtonAction,
  goToMenu,
  onDishClick,
  onOpenFavorites,
  handleResetPreferences,
  selectedMood,
  onSelectMood,
  recommendedDishes,
  shareableDishes,
  featuredLoading,
  categoriesLoading,
  onboardingAnswers,
  favoritesCount,
  isAuthenticated,
  isAuthLoading = false,
  isDishRecommended,
  t,
}: DynamicHomeSectionsProps) {
  const { currentLanguage } = useLanguage();
  const { sections, isSectionEnabled } = useHomeSections();
  const isMobile = useIsMobile();

  const renderSection = (section: HomeSection, index: number) => {
    const delay = 0.1 + index * 0.05;

    switch (section.section_key) {
      case 'stories':
        return (
          <motion.section
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <StoriesSection onOpenAbout={onOpenAbout} isLoading={categoriesLoading} />
          </motion.section>
        );

      case 'action_grid':
      case 'action_buttons':
        return (
          <motion.section
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <ActionButtonsGrid onAction={onButtonAction} />
          </motion.section>
        );

      case 'events':
        return (
          <motion.section
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <EventsSection />
          </motion.section>
        );

      case 'promos':
        return (
          <motion.section
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <PromosSection />
          </motion.section>
        );

      case 'mood_selector':
        return (
          <motion.section
            key={section.id}
            className="space-y-3"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              {section.title?.[currentLanguage as 'it' | 'en'] || 'Come ti senti?'}
            </h2>
            <MoodSelector selectedMood={selectedMood} onSelectMood={onSelectMood} />
          </motion.section>
        );

      case 'featured':
      case 'recommended':
        const hasQuizAnswers = onboardingAnswers && Object.keys(onboardingAnswers).length > 0;
        // Filter out welcome step from count
        const quizStepCount = hasQuizAnswers 
          ? Object.keys(onboardingAnswers).filter(key => key !== 'welcome').length 
          : 0;
        
        const hasPersonalization = hasQuizAnswers || selectedMood;
        const tipMessage = hasQuizAnswers 
          ? "Grazie al quiz, abbiamo trovato questi piatti perfetti per te!"
          : "In base al mood selezionato, ecco i piatti che ti consigliamo!";
        
        return (
          <motion.section
            key={section.id}
            className="space-y-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            {/* Mobile: Show tip banner below header for touch accessibility */}
            {hasPersonalization && isMobile && (
              <motion.div 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 rounded-xl bg-gradient-to-r from-accent/15 to-accent/5 border border-accent/20"
              >
                <div className="flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-accent">Per Te</span>
                      {quizStepCount > 0 && (
                        <span className="text-[10px] text-accent/80 bg-accent/20 px-2 py-0.5 rounded-full">
                          {quizStepCount} {quizStepCount === 1 ? 'risposta' : 'risposte'}
                        </span>
                      )}
                      {selectedMood && !hasQuizAnswers && (
                        <span className="text-[10px] text-accent/80 bg-accent/20 px-2 py-0.5 rounded-full">
                          mood
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{tipMessage}</p>
                  </div>
                </div>
              </motion.div>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {/* Desktop: Keep tooltip for hover interaction */}
                {hasPersonalization && !isMobile ? (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-accent/20 to-accent/10 border border-accent/30 cursor-help">
                        <Sparkles className="w-3.5 h-3.5 text-accent" />
                        <span className="text-xs font-semibold text-accent">Per Te</span>
                        {quizStepCount > 0 && (
                          <span className="text-[10px] text-accent/80 bg-accent/15 px-1.5 py-0.5 rounded-full">
                            {quizStepCount} {quizStepCount === 1 ? 'risposta' : 'risposte'}
                          </span>
                        )}
                        {selectedMood && !hasQuizAnswers && (
                          <span className="text-[10px] text-accent/80 bg-accent/15 px-1.5 py-0.5 rounded-full">
                            mood
                          </span>
                        )}
                        <HelpCircle className="w-3 h-3 text-accent/50" />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent side="bottom" className="max-w-[220px] text-center">
                      <p className="text-xs">{tipMessage}</p>
                    </TooltipContent>
                  </Tooltip>
                ) : hasPersonalization && isMobile ? (
                  // Mobile: Simple badge without tooltip (tip shown above)
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-accent/20 to-accent/10 border border-accent/30">
                    <Sparkles className="w-3.5 h-3.5 text-accent" />
                    <span className="text-xs font-semibold text-accent">Per Te</span>
                  </div>
                ) : (
                  <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    {section.title?.[currentLanguage as 'it' | 'en'] || t('featured')}
                  </h2>
                )}
              </div>
              <button
                onClick={goToMenu}
                className="text-xs text-foreground bg-accent/20 hover:bg-accent/30 flex items-center gap-1 transition-colors font-semibold px-3 py-1.5 rounded-full border border-accent/40 hover:border-accent/60"
              >
                {t('viewMenu')}
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
            {featuredLoading ? (
              isMobile ? <DishCarouselSkeleton count={4} /> : <DishGridSkeleton count={4} compact />
            ) : (
              <>
                {/* Mobile: Horizontal Carousel */}
                <div className="md:hidden -mx-4 px-4 overflow-x-auto scrollbar-hide">
                  <div className="flex gap-3" style={{ width: 'max-content' }}>
                    {recommendedDishes.map((dish, dishIndex) => (
                      <motion.div
                        key={dish.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: delay + dishIndex * 0.1 }}
                        className="w-40 flex-shrink-0"
                      >
                        <DishCard
                          dish={dish}
                          compact
                          onClick={() => onDishClick(dish)}
                          isRecommended={isDishRecommended(dish)}
                        />
                      </motion.div>
                    ))}
                  </div>
                </div>
                {/* Desktop/Tablet: 4 Column Grid */}
                <div className="hidden md:grid md:grid-cols-4 gap-3">
                  {recommendedDishes.map((dish, dishIndex) => (
                    <motion.div
                      key={dish.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: delay + dishIndex * 0.1 }}
                    >
                      <DishCard
                        dish={dish}
                        compact
                        onClick={() => onDishClick(dish)}
                        isRecommended={isDishRecommended(dish)}
                      />
                    </motion.div>
                  ))}
                </div>
              </>
            )}
          </motion.section>
        );

      case 'shareable':
      case 'sharing':
        if (shareableDishes.length === 0) return null;
        return (
          <motion.section
            key={section.id}
            className="space-y-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-accent" />
                <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  {section.title?.[currentLanguage as 'it' | 'en'] || 'Perfetti da condividere'}
                </h2>
              </div>
              <button
                onClick={goToMenu}
                className="text-xs text-foreground bg-accent/20 hover:bg-accent/30 flex items-center gap-1 transition-colors font-semibold px-3 py-1.5 rounded-full border border-accent/40 hover:border-accent/60"
              >
                {t('viewMenu')}
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
            {/* Mobile: Horizontal Carousel */}
            <div className="md:hidden -mx-4 px-4 overflow-x-auto scrollbar-hide">
              <div className="flex gap-3" style={{ width: 'max-content' }}>
                {shareableDishes.map((dish, dishIndex) => (
                  <motion.div
                    key={dish.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: delay + dishIndex * 0.1 }}
                    className="w-40 flex-shrink-0"
                  >
                    <DishCard dish={dish} compact onClick={() => onDishClick(dish)} />
                  </motion.div>
                ))}
              </div>
            </div>
            {/* Desktop/Tablet: 4 Column Grid */}
            <div className="hidden md:grid md:grid-cols-4 gap-3">
              {shareableDishes.map((dish, dishIndex) => (
                <motion.div
                  key={dish.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: delay + dishIndex * 0.1 }}
                >
                  <DishCard dish={dish} compact onClick={() => onDishClick(dish)} />
                </motion.div>
              ))}
            </div>
          </motion.section>
        );

      case 'favorites_shortcut':
        if (favoritesCount === 0) return null;
        return (
          <motion.section
            key={section.id}
            className="pt-2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <button
              onClick={onOpenFavorites}
              className="w-full py-3 bg-accent/20 border border-accent/30 rounded-xl text-accent flex items-center justify-center gap-2 hover:bg-accent/30 transition-all"
            >
              <Heart className="w-4 h-4" fill="currentColor" />
              <span className="text-sm font-medium">
                {section.title?.[currentLanguage as 'it' | 'en'] || 'I tuoi preferiti'} ({favoritesCount})
              </span>
            </button>
          </motion.section>
        );

      case 'instagram_feed':
        return (
          <motion.section
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <InstagramFeed />
          </motion.section>
        );

      case 'restaurant_info':
        return (
          <motion.section
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-4">
              {section.title?.[currentLanguage as 'it' | 'en'] || 'Info & Contatti'}
            </h2>
            <RestaurantInfoCard 
              onResetQuiz={handleResetPreferences}
              hasQuizAnswers={!!onboardingAnswers}
            />
          </motion.section>
        );

      case 'google_reviews':
        return (
          <motion.section
            key={section.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
          >
            <GoogleReviews />
          </motion.section>
        );

      case 'account':
        // Don't show account section while auth is loading or if user is authenticated
        if (isAuthLoading || isAuthenticated) return null;
        return (
          <motion.section
            key={section.id}
            id="account"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.5 }}
            className="space-y-3 scroll-mt-20"
          >
            <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              {section.title?.[currentLanguage as 'it' | 'en'] || 'Il tuo account'}
            </h2>
            <Link
              to="/auth"
              className="block p-4 rounded-2xl bg-gradient-to-br from-accent/10 to-transparent border border-accent/20 hover:from-accent/20 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                  <User className="w-5 h-5 text-accent" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-foreground">Accedi o Registrati</p>
                  <p className="text-xs text-muted-foreground">
                    Salva preferiti e ricevi notifiche WhatsApp
                  </p>
                </div>
                <ChevronRight className="w-5 h-5 text-muted-foreground" />
              </div>
            </Link>
          </motion.section>
        );

      default:
        return null;
    }
  };

  return (
    <>
      {sections.map((section, index) => renderSection(section, index))}
      
      {/* Note: "Rifai il quiz" button is now shown under restaurant_info section */}
      
      {/* Spacer for bottom nav */}
      <div className="pb-24 md:pb-8" />
    </>
  );
}
