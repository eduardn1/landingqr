import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Instagram } from 'lucide-react';
import { useRestaurantConfig } from '@/hooks/useRestaurantConfig';

interface InstagramFeedProps {
  title?: string;
  subtitle?: string;
  showTitle?: boolean;
}

export function InstagramFeed({ 
  title = "Seguici su Instagram", 
  subtitle = "Scopri le nostre creazioni",
  showTitle = true 
}: InstagramFeedProps) {
  const { config, features } = useRestaurantConfig();
  const [isLoaded, setIsLoaded] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  
  const instagramUsername = config?.instagram_username;
  const widgetId = 'ff236ced-fe26-49b1-882f-b83399cb00ff'; // Elfsight widget ID

  useEffect(() => {
    // Only load if Instagram feed is enabled
    if (!features.instagram_feed_enabled) return;

    // Check if script already exists
    const existingScript = document.querySelector('script[src="https://elfsightcdn.com/platform.js"]');
    
    if (!existingScript) {
      const script = document.createElement('script');
      script.src = 'https://elfsightcdn.com/platform.js';
      script.async = true;
      script.onload = () => {
        setIsLoaded(true);
      };
      script.onerror = () => {
        console.error('Failed to load Elfsight script');
      };
      document.body.appendChild(script);
    } else {
      setIsLoaded(true);
    }

    return () => {
      // Don't remove script on unmount - other components might need it
    };
  }, [features.instagram_feed_enabled]);

  // Re-initialize widget when container changes
  useEffect(() => {
    if (isLoaded && containerRef.current) {
      // @ts-ignore - Elfsight global
      if (window.eapps) {
        // @ts-ignore
        window.eapps.Platform.renderAll();
      }
    }
  }, [isLoaded]);

  if (!features.instagram_feed_enabled) return null;

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {showTitle && (
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 flex items-center justify-center">
              <Instagram className="w-4 h-4 text-white" />
            </div>
            <h2 className="text-xl font-bold">{title}</h2>
          </div>
          {subtitle && (
            <p className="text-sm text-muted-foreground">{subtitle}</p>
          )}
          {instagramUsername && (
            <a 
              href={`https://instagram.com/${instagramUsername}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-pink-500 hover:text-pink-400 transition-colors"
            >
              @{instagramUsername}
            </a>
          )}
        </div>
      )}

      {/* Elfsight Instagram Feed Widget */}
      <div 
        ref={containerRef}
        className="w-full overflow-hidden rounded-xl"
      >
        <div 
          className={`elfsight-app-${widgetId}`}
          data-elfsight-app-lazy
        />
      </div>
    </motion.section>
  );
}
