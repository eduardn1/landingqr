import { motion } from 'framer-motion';
import { useActionButtons, type ActionButton } from '@/hooks/useActionButtons';
import { useLanguage } from '@/contexts/LanguageContext';
import { ActionButtonsSkeleton } from './DishCardSkeleton';
import { cn } from '@/lib/utils';
import * as LucideIcons from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';

interface ActionButtonsGridProps {
  onAction: (actionType: string, actionValue: string | null) => void;
}

// Dynamic icon component
const DynamicIcon = ({ name, className, style }: { name: string; className?: string; style?: React.CSSProperties }) => {
  const IconComponent = (LucideIcons as any)[name];
  if (!IconComponent) {
    return <LucideIcons.HelpCircle className={className} style={style} />;
  }
  return <IconComponent className={className} style={style} />;
};

// Extract first hex color from gradient string
const extractFirstHexFromGradient = (gradient: string): string | null => {
  const match = gradient.match(/#([a-fA-F0-9]{6})/);
  return match ? `#${match[1]}` : null;
};

// Parse color - could be HSL values, hex, gradient, or 'none'
const parseColor = (color: string | null | undefined, opacity: number = 1): string | undefined => {
  if (!color || color.trim() === '' || color.toLowerCase() === 'none') return undefined;
  const trimmed = color.trim();
  
  // Check if it's a gradient - extract first color
  if (trimmed.includes('from-') || trimmed.includes('to-') || trimmed.includes('gradient')) {
    const hexColor = extractFirstHexFromGradient(trimmed);
    if (hexColor) {
      if (opacity < 1) {
        const hex = hexColor.replace('#', '');
        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);
        return `rgba(${r}, ${g}, ${b}, ${opacity})`;
      }
      return hexColor;
    }
    return undefined;
  }
  
  // Check if it's a hex color
  if (trimmed.startsWith('#')) {
    if (opacity < 1) {
      // Convert hex to rgba
      const hex = trimmed.replace('#', '');
      const r = parseInt(hex.substring(0, 2), 16);
      const g = parseInt(hex.substring(2, 4), 16);
      const b = parseInt(hex.substring(4, 6), 16);
      return `rgba(${r}, ${g}, ${b}, ${opacity})`;
    }
    return trimmed;
  }
  
  // Check if it's an HSL value (contains spaces or starts with numbers)
  if (/^\d/.test(trimmed) || (trimmed.includes(' ') && !trimmed.includes('('))) {
    // HSL format: "12 76% 61%" -> hsl(12, 76%, 61%)
    const parts = trimmed.split(/\s+/);
    if (parts.length >= 3) {
      return opacity < 1 
        ? `hsla(${parts[0]}, ${parts[1]}, ${parts[2]}, ${opacity})`
        : `hsl(${parts[0]}, ${parts[1]}, ${parts[2]})`;
    }
    // Fallback for other formats
    return opacity < 1 
      ? `hsla(${trimmed.replace(/%/g, '%')}, ${opacity})`
      : `hsl(${trimmed})`;
  }
  
  return trimmed;
};

// Parse gradient - handles Tailwind-style gradients with hex colors
const parseGradient = (gradient: string | null | undefined): string | undefined => {
  if (!gradient || gradient.trim() === '') return undefined;
  const trimmed = gradient.trim();
  
  // Check if it contains hex color references like from-[#color]
  const hexMatch = trimmed.match(/\[#([a-fA-F0-9]{6})\]/g);
  if (hexMatch) {
    // Extract hex colors from the gradient
    const colors: string[] = [];
    const matches = trimmed.matchAll(/\[#([a-fA-F0-9]{6})\]/g);
    for (const match of matches) {
      colors.push(`#${match[1]}`);
    }
    if (colors.length >= 2) {
      return `linear-gradient(135deg, ${colors[0]}, ${colors[1]})`;
    }
  }
  
  // Return as-is for CSS gradient values
  if (trimmed.includes('gradient') || trimmed.includes('linear') || trimmed.includes('radial')) {
    return trimmed;
  }
  
  return undefined;
};

export function ActionButtonsGrid({ onAction }: ActionButtonsGridProps) {
  const { buttons, isLoading } = useActionButtons();
  const { currentLanguage } = useLanguage();
  const isMobile = useIsMobile();

  if (isLoading) {
    return <ActionButtonsSkeleton />;
  }

  // Filter buttons based on device
  const visibleButtons = buttons.filter(btn => 
    isMobile ? btn.is_visible_mobile : btn.is_visible_desktop
  );

  if (visibleButtons.length === 0) return null;

  // Size configurations
  const getSizeClasses = (size: string) => {
    const baseSize = {
      small: {
        mobile: 'w-24 min-w-[6rem]',
        desktop: 'p-3',
        icon: 'w-8 h-8',
        iconSize: 'w-4 h-4',
        text: 'text-xs',
        subtitle: 'text-[9px]'
      },
      medium: {
        mobile: 'w-28 min-w-[7rem]',
        desktop: 'p-4',
        icon: 'w-10 h-10',
        iconSize: 'w-5 h-5',
        text: 'text-sm',
        subtitle: 'text-[10px]'
      },
      large: {
        mobile: 'w-36 min-w-[9rem]',
        desktop: 'p-5',
        icon: 'w-12 h-12',
        iconSize: 'w-6 h-6',
        text: 'text-base',
        subtitle: 'text-xs'
      }
    };
    
    return baseSize[size as keyof typeof baseSize] || baseSize.medium;
  };

  // Get display style classes
  const getDisplayStyleClasses = (displayStyle: string | null | undefined) => {
    switch (displayStyle) {
      case 'button':
        return {
          wrapper: 'rounded-xl flex-row gap-3 py-3 px-4',
          showIcon: true,
          iconWrapper: false,
          layout: 'horizontal'
        };
      case 'pill':
        return {
          wrapper: 'rounded-full flex-row gap-2 py-2 px-4',
          showIcon: true,
          iconWrapper: false,
          layout: 'horizontal'
        };
      case 'minimal':
        return {
          wrapper: 'rounded-lg bg-transparent border-0 shadow-none',
          showIcon: true,
          iconWrapper: false,
          layout: 'vertical'
        };
      case 'card':
      default:
        return {
          wrapper: 'rounded-2xl flex-col gap-2',
          showIcon: true,
          iconWrapper: true,
          layout: 'vertical'
        };
    }
  };

  return (
    <div className={cn(
      "flex gap-3 pb-2",
      // Mobile: horizontal scroll
      "overflow-x-auto scrollbar-hide",
      // Desktop: 6-column grid for flexible spanning
      "md:grid md:grid-cols-6 md:overflow-visible md:gap-4"
    )}>
      {visibleButtons.map((button, index) => {
        const sizeConfig = getSizeClasses(button.size);
        const styleConfig = getDisplayStyleClasses(button.display_style);
        
        // Custom colors from backend
        const hasCustomBg = button.bg_color && button.bg_color.trim() !== '' && button.bg_color.toLowerCase() !== 'none';
        const hasCustomLabel = button.label_color && button.label_color.trim() !== '';
        const hasCustomIcon = button.icon_color && button.icon_color.trim() !== '';
        const hasCustomBorder = button.border_color && button.border_color.trim() !== '';
        const hasGradient = button.gradient && button.gradient.trim() !== '';
        const opacity = button.bg_opacity ?? 1;
        
        // Legacy support for button_color
        const hasLegacyColor = button.button_color && button.button_color.trim() !== '';
        const hasAnyCustomColor = hasCustomBg || hasLegacyColor || hasGradient;
        
        // Build background style
        const bgStyle: React.CSSProperties = {};
        
        // Parse and apply gradient
        const parsedGradient = parseGradient(button.gradient);
        if (parsedGradient && !hasCustomBg) {
          bgStyle.background = parsedGradient;
        } else if (hasCustomBg) {
          bgStyle.backgroundColor = parseColor(button.bg_color, opacity);
        } else if (hasLegacyColor) {
          bgStyle.backgroundColor = parseColor(button.button_color, 0.15 * opacity);
        }
        
        // Border style
        if (hasCustomBorder) {
          bgStyle.borderColor = parseColor(button.border_color);
        } else if (hasLegacyColor) {
          bgStyle.borderColor = parseColor(button.button_color, 0.25);
        }
        
        // Label color
        const labelStyle: React.CSSProperties = {};
        if (hasCustomLabel) {
          labelStyle.color = parseColor(button.label_color);
        }
        
        // Icon color
        const iconStyle: React.CSSProperties = {};
        if (hasCustomIcon) {
          iconStyle.color = parseColor(button.icon_color);
        } else if (hasLegacyColor) {
          iconStyle.color = parseColor(button.button_color);
        }
        
        const isHorizontal = styleConfig.layout === 'horizontal';
        
        return (
          <motion.button
            key={button.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => onAction(button.action_type, button.action_value)}
            style={{
              gridColumn: isMobile ? undefined : `span ${button.col_span}`,
              ...bgStyle
            }}
            className={cn(
              // Base styles
              "flex-shrink-0 flex items-center justify-center",
              "transition-all duration-300 group",
              styleConfig.wrapper,
              // Mobile: size-based width
              !isHorizontal && sizeConfig.mobile,
              sizeConfig.desktop,
              // Desktop: full width within grid span
              "md:w-auto md:min-w-0",
              // Default colors (when no custom color)
              !hasAnyCustomColor && button.display_style !== 'minimal' && "bg-foreground/[0.04] border border-foreground/[0.06]",
              !hasAnyCustomColor && button.display_style !== 'minimal' && "hover:bg-foreground/[0.08] hover:border-foreground/[0.12] hover:shadow-lg",
              !hasAnyCustomColor && button.display_style !== 'minimal' && "dark:bg-foreground/[0.06] dark:border-foreground/[0.08]",
              !hasAnyCustomColor && button.display_style !== 'minimal' && "dark:hover:bg-foreground/[0.10] dark:hover:border-foreground/[0.15]",
              // Custom color hover styles
              hasAnyCustomColor && "border hover:shadow-lg hover:scale-[1.02]"
            )}
          >
            {styleConfig.showIcon && (
              styleConfig.iconWrapper ? (
                <div 
                  className={cn(
                    "rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform",
                    !hasCustomIcon && !hasLegacyColor && "bg-foreground/[0.05] dark:bg-foreground/[0.08]",
                    sizeConfig.icon
                  )}
                  style={hasCustomIcon || hasLegacyColor ? { 
                    backgroundColor: hasCustomIcon 
                      ? parseColor(button.icon_color, 0.15) 
                      : parseColor(button.button_color, 0.20) 
                  } : undefined}
                >
                  <DynamicIcon 
                    name={button.icon} 
                    className={cn(sizeConfig.iconSize, !hasCustomIcon && !hasLegacyColor && "text-foreground/60 dark:text-foreground/70")}
                    style={iconStyle}
                  />
                </div>
              ) : (
                <DynamicIcon 
                  name={button.icon} 
                  className={cn(sizeConfig.iconSize, "group-hover:scale-110 transition-transform", !hasCustomIcon && !hasLegacyColor && "text-foreground/60 dark:text-foreground/70")}
                  style={iconStyle}
                />
              )
            )}
            <div className={cn("text-center", isHorizontal && "text-left")}>
              <h3 
                className={cn("font-semibold leading-tight", sizeConfig.text, !hasCustomLabel && "text-foreground")}
                style={labelStyle}
              >
                {(button.label as Record<string, string>)[currentLanguage] || button.label.en || button.label.it}
              </h3>
              {button.subtitle && (button.subtitle.it || button.subtitle.en) && (
                <p 
                  className={cn("leading-tight mt-0.5", sizeConfig.subtitle, !hasCustomLabel && "text-muted-foreground")}
                  style={hasCustomLabel ? { color: parseColor(button.label_color, 0.7) } : undefined}
                >
                  {(button.subtitle as Record<string, string>)[currentLanguage] || button.subtitle.en || button.subtitle.it}
                </p>
              )}
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}
