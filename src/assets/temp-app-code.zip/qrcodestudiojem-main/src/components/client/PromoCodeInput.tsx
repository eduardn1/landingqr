import { useState, forwardRef } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tag, X, Check, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useLanguage } from '@/contexts/LanguageContext';

interface PromoCodeInputProps {
  subtotal: number;
  onPromoApplied: (promo: AppliedPromo | null) => void;
  appliedPromo: AppliedPromo | null;
  hasDiscountedItems?: boolean; // true if cart contains items with original_price
}

export interface AppliedPromo {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed' | 'free_delivery';
  discountValue: number;
  discountAmount: number;
  excludeDiscountedItems?: boolean;
}

export const PromoCodeInput = forwardRef<HTMLDivElement, PromoCodeInputProps>(({ subtotal, onPromoApplied, appliedPromo, hasDiscountedItems = false }, ref) => {
  const { currentLanguage } = useLanguage();
  const [code, setCode] = useState('');
  const [isValidating, setIsValidating] = useState(false);

  const validatePromo = async () => {
    if (!code.trim()) return;

    setIsValidating(true);
    try {
      const now = new Date().toISOString();
      const dayOfWeek = new Date().getDay(); // 0 = Sunday

      const { data: promo, error } = await supabase
        .from('daily_promos')
        .select('*')
        .eq('promo_code', code.toUpperCase())
        .eq('is_active', true)
        .lte('valid_from', now)
        .gte('valid_until', now)
        .maybeSingle();

      if (error) throw error;

      if (!promo) {
        toast.error(currentLanguage === 'it' ? 'Codice non valido o scaduto' : 'Invalid or expired code');
        return;
      }

      // Check day of week
      if (promo.days_of_week && !promo.days_of_week.includes(dayOfWeek)) {
        toast.error(
          currentLanguage === 'it'
            ? 'Codice non valido per oggi'
            : 'Code not valid for today'
        );
        return;
      }

      // Check minimum order
      if (promo.minimum_order && subtotal < promo.minimum_order) {
        toast.error(
          currentLanguage === 'it'
            ? `Ordine minimo €${promo.minimum_order.toFixed(2)}`
            : `Minimum order €${promo.minimum_order.toFixed(2)}`
        );
        return;
      }

      // Check max uses
      if (promo.max_uses && promo.current_uses >= promo.max_uses) {
        toast.error(
          currentLanguage === 'it'
            ? 'Codice esaurito'
            : 'Code limit reached'
        );
        return;
      }

      // Check if promo excludes discounted items and cart has them
      const promoAny = promo as any;
      if (promoAny.exclude_discounted_items && hasDiscountedItems) {
        toast.error(
          currentLanguage === 'it'
            ? 'Codice non valido per prodotti già scontati'
            : 'Code not valid for already discounted products'
        );
        return;
      }

      // Calculate discount
      let discountAmount = 0;
      if (promo.discount_type === 'percentage') {
        discountAmount = (subtotal * (promo.discount_value || 0)) / 100;
      } else if (promo.discount_type === 'fixed') {
        discountAmount = promo.discount_value || 0;
      }

      onPromoApplied({
        id: promo.id,
        code: promo.promo_code!,
        discountType: promo.discount_type as 'percentage' | 'fixed' | 'free_delivery',
        discountValue: promo.discount_value || 0,
        discountAmount,
        excludeDiscountedItems: promoAny.exclude_discounted_items,
      });

      toast.success(currentLanguage === 'it' ? 'Codice applicato!' : 'Code applied!');
      setCode('');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setIsValidating(false);
    }
  };

  const removePromo = () => {
    onPromoApplied(null);
    toast.success(currentLanguage === 'it' ? 'Codice rimosso' : 'Code removed');
  };

  if (appliedPromo) {
    return (
      <div className="flex items-center justify-between p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
        <div className="flex items-center gap-2">
          <Check className="w-4 h-4 text-green-500" />
          <span className="font-medium text-green-600">{appliedPromo.code}</span>
          <Badge variant="secondary" className="text-xs">
            {appliedPromo.discountType === 'percentage'
              ? `-${appliedPromo.discountValue}%`
              : appliedPromo.discountType === 'free_delivery'
              ? currentLanguage === 'it' ? 'Consegna gratis' : 'Free delivery'
              : `-€${appliedPromo.discountValue.toFixed(2)}`}
          </Badge>
        </div>
        <Button
          type="button"
          size="icon"
          variant="ghost"
          className="h-8 w-8 text-muted-foreground hover:text-destructive"
          onClick={removePromo}
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    );
  }

  return (
    <div ref={ref} className="flex gap-2">
      <div className="relative flex-1">
        <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder={currentLanguage === 'it' ? 'Codice promo' : 'Promo code'}
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          className="pl-10"
          onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), validatePromo())}
        />
      </div>
      <Button
        type="button"
        variant="outline"
        onClick={validatePromo}
        disabled={isValidating || !code.trim()}
      >
        {isValidating ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          currentLanguage === 'it' ? 'Applica' : 'Apply'
        )}
      </Button>
    </div>
  );
});

PromoCodeInput.displayName = 'PromoCodeInput';
