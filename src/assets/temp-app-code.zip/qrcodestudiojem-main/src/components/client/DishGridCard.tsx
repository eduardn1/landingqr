import { useLanguage } from '@/contexts/LanguageContext';
import { getLocalizedContent } from '@/lib/i18n';
import { type Dish } from '@/lib/mockData';
import { cn } from '@/lib/utils';
import { Flame, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { DishPlaceholder, PlaceholderType } from './DishPlaceholder';

interface DishGridCardProps {
  dish: Dish;
  onClick?: () => void;
  isRecommended?: boolean;
  isMoodMatch?: boolean;
  categoryIcon?: string;
  placeholderType?: PlaceholderType;
  placeholderEmoji?: string;
  placeholderGradient?: string;
  placeholderImage?: string;
}

export function DishGridCard({ 
  dish, 
  onClick, 
  isRecommended, 
  isMoodMatch, 
  categoryIcon,
  placeholderType,
  placeholderEmoji,
  placeholderGradient,
  placeholderImage
}: DishGridCardProps) {
  const { currentLanguage } = useLanguage();
  const [imageError, setImageError] = useState(false);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat(currentLanguage, {
      style: 'currency',
      currency: dish.currency || 'EUR',
    }).format(price);
  };

  const renderSpicyLevel = () => {
    if (!dish.spicyLevel || dish.spicyLevel === 0) return null;
    return (
      <div className="flex items-center gap-0.5">
        {[1, 2, 3].map((level) => (
          <Flame
            key={level}
            className={cn(
              "h-2.5 w-2.5",
              level <= dish.spicyLevel! ? "text-accent" : "text-muted-foreground/20"
            )}
            fill={level <= dish.spicyLevel! ? "currentColor" : "none"}
          />
        ))}
      </div>
    );
  };

  const hasImage = dish.images && dish.images[0] && !imageError;

  return (
    <div
      onClick={onClick}
      className={cn(
        "overflow-hidden cursor-pointer group rounded-xl bg-secondary/20 border border-border/30 transition-all hover:bg-secondary/30",
        !dish.isAvailable && "opacity-50",
        isMoodMatch && "ring-2 ring-accent ring-offset-1 ring-offset-background"
      )}
    >
      {/* Square Image */}
      <div className="relative aspect-square overflow-hidden bg-secondary/30">
        {hasImage ? (
          <img
            src={dish.images[0]}
            alt={getLocalizedContent(dish.name, currentLanguage)}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            onError={() => setImageError(true)}
          />
        ) : (
          <DishPlaceholder 
            categoryIcon={categoryIcon} 
            size="medium" 
            placeholderType={placeholderType}
            placeholderEmoji={placeholderEmoji}
            placeholderGradient={placeholderGradient}
            placeholderImage={placeholderImage}
          />
        )}
        {isRecommended && !dish.badge && (
          <div className="absolute top-1.5 left-1.5 p-1 bg-gradient-to-r from-primary to-accent rounded-full z-10">
            <Sparkles className="w-2.5 h-2.5 text-primary-foreground" />
          </div>
        )}
        {dish.badge && (
          <div className="absolute top-1.5 left-1.5 px-1.5 py-0.5 bg-accent text-accent-foreground text-[9px] font-semibold rounded-full z-10 shadow-md backdrop-blur-sm">
            {dish.badge}
          </div>
        )}
      </div>

      {/* Compact Content */}
      <div className="p-2 space-y-0.5">
        <h3 className="font-medium text-xs leading-tight text-foreground line-clamp-1">
          {getLocalizedContent(dish.name, currentLanguage)}
        </h3>
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-foreground/80">{formatPrice(dish.price)}</span>
          {renderSpicyLevel()}
        </div>
      </div>

      {!dish.isAvailable && (
        <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
          <span className="bg-foreground text-background px-2 py-1 rounded-full text-[9px] font-medium">
            Non disponibile
          </span>
        </div>
      )}
    </div>
  );
}
