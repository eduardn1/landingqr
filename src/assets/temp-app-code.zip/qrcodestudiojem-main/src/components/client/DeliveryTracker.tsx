import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { MapPin, Truck, Clock, Phone, User } from 'lucide-react';
import { motion } from 'framer-motion';

interface DriverLocation {
  name: string;
  phone: string;
  vehicle_type: string | null;
  current_lat: number | null;
  current_lng: number | null;
  location_updated_at: string | null;
  is_online: boolean;
}

interface Props {
  orderId: string;
  driverId: string;
  deliveryAddress: {
    lat?: number;
    lng?: number;
    street: string;
    city: string;
  };
}

export function DeliveryTracker({ orderId, driverId, deliveryAddress }: Props) {
  const [driver, setDriver] = useState<DriverLocation | null>(null);
  const [eta, setEta] = useState<number | null>(null);

  useEffect(() => {
    // Fetch initial driver data
    const fetchDriver = async () => {
      const { data } = await supabase
        .from('takeaway_drivers')
        .select('name, phone, vehicle_type, current_lat, current_lng, location_updated_at, is_online')
        .eq('id', driverId)
        .single();
      
      if (data) {
        setDriver(data);
        calculateETA(data);
      }
    };

    fetchDriver();

    // Subscribe to driver location updates
    const channel = supabase
      .channel(`driver-location-${driverId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'takeaway_drivers',
          filter: `id=eq.${driverId}`,
        },
        (payload) => {
          const updatedDriver = payload.new as DriverLocation;
          setDriver(updatedDriver);
          calculateETA(updatedDriver);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [driverId]);

  const calculateETA = (driverData: DriverLocation) => {
    if (!driverData.current_lat || !driverData.current_lng) {
      setEta(null);
      return;
    }

    // Use delivery address coordinates or default
    const destLat = deliveryAddress.lat || 41.9028; // Default Rome
    const destLng = deliveryAddress.lng || 12.4964;

    // Haversine formula
    const R = 6371;
    const dLat = (destLat - driverData.current_lat) * Math.PI / 180;
    const dLng = (destLng - driverData.current_lng) * Math.PI / 180;
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(driverData.current_lat * Math.PI / 180) * Math.cos(destLat * Math.PI / 180) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distance = R * c;

    // Assume 25 km/h average city speed
    const etaMinutes = Math.max(5, Math.round((distance / 25) * 60));
    setEta(etaMinutes);
  };

  if (!driver) return null;

  return (
    <Card className="border-accent/30 bg-accent/5">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Truck className="w-5 h-5 text-accent" />
          Tracciamento consegna
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Driver Info */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="font-semibold">{driver.name}</p>
              <p className="text-xs text-muted-foreground">
                {driver.vehicle_type || 'Driver'}
              </p>
            </div>
          </div>
          <Badge variant={driver.is_online ? 'default' : 'secondary'}>
            {driver.is_online ? 'Online' : 'Offline'}
          </Badge>
        </div>

        {/* ETA */}
        {eta !== null && (
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-background rounded-lg p-4 text-center"
          >
            <div className="flex items-center justify-center gap-2 mb-1">
              <Clock className="w-5 h-5 text-accent" />
              <span className="text-sm text-muted-foreground">Arrivo stimato</span>
            </div>
            <p className="text-3xl font-bold text-accent">~{eta} min</p>
          </motion.div>
        )}

        {/* Location Status */}
        {driver.current_lat && driver.current_lng && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4" />
            <span>
              Posizione aggiornata {driver.location_updated_at 
                ? new Date(driver.location_updated_at).toLocaleTimeString('it-IT', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })
                : 'recentemente'}
            </span>
          </div>
        )}

        {/* Destination */}
        <div className="flex items-start gap-2 p-3 bg-secondary/30 rounded-lg">
          <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
          <div className="text-sm">
            <p className="font-medium">Consegna a:</p>
            <p className="text-muted-foreground">
              {deliveryAddress.street}, {deliveryAddress.city}
            </p>
          </div>
        </div>

        {/* Contact Driver */}
        <a
          href={`tel:${driver.phone}`}
          className="flex items-center justify-center gap-2 w-full py-3 bg-accent text-accent-foreground rounded-lg font-medium hover:bg-accent/90 transition-colors"
        >
          <Phone className="w-4 h-4" />
          Chiama il driver
        </a>
      </CardContent>
    </Card>
  );
}
