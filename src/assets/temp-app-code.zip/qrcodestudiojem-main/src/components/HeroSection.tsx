import { ArrowDown, MapPin, Star } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { restaurant } from '@/lib/mockData';
import { getLocalizedContent } from '@/lib/i18n';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import heroImage from '@/assets/hero-restaurant.jpg';
import logoImage from '@/assets/logo-restaurant.png';

interface HeroSectionProps {
  onScrollToMenu: () => void;
}

export function HeroSection({ onScrollToMenu }: HeroSectionProps) {
  const { currentLanguage, t } = useLanguage();

  return (
    <section className="relative min-h-[100svh] flex flex-col">
      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-4 md:p-6">
        <div className="flex items-center gap-3">
          <img src={logoImage} alt="Il Locale" className="h-10 w-10 rounded-lg bg-white/90 p-1" />
          <div className="flex items-center gap-2 text-white/90">
            <MapPin className="h-4 w-4" />
            <span className="text-sm font-medium">Napoli, Italia</span>
          </div>
        </div>
        <LanguageSwitcher />
      </div>

      {/* Hero Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex-1 flex flex-col justify-end p-6 md:p-12 pb-24 md:pb-32">
        <div className="max-w-2xl">
          {/* Rating */}
          <div className="flex items-center gap-2 mb-4 animate-fade-in">
            <div className="flex items-center gap-1 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-full">
              <Star className="h-4 w-4 text-accent fill-accent" />
              <span className="text-white text-sm font-medium">4.9</span>
            </div>
            <span className="text-white/70 text-sm">1,200+ reviews</span>
          </div>

          {/* Restaurant Name */}
          <h1 
            className="text-4xl sm:text-5xl md:text-7xl font-bold text-white mb-4 animate-fade-in-up tracking-tight"
            style={{ animationDelay: '0.1s' }}
          >
            {restaurant.name}
          </h1>

          {/* Tagline */}
          <p 
            className="text-lg sm:text-xl text-white/80 mb-8 animate-fade-in-up max-w-lg"
            style={{ animationDelay: '0.2s' }}
          >
            {getLocalizedContent(restaurant.tagline, currentLanguage)}
          </p>

          {/* CTA Button */}
          <button
            onClick={onScrollToMenu}
            className="group inline-flex items-center gap-3 animate-fade-in-up"
            style={{ animationDelay: '0.3s' }}
          >
            <span className="px-8 py-4 bg-white text-foreground font-semibold rounded-full transition-all duration-300 hover:bg-accent hover:text-white">
              {t('viewMenu')}
            </span>
            <span className="w-12 h-12 rounded-full border-2 border-white/30 flex items-center justify-center group-hover:border-white/60 transition-colors">
              <ArrowDown className="h-5 w-5 text-white animate-bounce" />
            </span>
          </button>
        </div>
      </div>

      {/* Bottom gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent z-10" />
    </section>
  );
}
