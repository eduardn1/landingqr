import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Star, TrendingUp, Clock, Truck, Target, Award, 
  Calendar, Timer
} from 'lucide-react';
import { format, startOfWeek, endOfWeek, differenceInMinutes } from 'date-fns';
import { it } from 'date-fns/locale';

interface DriverOrder {
  id: string;
  status: string;
  created_at: string;
  ready_at: string | null;
  completed_at: string | null;
  delivery_actual_time?: string | null;
}

interface DriverStats {
  name: string;
  average_rating: number | null;
  total_deliveries: number | null;
}

interface Props {
  driver: DriverStats;
  orders: DriverOrder[];
}

export function DriverPerformanceDashboard({ driver, orders }: Props) {
  const stats = useMemo(() => {
    const completedOrders = orders.filter(o => o.status === 'completed');
    const todayOrders = completedOrders.filter(o => 
      new Date(o.created_at).toDateString() === new Date().toDateString()
    );

    // Calculate average delivery time
    const deliveryTimes: number[] = [];
    completedOrders.forEach(order => {
      if (order.ready_at && order.completed_at) {
        const minutes = differenceInMinutes(
          new Date(order.completed_at),
          new Date(order.ready_at)
        );
        if (minutes > 0 && minutes < 180) { // Filter out outliers
          deliveryTimes.push(minutes);
        }
      }
    });

    const avgDeliveryTime = deliveryTimes.length > 0
      ? Math.round(deliveryTimes.reduce((a, b) => a + b, 0) / deliveryTimes.length)
      : 0;

    // This week's orders
    const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
    const weekEnd = endOfWeek(new Date(), { weekStartsOn: 1 });
    const thisWeekOrders = completedOrders.filter(o => {
      const date = new Date(o.created_at);
      return date >= weekStart && date <= weekEnd;
    });

    // Calculate on-time delivery rate (completed within 10 min of ready)
    let onTimeCount = 0;
    completedOrders.forEach(order => {
      if (order.ready_at && order.completed_at) {
        const minutes = differenceInMinutes(
          new Date(order.completed_at),
          new Date(order.ready_at)
        );
        if (minutes <= 30) onTimeCount++;
      }
    });
    const onTimeRate = completedOrders.length > 0
      ? Math.round((onTimeCount / completedOrders.length) * 100)
      : 100;

    return {
      todayCount: todayOrders.length,
      weekCount: thisWeekOrders.length,
      totalDeliveries: driver.total_deliveries || 0,
      avgDeliveryTime,
      avgRating: driver.average_rating || 0,
      onTimeRate,
    };
  }, [driver, orders]);

  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-lg flex items-center gap-2">
        <TrendingUp className="w-5 h-5 text-accent" />
        Le tue statistiche
      </h3>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        <Card className="bg-gradient-to-br from-yellow-500/10 to-amber-500/10 border-yellow-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Star className="w-5 h-5 fill-yellow-500 text-yellow-500" />
              <span className="text-xs text-muted-foreground">Valutazione</span>
            </div>
            <p className="text-2xl font-bold">
              {stats.avgRating > 0 ? stats.avgRating.toFixed(1) : '-'}
            </p>
            <p className="text-xs text-muted-foreground">media stelle</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-5 h-5 text-green-500" />
              <span className="text-xs text-muted-foreground">Puntualità</span>
            </div>
            <p className="text-2xl font-bold">{stats.onTimeRate}%</p>
            <p className="text-xs text-muted-foreground">in tempo</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500/10 to-indigo-500/10 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Timer className="w-5 h-5 text-blue-500" />
              <span className="text-xs text-muted-foreground">Media consegna</span>
            </div>
            <p className="text-2xl font-bold">
              {stats.avgDeliveryTime > 0 ? `${stats.avgDeliveryTime}'` : '-'}
            </p>
            <p className="text-xs text-muted-foreground">minuti</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border-purple-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Award className="w-5 h-5 text-purple-500" />
              <span className="text-xs text-muted-foreground">Totali</span>
            </div>
            <p className="text-2xl font-bold">{stats.totalDeliveries}</p>
            <p className="text-xs text-muted-foreground">consegne</p>
          </CardContent>
        </Card>
      </div>

      {/* Period Stats */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Periodo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Oggi</span>
            </div>
            <span className="font-bold">{stats.todayCount} consegne</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Questa settimana</span>
            </div>
            <span className="font-bold">{stats.weekCount} consegne</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
