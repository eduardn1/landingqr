import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Gift, CalendarDays, ShoppingBag, Star, Zap } from 'lucide-react';
import { useLoyalty } from '@/hooks/useLoyalty';
import { useLanguage } from '@/contexts/LanguageContext';
import { format } from 'date-fns';
import { it, enUS } from 'date-fns/locale';

const transactionIcons: Record<string, typeof Star> = {
  reservation: CalendarDays,
  order: ShoppingBag,
  redemption: Gift,
  bonus: Zap,
  welcome: Star,
};

const transactionColors: Record<string, string> = {
  reservation: 'text-accent bg-accent/10',
  order: 'text-orange-500 bg-orange-500/10',
  redemption: 'text-purple-500 bg-purple-500/10',
  bonus: 'text-yellow-500 bg-yellow-500/10',
  welcome: 'text-green-500 bg-green-500/10',
};

export function PointsHistory() {
  const { transactions, points, isLoading, getTierProgress } = useLoyalty();
  const { currentLanguage } = useLanguage();
  
  const dateLocale = currentLanguage === 'it' ? it : enUS;
  const tierProgress = getTierProgress();

  const t = {
    it: {
      title: 'Cronologia punti',
      totalPoints: 'Punti totali',
      lifetimePoints: 'Punti guadagnati',
      tier: 'Livello',
      noTransactions: 'Nessuna attività ancora',
      startEarning: 'Prenota o ordina per guadagnare punti!',
      earned: 'Guadagnati',
      spent: 'Spesi',
    },
    en: {
      title: 'Points History',
      totalPoints: 'Total Points',
      lifetimePoints: 'Lifetime Points',
      tier: 'Tier',
      noTransactions: 'No activity yet',
      startEarning: 'Book or order to earn points!',
      earned: 'Earned',
      spent: 'Spent',
    },
  };

  const labels = t[currentLanguage as keyof typeof t] || t.it;

  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-16 bg-secondary/50 rounded-xl animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Points Summary */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-gradient-to-br from-accent/20 to-accent/5 rounded-xl p-3 text-center border border-accent/20">
          <p className="text-2xl font-bold text-accent">{points?.total_points || 0}</p>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{labels.totalPoints}</p>
        </div>
        <div className="bg-secondary/50 rounded-xl p-3 text-center border border-border/50">
          <p className="text-2xl font-bold">{points?.lifetime_points || 0}</p>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{labels.lifetimePoints}</p>
        </div>
        <div className="bg-secondary/50 rounded-xl p-3 text-center border border-border/50">
          <p className="text-2xl font-bold capitalize">{tierProgress.current}</p>
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{labels.tier}</p>
        </div>
      </div>

      {/* Transactions List */}
      <div className="space-y-2">
        {transactions.length === 0 ? (
          <div className="text-center py-8">
            <Star className="w-12 h-12 mx-auto mb-3 text-muted-foreground/30" />
            <p className="text-muted-foreground font-medium">{labels.noTransactions}</p>
            <p className="text-xs text-muted-foreground mt-1">{labels.startEarning}</p>
          </div>
        ) : (
          transactions.map((tx, index) => {
            const Icon = transactionIcons[tx.transaction_type] || Star;
            const colorClass = transactionColors[tx.transaction_type] || 'text-accent bg-accent/10';
            const isPositive = tx.points > 0;

            return (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="flex items-center gap-3 p-3 bg-card border border-border/50 rounded-xl"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${colorClass}`}>
                  <Icon className="w-5 h-5" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">
                    {tx.description || tx.transaction_type}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {format(new Date(tx.created_at), 'd MMM yyyy, HH:mm', { locale: dateLocale })}
                  </p>
                </div>
                
                <div className={`flex items-center gap-1 font-bold ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
                  {isPositive ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : (
                    <TrendingDown className="w-4 h-4" />
                  )}
                  <span>{isPositive ? '+' : ''}{tx.points}</span>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}
