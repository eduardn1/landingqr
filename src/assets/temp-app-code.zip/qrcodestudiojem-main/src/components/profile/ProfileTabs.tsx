import { motion } from 'framer-motion';
import { User, CalendarDays, Star, Settings } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export type ProfileTabKey = 'profile' | 'orders' | 'points' | 'settings';

interface ProfileTabsProps {
  activeTab: ProfileTabKey;
  onTabChange: (tab: ProfileTabKey) => void;
  pointsCount?: number;
  ordersCount?: number;
}

export function ProfileTabs({ activeTab, onTabChange, pointsCount = 0, ordersCount = 0 }: ProfileTabsProps) {
  const { currentLanguage } = useLanguage();

  const tabs: { key: ProfileTabKey; icon: typeof User; label: { it: string; en: string }; badge?: number }[] = [
    { key: 'profile', icon: User, label: { it: 'Profilo', en: 'Profile' } },
    { key: 'orders', icon: CalendarDays, label: { it: 'Ordini', en: 'Orders' }, badge: ordersCount > 0 ? ordersCount : undefined },
    { key: 'points', icon: Star, label: { it: 'Punti', en: 'Points' }, badge: pointsCount > 0 ? pointsCount : undefined },
    { key: 'settings', icon: Settings, label: { it: 'Impostazioni', en: 'Settings' } },
  ];

  return (
    <div className="flex bg-secondary/50 rounded-2xl p-1.5 gap-1">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.key;
        const Icon = tab.icon;
        
        return (
          <button
            key={tab.key}
            onClick={() => onTabChange(tab.key)}
            className={`relative flex-1 flex flex-col items-center gap-1.5 py-3 px-2 rounded-xl transition-all ${
              isActive 
                ? 'bg-card text-foreground shadow-sm' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {isActive && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 bg-card rounded-xl shadow-sm"
                transition={{ type: 'spring', bounce: 0.2, duration: 0.4 }}
              />
            )}
            
            <div className="relative z-10 flex items-center gap-1">
              <Icon className="w-5 h-5" />
              {tab.badge !== undefined && (
                <span className="absolute -top-1.5 -right-2.5 min-w-5 h-5 px-1 rounded-full bg-accent text-[10px] font-bold text-accent-foreground flex items-center justify-center">
                  {tab.badge > 99 ? '99+' : tab.badge}
                </span>
              )}
            </div>
            
            <span className="relative z-10 text-xs font-semibold uppercase tracking-wide">
              {tab.label[currentLanguage as keyof typeof tab.label] || tab.label.it}
            </span>
          </button>
        );
      })}
    </div>
  );
}
