import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const PROFILE_EMOJIS = [
  '😊', '😎', '🤗', '😋', '🥳', '🤩', '😇', '🧐',
  '👨‍🍳', '👩‍🍳', '🍕', '🍝', '🍷', '🍽️', '☕', '🥂',
  '🌟', '✨', '💫', '🔥', '💪', '🎉', '❤️', '💜',
  '🦊', '🐱', '🐶', '🦁', '🐼', '🦄', '🐸', '🦋',
];

interface ProfileAvatarProps {
  userId: string;
  currentEmoji: string | null;
  onEmojiChange: (emoji: string) => void;
  size?: 'sm' | 'md' | 'lg';
}

export function ProfileAvatar({ userId, currentEmoji, onEmojiChange, size = 'lg' }: ProfileAvatarProps) {
  const [isPickerOpen, setIsPickerOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const displayEmoji = currentEmoji || '😊';

  const sizeClasses = {
    sm: 'w-12 h-12 text-2xl',
    md: 'w-16 h-16 text-3xl',
    lg: 'w-20 h-20 text-4xl',
  };

  const handleSelectEmoji = async (emoji: string) => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ avatar_emoji: emoji })
        .eq('user_id', userId);

      if (error) throw error;
      
      onEmojiChange(emoji);
      setIsPickerOpen(false);
      toast.success('Avatar aggiornato!', { duration: 1500 });
    } catch (error) {
      console.error('Error updating avatar:', error);
      toast.error('Errore nel salvataggio');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="relative">
      {/* Avatar Button */}
      <motion.button
        onClick={() => setIsPickerOpen(true)}
        className={`${sizeClasses[size]} rounded-full bg-gradient-to-br from-accent/30 via-accent/20 to-accent/10 flex items-center justify-center border-2 border-accent/30 hover:border-accent/50 transition-all relative group`}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <span className="select-none">{displayEmoji}</span>
        <div className="absolute inset-0 rounded-full bg-foreground/0 group-hover:bg-foreground/10 transition-colors flex items-center justify-center">
          <span className="text-xs font-medium text-foreground opacity-0 group-hover:opacity-100 transition-opacity">
            ✏️
          </span>
        </div>
      </motion.button>

      {/* Emoji Picker Modal */}
      <AnimatePresence>
        {isPickerOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsPickerOpen(false)}
              className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50"
            />
            
            {/* Picker */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-[90vw] max-w-sm bg-card border border-border rounded-2xl p-4 shadow-xl"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Scegli il tuo avatar</h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsPickerOpen(false)}
                  className="h-8 w-8"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="grid grid-cols-8 gap-2">
                {PROFILE_EMOJIS.map((emoji) => (
                  <motion.button
                    key={emoji}
                    onClick={() => handleSelectEmoji(emoji)}
                    disabled={isSaving}
                    className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl hover:bg-accent/20 transition-colors ${
                      displayEmoji === emoji ? 'bg-accent/30 ring-2 ring-accent' : 'bg-secondary/50'
                    }`}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    {emoji}
                  </motion.button>
                ))}
              </div>
              
              <p className="text-xs text-muted-foreground text-center mt-4">
                Il tuo avatar sarà visibile nel tuo profilo
              </p>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
