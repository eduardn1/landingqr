import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Plus, Trash2, Check, Home, Building2, Briefcase, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useLanguage } from '@/contexts/LanguageContext';

interface DeliveryAddress {
  id: string;
  user_id: string;
  label: string;
  address: string;
  city: string;
  zip_code: string;
  apartment_floor: string | null;
  delivery_notes: string | null;
  is_default: boolean;
}

const ADDRESS_LABELS = [
  { key: 'Casa', icon: Home, color: 'text-green-500 bg-green-500/10' },
  { key: 'Ufficio', icon: Briefcase, color: 'text-blue-500 bg-blue-500/10' },
  { key: 'Altro', icon: Building2, color: 'text-purple-500 bg-purple-500/10' },
];

interface DeliveryAddressesProps {
  userId: string;
}

export function DeliveryAddresses({ userId }: DeliveryAddressesProps) {
  const { currentLanguage } = useLanguage();
  const [addresses, setAddresses] = useState<DeliveryAddress[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    label: 'Casa',
    address: '',
    city: '',
    zip_code: '',
    apartment_floor: '',
    delivery_notes: '',
  });

  const t = {
    it: {
      title: 'Indirizzi di consegna',
      addNew: 'Aggiungi indirizzo',
      save: 'Salva',
      cancel: 'Annulla',
      setDefault: 'Imposta come predefinito',
      default: 'Predefinito',
      address: 'Via e numero civico',
      city: 'Città',
      zipCode: 'CAP',
      floor: 'Piano / Interno',
      notes: 'Note consegna',
      noAddresses: 'Nessun indirizzo salvato',
      addFirst: 'Aggiungi il tuo primo indirizzo',
    },
    en: {
      title: 'Delivery Addresses',
      addNew: 'Add address',
      save: 'Save',
      cancel: 'Cancel',
      setDefault: 'Set as default',
      default: 'Default',
      address: 'Street address',
      city: 'City',
      zipCode: 'ZIP Code',
      floor: 'Floor / Apt',
      notes: 'Delivery notes',
      noAddresses: 'No saved addresses',
      addFirst: 'Add your first address',
    },
  };

  const labels = t[currentLanguage as keyof typeof t] || t.it;

  // Fetch addresses
  useEffect(() => {
    const fetchAddresses = async () => {
      const { data, error } = await supabase
        .from('delivery_addresses')
        .select('*')
        .eq('user_id', userId)
        .order('is_default', { ascending: false });

      if (!error && data) {
        setAddresses(data as DeliveryAddress[]);
      }
      setIsLoading(false);
    };

    fetchAddresses();
  }, [userId]);

  const resetForm = () => {
    setFormData({
      label: 'Casa',
      address: '',
      city: '',
      zip_code: '',
      apartment_floor: '',
      delivery_notes: '',
    });
    setIsAdding(false);
    setEditingId(null);
  };

  const handleSave = async () => {
    if (!formData.address || !formData.city || !formData.zip_code) {
      toast.error(currentLanguage === 'it' ? 'Compila tutti i campi obbligatori' : 'Fill all required fields');
      return;
    }

    try {
      if (editingId) {
        // Update existing
        const { error } = await supabase
          .from('delivery_addresses')
          .update({
            label: formData.label,
            address: formData.address,
            city: formData.city,
            zip_code: formData.zip_code,
            apartment_floor: formData.apartment_floor || null,
            delivery_notes: formData.delivery_notes || null,
          })
          .eq('id', editingId);

        if (error) throw error;
        
        setAddresses(prev => prev.map(a => 
          a.id === editingId 
            ? { ...a, ...formData, apartment_floor: formData.apartment_floor || null, delivery_notes: formData.delivery_notes || null }
            : a
        ));
      } else {
        // Create new
        const isFirst = addresses.length === 0;
        const { data, error } = await supabase
          .from('delivery_addresses')
          .insert({
            user_id: userId,
            label: formData.label,
            address: formData.address,
            city: formData.city,
            zip_code: formData.zip_code,
            apartment_floor: formData.apartment_floor || null,
            delivery_notes: formData.delivery_notes || null,
            is_default: isFirst,
          })
          .select()
          .single();

        if (error) throw error;
        setAddresses(prev => [...prev, data as DeliveryAddress]);
      }

      toast.success(currentLanguage === 'it' ? 'Salvato!' : 'Saved!');
      resetForm();
    } catch (error) {
      console.error('Error saving address:', error);
      toast.error(currentLanguage === 'it' ? 'Errore nel salvataggio' : 'Error saving');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('delivery_addresses')
        .delete()
        .eq('id', id);

      if (error) throw error;
      setAddresses(prev => prev.filter(a => a.id !== id));
      toast.success(currentLanguage === 'it' ? 'Eliminato!' : 'Deleted!');
    } catch (error) {
      console.error('Error deleting address:', error);
      toast.error(currentLanguage === 'it' ? 'Errore' : 'Error');
    }
  };

  const handleSetDefault = async (id: string) => {
    try {
      // Remove default from all
      await supabase
        .from('delivery_addresses')
        .update({ is_default: false })
        .eq('user_id', userId);

      // Set new default
      const { error } = await supabase
        .from('delivery_addresses')
        .update({ is_default: true })
        .eq('id', id);

      if (error) throw error;

      setAddresses(prev => prev.map(a => ({
        ...a,
        is_default: a.id === id
      })));
      
      toast.success(currentLanguage === 'it' ? 'Impostato come predefinito' : 'Set as default');
    } catch (error) {
      console.error('Error setting default:', error);
    }
  };

  const startEdit = (addr: DeliveryAddress) => {
    setFormData({
      label: addr.label,
      address: addr.address,
      city: addr.city,
      zip_code: addr.zip_code,
      apartment_floor: addr.apartment_floor || '',
      delivery_notes: addr.delivery_notes || '',
    });
    setEditingId(addr.id);
    setIsAdding(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-2">
        {[1, 2].map(i => (
          <div key={i} className="h-20 bg-secondary/50 rounded-xl animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Address List */}
      {addresses.length === 0 && !isAdding ? (
        <div className="text-center py-6">
          <MapPin className="w-10 h-10 mx-auto mb-2 text-muted-foreground/30" />
          <p className="text-sm text-muted-foreground">{labels.noAddresses}</p>
          <p className="text-xs text-muted-foreground">{labels.addFirst}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {addresses.map((addr) => {
            const labelConfig = ADDRESS_LABELS.find(l => l.key === addr.label) || ADDRESS_LABELS[2];
            const Icon = labelConfig.icon;
            
            return (
              <motion.div
                key={addr.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-start gap-3 p-3 bg-background rounded-xl"
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${labelConfig.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">{addr.label}</span>
                    {addr.is_default && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-accent/10 text-accent font-medium">
                        {labels.default}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">
                    {addr.address}, {addr.zip_code} {addr.city}
                  </p>
                  {addr.apartment_floor && (
                    <p className="text-xs text-muted-foreground">{addr.apartment_floor}</p>
                  )}
                </div>
                
                <div className="flex items-center gap-1 shrink-0">
                  {!addr.is_default && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleSetDefault(addr.id)}
                      className="h-8 w-8"
                    >
                      <Check className="w-4 h-4 text-muted-foreground" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => startEdit(addr)}
                    className="h-8 w-8"
                  >
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(addr.id)}
                    className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Add/Edit Form */}
      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="p-4 bg-secondary/30 rounded-xl space-y-4 border border-border/50">
              {/* Label Selection */}
              <div className="flex gap-2">
                {ADDRESS_LABELS.map((label) => {
                  const Icon = label.icon;
                  const isSelected = formData.label === label.key;
                  
                  return (
                    <button
                      key={label.key}
                      onClick={() => setFormData({ ...formData, label: label.key })}
                      className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg border transition-all ${
                        isSelected 
                          ? 'border-accent bg-accent/10 text-foreground' 
                          : 'border-border/50 text-muted-foreground hover:border-accent/50'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm font-medium">{label.key}</span>
                    </button>
                  );
                })}
              </div>

              {/* Address Fields */}
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">{labels.address} *</Label>
                  <Input
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Via Roma 123"
                    className="bg-background mt-1"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs text-muted-foreground">{labels.city} *</Label>
                    <Input
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      placeholder="Milano"
                      className="bg-background mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">{labels.zipCode} *</Label>
                    <Input
                      value={formData.zip_code}
                      onChange={(e) => setFormData({ ...formData, zip_code: e.target.value })}
                      placeholder="20100"
                      className="bg-background mt-1"
                    />
                  </div>
                </div>
                
                <div>
                  <Label className="text-xs text-muted-foreground">{labels.floor}</Label>
                  <Input
                    value={formData.apartment_floor}
                    onChange={(e) => setFormData({ ...formData, apartment_floor: e.target.value })}
                    placeholder="Piano 2, Interno 5"
                    className="bg-background mt-1"
                  />
                </div>
                
                <div>
                  <Label className="text-xs text-muted-foreground">{labels.notes}</Label>
                  <Input
                    value={formData.delivery_notes}
                    onChange={(e) => setFormData({ ...formData, delivery_notes: e.target.value })}
                    placeholder="Citofono, istruzioni..."
                    className="bg-background mt-1"
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={resetForm}
                  className="flex-1"
                >
                  {labels.cancel}
                </Button>
                <Button
                  onClick={handleSave}
                  className="flex-1"
                >
                  {labels.save}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Add Button */}
      {!isAdding && addresses.length < 3 && (
        <Button
          variant="outline"
          onClick={() => setIsAdding(true)}
          className="w-full gap-2"
        >
          <Plus className="w-4 h-4" />
          {labels.addNew}
        </Button>
      )}
    </div>
  );
}
