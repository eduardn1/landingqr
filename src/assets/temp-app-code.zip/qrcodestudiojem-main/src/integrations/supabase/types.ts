export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      action_buttons: {
        Row: {
          action_type: string
          action_value: string | null
          bg_color: string | null
          bg_opacity: number | null
          border_color: string | null
          button_color: string | null
          button_key: string
          col_span: number
          created_at: string
          display_order: number
          display_style: string | null
          gradient: string | null
          icon: string
          icon_color: string | null
          id: string
          is_active: boolean
          is_visible_desktop: boolean
          is_visible_mobile: boolean
          label: Json
          label_color: string | null
          size: string
          subtitle: Json | null
          updated_at: string
        }
        Insert: {
          action_type?: string
          action_value?: string | null
          bg_color?: string | null
          bg_opacity?: number | null
          border_color?: string | null
          button_color?: string | null
          button_key: string
          col_span?: number
          created_at?: string
          display_order?: number
          display_style?: string | null
          gradient?: string | null
          icon?: string
          icon_color?: string | null
          id?: string
          is_active?: boolean
          is_visible_desktop?: boolean
          is_visible_mobile?: boolean
          label?: Json
          label_color?: string | null
          size?: string
          subtitle?: Json | null
          updated_at?: string
        }
        Update: {
          action_type?: string
          action_value?: string | null
          bg_color?: string | null
          bg_opacity?: number | null
          border_color?: string | null
          button_color?: string | null
          button_key?: string
          col_span?: number
          created_at?: string
          display_order?: number
          display_style?: string | null
          gradient?: string | null
          icon?: string
          icon_color?: string | null
          id?: string
          is_active?: boolean
          is_visible_desktop?: boolean
          is_visible_mobile?: boolean
          label?: Json
          label_color?: string | null
          size?: string
          subtitle?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      active_template_config: {
        Row: {
          created_at: string | null
          footer_variant: string | null
          header_variant: string | null
          homepage_custom_config: Json | null
          homepage_template_key: string | null
          id: string
          onboarding_custom_config: Json | null
          onboarding_template_key: string | null
          takeaway_custom_config: Json | null
          takeaway_template_key: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          footer_variant?: string | null
          header_variant?: string | null
          homepage_custom_config?: Json | null
          homepage_template_key?: string | null
          id?: string
          onboarding_custom_config?: Json | null
          onboarding_template_key?: string | null
          takeaway_custom_config?: Json | null
          takeaway_template_key?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          footer_variant?: string | null
          header_variant?: string | null
          homepage_custom_config?: Json | null
          homepage_template_key?: string | null
          id?: string
          onboarding_custom_config?: Json | null
          onboarding_template_key?: string | null
          takeaway_custom_config?: Json | null
          takeaway_template_key?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      admin_users: {
        Row: {
          created_at: string
          id: string
          role: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      allergens: {
        Row: {
          code: string
          color: string
          icon: string
          name_de: string | null
          name_en: string
          name_es: string | null
          name_fr: string | null
          name_it: string
        }
        Insert: {
          code: string
          color?: string
          icon: string
          name_de?: string | null
          name_en: string
          name_es?: string | null
          name_fr?: string | null
          name_it: string
        }
        Update: {
          code?: string
          color?: string
          icon?: string
          name_de?: string | null
          name_en?: string
          name_es?: string | null
          name_fr?: string | null
          name_it?: string
        }
        Relationships: []
      }
      broadcast_messages: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          message: string
          recipients_count: number | null
          sent_at: string | null
          status: string | null
          template_id: string | null
          title: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          message: string
          recipients_count?: number | null
          sent_at?: string | null
          status?: string | null
          template_id?: string | null
          title: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          message?: string
          recipients_count?: number | null
          sent_at?: string | null
          status?: string | null
          template_id?: string | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "broadcast_messages_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          created_at: string
          description_de: string | null
          description_en: string | null
          description_es: string | null
          description_fr: string | null
          description_it: string | null
          display_order: number
          icon: string
          id: string
          image_url: string | null
          is_active: boolean
          is_featured: boolean
          name_de: string | null
          name_en: string
          name_es: string | null
          name_fr: string | null
          name_it: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          icon?: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          is_featured?: boolean
          name_de?: string | null
          name_en: string
          name_es?: string | null
          name_fr?: string | null
          name_it: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          icon?: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          is_featured?: boolean
          name_de?: string | null
          name_en?: string
          name_es?: string | null
          name_fr?: string | null
          name_it?: string
          updated_at?: string
        }
        Relationships: []
      }
      closed_dates: {
        Row: {
          created_at: string
          date: string
          id: string
          is_recurring: boolean | null
          reason: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          date: string
          id?: string
          is_recurring?: boolean | null
          reason?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          date?: string
          id?: string
          is_recurring?: boolean | null
          reason?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      daily_promos: {
        Row: {
          applies_to: string
          category_ids: string[] | null
          created_at: string | null
          current_uses: number | null
          days_of_week: number[] | null
          description: Json | null
          discount_type: string
          discount_value: number | null
          dish_ids: string[] | null
          exclude_discounted_items: boolean | null
          free_dish_id: string | null
          id: string
          image_url: string | null
          is_active: boolean | null
          max_uses: number | null
          max_uses_per_user: number | null
          minimum_order: number | null
          promo_code: string | null
          title: Json
          updated_at: string | null
          valid_from: string
          valid_until: string
        }
        Insert: {
          applies_to: string
          category_ids?: string[] | null
          created_at?: string | null
          current_uses?: number | null
          days_of_week?: number[] | null
          description?: Json | null
          discount_type: string
          discount_value?: number | null
          dish_ids?: string[] | null
          exclude_discounted_items?: boolean | null
          free_dish_id?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          max_uses?: number | null
          max_uses_per_user?: number | null
          minimum_order?: number | null
          promo_code?: string | null
          title?: Json
          updated_at?: string | null
          valid_from: string
          valid_until: string
        }
        Update: {
          applies_to?: string
          category_ids?: string[] | null
          created_at?: string | null
          current_uses?: number | null
          days_of_week?: number[] | null
          description?: Json | null
          discount_type?: string
          discount_value?: number | null
          dish_ids?: string[] | null
          exclude_discounted_items?: boolean | null
          free_dish_id?: string | null
          id?: string
          image_url?: string | null
          is_active?: boolean | null
          max_uses?: number | null
          max_uses_per_user?: number | null
          minimum_order?: number | null
          promo_code?: string | null
          title?: Json
          updated_at?: string | null
          valid_from?: string
          valid_until?: string
        }
        Relationships: [
          {
            foreignKeyName: "daily_promos_free_dish_id_fkey"
            columns: ["free_dish_id"]
            isOneToOne: false
            referencedRelation: "dishes"
            referencedColumns: ["id"]
          },
        ]
      }
      delivery_addresses: {
        Row: {
          address: string
          apartment_floor: string | null
          city: string
          created_at: string
          delivery_notes: string | null
          id: string
          is_default: boolean
          label: string
          updated_at: string
          user_id: string
          zip_code: string
        }
        Insert: {
          address: string
          apartment_floor?: string | null
          city: string
          created_at?: string
          delivery_notes?: string | null
          id?: string
          is_default?: boolean
          label?: string
          updated_at?: string
          user_id: string
          zip_code: string
        }
        Update: {
          address?: string
          apartment_floor?: string | null
          city?: string
          created_at?: string
          delivery_notes?: string | null
          id?: string
          is_default?: boolean
          label?: string
          updated_at?: string
          user_id?: string
          zip_code?: string
        }
        Relationships: []
      }
      delivery_zones: {
        Row: {
          available_hours: Json | null
          created_at: string | null
          delivery_fee: number
          description: string | null
          estimated_minutes: number
          id: string
          is_active: boolean | null
          minimum_order: number | null
          name: string
          updated_at: string | null
          zip_codes: string[]
        }
        Insert: {
          available_hours?: Json | null
          created_at?: string | null
          delivery_fee?: number
          description?: string | null
          estimated_minutes?: number
          id?: string
          is_active?: boolean | null
          minimum_order?: number | null
          name: string
          updated_at?: string | null
          zip_codes?: string[]
        }
        Update: {
          available_hours?: Json | null
          created_at?: string | null
          delivery_fee?: number
          description?: string | null
          estimated_minutes?: number
          id?: string
          is_active?: boolean | null
          minimum_order?: number | null
          name?: string
          updated_at?: string | null
          zip_codes?: string[]
        }
        Relationships: []
      }
      design_templates: {
        Row: {
          best_for: string[] | null
          created_at: string | null
          design_config: Json
          difficulty_level: string | null
          display_order: number | null
          features: Json | null
          id: string
          is_active: boolean | null
          is_premium: boolean | null
          preview_image_url: string | null
          tags: string[] | null
          template_description: Json | null
          template_key: string
          template_name: Json
          template_type: string
          updated_at: string | null
        }
        Insert: {
          best_for?: string[] | null
          created_at?: string | null
          design_config?: Json
          difficulty_level?: string | null
          display_order?: number | null
          features?: Json | null
          id?: string
          is_active?: boolean | null
          is_premium?: boolean | null
          preview_image_url?: string | null
          tags?: string[] | null
          template_description?: Json | null
          template_key: string
          template_name?: Json
          template_type: string
          updated_at?: string | null
        }
        Update: {
          best_for?: string[] | null
          created_at?: string | null
          design_config?: Json
          difficulty_level?: string | null
          display_order?: number | null
          features?: Json | null
          id?: string
          is_active?: boolean | null
          is_premium?: boolean | null
          preview_image_url?: string | null
          tags?: string[] | null
          template_description?: Json | null
          template_key?: string
          template_name?: Json
          template_type?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      dish_allergens: {
        Row: {
          allergen_code: string
          dish_id: string
        }
        Insert: {
          allergen_code: string
          dish_id: string
        }
        Update: {
          allergen_code?: string
          dish_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "dish_allergens_allergen_code_fkey"
            columns: ["allergen_code"]
            isOneToOne: false
            referencedRelation: "allergens"
            referencedColumns: ["code"]
          },
          {
            foreignKeyName: "dish_allergens_dish_id_fkey"
            columns: ["dish_id"]
            isOneToOne: false
            referencedRelation: "dishes"
            referencedColumns: ["id"]
          },
        ]
      }
      dishes: {
        Row: {
          alcohol_level: string | null
          available_for_delivery: boolean | null
          available_for_takeaway: boolean | null
          badge: string | null
          category_id: string
          created_at: string
          currency: string
          description_de: string | null
          description_en: string | null
          description_es: string | null
          description_fr: string | null
          description_it: string | null
          display_order: number
          extras: Json | null
          has_extras: boolean | null
          id: string
          image_url: string | null
          ingredients_de: string | null
          ingredients_en: string | null
          ingredients_es: string | null
          ingredients_fr: string | null
          ingredients_it: string | null
          is_available: boolean
          is_featured: boolean
          is_seasonal: boolean
          name_de: string | null
          name_en: string
          name_es: string | null
          name_fr: string | null
          name_it: string
          original_price: number | null
          portion_size: string | null
          price: number
          size_variants: Json | null
          spicy_level: number | null
          tags: string[] | null
          takeaway_prep_time: number | null
          takeaway_price: number | null
          updated_at: string
          wine_pairing_de: string | null
          wine_pairing_en: string | null
          wine_pairing_es: string | null
          wine_pairing_fr: string | null
          wine_pairing_it: string | null
          wine_region: string | null
          wine_year: number | null
        }
        Insert: {
          alcohol_level?: string | null
          available_for_delivery?: boolean | null
          available_for_takeaway?: boolean | null
          badge?: string | null
          category_id: string
          created_at?: string
          currency?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          extras?: Json | null
          has_extras?: boolean | null
          id?: string
          image_url?: string | null
          ingredients_de?: string | null
          ingredients_en?: string | null
          ingredients_es?: string | null
          ingredients_fr?: string | null
          ingredients_it?: string | null
          is_available?: boolean
          is_featured?: boolean
          is_seasonal?: boolean
          name_de?: string | null
          name_en: string
          name_es?: string | null
          name_fr?: string | null
          name_it: string
          original_price?: number | null
          portion_size?: string | null
          price: number
          size_variants?: Json | null
          spicy_level?: number | null
          tags?: string[] | null
          takeaway_prep_time?: number | null
          takeaway_price?: number | null
          updated_at?: string
          wine_pairing_de?: string | null
          wine_pairing_en?: string | null
          wine_pairing_es?: string | null
          wine_pairing_fr?: string | null
          wine_pairing_it?: string | null
          wine_region?: string | null
          wine_year?: number | null
        }
        Update: {
          alcohol_level?: string | null
          available_for_delivery?: boolean | null
          available_for_takeaway?: boolean | null
          badge?: string | null
          category_id?: string
          created_at?: string
          currency?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          extras?: Json | null
          has_extras?: boolean | null
          id?: string
          image_url?: string | null
          ingredients_de?: string | null
          ingredients_en?: string | null
          ingredients_es?: string | null
          ingredients_fr?: string | null
          ingredients_it?: string | null
          is_available?: boolean
          is_featured?: boolean
          is_seasonal?: boolean
          name_de?: string | null
          name_en?: string
          name_es?: string | null
          name_fr?: string | null
          name_it?: string
          original_price?: number | null
          portion_size?: string | null
          price?: number
          size_variants?: Json | null
          spicy_level?: number | null
          tags?: string[] | null
          takeaway_prep_time?: number | null
          takeaway_price?: number | null
          updated_at?: string
          wine_pairing_de?: string | null
          wine_pairing_en?: string | null
          wine_pairing_es?: string | null
          wine_pairing_fr?: string | null
          wine_pairing_it?: string | null
          wine_region?: string | null
          wine_year?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "dishes_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          created_at: string
          description_de: string | null
          description_en: string | null
          description_es: string | null
          description_fr: string | null
          description_it: string | null
          end_time: string | null
          entry_price: number | null
          entry_price_note_de: string | null
          entry_price_note_en: string | null
          entry_price_note_es: string | null
          entry_price_note_fr: string | null
          entry_price_note_it: string | null
          event_date: string
          event_type: string
          id: string
          image_url: string | null
          is_active: boolean
          is_featured: boolean
          start_time: string
          title_de: string | null
          title_en: string | null
          title_es: string | null
          title_fr: string | null
          title_it: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          end_time?: string | null
          entry_price?: number | null
          entry_price_note_de?: string | null
          entry_price_note_en?: string | null
          entry_price_note_es?: string | null
          entry_price_note_fr?: string | null
          entry_price_note_it?: string | null
          event_date: string
          event_type?: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          is_featured?: boolean
          start_time: string
          title_de?: string | null
          title_en?: string | null
          title_es?: string | null
          title_fr?: string | null
          title_it: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          end_time?: string | null
          entry_price?: number | null
          entry_price_note_de?: string | null
          entry_price_note_en?: string | null
          entry_price_note_es?: string | null
          entry_price_note_fr?: string | null
          entry_price_note_it?: string | null
          event_date?: string
          event_type?: string
          id?: string
          image_url?: string | null
          is_active?: boolean
          is_featured?: boolean
          start_time?: string
          title_de?: string | null
          title_en?: string | null
          title_es?: string | null
          title_fr?: string | null
          title_it?: string
          updated_at?: string
        }
        Relationships: []
      }
      favorites: {
        Row: {
          created_at: string
          dish_id: string
          id: string
          source: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          dish_id: string
          id?: string
          source?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          dish_id?: string
          id?: string
          source?: string | null
          user_id?: string
        }
        Relationships: []
      }
      home_sections: {
        Row: {
          config: Json | null
          created_at: string
          display_order: number
          id: string
          is_active: boolean
          section_key: string
          subtitle: Json | null
          title: Json | null
          updated_at: string
        }
        Insert: {
          config?: Json | null
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          section_key: string
          subtitle?: Json | null
          title?: Json | null
          updated_at?: string
        }
        Update: {
          config?: Json | null
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          section_key?: string
          subtitle?: Json | null
          title?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      loyalty_badges: {
        Row: {
          badge_key: string
          category: string
          color: string | null
          created_at: string
          description_de: string | null
          description_en: string | null
          description_es: string | null
          description_fr: string | null
          description_it: string | null
          display_order: number
          icon: string
          id: string
          is_active: boolean
          is_secret: boolean | null
          name_de: string | null
          name_en: string | null
          name_es: string | null
          name_fr: string | null
          name_it: string
          points_reward: number | null
          requirement_type: string
          requirement_value: number
          updated_at: string
        }
        Insert: {
          badge_key: string
          category?: string
          color?: string | null
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          icon?: string
          id?: string
          is_active?: boolean
          is_secret?: boolean | null
          name_de?: string | null
          name_en?: string | null
          name_es?: string | null
          name_fr?: string | null
          name_it: string
          points_reward?: number | null
          requirement_type?: string
          requirement_value?: number
          updated_at?: string
        }
        Update: {
          badge_key?: string
          category?: string
          color?: string | null
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          icon?: string
          id?: string
          is_active?: boolean
          is_secret?: boolean | null
          name_de?: string | null
          name_en?: string | null
          name_es?: string | null
          name_fr?: string | null
          name_it?: string
          points_reward?: number | null
          requirement_type?: string
          requirement_value?: number
          updated_at?: string
        }
        Relationships: []
      }
      loyalty_challenges: {
        Row: {
          challenge_key: string
          challenge_type: string
          color: string | null
          created_at: string
          description_de: string | null
          description_en: string | null
          description_es: string | null
          description_fr: string | null
          description_it: string | null
          display_order: number
          expires_at: string | null
          icon: string
          id: string
          is_active: boolean
          name_de: string | null
          name_en: string | null
          name_es: string | null
          name_fr: string | null
          name_it: string
          points_reward: number
          requirement_type: string
          requirement_value: number
          starts_at: string | null
          updated_at: string
        }
        Insert: {
          challenge_key: string
          challenge_type?: string
          color?: string | null
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          expires_at?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          name_de?: string | null
          name_en?: string | null
          name_es?: string | null
          name_fr?: string | null
          name_it: string
          points_reward?: number
          requirement_type?: string
          requirement_value?: number
          starts_at?: string | null
          updated_at?: string
        }
        Update: {
          challenge_key?: string
          challenge_type?: string
          color?: string | null
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          expires_at?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          name_de?: string | null
          name_en?: string | null
          name_es?: string | null
          name_fr?: string | null
          name_it?: string
          points_reward?: number
          requirement_type?: string
          requirement_value?: number
          starts_at?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      loyalty_config: {
        Row: {
          created_at: string
          daily_login_bonus: number | null
          id: string
          is_active: boolean
          points_per_guest: number
          points_per_reservation: number
          streak_bonus_multiplier: number | null
          updated_at: string
          welcome_bonus: number
        }
        Insert: {
          created_at?: string
          daily_login_bonus?: number | null
          id?: string
          is_active?: boolean
          points_per_guest?: number
          points_per_reservation?: number
          streak_bonus_multiplier?: number | null
          updated_at?: string
          welcome_bonus?: number
        }
        Update: {
          created_at?: string
          daily_login_bonus?: number | null
          id?: string
          is_active?: boolean
          points_per_guest?: number
          points_per_reservation?: number
          streak_bonus_multiplier?: number | null
          updated_at?: string
          welcome_bonus?: number
        }
        Relationships: []
      }
      loyalty_points: {
        Row: {
          created_at: string
          id: string
          level: number
          lifetime_points: number
          tier: string
          total_points: number
          updated_at: string
          user_id: string
          xp_current: number
          xp_to_next_level: number
        }
        Insert: {
          created_at?: string
          id?: string
          level?: number
          lifetime_points?: number
          tier?: string
          total_points?: number
          updated_at?: string
          user_id: string
          xp_current?: number
          xp_to_next_level?: number
        }
        Update: {
          created_at?: string
          id?: string
          level?: number
          lifetime_points?: number
          tier?: string
          total_points?: number
          updated_at?: string
          user_id?: string
          xp_current?: number
          xp_to_next_level?: number
        }
        Relationships: []
      }
      loyalty_rewards: {
        Row: {
          created_at: string
          description_de: string | null
          description_en: string | null
          description_es: string | null
          description_fr: string | null
          description_it: string | null
          display_order: number
          id: string
          image_url: string | null
          is_active: boolean
          name_de: string | null
          name_en: string | null
          name_es: string | null
          name_fr: string | null
          name_it: string
          points_required: number
          reward_type: string
          reward_value: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          id?: string
          image_url?: string | null
          is_active?: boolean
          name_de?: string | null
          name_en?: string | null
          name_es?: string | null
          name_fr?: string | null
          name_it: string
          points_required: number
          reward_type?: string
          reward_value?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          id?: string
          image_url?: string | null
          is_active?: boolean
          name_de?: string | null
          name_en?: string | null
          name_es?: string | null
          name_fr?: string | null
          name_it?: string
          points_required?: number
          reward_type?: string
          reward_value?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      loyalty_streaks: {
        Row: {
          created_at: string
          current_streak: number
          id: string
          last_activity_date: string | null
          longest_streak: number
          streak_type: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          current_streak?: number
          id?: string
          last_activity_date?: string | null
          longest_streak?: number
          streak_type?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          current_streak?: number
          id?: string
          last_activity_date?: string | null
          longest_streak?: number
          streak_type?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      loyalty_transactions: {
        Row: {
          created_at: string
          description: string | null
          id: string
          points: number
          reservation_id: string | null
          reward_id: string | null
          takeaway_order_id: string | null
          transaction_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          points: number
          reservation_id?: string | null
          reward_id?: string | null
          takeaway_order_id?: string | null
          transaction_type: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          points?: number
          reservation_id?: string | null
          reward_id?: string | null
          takeaway_order_id?: string | null
          transaction_type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "loyalty_transactions_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "loyalty_transactions_reward_id_fkey"
            columns: ["reward_id"]
            isOneToOne: false
            referencedRelation: "loyalty_rewards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "loyalty_transactions_takeaway_order_id_fkey"
            columns: ["takeaway_order_id"]
            isOneToOne: false
            referencedRelation: "takeaway_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      moods: {
        Row: {
          created_at: string
          display_order: number
          emoji: string
          filters: Json | null
          gradient: string | null
          id: string
          is_active: boolean
          label: Json
          mood_key: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          emoji?: string
          filters?: Json | null
          gradient?: string | null
          id?: string
          is_active?: boolean
          label?: Json
          mood_key: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          emoji?: string
          filters?: Json | null
          gradient?: string | null
          id?: string
          is_active?: boolean
          label?: Json
          mood_key?: string
          updated_at?: string
        }
        Relationships: []
      }
      navigation_config: {
        Row: {
          available_languages: Json
          created_at: string
          default_language: string
          header_favorites_visible: boolean
          header_favorites_visible_desktop: boolean | null
          header_favorites_visible_mobile: boolean | null
          header_favorites_visible_tablet: boolean | null
          header_language_switcher_visible: boolean
          header_language_visible_desktop: boolean | null
          header_language_visible_mobile: boolean | null
          header_language_visible_tablet: boolean | null
          header_logo_visible: boolean
          header_logo_visible_desktop: boolean | null
          header_logo_visible_mobile: boolean | null
          header_logo_visible_tablet: boolean | null
          header_menu_items: Json | null
          header_notifications_visible_desktop: boolean | null
          header_notifications_visible_mobile: boolean | null
          header_notifications_visible_tablet: boolean | null
          header_profile_visible: boolean
          header_profile_visible_desktop: boolean | null
          header_profile_visible_mobile: boolean | null
          header_profile_visible_tablet: boolean | null
          header_theme_toggle_visible: boolean
          header_theme_visible_desktop: boolean | null
          header_theme_visible_mobile: boolean | null
          header_theme_visible_tablet: boolean | null
          id: string
          navbar_items: Json
          updated_at: string
        }
        Insert: {
          available_languages?: Json
          created_at?: string
          default_language?: string
          header_favorites_visible?: boolean
          header_favorites_visible_desktop?: boolean | null
          header_favorites_visible_mobile?: boolean | null
          header_favorites_visible_tablet?: boolean | null
          header_language_switcher_visible?: boolean
          header_language_visible_desktop?: boolean | null
          header_language_visible_mobile?: boolean | null
          header_language_visible_tablet?: boolean | null
          header_logo_visible?: boolean
          header_logo_visible_desktop?: boolean | null
          header_logo_visible_mobile?: boolean | null
          header_logo_visible_tablet?: boolean | null
          header_menu_items?: Json | null
          header_notifications_visible_desktop?: boolean | null
          header_notifications_visible_mobile?: boolean | null
          header_notifications_visible_tablet?: boolean | null
          header_profile_visible?: boolean
          header_profile_visible_desktop?: boolean | null
          header_profile_visible_mobile?: boolean | null
          header_profile_visible_tablet?: boolean | null
          header_theme_toggle_visible?: boolean
          header_theme_visible_desktop?: boolean | null
          header_theme_visible_mobile?: boolean | null
          header_theme_visible_tablet?: boolean | null
          id?: string
          navbar_items?: Json
          updated_at?: string
        }
        Update: {
          available_languages?: Json
          created_at?: string
          default_language?: string
          header_favorites_visible?: boolean
          header_favorites_visible_desktop?: boolean | null
          header_favorites_visible_mobile?: boolean | null
          header_favorites_visible_tablet?: boolean | null
          header_language_switcher_visible?: boolean
          header_language_visible_desktop?: boolean | null
          header_language_visible_mobile?: boolean | null
          header_language_visible_tablet?: boolean | null
          header_logo_visible?: boolean
          header_logo_visible_desktop?: boolean | null
          header_logo_visible_mobile?: boolean | null
          header_logo_visible_tablet?: boolean | null
          header_menu_items?: Json | null
          header_notifications_visible_desktop?: boolean | null
          header_notifications_visible_mobile?: boolean | null
          header_notifications_visible_tablet?: boolean | null
          header_profile_visible?: boolean
          header_profile_visible_desktop?: boolean | null
          header_profile_visible_mobile?: boolean | null
          header_profile_visible_tablet?: boolean | null
          header_theme_toggle_visible?: boolean
          header_theme_visible_desktop?: boolean | null
          header_theme_visible_mobile?: boolean | null
          header_theme_visible_tablet?: boolean | null
          id?: string
          navbar_items?: Json
          updated_at?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          action_url: string | null
          body: string
          created_at: string
          id: string
          is_read: boolean
          metadata: Json | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          action_url?: string | null
          body: string
          created_at?: string
          id?: string
          is_read?: boolean
          metadata?: Json | null
          title: string
          type?: string
          user_id: string
        }
        Update: {
          action_url?: string | null
          body?: string
          created_at?: string
          id?: string
          is_read?: boolean
          metadata?: Json | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      onboarding_actions: {
        Row: {
          action_key: string
          action_type: string
          action_value: string
          created_at: string
          display_order: number
          gradient: string | null
          icon: string
          id: string
          is_active: boolean
          label: Json
          subtitle: Json | null
          updated_at: string
        }
        Insert: {
          action_key: string
          action_type?: string
          action_value?: string
          created_at?: string
          display_order?: number
          gradient?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          label?: Json
          subtitle?: Json | null
          updated_at?: string
        }
        Update: {
          action_key?: string
          action_type?: string
          action_value?: string
          created_at?: string
          display_order?: number
          gradient?: string | null
          icon?: string
          id?: string
          is_active?: boolean
          label?: Json
          subtitle?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      onboarding_steps: {
        Row: {
          created_at: string
          display_order: number
          id: string
          is_active: boolean
          is_optional: boolean
          options: Json
          question: Json
          skip_button_text: Json | null
          step_key: string
          subtext: Json | null
          tip: Json | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          is_optional?: boolean
          options?: Json
          question?: Json
          skip_button_text?: Json | null
          step_key: string
          subtext?: Json | null
          tip?: Json | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          id?: string
          is_active?: boolean
          is_optional?: boolean
          options?: Json
          question?: Json
          skip_button_text?: Json | null
          step_key?: string
          subtext?: Json | null
          tip?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      order_ratings: {
        Row: {
          comment: string | null
          created_at: string | null
          delivery_rating: number | null
          driver_rating: number | null
          food_rating: number | null
          id: string
          order_id: string | null
          overall_rating: number | null
          responded_at: string | null
          responded_by: string | null
          response_text: string | null
          user_id: string | null
        }
        Insert: {
          comment?: string | null
          created_at?: string | null
          delivery_rating?: number | null
          driver_rating?: number | null
          food_rating?: number | null
          id?: string
          order_id?: string | null
          overall_rating?: number | null
          responded_at?: string | null
          responded_by?: string | null
          response_text?: string | null
          user_id?: string | null
        }
        Update: {
          comment?: string | null
          created_at?: string | null
          delivery_rating?: number | null
          driver_rating?: number | null
          food_rating?: number | null
          id?: string
          order_id?: string | null
          overall_rating?: number | null
          responded_at?: string | null
          responded_by?: string | null
          response_text?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "order_ratings_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "takeaway_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      password_reset_tokens: {
        Row: {
          created_at: string
          expires_at: string
          id: string
          phone: string
          token: string
          used_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at: string
          id?: string
          phone: string
          token: string
          used_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          id?: string
          phone?: string
          token?: string
          used_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          address: string | null
          apartment_floor: string | null
          avatar_emoji: string | null
          city: string | null
          created_at: string
          delivery_notes: string | null
          display_name: string | null
          id: string
          phone: string
          preferred_theme: string | null
          push_notifications: boolean | null
          updated_at: string
          user_id: string
          whatsapp_notifications: boolean | null
          zip_code: string | null
        }
        Insert: {
          address?: string | null
          apartment_floor?: string | null
          avatar_emoji?: string | null
          city?: string | null
          created_at?: string
          delivery_notes?: string | null
          display_name?: string | null
          id?: string
          phone: string
          preferred_theme?: string | null
          push_notifications?: boolean | null
          updated_at?: string
          user_id: string
          whatsapp_notifications?: boolean | null
          zip_code?: string | null
        }
        Update: {
          address?: string | null
          apartment_floor?: string | null
          avatar_emoji?: string | null
          city?: string | null
          created_at?: string
          delivery_notes?: string | null
          display_name?: string | null
          id?: string
          phone?: string
          preferred_theme?: string | null
          push_notifications?: boolean | null
          updated_at?: string
          user_id?: string
          whatsapp_notifications?: boolean | null
          zip_code?: string | null
        }
        Relationships: []
      }
      promos: {
        Row: {
          created_at: string
          description_de: string | null
          description_en: string | null
          description_es: string | null
          description_fr: string | null
          description_it: string | null
          display_order: number
          expires_at: string | null
          id: string
          image_url: string
          is_active: boolean
          link_type: string | null
          link_url: string | null
          starts_at: string | null
          title_de: string | null
          title_en: string | null
          title_es: string | null
          title_fr: string | null
          title_it: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          expires_at?: string | null
          id?: string
          image_url: string
          is_active?: boolean
          link_type?: string | null
          link_url?: string | null
          starts_at?: string | null
          title_de?: string | null
          title_en?: string | null
          title_es?: string | null
          title_fr?: string | null
          title_it: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description_de?: string | null
          description_en?: string | null
          description_es?: string | null
          description_fr?: string | null
          description_it?: string | null
          display_order?: number
          expires_at?: string | null
          id?: string
          image_url?: string
          is_active?: boolean
          link_type?: string | null
          link_url?: string | null
          starts_at?: string | null
          title_de?: string | null
          title_en?: string | null
          title_es?: string | null
          title_fr?: string | null
          title_it?: string
          updated_at?: string
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth_key: string
          created_at: string
          endpoint: string
          id: string
          p256dh_key: string
          user_id: string
        }
        Insert: {
          auth_key: string
          created_at?: string
          endpoint: string
          id?: string
          p256dh_key: string
          user_id: string
        }
        Update: {
          auth_key?: string
          created_at?: string
          endpoint?: string
          id?: string
          p256dh_key?: string
          user_id?: string
        }
        Relationships: []
      }
      reservations: {
        Row: {
          created_at: string
          email: string | null
          event_id: string | null
          guests: number
          id: string
          name: string
          notes: string | null
          phone: string
          reminder_sent: boolean | null
          reservation_date: string
          reservation_time: string
          status: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          event_id?: string | null
          guests?: number
          id?: string
          name: string
          notes?: string | null
          phone: string
          reminder_sent?: boolean | null
          reservation_date: string
          reservation_time: string
          status?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email?: string | null
          event_id?: string | null
          guests?: number
          id?: string
          name?: string
          notes?: string | null
          phone?: string
          reminder_sent?: boolean | null
          reservation_date?: string
          reservation_time?: string
          status?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reservations_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      restaurant_config: {
        Row: {
          about_gallery: Json | null
          about_keywords: Json | null
          address: string | null
          border_radius: string | null
          business_hours: Json | null
          city: string | null
          color_accent: string | null
          color_background: string | null
          color_foreground: string | null
          color_primary: string | null
          color_secondary: string | null
          country: string | null
          cover_image_url: string | null
          created_at: string
          description: Json | null
          email: string | null
          facebook_url: string | null
          favicon_url: string | null
          features: Json | null
          font_body: string | null
          font_heading: string | null
          google_maps_url: string | null
          google_place_id: string | null
          id: string
          instagram_url: string | null
          instagram_username: string | null
          logo_url: string | null
          max_guests_per_slot: number | null
          menu_view_mode: string | null
          name: string
          onboarding_variant: string | null
          phone: string | null
          placeholder_emoji: string | null
          placeholder_gradient: string | null
          placeholder_image: string | null
          placeholder_type: string | null
          pwa_background_color: string | null
          pwa_description: string | null
          pwa_icon_192: string | null
          pwa_icon_512: string | null
          pwa_name: string | null
          pwa_short_name: string | null
          pwa_theme_color: string | null
          tagline: Json | null
          theme: string | null
          tiktok_url: string | null
          tripadvisor_url: string | null
          updated_at: string
          whatsapp: string | null
        }
        Insert: {
          about_gallery?: Json | null
          about_keywords?: Json | null
          address?: string | null
          border_radius?: string | null
          business_hours?: Json | null
          city?: string | null
          color_accent?: string | null
          color_background?: string | null
          color_foreground?: string | null
          color_primary?: string | null
          color_secondary?: string | null
          country?: string | null
          cover_image_url?: string | null
          created_at?: string
          description?: Json | null
          email?: string | null
          facebook_url?: string | null
          favicon_url?: string | null
          features?: Json | null
          font_body?: string | null
          font_heading?: string | null
          google_maps_url?: string | null
          google_place_id?: string | null
          id?: string
          instagram_url?: string | null
          instagram_username?: string | null
          logo_url?: string | null
          max_guests_per_slot?: number | null
          menu_view_mode?: string | null
          name?: string
          onboarding_variant?: string | null
          phone?: string | null
          placeholder_emoji?: string | null
          placeholder_gradient?: string | null
          placeholder_image?: string | null
          placeholder_type?: string | null
          pwa_background_color?: string | null
          pwa_description?: string | null
          pwa_icon_192?: string | null
          pwa_icon_512?: string | null
          pwa_name?: string | null
          pwa_short_name?: string | null
          pwa_theme_color?: string | null
          tagline?: Json | null
          theme?: string | null
          tiktok_url?: string | null
          tripadvisor_url?: string | null
          updated_at?: string
          whatsapp?: string | null
        }
        Update: {
          about_gallery?: Json | null
          about_keywords?: Json | null
          address?: string | null
          border_radius?: string | null
          business_hours?: Json | null
          city?: string | null
          color_accent?: string | null
          color_background?: string | null
          color_foreground?: string | null
          color_primary?: string | null
          color_secondary?: string | null
          country?: string | null
          cover_image_url?: string | null
          created_at?: string
          description?: Json | null
          email?: string | null
          facebook_url?: string | null
          favicon_url?: string | null
          features?: Json | null
          font_body?: string | null
          font_heading?: string | null
          google_maps_url?: string | null
          google_place_id?: string | null
          id?: string
          instagram_url?: string | null
          instagram_username?: string | null
          logo_url?: string | null
          max_guests_per_slot?: number | null
          menu_view_mode?: string | null
          name?: string
          onboarding_variant?: string | null
          phone?: string | null
          placeholder_emoji?: string | null
          placeholder_gradient?: string | null
          placeholder_image?: string | null
          placeholder_type?: string | null
          pwa_background_color?: string | null
          pwa_description?: string | null
          pwa_icon_192?: string | null
          pwa_icon_512?: string | null
          pwa_name?: string | null
          pwa_short_name?: string | null
          pwa_theme_color?: string | null
          tagline?: Json | null
          theme?: string | null
          tiktok_url?: string | null
          tripadvisor_url?: string | null
          updated_at?: string
          whatsapp?: string | null
        }
        Relationships: []
      }
      seo_settings: {
        Row: {
          canonical_url: string | null
          change_frequency: string | null
          created_at: string | null
          description: Json
          hreflang_urls: Json | null
          id: string
          is_active: boolean | null
          keywords: Json | null
          og_description: Json | null
          og_image_url: string | null
          og_title: Json | null
          og_type: string | null
          page_name: string
          page_slug: string
          priority: number | null
          robots: string | null
          schema_data: Json | null
          title: Json
          twitter_card_type: string | null
          twitter_description: Json | null
          twitter_image_url: string | null
          twitter_title: Json | null
          updated_at: string | null
        }
        Insert: {
          canonical_url?: string | null
          change_frequency?: string | null
          created_at?: string | null
          description?: Json
          hreflang_urls?: Json | null
          id?: string
          is_active?: boolean | null
          keywords?: Json | null
          og_description?: Json | null
          og_image_url?: string | null
          og_title?: Json | null
          og_type?: string | null
          page_name: string
          page_slug: string
          priority?: number | null
          robots?: string | null
          schema_data?: Json | null
          title?: Json
          twitter_card_type?: string | null
          twitter_description?: Json | null
          twitter_image_url?: string | null
          twitter_title?: Json | null
          updated_at?: string | null
        }
        Update: {
          canonical_url?: string | null
          change_frequency?: string | null
          created_at?: string | null
          description?: Json
          hreflang_urls?: Json | null
          id?: string
          is_active?: boolean | null
          keywords?: Json | null
          og_description?: Json | null
          og_image_url?: string | null
          og_title?: Json | null
          og_type?: string | null
          page_name?: string
          page_slug?: string
          priority?: number | null
          robots?: string | null
          schema_data?: Json | null
          title?: Json
          twitter_card_type?: string | null
          twitter_description?: Json | null
          twitter_image_url?: string | null
          twitter_title?: Json | null
          updated_at?: string | null
        }
        Relationships: []
      }
      stories: {
        Row: {
          created_at: string
          display_order: number
          expires_at: string | null
          gradient: string | null
          has_new: boolean | null
          icon: string | null
          id: string
          is_active: boolean
          label: Json
          publish_at: string | null
          slides: Json
          story_key: string
          thumbnail_url: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_order?: number
          expires_at?: string | null
          gradient?: string | null
          has_new?: boolean | null
          icon?: string | null
          id?: string
          is_active?: boolean
          label?: Json
          publish_at?: string | null
          slides?: Json
          story_key: string
          thumbnail_url?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_order?: number
          expires_at?: string | null
          gradient?: string | null
          has_new?: boolean | null
          icon?: string | null
          id?: string
          is_active?: boolean
          label?: Json
          publish_at?: string | null
          slides?: Json
          story_key?: string
          thumbnail_url?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      swipe_interactions: {
        Row: {
          action: string
          created_at: string
          dish_id: string
          id: string
          user_id: string
        }
        Insert: {
          action: string
          created_at?: string
          dish_id: string
          id?: string
          user_id: string
        }
        Update: {
          action?: string
          created_at?: string
          dish_id?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      takeaway_drivers: {
        Row: {
          access_token: string | null
          average_rating: number | null
          created_at: string | null
          current_lat: number | null
          current_lng: number | null
          current_orders_count: number | null
          email: string | null
          emoji: string | null
          id: string
          is_active: boolean | null
          is_online: boolean | null
          last_login_at: string | null
          location_updated_at: string | null
          name: string
          notes: string | null
          phone: string
          photo_url: string | null
          pin_code: string | null
          status: string
          total_deliveries: number | null
          updated_at: string | null
          vehicle_color: string | null
          vehicle_plate: string | null
          vehicle_type: string | null
        }
        Insert: {
          access_token?: string | null
          average_rating?: number | null
          created_at?: string | null
          current_lat?: number | null
          current_lng?: number | null
          current_orders_count?: number | null
          email?: string | null
          emoji?: string | null
          id?: string
          is_active?: boolean | null
          is_online?: boolean | null
          last_login_at?: string | null
          location_updated_at?: string | null
          name: string
          notes?: string | null
          phone: string
          photo_url?: string | null
          pin_code?: string | null
          status?: string
          total_deliveries?: number | null
          updated_at?: string | null
          vehicle_color?: string | null
          vehicle_plate?: string | null
          vehicle_type?: string | null
        }
        Update: {
          access_token?: string | null
          average_rating?: number | null
          created_at?: string | null
          current_lat?: number | null
          current_lng?: number | null
          current_orders_count?: number | null
          email?: string | null
          emoji?: string | null
          id?: string
          is_active?: boolean | null
          is_online?: boolean | null
          last_login_at?: string | null
          location_updated_at?: string | null
          name?: string
          notes?: string | null
          phone?: string
          photo_url?: string | null
          pin_code?: string | null
          status?: string
          total_deliveries?: number | null
          updated_at?: string | null
          vehicle_color?: string | null
          vehicle_plate?: string | null
          vehicle_type?: string | null
        }
        Relationships: []
      }
      takeaway_orders: {
        Row: {
          accepted_at: string | null
          completed_at: string | null
          created_at: string | null
          customer_email: string | null
          customer_name: string
          customer_phone: string
          delivery_actual_time: string | null
          delivery_address: Json | null
          delivery_fee: number | null
          delivery_time_estimate: string | null
          delivery_zone_id: string | null
          discount: number | null
          driver_id: string | null
          driver_lat: number | null
          driver_lng: number | null
          estimated_delivery_at: string | null
          estimated_ready_at: string | null
          id: string
          items: Json
          loyalty_points_earned: number | null
          loyalty_points_used: number | null
          order_number: string | null
          order_type: string
          pickup_actual_time: string | null
          pickup_time: string | null
          preparation_time: number | null
          promo_code: string | null
          rated_at: string | null
          rating: number | null
          rating_comment: string | null
          ready_at: string | null
          special_notes: string | null
          status: string
          subtotal: number
          total: number
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          accepted_at?: string | null
          completed_at?: string | null
          created_at?: string | null
          customer_email?: string | null
          customer_name: string
          customer_phone: string
          delivery_actual_time?: string | null
          delivery_address?: Json | null
          delivery_fee?: number | null
          delivery_time_estimate?: string | null
          delivery_zone_id?: string | null
          discount?: number | null
          driver_id?: string | null
          driver_lat?: number | null
          driver_lng?: number | null
          estimated_delivery_at?: string | null
          estimated_ready_at?: string | null
          id?: string
          items: Json
          loyalty_points_earned?: number | null
          loyalty_points_used?: number | null
          order_number?: string | null
          order_type: string
          pickup_actual_time?: string | null
          pickup_time?: string | null
          preparation_time?: number | null
          promo_code?: string | null
          rated_at?: string | null
          rating?: number | null
          rating_comment?: string | null
          ready_at?: string | null
          special_notes?: string | null
          status?: string
          subtotal: number
          total: number
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          accepted_at?: string | null
          completed_at?: string | null
          created_at?: string | null
          customer_email?: string | null
          customer_name?: string
          customer_phone?: string
          delivery_actual_time?: string | null
          delivery_address?: Json | null
          delivery_fee?: number | null
          delivery_time_estimate?: string | null
          delivery_zone_id?: string | null
          discount?: number | null
          driver_id?: string | null
          driver_lat?: number | null
          driver_lng?: number | null
          estimated_delivery_at?: string | null
          estimated_ready_at?: string | null
          id?: string
          items?: Json
          loyalty_points_earned?: number | null
          loyalty_points_used?: number | null
          order_number?: string | null
          order_type?: string
          pickup_actual_time?: string | null
          pickup_time?: string | null
          preparation_time?: number | null
          promo_code?: string | null
          rated_at?: string | null
          rating?: number | null
          rating_comment?: string | null
          ready_at?: string | null
          special_notes?: string | null
          status?: string
          subtotal?: number
          total?: number
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "takeaway_orders_delivery_zone_id_fkey"
            columns: ["delivery_zone_id"]
            isOneToOne: false
            referencedRelation: "delivery_zones"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "takeaway_orders_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "public_driver_profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "takeaway_orders_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "takeaway_drivers"
            referencedColumns: ["id"]
          },
        ]
      }
      takeaway_settings: {
        Row: {
          accepts_card_on_delivery: boolean | null
          accepts_cash: boolean | null
          accepts_delivery: boolean | null
          accepts_pickup: boolean | null
          auto_accept_orders: boolean | null
          created_at: string | null
          custom_hours: Json | null
          id: string
          is_enabled: boolean | null
          max_concurrent_orders: number | null
          max_daily_orders: number | null
          max_prep_time: number | null
          min_prep_time: number | null
          notification_phone: string | null
          pickup_intervals: number | null
          updated_at: string | null
        }
        Insert: {
          accepts_card_on_delivery?: boolean | null
          accepts_cash?: boolean | null
          accepts_delivery?: boolean | null
          accepts_pickup?: boolean | null
          auto_accept_orders?: boolean | null
          created_at?: string | null
          custom_hours?: Json | null
          id?: string
          is_enabled?: boolean | null
          max_concurrent_orders?: number | null
          max_daily_orders?: number | null
          max_prep_time?: number | null
          min_prep_time?: number | null
          notification_phone?: string | null
          pickup_intervals?: number | null
          updated_at?: string | null
        }
        Update: {
          accepts_card_on_delivery?: boolean | null
          accepts_cash?: boolean | null
          accepts_delivery?: boolean | null
          accepts_pickup?: boolean | null
          auto_accept_orders?: boolean | null
          created_at?: string | null
          custom_hours?: Json | null
          id?: string
          is_enabled?: boolean | null
          max_concurrent_orders?: number | null
          max_daily_orders?: number | null
          max_prep_time?: number | null
          min_prep_time?: number | null
          notification_phone?: string | null
          pickup_intervals?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      user_badges: {
        Row: {
          badge_id: string
          earned_at: string
          id: string
          is_new: boolean | null
          user_id: string
        }
        Insert: {
          badge_id: string
          earned_at?: string
          id?: string
          is_new?: boolean | null
          user_id: string
        }
        Update: {
          badge_id?: string
          earned_at?: string
          id?: string
          is_new?: boolean | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_badges_badge_id_fkey"
            columns: ["badge_id"]
            isOneToOne: false
            referencedRelation: "loyalty_badges"
            referencedColumns: ["id"]
          },
        ]
      }
      user_challenges: {
        Row: {
          challenge_id: string
          completed_at: string | null
          current_progress: number
          id: string
          is_completed: boolean | null
          started_at: string
          user_id: string
        }
        Insert: {
          challenge_id: string
          completed_at?: string | null
          current_progress?: number
          id?: string
          is_completed?: boolean | null
          started_at?: string
          user_id: string
        }
        Update: {
          challenge_id?: string
          completed_at?: string | null
          current_progress?: number
          id?: string
          is_completed?: boolean | null
          started_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_challenges_challenge_id_fkey"
            columns: ["challenge_id"]
            isOneToOne: false
            referencedRelation: "loyalty_challenges"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_message_logs: {
        Row: {
          broadcast_id: string | null
          created_at: string
          created_by: string | null
          delivered_at: string | null
          error_message: string | null
          id: string
          message_content: string
          msg_id: string | null
          recipient_name: string | null
          recipient_phone: string
          reservation_id: string | null
          sent_at: string | null
          status: string
          template_key: string | null
        }
        Insert: {
          broadcast_id?: string | null
          created_at?: string
          created_by?: string | null
          delivered_at?: string | null
          error_message?: string | null
          id?: string
          message_content: string
          msg_id?: string | null
          recipient_name?: string | null
          recipient_phone: string
          reservation_id?: string | null
          sent_at?: string | null
          status?: string
          template_key?: string | null
        }
        Update: {
          broadcast_id?: string | null
          created_at?: string
          created_by?: string | null
          delivered_at?: string | null
          error_message?: string | null
          id?: string
          message_content?: string
          msg_id?: string | null
          recipient_name?: string | null
          recipient_phone?: string
          reservation_id?: string | null
          sent_at?: string | null
          status?: string
          template_key?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_message_logs_broadcast_id_fkey"
            columns: ["broadcast_id"]
            isOneToOne: false
            referencedRelation: "broadcast_messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "whatsapp_message_logs_reservation_id_fkey"
            columns: ["reservation_id"]
            isOneToOne: false
            referencedRelation: "reservations"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_templates: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean | null
          message_template: string
          name: string
          template_key: string
          updated_at: string
          variables: Json | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          message_template: string
          name: string
          template_key: string
          updated_at?: string
          variables?: Json | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean | null
          message_template?: string
          name?: string
          template_key?: string
          updated_at?: string
          variables?: Json | null
        }
        Relationships: []
      }
    }
    Views: {
      public_driver_profiles: {
        Row: {
          average_rating: number | null
          current_orders_count: number | null
          emoji: string | null
          id: string | null
          is_online: boolean | null
          name: string | null
          photo_url: string | null
          vehicle_type: string | null
        }
        Insert: {
          average_rating?: number | null
          current_orders_count?: number | null
          emoji?: string | null
          id?: string | null
          is_online?: boolean | null
          name?: string | null
          photo_url?: string | null
          vehicle_type?: string | null
        }
        Update: {
          average_rating?: number | null
          current_orders_count?: number | null
          emoji?: string | null
          id?: string | null
          is_online?: boolean | null
          name?: string | null
          photo_url?: string | null
          vehicle_type?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      is_admin: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
