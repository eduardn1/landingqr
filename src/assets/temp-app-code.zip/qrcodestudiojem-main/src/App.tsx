import { useEffect, lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { TakeAwayCartProvider } from "@/contexts/TakeAwayCartContext";
import { ThemeProvider } from "next-themes";
import { Skeleton } from "@/components/ui/skeleton";
import { AdminGuard } from "@/components/admin/AdminGuard";
import { useDynamicFavicon } from "@/hooks/useDynamicFavicon";
import { useDynamicManifest } from "@/hooks/useDynamicManifest";
import { useDynamicMeta } from "@/hooks/useDynamicMeta";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { CookieConsent } from "@/components/client/CookieConsent";
import { usePrefetch } from "@/hooks/usePrefetch";

// Lazy load pages for better initial load time
const Index = lazy(() => import("./pages/Index"));
const Auth = lazy(() => import("./pages/Auth"));
const Profile = lazy(() => import("./pages/Profile"));
const Admin = lazy(() => import("./pages/Admin"));
const Quiz = lazy(() => import("./pages/Quiz"));
const Menu = lazy(() => import("./pages/Menu"));
const PrivacyPolicy = lazy(() => import("./pages/PrivacyPolicy"));
const CookiePolicy = lazy(() => import("./pages/CookiePolicy"));
const TakeAway = lazy(() => import("./pages/TakeAway"));
const TakeAwayCheckout = lazy(() => import("./pages/TakeAwayCheckout"));
const TakeAwayOrderConfirmation = lazy(() => import("./pages/TakeAwayOrderConfirmation"));
const Driver = lazy(() => import("./pages/Driver"));
const NotFound = lazy(() => import("./pages/NotFound"));

// Loading fallback component
function PageLoader() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-4">
        <Skeleton className="h-12 w-3/4 mx-auto" />
        <Skeleton className="h-48 w-full" />
        <Skeleton className="h-8 w-full" />
        <Skeleton className="h-8 w-2/3" />
      </div>
    </div>
  );
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Cache for 24 hours
      gcTime: 1000 * 60 * 60 * 24,
      // Stale after 5 minutes
      staleTime: 1000 * 60 * 5,
      // Refetch settings
      refetchOnWindowFocus: false,
      refetchOnReconnect: true,
      retry: 2,
    },
  },
});

// Prefetch hook that runs on app load
function PrefetchOnLoad() {
  const { prefetchHome } = usePrefetch();
  
  useEffect(() => {
    // Prefetch home data immediately on app load
    prefetchHome();
  }, [prefetchHome]);
  
  return null;
}

function AppContent() {
  useDynamicFavicon();
  useDynamicManifest();
  useDynamicMeta();
  
  return (
    <BrowserRouter>
      <PrefetchOnLoad />
      <Suspense fallback={<PageLoader />}>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/quiz" element={<Quiz />} />
          <Route path="/menu" element={<Menu />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="/takeaway" element={<TakeAway />} />
          <Route path="/takeaway/checkout" element={<TakeAwayCheckout />} />
          <Route path="/takeaway/order/:orderId" element={<TakeAwayOrderConfirmation />} />
          <Route path="/driver" element={<Driver />} />
          <Route path="/admin" element={
            <AdminGuard>
              <Admin />
            </AdminGuard>
          } />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
      <CookieConsent onlyAfterOnboarding={true} />
    </BrowserRouter>
  );
}

const App = () => (
  <ErrorBoundary>
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} storageKey="app-theme">
        <LanguageProvider>
          <TakeAwayCartProvider>
            <TooltipProvider>
              <Toaster />
              <Sonner />
              <AppContent />
            </TooltipProvider>
          </TakeAwayCartProvider>
        </LanguageProvider>
      </ThemeProvider>
    </QueryClientProvider>
  </ErrorBoundary>
);

export default App;
