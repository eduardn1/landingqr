/**
 * Utility functions for handling gradient colors
 * Converts Tailwind gradient classes to CSS gradients and extracts colors
 */

// Convert hex to HSL string (space-separated for CSS variables)
export const hexToHsl = (hex: string): string => {
  hex = hex.replace('#', '');
  
  const r = parseInt(hex.slice(0, 2), 16) / 255;
  const g = parseInt(hex.slice(2, 4), 16) / 255;
  const b = parseInt(hex.slice(4, 6), 16) / 255;
  
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;
  
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = ((g - b) / d + (g < b ? 6 : 0)) / 6; break;
      case g: h = ((b - r) / d + 2) / 6; break;
      case b: h = ((r - g) / d + 4) / 6; break;
    }
  }
  
  return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
};

// Check if value is a gradient
export const isGradient = (value: string | null | undefined): boolean => {
  if (!value) return false;
  return value.startsWith('from-') || value.includes('gradient');
};

// Extract all hex colors from gradient string
export const extractColorsFromGradient = (gradient: string): string[] => {
  const hexMatches = gradient.match(/#([a-fA-F0-9]{6})/g);
  return hexMatches || [];
};

// Extract primary color (first color) from gradient
export const extractPrimaryFromGradient = (gradient: string): string | null => {
  const match = gradient.match(/from-\[#([a-fA-F0-9]{6})\]/);
  if (match) {
    return hexToHsl(match[1]);
  }
  
  const hexColors = extractColorsFromGradient(gradient);
  if (hexColors.length > 0) {
    return hexToHsl(hexColors[0].replace('#', ''));
  }
  
  return null;
};

/**
 * Convert Tailwind gradient class to CSS linear-gradient
 * e.g., "from-[#ff4b1f] to-[#1fddff]" → "linear-gradient(to right, #ff4b1f, #1fddff)"
 * e.g., "from-[#ff4b1f] via-[#ff8c00] to-[#1fddff]" → "linear-gradient(to right, #ff4b1f, #ff8c00, #1fddff)"
 */
export const tailwindGradientToCss = (gradient: string, direction: string = 'to right'): string | null => {
  if (!gradient || !isGradient(gradient)) return null;
  
  const colors: string[] = [];
  
  // Extract from color
  const fromMatch = gradient.match(/from-\[#([a-fA-F0-9]{6})\]/);
  if (fromMatch) {
    colors.push(`#${fromMatch[1]}`);
  }
  
  // Extract via color (optional middle color)
  const viaMatch = gradient.match(/via-\[#([a-fA-F0-9]{6})\]/);
  if (viaMatch) {
    colors.push(`#${viaMatch[1]}`);
  }
  
  // Extract to color
  const toMatch = gradient.match(/to-\[#([a-fA-F0-9]{6})\]/);
  if (toMatch) {
    colors.push(`#${toMatch[1]}`);
  }
  
  if (colors.length < 2) return null;
  
  return `linear-gradient(${direction}, ${colors.join(', ')})`;
};

/**
 * Get CSS style object for gradient or solid color background
 */
export const getAccentBackgroundStyle = (
  colorAccent: string | null | undefined,
  options: { opacity?: number; direction?: string } = {}
): React.CSSProperties => {
  const { opacity = 1, direction = 'to right' } = options;
  
  if (!colorAccent) {
    return { backgroundColor: `hsl(var(--accent) / ${opacity})` };
  }
  
  if (isGradient(colorAccent)) {
    const cssGradient = tailwindGradientToCss(colorAccent, direction);
    if (cssGradient) {
      if (opacity < 1) {
        // For opacity, we need to use a pseudo-element or overlay approach
        // For now, just return the gradient
        return { background: cssGradient };
      }
      return { background: cssGradient };
    }
  }
  
  // Solid HSL color
  return { backgroundColor: `hsl(${colorAccent} / ${opacity})` };
};

/**
 * Get the primary color from accent (first color if gradient, or the color itself)
 */
export const getPrimaryAccentColor = (colorAccent: string | null | undefined): string => {
  if (!colorAccent) return 'hsl(var(--accent))';
  
  if (isGradient(colorAccent)) {
    const hsl = extractPrimaryFromGradient(colorAccent);
    if (hsl) return `hsl(${hsl})`;
  }
  
  return `hsl(${colorAccent})`;
};
