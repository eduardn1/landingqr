/**
 * Image compression utility for optimizing uploads
 */

export interface CompressionOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  mimeType?: 'image/jpeg' | 'image/webp' | 'image/png';
}

const defaultOptions: CompressionOptions = {
  maxWidth: 1200,
  maxHeight: 1200,
  quality: 0.8,
  mimeType: 'image/webp',
};

/**
 * Compress an image file
 */
export async function compressImage(
  file: File,
  options: CompressionOptions = {}
): Promise<File> {
  const opts = { ...defaultOptions, ...options };

  return new Promise((resolve, reject) => {
    // Skip compression for small files (< 100KB)
    if (file.size < 100 * 1024) {
      resolve(file);
      return;
    }

    const img = new Image();
    const reader = new FileReader();

    reader.onload = (e) => {
      img.src = e.target?.result as string;
    };

    img.onload = () => {
      const canvas = document.createElement('canvas');
      let { width, height } = img;

      // Calculate new dimensions
      if (width > opts.maxWidth! || height > opts.maxHeight!) {
        const ratio = Math.min(
          opts.maxWidth! / width,
          opts.maxHeight! / height
        );
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);
      }

      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }

      // Enable image smoothing for better quality
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';

      ctx.drawImage(img, 0, 0, width, height);

      canvas.toBlob(
        (blob) => {
          if (!blob) {
            reject(new Error('Could not compress image'));
            return;
          }

          // Generate filename with correct extension
          const ext = opts.mimeType === 'image/webp' ? 'webp' : 
                     opts.mimeType === 'image/png' ? 'png' : 'jpg';
          const baseName = file.name.replace(/\.[^/.]+$/, '');
          const newFileName = `${baseName}.${ext}`;

          const compressedFile = new File([blob], newFileName, {
            type: opts.mimeType,
            lastModified: Date.now(),
          });

          // Only use compressed if it's actually smaller
          if (compressedFile.size < file.size) {
            resolve(compressedFile);
          } else {
            resolve(file);
          }
        },
        opts.mimeType,
        opts.quality
      );
    };

    img.onerror = () => reject(new Error('Could not load image'));
    reader.onerror = () => reject(new Error('Could not read file'));

    reader.readAsDataURL(file);
  });
}

/**
 * Compress multiple images in parallel
 */
export async function compressImages(
  files: File[],
  options: CompressionOptions = {}
): Promise<File[]> {
  return Promise.all(files.map(file => compressImage(file, options)));
}

/**
 * Get compression stats
 */
export function getCompressionStats(original: File, compressed: File) {
  const savedBytes = original.size - compressed.size;
  const savedPercent = ((savedBytes / original.size) * 100).toFixed(1);
  
  return {
    originalSize: formatFileSize(original.size),
    compressedSize: formatFileSize(compressed.size),
    savedBytes: formatFileSize(savedBytes),
    savedPercent: `${savedPercent}%`,
    wasCompressed: compressed.size < original.size,
  };
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
