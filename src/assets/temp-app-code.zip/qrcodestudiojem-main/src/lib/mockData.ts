// Mock data for the restaurant menu system
// This simulates the database structure from the documentation

export interface Restaurant {
  id: string;
  slug: string;
  name: string;
  tagline: Record<string, string>;
  description: Record<string, string>;
  phone: string;
  email: string;
  website: string;
  address: {
    street: string;
    city: string;
    postalCode: string;
    country: string;
  };
  socialMedia: {
    instagram?: string;
    facebook?: string;
    tiktok?: string;
  };
  openingHours: Record<string, { open: string; close: string }>;
  primaryColor: string;
  accentColor: string;
  logoUrl: string;
  coverImageUrl: string;
  defaultLanguage: string;
  currency: string;
}

export interface Category {
  id: string;
  name: Record<string, string>;
  description: Record<string, string>;
  icon: string;
  imageUrl: string;
  displayOrder: number;
  isActive: boolean;
  isFeatured: boolean;
}

export interface Dish {
  id: string;
  categoryId: string;
  name: Record<string, string>;
  description: Record<string, string>;
  ingredients: Record<string, string>;
  images: string[];
  price: number;
  originalPrice?: number;
  currency: string;
  tags: string[];
  allergens: string[];
  spicyLevel?: number;
  portionSize?: string;
  isAvailable: boolean;
  isFeatured: boolean;
  isSeasonal: boolean;
  badge?: string;
  displayOrder: number;
}

export interface Allergen {
  code: string;
  name: Record<string, string>;
  icon: string;
  color: string;
}

// Restaurant Data
export const restaurant: Restaurant = {
  id: '1',
  slug: 'il-locale-studiojem',
  name: 'Il Locale by studiojem.it',
  tagline: {
    it: 'Sapori autentici della tradizione italiana',
    en: 'Authentic flavors of Italian tradition',
    fr: 'Saveurs authentiques de la tradition italienne',
    de: 'Authentische Aromen der italienischen Tradition',
    es: 'Sabores auténticos de la tradición italiana',
  },
  description: {
    it: 'Vi accogliamo con i sapori più autentici della cucina italiana. Ogni piatto racconta una storia di passione e tradizione.',
    en: 'We welcome you with the most authentic flavors of Italian cuisine. Every dish tells a story of passion and tradition.',
    fr: 'Nous vous accueillons avec les saveurs les plus authentiques de la cuisine italienne.',
    de: 'Wir begrüßen Sie mit den authentischsten Aromen der italienischen Küche.',
    es: 'Le damos la bienvenida con los sabores más auténticos de la cocina italiana.',
  },
  phone: '+39 081 123 4567',
  email: 'info@studiojem.it',
  website: 'www.studiojem.it',
  address: {
    street: 'Via Toledo, 123',
    city: 'Napoli',
    postalCode: '80134',
    country: 'Italia',
  },
  socialMedia: {
    instagram: '@illocale.studiojem',
    facebook: 'illocale.studiojem',
  },
  openingHours: {
    monday: { open: '12:00', close: '23:00' },
    tuesday: { open: '12:00', close: '23:00' },
    wednesday: { open: '12:00', close: '23:00' },
    thursday: { open: '12:00', close: '23:00' },
    friday: { open: '12:00', close: '00:00' },
    saturday: { open: '12:00', close: '00:00' },
    sunday: { open: '12:00', close: '22:00' },
  },
  primaryColor: '#722F37',
  accentColor: '#D4A84B',
  logoUrl: '',
  coverImageUrl: '',
  defaultLanguage: 'it',
  currency: 'EUR',
};

// Categories
export const categories: Category[] = [
  {
    id: '1',
    name: { it: 'Antipasti', en: 'Appetizers', fr: 'Entrées', de: 'Vorspeisen', es: 'Entrantes' },
    description: { it: 'Per iniziare il vostro viaggio culinario', en: 'To start your culinary journey' },
    icon: '🍽️',
    imageUrl: '',
    displayOrder: 1,
    isActive: true,
    isFeatured: true,
  },
  {
    id: '2',
    name: { it: 'Primi Piatti', en: 'First Courses', fr: 'Premiers Plats', de: 'Erste Gänge', es: 'Primeros Platos' },
    description: { it: 'Pasta fresca e risotti della tradizione', en: 'Fresh pasta and traditional risottos' },
    icon: '🍝',
    imageUrl: '',
    displayOrder: 2,
    isActive: true,
    isFeatured: true,
  },
  {
    id: '3',
    name: { it: 'Pizze', en: 'Pizzas', fr: 'Pizzas', de: 'Pizzen', es: 'Pizzas' },
    description: { it: 'Pizza napoletana cotta nel forno a legna', en: 'Neapolitan pizza baked in wood-fired oven' },
    icon: '🍕',
    imageUrl: '',
    displayOrder: 3,
    isActive: true,
    isFeatured: true,
  },
  {
    id: '4',
    name: { it: 'Secondi', en: 'Main Courses', fr: 'Plats Principaux', de: 'Hauptgerichte', es: 'Segundos' },
    description: { it: 'Carne e pesce preparati con maestria', en: 'Meat and fish prepared with mastery' },
    icon: '🥩',
    imageUrl: '',
    displayOrder: 4,
    isActive: true,
    isFeatured: false,
  },
  {
    id: '5',
    name: { it: 'Dolci', en: 'Desserts', fr: 'Desserts', de: 'Nachspeisen', es: 'Postres' },
    description: { it: 'Dolci della tradizione napoletana', en: 'Traditional Neapolitan desserts' },
    icon: '🍰',
    imageUrl: '',
    displayOrder: 5,
    isActive: true,
    isFeatured: true,
  },
  {
    id: '6',
    name: { it: 'Bevande', en: 'Drinks', fr: 'Boissons', de: 'Getränke', es: 'Bebidas' },
    description: { it: 'Vini selezionati e bevande', en: 'Selected wines and beverages' },
    icon: '🍷',
    imageUrl: '',
    displayOrder: 6,
    isActive: true,
    isFeatured: false,
  },
];

// Dishes
export const dishes: Dish[] = [
  // Antipasti
  {
    id: '1',
    categoryId: '1',
    name: { it: 'Bruschetta al Pomodoro', en: 'Tomato Bruschetta', fr: 'Bruschetta aux Tomates', de: 'Tomaten-Bruschetta', es: 'Bruschetta de Tomate' },
    description: { 
      it: 'Pane tostato con pomodori freschi, basilico, aglio e olio extravergine di oliva', 
      en: 'Toasted bread with fresh tomatoes, basil, garlic and extra virgin olive oil' 
    },
    ingredients: { it: 'Pane, pomodori, basilico, aglio, olio EVO, sale', en: 'Bread, tomatoes, basil, garlic, EVOO, salt' },
    images: ['/src/assets/dishes/bruschetta.jpg'],
    price: 8.50,
    currency: 'EUR',
    tags: ['vegetarian', 'vegan'],
    allergens: ['gluten'],
    isAvailable: true,
    isFeatured: true,
    isSeasonal: false,
    displayOrder: 1,
  },
  {
    id: '2',
    categoryId: '1',
    name: { it: 'Mozzarella di Bufala DOP', en: 'Buffalo Mozzarella DOP', fr: 'Mozzarella de Bufflonne DOP' },
    description: { 
      it: 'Mozzarella di bufala campana DOP con pomodorini e basilico fresco', 
      en: 'DOP Campania buffalo mozzarella with cherry tomatoes and fresh basil' 
    },
    ingredients: { it: 'Mozzarella di bufala, pomodorini, basilico, olio EVO' },
    images: ['/src/assets/dishes/mozzarella-bufala.jpg'],
    price: 14.00,
    currency: 'EUR',
    tags: ['vegetarian', 'gluten-free'],
    allergens: ['lactose'],
    isAvailable: true,
    isFeatured: true,
    isSeasonal: false,
    badge: 'DOP',
    displayOrder: 2,
  },
  {
    id: '3',
    categoryId: '1',
    name: { it: 'Frittura di Calamari', en: 'Fried Calamari', fr: 'Calamars Frits' },
    description: { 
      it: 'Calamari freschi in pastella croccante con maionese agli agrumi', 
      en: 'Fresh calamari in crispy batter with citrus mayo' 
    },
    ingredients: { it: 'Calamari, farina, limone, maionese, agrumi' },
    images: ['/src/assets/dishes/calamari-fritti.jpg'],
    price: 16.00,
    currency: 'EUR',
    tags: [],
    allergens: ['gluten', 'eggs', 'fish'],
    isAvailable: true,
    isFeatured: false,
    isSeasonal: false,
    displayOrder: 3,
  },
  // Primi Piatti
  {
    id: '4',
    categoryId: '2',
    name: { it: 'Spaghetti alla Carbonara', en: 'Carbonara Spaghetti', fr: 'Spaghetti Carbonara' },
    description: { 
      it: 'Spaghetti con guanciale croccante, tuorlo d\'uovo, pecorino romano e pepe nero', 
      en: 'Spaghetti with crispy guanciale, egg yolk, pecorino romano and black pepper' 
    },
    ingredients: { it: 'Spaghetti, guanciale, uova, pecorino romano, pepe nero' },
    images: ['/src/assets/dishes/carbonara.jpg'],
    price: 14.00,
    currency: 'EUR',
    tags: [],
    allergens: ['gluten', 'eggs', 'lactose'],
    isAvailable: true,
    isFeatured: true,
    isSeasonal: false,
    displayOrder: 1,
  },
  {
    id: '5',
    categoryId: '2',
    name: { it: 'Risotto ai Funghi Porcini', en: 'Porcini Mushroom Risotto', fr: 'Risotto aux Cèpes' },
    description: { 
      it: 'Risotto cremoso con funghi porcini freschi e tartufo nero', 
      en: 'Creamy risotto with fresh porcini mushrooms and black truffle' 
    },
    ingredients: { it: 'Riso carnaroli, funghi porcini, tartufo nero, parmigiano, burro' },
    images: ['/src/assets/dishes/risotto-porcini.jpg'],
    price: 22.00,
    currency: 'EUR',
    tags: ['vegetarian'],
    allergens: ['lactose'],
    isAvailable: true,
    isFeatured: true,
    isSeasonal: true,
    badge: 'Chef\'s Choice',
    displayOrder: 2,
  },
  {
    id: '6',
    categoryId: '2',
    name: { it: 'Paccheri allo Scoglio', en: 'Paccheri with Seafood', fr: 'Paccheri aux Fruits de Mer' },
    description: { 
      it: 'Paccheri con frutti di mare misti, pomodorini e prezzemolo', 
      en: 'Paccheri pasta with mixed seafood, cherry tomatoes and parsley' 
    },
    ingredients: { it: 'Paccheri, cozze, vongole, gamberi, pomodorini, prezzemolo, aglio' },
    images: ['/src/assets/dishes/paccheri-scoglio.jpg'],
    price: 24.00,
    currency: 'EUR',
    tags: [],
    allergens: ['gluten', 'shellfish', 'mollusks'],
    spicyLevel: 1,
    isAvailable: true,
    isFeatured: false,
    isSeasonal: false,
    displayOrder: 3,
  },
  // Pizze
  {
    id: '7',
    categoryId: '3',
    name: { it: 'Margherita', en: 'Margherita', fr: 'Margherita' },
    description: { 
      it: 'La classica pizza napoletana con pomodoro San Marzano, mozzarella di bufala e basilico', 
      en: 'The classic Neapolitan pizza with San Marzano tomatoes, buffalo mozzarella and basil' 
    },
    ingredients: { it: 'Farina, pomodoro San Marzano, mozzarella di bufala, basilico, olio EVO' },
    images: ['/src/assets/dishes/margherita.jpg'],
    price: 12.00,
    currency: 'EUR',
    tags: ['vegetarian'],
    allergens: ['gluten', 'lactose'],
    isAvailable: true,
    isFeatured: true,
    isSeasonal: false,
    displayOrder: 1,
  },
  {
    id: '8',
    categoryId: '3',
    name: { it: 'Diavola', en: 'Diavola', fr: 'Diavola' },
    description: { 
      it: 'Pizza con salame piccante, mozzarella e peperoncino fresco', 
      en: 'Pizza with spicy salami, mozzarella and fresh chili' 
    },
    ingredients: { it: 'Farina, pomodoro, mozzarella, salame piccante, peperoncino' },
    images: ['/src/assets/dishes/diavola.jpg'],
    price: 14.00,
    currency: 'EUR',
    tags: [],
    allergens: ['gluten', 'lactose'],
    spicyLevel: 3,
    isAvailable: true,
    isFeatured: false,
    isSeasonal: false,
    displayOrder: 2,
  },
  {
    id: '9',
    categoryId: '3',
    name: { it: 'Quattro Formaggi', en: 'Four Cheese', fr: 'Quatre Fromages' },
    description: { 
      it: 'Mozzarella, gorgonzola, fontina e parmigiano reggiano', 
      en: 'Mozzarella, gorgonzola, fontina and parmigiano reggiano' 
    },
    ingredients: { it: 'Farina, mozzarella, gorgonzola, fontina, parmigiano' },
    images: ['/src/assets/dishes/quattro-formaggi.jpg'],
    price: 15.00,
    currency: 'EUR',
    tags: ['vegetarian'],
    allergens: ['gluten', 'lactose'],
    isAvailable: true,
    isFeatured: false,
    isSeasonal: false,
    displayOrder: 3,
  },
  // Secondi
  {
    id: '10',
    categoryId: '4',
    name: { it: 'Branzino al Forno', en: 'Baked Sea Bass', fr: 'Bar au Four' },
    description: { 
      it: 'Branzino intero al forno con patate, olive e capperi', 
      en: 'Whole baked sea bass with potatoes, olives and capers' 
    },
    ingredients: { it: 'Branzino, patate, olive, capperi, limone, prezzemolo' },
    images: ['/src/assets/dishes/branzino.jpg'],
    price: 28.00,
    currency: 'EUR',
    tags: ['gluten-free'],
    allergens: ['fish'],
    isAvailable: true,
    isFeatured: true,
    isSeasonal: false,
    displayOrder: 1,
  },
  {
    id: '11',
    categoryId: '4',
    name: { it: 'Tagliata di Manzo', en: 'Sliced Beef Steak', fr: 'Tagliata de Bœuf' },
    description: { 
      it: 'Controfiletto di manzo alla griglia con rucola e scaglie di parmigiano', 
      en: 'Grilled sirloin with arugula and parmesan shavings' 
    },
    ingredients: { it: 'Manzo, rucola, parmigiano, olio EVO, sale, pepe' },
    images: ['/src/assets/dishes/tagliata.jpg'],
    price: 32.00,
    currency: 'EUR',
    tags: ['gluten-free'],
    allergens: ['lactose'],
    isAvailable: true,
    isFeatured: true,
    isSeasonal: false,
    badge: 'Premium',
    displayOrder: 2,
  },
  // Dolci
  {
    id: '12',
    categoryId: '5',
    name: { it: 'Tiramisù', en: 'Tiramisu', fr: 'Tiramisu' },
    description: { 
      it: 'Il classico dolce italiano con mascarpone, caffè e savoiardi', 
      en: 'The classic Italian dessert with mascarpone, coffee and ladyfingers' 
    },
    ingredients: { it: 'Mascarpone, uova, caffè, savoiardi, cacao' },
    images: ['/src/assets/dishes/tiramisu.jpg'],
    price: 8.00,
    currency: 'EUR',
    tags: ['vegetarian'],
    allergens: ['gluten', 'eggs', 'lactose'],
    isAvailable: true,
    isFeatured: true,
    isSeasonal: false,
    displayOrder: 1,
  },
  {
    id: '13',
    categoryId: '5',
    name: { it: 'Babà al Rum', en: 'Rum Baba', fr: 'Baba au Rhum' },
    description: { 
      it: 'Soffice babà napoletano imbevuto nel rum con panna montata', 
      en: 'Soft Neapolitan baba soaked in rum with whipped cream' 
    },
    ingredients: { it: 'Farina, uova, burro, rum, panna' },
    images: ['/src/assets/dishes/baba.jpg'],
    price: 9.00,
    currency: 'EUR',
    tags: ['vegetarian'],
    allergens: ['gluten', 'eggs', 'lactose'],
    isAvailable: true,
    isFeatured: true,
    isSeasonal: false,
    badge: 'Tipico',
    displayOrder: 2,
  },
  {
    id: '14',
    categoryId: '5',
    name: { it: 'Panna Cotta ai Frutti di Bosco', en: 'Berry Panna Cotta', fr: 'Panna Cotta aux Fruits des Bois' },
    description: { 
      it: 'Delicata panna cotta con coulis di frutti di bosco freschi', 
      en: 'Delicate panna cotta with fresh berry coulis' 
    },
    ingredients: { it: 'Panna, zucchero, gelatina, frutti di bosco' },
    images: ['/src/assets/dishes/panna-cotta.jpg'],
    price: 7.50,
    currency: 'EUR',
    tags: ['vegetarian', 'gluten-free'],
    allergens: ['lactose'],
    isAvailable: true,
    isFeatured: false,
    isSeasonal: true,
    displayOrder: 3,
  },
  // Bevande
  {
    id: '15',
    categoryId: '6',
    name: { it: 'Acqua Minerale', en: 'Mineral Water', fr: 'Eau Minérale' },
    description: { it: 'Naturale o frizzante (75cl)', en: 'Still or sparkling (75cl)' },
    ingredients: {},
    images: [],
    price: 3.50,
    currency: 'EUR',
    tags: ['vegan', 'gluten-free'],
    allergens: [],
    isAvailable: true,
    isFeatured: false,
    isSeasonal: false,
    displayOrder: 1,
  },
  {
    id: '16',
    categoryId: '6',
    name: { it: 'Chianti Classico DOCG', en: 'Chianti Classico DOCG', fr: 'Chianti Classico DOCG' },
    description: { 
      it: 'Vino rosso toscano, calice o bottiglia', 
      en: 'Tuscan red wine, glass or bottle' 
    },
    ingredients: {},
    images: [],
    price: 8.00,
    originalPrice: 35.00,
    currency: 'EUR',
    tags: ['vegan', 'gluten-free'],
    allergens: ['sulfites'],
    portionSize: 'Calice / Glass',
    isAvailable: true,
    isFeatured: true,
    isSeasonal: false,
    displayOrder: 2,
  },
];

// Allergens data
export const allergens: Allergen[] = [
  { code: 'gluten', name: { it: 'Glutine', en: 'Gluten', fr: 'Gluten', de: 'Gluten', es: 'Gluten' }, icon: '🌾', color: '#ef4444' },
  { code: 'lactose', name: { it: 'Lattosio', en: 'Lactose', fr: 'Lactose', de: 'Laktose', es: 'Lactosa' }, icon: '🥛', color: '#3b82f6' },
  { code: 'eggs', name: { it: 'Uova', en: 'Eggs', fr: 'Œufs', de: 'Eier', es: 'Huevos' }, icon: '🥚', color: '#f59e0b' },
  { code: 'fish', name: { it: 'Pesce', en: 'Fish', fr: 'Poisson', de: 'Fisch', es: 'Pescado' }, icon: '🐟', color: '#06b6d4' },
  { code: 'shellfish', name: { it: 'Crostacei', en: 'Shellfish', fr: 'Crustacés', de: 'Schalentiere', es: 'Mariscos' }, icon: '🦐', color: '#ec4899' },
  { code: 'nuts', name: { it: 'Frutta a guscio', en: 'Tree nuts', fr: 'Fruits à coque', de: 'Schalenfrüchte', es: 'Frutos secos' }, icon: '🌰', color: '#84cc16' },
  { code: 'peanuts', name: { it: 'Arachidi', en: 'Peanuts', fr: 'Arachides', de: 'Erdnüsse', es: 'Cacahuetes' }, icon: '🥜', color: '#a855f7' },
  { code: 'soy', name: { it: 'Soia', en: 'Soy', fr: 'Soja', de: 'Soja', es: 'Soja' }, icon: '🫘', color: '#22c55e' },
  { code: 'sulfites', name: { it: 'Solfiti', en: 'Sulfites', fr: 'Sulfites', de: 'Sulfite', es: 'Sulfitos' }, icon: '🍷', color: '#6366f1' },
  { code: 'mollusks', name: { it: 'Molluschi', en: 'Mollusks', fr: 'Mollusques', de: 'Weichtiere', es: 'Moluscos' }, icon: '🦑', color: '#0ea5e9' },
];

// Diet types
export const dietTypes = [
  { code: 'vegetarian', name: { it: 'Vegetariano', en: 'Vegetarian', fr: 'Végétarien', de: 'Vegetarisch', es: 'Vegetariano' }, icon: '🥬', color: '#22c55e' },
  { code: 'vegan', name: { it: 'Vegano', en: 'Vegan', fr: 'Végétalien', de: 'Vegan', es: 'Vegano' }, icon: '🌱', color: '#16a34a' },
  { code: 'gluten-free', name: { it: 'Senza Glutine', en: 'Gluten Free', fr: 'Sans Gluten', de: 'Glutenfrei', es: 'Sin Gluten' }, icon: '🌾', color: '#f59e0b' },
  { code: 'lactose-free', name: { it: 'Senza Lattosio', en: 'Lactose Free', fr: 'Sans Lactose', de: 'Laktosefrei', es: 'Sin Lactosa' }, icon: '🥛', color: '#3b82f6' },
];
