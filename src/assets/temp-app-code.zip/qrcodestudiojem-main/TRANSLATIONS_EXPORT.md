# Translation Export for Multi-Language Support

This file contains all translatable content that needs to be translated into German (de), Spanish (es), and French (fr).

## Instructions for Claude.ai
Please translate all the Italian (it) and English (en) text below into:
- German (de)
- Spanish (es)  
- French (fr)

Return the translations in JSON format that can be imported back.

---

## UI Translations (src/lib/i18n.ts)

These are already partially translated. Please complete any missing translations:

```json
{
  "de": {
    "profile": "Profil",
    "reservations": "Reservierungen",
    "notifications": "Benachrichtigungen",
    "loyalty": "Treueprogramm",
    "points": "Punkte",
    "rewards": "Prämien",
    "tier": "Stufe",
    "bronze": "Bronze",
    "silver": "Silber",
    "gold": "Gold",
    "platinum": "Platin",
    "yourPoints": "Ihre Punkte",
    "nextTier": "Nächste Stufe",
    "pointsNeeded": "benötigte Punkte",
    "availableRewards": "Verfügbare Prämien",
    "noRewards": "Sammeln Sie Punkte um Prämien freizuschalten!",
    "upcoming": "Bevorstehend",
    "confirmed": "Bestätigt",
    "cancelled": "Storniert",
    "pending": "Ausstehend",
    "completed": "Abgeschlossen",
    "rejected": "Abgelehnt",
    "login": "Anmelden",
    "logout": "Abmelden",
    "save": "Speichern",
    "cancel": "Abbrechen",
    "delete": "Löschen",
    "edit": "Bearbeiten",
    "close": "Schließen",
    "back": "Zurück",
    "next": "Weiter",
    "skip": "Überspringen",
    "goToMenu": "Zum Menü",
    "personalInfo": "Persönliche Daten",
    "name": "Name",
    "phone": "Telefon",
    "pushNotifications": "Push-Benachrichtigungen",
    "whatsappNotifications": "WhatsApp-Benachrichtigungen",
    "language": "Sprache",
    "favorites": "Favoriten",
    "cache": "Cache",
    "clearCache": "Cache leeren",
    "refreshMenu": "Menü aktualisieren",
    "clearImages": "Bilder löschen",
    "quizPreferences": "Quiz-Präferenzen",
    "redoQuiz": "Quiz wiederholen",
    "noOnboarding": "Machen Sie das Quiz für personalisierte Empfehlungen",
    "loginRequired": "Melden Sie sich an, um Ihre Präferenzen zu speichern",
    "profileUpdated": "Profil aktualisiert!",
    "errorSaving": "Fehler beim Speichern",
    "cacheCleared": "Cache gelöscht!",
    "menuRefreshed": "Menü aktualisiert!",
    "loggedOut": "Abgemeldet",
    "manageAccount": "Verwalten Sie Ihr Konto hier",
    "noReservations": "Keine Reservierungen",
    "person": "Person",
    "persons": "Personen"
  },
  "es": {
    "profile": "Perfil",
    "reservations": "Reservas",
    "notifications": "Notificaciones",
    "loyalty": "Programa de fidelidad",
    "points": "Puntos",
    "rewards": "Recompensas",
    "tier": "Nivel",
    "bronze": "Bronce",
    "silver": "Plata",
    "gold": "Oro",
    "platinum": "Platino",
    "yourPoints": "Tus puntos",
    "nextTier": "Próximo nivel",
    "pointsNeeded": "puntos necesarios",
    "availableRewards": "Recompensas disponibles",
    "noRewards": "¡Acumula puntos para desbloquear recompensas!",
    "upcoming": "Próximas",
    "confirmed": "Confirmada",
    "cancelled": "Cancelada",
    "pending": "Pendiente",
    "completed": "Completada",
    "rejected": "Rechazada",
    "login": "Iniciar sesión",
    "logout": "Cerrar sesión",
    "save": "Guardar",
    "cancel": "Cancelar",
    "delete": "Eliminar",
    "edit": "Editar",
    "close": "Cerrar",
    "back": "Atrás",
    "next": "Siguiente",
    "skip": "Omitir",
    "goToMenu": "Ir al menú",
    "personalInfo": "Datos personales",
    "name": "Nombre",
    "phone": "Teléfono",
    "pushNotifications": "Notificaciones push",
    "whatsappNotifications": "Notificaciones WhatsApp",
    "language": "Idioma",
    "favorites": "Favoritos",
    "cache": "Caché",
    "clearCache": "Limpiar caché",
    "refreshMenu": "Actualizar menú",
    "clearImages": "Borrar imágenes",
    "quizPreferences": "Preferencias del quiz",
    "redoQuiz": "Repetir quiz",
    "noOnboarding": "Haz el quiz para recibir recomendaciones personalizadas",
    "loginRequired": "Inicia sesión para guardar tus preferencias",
    "profileUpdated": "¡Perfil actualizado!",
    "errorSaving": "Error al guardar",
    "cacheCleared": "¡Caché limpiada!",
    "menuRefreshed": "¡Menú actualizado!",
    "loggedOut": "Sesión cerrada",
    "manageAccount": "Gestiona tu cuenta aquí",
    "noReservations": "Sin reservas",
    "person": "persona",
    "persons": "personas"
  },
  "fr": {
    "profile": "Profil",
    "reservations": "Réservations",
    "notifications": "Notifications",
    "loyalty": "Programme de fidélité",
    "points": "Points",
    "rewards": "Récompenses",
    "tier": "Niveau",
    "bronze": "Bronze",
    "silver": "Argent",
    "gold": "Or",
    "platinum": "Platine",
    "yourPoints": "Vos points",
    "nextTier": "Prochain niveau",
    "pointsNeeded": "points nécessaires",
    "availableRewards": "Récompenses disponibles",
    "noRewards": "Accumulez des points pour débloquer des récompenses !",
    "upcoming": "À venir",
    "confirmed": "Confirmée",
    "cancelled": "Annulée",
    "pending": "En attente",
    "completed": "Terminée",
    "rejected": "Refusée",
    "login": "Connexion",
    "logout": "Déconnexion",
    "save": "Enregistrer",
    "cancel": "Annuler",
    "delete": "Supprimer",
    "edit": "Modifier",
    "close": "Fermer",
    "back": "Retour",
    "next": "Suivant",
    "skip": "Passer",
    "goToMenu": "Aller au menu",
    "personalInfo": "Informations personnelles",
    "name": "Nom",
    "phone": "Téléphone",
    "pushNotifications": "Notifications push",
    "whatsappNotifications": "Notifications WhatsApp",
    "language": "Langue",
    "favorites": "Favoris",
    "cache": "Cache",
    "clearCache": "Vider le cache",
    "refreshMenu": "Actualiser le menu",
    "clearImages": "Supprimer les images",
    "quizPreferences": "Préférences du quiz",
    "redoQuiz": "Refaire le quiz",
    "noOnboarding": "Faites le quiz pour des recommandations personnalisées",
    "loginRequired": "Connectez-vous pour enregistrer vos préférences",
    "profileUpdated": "Profil mis à jour !",
    "errorSaving": "Erreur lors de la sauvegarde",
    "cacheCleared": "Cache vidé !",
    "menuRefreshed": "Menu actualisé !",
    "loggedOut": "Déconnecté",
    "manageAccount": "Gérez votre compte ici",
    "noReservations": "Aucune réservation",
    "person": "personne",
    "persons": "personnes"
  }
}
```

---

## Database Content to Translate

The following content is stored in the database and needs translations added for de, es, fr fields:

### Categories (categories table)
- name_it, name_en → need name_de, name_es, name_fr
- description_it, description_en → need description_de, description_es, description_fr

### Dishes (dishes table)
- name_it, name_en → need name_de, name_es, name_fr
- description_it, description_en → need description_de, description_es, description_fr
- ingredients_it, ingredients_en → need ingredients_de, ingredients_es, ingredients_fr

### Events (events table)
- title_it, title_en → need title_de, title_es, title_fr
- description_it, description_en → need description_de, description_es, description_fr

### Promos (promos table)
- title_it, title_en → need title_de, title_es, title_fr
- description_it, description_en → need description_de, description_es, description_fr

### Loyalty Rewards (loyalty_rewards table)
- name_it, name_en → need name_de, name_es, name_fr
- description_it, description_en → need description_de, description_es, description_fr

---

## JSONB Fields Needing Translation

These fields use JSONB format with {it: "", en: ""} structure:

### Action Buttons (action_buttons table)
- label: {it: "...", en: "..."} → add de, es, fr
- subtitle: {it: "...", en: "..."} → add de, es, fr

### Stories (stories table)  
- label: {it: "...", en: "..."} → add de, es, fr

### Moods (moods table)
- label: {it: "...", en: "..."} → add de, es, fr

### Onboarding Steps (onboarding_steps table)
- question: {it: "...", en: "..."} → add de, es, fr
- subtext: {it: "...", en: "..."} → add de, es, fr
- tip: {it: "...", en: "..."} → add de, es, fr
- options[].label: {it: "...", en: "..."} → add de, es, fr

### Home Sections (home_sections table)
- title: {it: "...", en: "..."} → add de, es, fr
- subtitle: {it: "...", en: "..."} → add de, es, fr

### Restaurant Config (restaurant_config table)
- tagline: {it: "...", en: "..."} → add de, es, fr
- description: {it: "...", en: "..."} → add de, es, fr

---

## After Translation

Once you receive the translations from Claude.ai:

1. The UI translations go into `src/lib/i18n.ts` in the `translations` object
2. Database content requires SQL UPDATE statements or admin panel updates
3. Enable the additional languages in `navigation_config.available_languages`

To activate the languages, update the navigation_config table:
```sql
UPDATE navigation_config 
SET available_languages = '[
  {"code": "it", "flag": "🇮🇹", "label": "Italiano", "visible": true},
  {"code": "en", "flag": "🇬🇧", "label": "English", "visible": true},
  {"code": "de", "flag": "🇩🇪", "label": "Deutsch", "visible": true},
  {"code": "es", "flag": "🇪🇸", "label": "Español", "visible": true},
  {"code": "fr", "flag": "🇫🇷", "label": "Français", "visible": true}
]';
```
